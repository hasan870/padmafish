# MotsyoMela — Installation Guide

**Release:** 1.0.0 · **Target host:** Hostinger shared hosting (also works on cPanel/Apache + LiteSpeed)
**Application:** Laravel 13 storefront and admin panel for a fresh-fish shop
**Installer:** browser-based, no SSH or Composer required on the server

This guide takes you from an empty Hostinger domain to a working store with an administrator account. The whole
process usually takes 10–15 minutes, plus about 2 minutes for the installer itself.

---

## 1. What is in the ZIP

```
MotsyoMela-installer-v1.0.0.zip
├── public_html/            → the public web root (front controller, installer, assets)
│   ├── index.php
│   ├── .htaccess
│   ├── favicon.ico
│   ├── robots.txt
│   └── install/            → the setup wizard (deleted after installation)
├── motsyomela/             → the Laravel application, kept OUTSIDE the web root
│   ├── app/  bootstrap/  config/  database/  resources/  routes/
│   ├── storage/            → logs, sessions, invoice fonts, uploaded images
│   ├── vendor/             → Composer dependencies, pre-installed
│   ├── artisan
│   └── .htaccess           → blocks direct access if this folder ends up under public_html
├── INSTALL.md              → this file
└── README.md               → quick overview
```

**Why two folders?** Only `public_html` is reachable from the internet. The application, `.env` secrets, database
credentials and uploaded files stay in `motsyomela/`, one level above it. Do not rename either folder during a normal
installation — the front controller looks for `../motsyomela` and `./motsyomela`.

The ZIP already contains `vendor/`, so the server does **not** need Composer, Node.js or a build step. The storefront
loads Tailwind CSS, Font Awesome, Google Fonts and demo product images from public CDNs, so visitors only need normal
internet access.

---

## 2. Server requirements

| Requirement | Notes |
|---|---|
| PHP **8.3 or newer** (8.4 recommended) | Hostinger supports both. Select it before installing. |
| MySQL 8.0+ / MariaDB 10.6+ | Hostinger creates the database and user in hPanel. |
| PHP extensions | `pdo_mysql`, `mbstring`, `openssl`, `tokenizer`, `dom`, `curl`, `fileinfo`, `json`, `ctype`, `session`, `filter`, `hash`, `pcre` |
| Optional but recommended | `gd`, `intl`, `zip`, `bcmath` |
| Writable folders | `motsyomela/storage/**`, `motsyomela/bootstrap/cache`, `motsyomela` (for `.env`), `public_html` (for the `storage` link and installer lock) |
| HTTPS | Strongly recommended; enable the free SSL certificate before you install. |
| Symbolic links | Needed to serve uploaded product images at `/storage`. Hostinger supports them. |

The installer checks every item on its first screen and creates missing runtime folders automatically. It cannot install
PHP extensions — if one is missing, enable it in **hPanel → Advanced → PHP Configuration** (or ask Hostinger support).

---

## 3. Prepare the domain in Hostinger (5 minutes)

1. Sign in to **hPanel** and open **Websites → Manage** for the domain.
2. **Enable SSL.** Open **Security → SSL** and activate the free certificate. Wait until it shows as active.
   Installing over HTTPS avoids mixed-content and cookie problems later.
3. **Select PHP 8.3 or 8.4.** Open **Advanced → PHP Configuration** and choose PHP 8.3+.
   While you are there, confirm `memory_limit` is at least 128 MB and `upload_max_filesize` at least 8 MB.
   Hostinger's defaults normally satisfy both.
4. **Create the database.** Open **Databases → MySQL Databases**:
   - Create a database, for example `motsyomela`.
   - Create a database user with a strong password.
   - Attach the user to the database with **All privileges**.
   - Copy the **full** names shown by hPanel. They are prefixed with your account ID, e.g.
     database `u123456_motsyomela`, user `u123456_motsyomela`, host `localhost`.
5. Keep the database name, username, password and host ready for the installer.

> **Do not** use your Hostinger account password as the database password. Create a dedicated MySQL user.

---

## 4. Upload and extract the ZIP

The ZIP must be extracted **one level above `public_html`**, into the domain folder.

1. Open **hPanel → Files → File Manager**.
2. Navigate to:

   ```
   /home/uXXXXXXXX/domains/yourdomain.com/
   ```

   This folder contains `public_html` and `logs`. If you use the primary domain, the path may be
   `/home/uXXXXXXXX/` with `public_html` directly inside it.
3. Back up or remove the default files in `public_html` (Hostinger's placeholder `default.php`, old `index.html`,
   etc.). Keeping them is harmless but the old `index.php` would win over the new one.
   Do **not** delete `public_html` if another website depends on it.
4. Upload `MotsyoMela-installer-v1.0.0.zip` **into this domain folder** (not inside `public_html`).
   If File Manager rejects the upload because of its size, upload it over SFTP/FTP (FileZilla) and return to
   File Manager to extract it.
5. Right-click the ZIP → **Extract**. Extract into the current folder (the domain folder).
6. You should now see:

   ```
   domains/yourdomain.com/
   ├── public_html/        ← new index.php, .htaccess, install/
   ├── motsyomela/         ← application + vendor
   ├── INSTALL.md
   └── README.md
   ```

7. Check **public_html** contains `index.php`, `.htaccess`, `install/`. Enable **Show hidden files** in File Manager
   to see `.htaccess`.
8. Permissions (only if the installer reports a problem): folders `755`, `motsyomela/storage` and
   `motsyomela/bootstrap/cache` `775`. Hostinger's extractor normally sets these correctly.

### If the ZIP was extracted in the wrong place

- **Inside `public_html`** you will get `public_html/public_html/` and `public_html/motsyomela/`.
  Move the contents of the inner `public_html` folder up one level, delete the empty inner folder, and keep
  `motsyomela` inside `public_html` (the app's `.htaccess` protects it) — or, preferably, move `motsyomela`
  one level up next to `public_html`.
- If you renamed the application folder, edit `public_html/index.php` and add the correct path to the
  `$candidates` list, or set `MOTSYOMELA_APP_PATH` through `.htaccess`.

The installer shows the folders it detected on its first screen, so a wrong layout is visible immediately.

---

## 5. Run the installer

Open:

```
https://yourdomain.com/install/
```

If you see a 404, make sure `public_html/install/index.php` exists and the domain is pointing at this `public_html`.

### Step 1 — Server requirements

The installer checks PHP, extensions, file permissions and the application layout; it also creates missing
`storage` / `bootstrap/cache` folders. Optional items (GD, Intl, ZIP, BCMath, memory limit, symlinks) are amber:
they do not block installation, but enabling them is recommended. Fix red items by changing the PHP version or
folder permissions, then press **Check again**.

### Step 2 — Database

Fill in the values from hPanel:

| Field | Typical Hostinger value |
|---|---|
| MySQL host | `localhost` (use `127.0.0.1` only if your host requires it) |
| Port | `3306` |
| Database name | `u123456_motsyomela` (copy it exactly) |
| MySQL username | `u123456_motsyomela` |
| MySQL password | the database user's password |
| Create database automatically | leave ticked; it is ignored when the database already exists |

The connection is tested before anything is written. If the database already contains tables you are shown a
confirmation screen and nothing is changed until you confirm. If automatic creation is not permitted, create the
database in hPanel and run the step again.

### Step 3 — Store and administrator

- **Store name** — shown in the header, page titles and invoices. Bangla or English is fine.
- **Public site URL** — the final HTTPS address, e.g. `https://yourdomain.com`, without a trailing slash.
  This is written to `APP_URL`. Use the final domain (not a temporary preview URL).
- **Administrator name, email and password** — this is the account for `https://yourdomain.com/admin`.
  Passwords are stored hashed and cannot be recovered by the installer.
- **Install demo data** — ticked by default. It adds 6 categories, 10 fish products with sizes and photos,
  2 coupons, 2 combo packs, sample FAQs, reviews and an announcement. Untick for an empty catalogue.

Press **Install MotsyoMela** and keep the tab open. The installer:

1. writes `.env` with a fresh `APP_KEY` (outside the web root),
2. runs all database migrations,
3. installs default settings, Bangla/English translations, menu links, policy pages, delivery zones and time slots,
4. optionally installs the demo catalogue and content,
5. creates your super-admin account and links `public_html/storage` to `motsyomela/storage/app/public`,
6. writes `storage/app/installed.lock` so the installer cannot run again.

### Step 4 — Finish

The success page shows the storefront and admin links, installed counts and any warnings. The most common warning is
the missing `storage` symlink (see Troubleshooting).

Complete the checklist on that page, then **Delete installer folder** — or delete `public_html/install` manually in
File Manager. This is the most important security step. The store keeps working without the installer.

---

## 6. After installation — first hour checklist

1. **Sign in** at `https://yourdomain.com/admin` with the administrator email and password you chose.
2. **Payments** — open **Payments**. Cash on delivery is enabled. Add your bKash and Nagad numbers, account type
   (personal/agent/merchant), instructions and, if you have one, a payment link. Disable methods you do not use.
3. **Email** — open **Mail settings**. The default driver is `log`, which writes messages to
   `motsyomela/storage/logs/laravel.log` instead of sending them. To send real order confirmations:
   - Driver: **SMTP**
   - Host: `smtp.hostinger.com` (confirm in hPanel → Emails)
   - Port: `465` with SSL, or `587` with TLS
   - Username: the full mailbox address, Password: that mailbox's password
   - From address: the same mailbox
   - Enter an admin notification address, save, and use **Send test**.
4. **Store settings** — update hotline, WhatsApp number, delivery hours and address under **Site settings**.
   Review **Delivery zones** and **Time slots**; the defaults are Dhaka-focused examples.
5. **Products** — replace demo products, prices, stock and images, or delete them and add your own.
6. **Theme and content** — adjust colours, logo, hero promo, banners, FAQs, reviews, menu and footer under the
   corresponding admin pages.
7. **Place a test order** from the storefront, then check it in **Admin → Orders**, print/download the invoice PDF,
   and confirm the success screen appears on a phone.
8. **Backups** — enable Hostinger backups. The store lives in MySQL plus `motsyomela/storage/app/public` (uploads)
   and `.env` (configuration). Back up all three.

---

## 7. Verify the installation

| Check | Expected |
|---|---|
| `https://yourdomain.com/` | Storefront loads with fish products (or an empty catalogue message if demo data was skipped) |
| `https://yourdomain.com/admin` | Login page, then dashboard after signing in |
| `https://yourdomain.com/install/` | “Installation locked” (after the folder is deleted: 404 — also fine) |
| Add an image in Admin → Products | Image uploads and is visible on the storefront (`/storage/...`) |
| Admin → Orders → invoice | Bangla invoice PDF downloads |
| Language switch | Bangla ⇄ English works in the header |
| `motsyomela/.env` via browser | 403 / not found — it must never be readable |

---

## 8. Troubleshooting

### HTTP 500 on every page
- Open `motsyomela/storage/logs/laravel.log` for the actual error.
- Check PHP is 8.3+ in hPanel and that `motsyomela/storage` and `motsyomela/bootstrap/cache` are writable (775).
- If the error mentions a missing `APP_KEY`, the installer did not finish writing `.env`; re-run it or add a key
  manually with `php artisan key:generate` over SSH.

### “Application files not found” instead of the store
`public_html/index.php` could not find `motsyomela/vendor/autoload.php`. Confirm the application folder sits next to
`public_html` (recommended) or directly inside it as `motsyomela`. Do not rename `vendor`.

### The installer shows “Installation locked”
This copy is already installed. Delete `public_html/install` and use the store. To intentionally reinstall,
remove `motsyomela/.env` and `motsyomela/storage/app/installed.lock` **only on a fresh copy** — a reinstall resets the
administrator account and can overwrite settings.

### Database connection refused or access denied
- Host is usually `localhost`, port `3306`.
- Names and usernames are prefixed (`u123456_...`) and must be copied exactly.
- The user must be attached to the database in hPanel with all privileges.
- If the database does not exist and the installer cannot create it, create it in hPanel first.

### Uploaded images return 404
The `public_html/storage` link is missing. Over SSH run:

```bash
cd ~/domains/yourdomain.com/motsyomela
php artisan storage:link
```

Without SSH, enable **Terminal** in hPanel if your plan includes it, or ask Hostinger support to create a symlink from
`public_html/storage` to `motsyomela/storage/app/public`. Some hosts disable PHP's `symlink()` function; in that case
the link must be created by support or by uploading images to a real folder.

### Order emails are not arriving
Mail uses the `log` driver by default. Configure SMTP in **Admin → Mail settings**, enable notifications and send a
test. Check `motsyomela/storage/logs/laravel.log` if the test fails.

### Blank page / “Too many redirects” after enabling SSL
Edit `APP_URL` in `motsyomela/.env` to the exact HTTPS URL, and make sure `SESSION_SECURE_COOKIE` is not `true` while
you are still testing over HTTP. Clear caches by deleting the `*.php` files inside `motsyomela/bootstrap/cache`.

### Fonts or icons look broken
The storefront loads Tailwind, Font Awesome, Google Fonts and demo images from public CDNs. A visitor without internet
access, or a network that blocks those domains, will see unstyled content. Replace them with local assets if you need
an offline/intranet deployment.

### Re-running the installer after a failed attempt
That is safe: migrations and seeders are idempotent. Submit the same database details again; the installer reuses the
existing `APP_KEY`. The installation only locks after it completes successfully.

### The installer cannot delete its own folder
On some servers the running script holds a file lock. Delete `public_html/install` manually in File Manager. The lock
file in `motsyomela/storage/app/installed.lock` still prevents a second installation.

### Permissions cheat sheet
```text
motsyomela/                        755 (775 while installing)
motsyomela/.env                    600
motsyomela/storage/**              775
motsyomela/bootstrap/cache/**      775
public_html/                       755
public_html/install/               755 (delete after installation)
```

---

## 9. Security notes

- Delete `public_html/install` after installation. The lock file protects you, but there is no reason to keep the
  wizard online.
- Keep `motsyomela` outside `public_html`. If it must live inside, the included `.htaccess` denies direct access —
  confirm by opening `https://yourdomain.com/motsyomela/.env` (it must not download).
- Use HTTPS. Set `APP_URL` to the final HTTPS address.
- Use a strong, unique administrator password and do not share the admin account.
- Never send `.env` contents, database passwords or admin passwords in support messages.
- Enable Hostinger backups and test a restore once.
- Super-admin accounts can add other admins at **Admin → Admin users**. Give staff the lowest role they need.

---

## 10. Manual installation (developers, optional)

The ZIP is ready to run; this section is only for installing from the source repository.

```bash
composer install --no-dev --optimize-autoloader
cp .env.example .env
php artisan key:generate
# set DB_DATABASE, DB_USERNAME, DB_PASSWORD, APP_URL in .env
php artisan migrate --force
php artisan db:seed --force          # includes demo data and the default admin
php artisan storage:link
```

Change the seeded administrator (`admin@motsyomela.local` / `ChangeMe123!`) immediately, or create your own super-admin
and delete the seed account. For a production build without demo data, run the installer instead — it lets you choose.

### Rebuilding the release ZIP

From the repository root:

```bash
php -d extension=zip tools/build-installer.php
```

Optional flags: `--no-zip` (stage only), `--composer=/path/to/composer.phar` (install a production-only vendor),
`--keep-build` (do not delete the staging folder). The ZIP and its SHA-256 checksum are written to `dist/`.

---

## 11. What the installer cannot do for you

- Enable a PHP extension, change the PHP version or create a hosting account.
- Configure DNS, SSL or email mailboxes.
- Enter your payment gateway credentials or SMTP password for you — do that in the admin panel.
- Recover an administrator password (it is hashed). Use another super-admin or reset it over SSH with `php artisan tinker`.

If something fails, note the exact message, the PHP version and the last lines of `storage/logs/laravel.log`, then
contact your developer or Hostinger support. Never paste database or admin passwords.
