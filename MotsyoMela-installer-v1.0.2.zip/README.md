# MotsyoMela — Hostinger installer package

A ready-to-upload Laravel storefront and admin panel for a fresh-fish business, with a browser-based installer.
No SSH, Composer or `npm` is required on the server: dependencies are included.

**Version 1.0.0**

## Quick start (about 15 minutes)

1. In Hostinger hPanel: enable **SSL**, select **PHP 8.3/8.4**, and create a **MySQL database + user**
   (**Websites → Manage → Databases**). Keep the prefixed names (`u123456_...`) and the password.
2. Upload this ZIP **one level above `public_html`** — in `/home/uXXXXXXXX/domains/yourdomain.com/` — and extract it.
   You should end up with `public_html/` and `motsyomela/` side by side.
3. Open `https://yourdomain.com/install/`.
4. Check the requirements, enter the database details, then choose the store name, site URL, administrator login
   and demo data.
5. When the success page appears, sign in at `https://yourdomain.com/admin`, configure payments and email, and
   **delete `public_html/install`**.

The full, step-by-step guide — including the Hostinger screens, post-install checklist and troubleshooting — is in
[`INSTALL.md`](INSTALL.md).

## What is inside

| Folder | Purpose |
|---|---|
| `public_html/` | Public web root: front controller, `.htaccess`, favicon, installer wizard |
| `motsyomela/` | Laravel application, `vendor/`, `.env` (created by the installer), storage and uploads |
| `INSTALL.md` | Complete installation and troubleshooting guide |
| `README.md` | This quick overview |

Keep `motsyomela/` outside the web root. The installer writes the database configuration to `motsyomela/.env` and
never exposes it through the browser.

## Requirements

- PHP **8.3+** with `pdo_mysql`, `mbstring`, `openssl`, `tokenizer`, `dom`, `curl`, `fileinfo`, `json`, `ctype`,
  `session`, `filter`, `hash`, `pcre`
- MySQL 8.0+ / MariaDB 10.6+
- Writable `motsyomela/storage`, `motsyomela/bootstrap/cache`
- HTTPS for production

Optional: GD, Intl, ZIP, BCMath and symbolic-link support (recommended, not blocking).

## Included features

- Bangla-first storefront with English toggle, dark/light theme, mobile bottom navigation
- Product catalogue with sizes, stock, categories, combo packs, coupons and delivery zones
- Cart, checkout (COD / bKash / Nagad / card link), delivery time slots, optional customer accounts with order history
- Admin panel: orders, products, categories, banners, FAQ, reviews, pages, menus, translations, invoices (PDF),
  payments, SMTP mail, theme, SEO and super-admin user management
- Optional demo content: 10 products, 6 categories, coupons, combo packs, FAQs, reviews and one announcement

## After installation

- **Delete the installer** (`public_html/install`).
- Admin URL: `https://yourdomain.com/admin`
- Configure **Payments**, **Mail settings** and **Site settings** before taking real orders.
- Enable Hostinger backups and keep a copy of `motsyomela/.env`.

## Troubleshooting

Most problems are covered in [`INSTALL.md`](INSTALL.md#8-troubleshooting): 500 errors, missing storage link,
database access, email, SSL and wrong extraction layout.

When asking for help, include the PHP version, the exact error and the last lines of
`motsyomela/storage/logs/laravel.log`. Never share `.env` or passwords.
