<?php

declare(strict_types=1);

namespace MotsyoMela\Installer;

use PDO;
use PDOException;
use RuntimeException;
use Throwable;

/**
 * Standalone installer engine.
 *
 * This file intentionally does not depend on the Laravel application: it must
 * run before vendor/autoload.php can be assumed, and before .env exists.
 */
final class Installer
{
    public const VERSION = '1.0.0';

    public const MIN_PHP = '8.3.0';

    private string $publicPath;

    private ?string $appPath = null;

    private bool $appPathResolved = false;

    public function __construct(string $publicPath)
    {
        $this->publicPath = rtrim($publicPath, '/\\');
    }

    public function publicPath(): string
    {
        return $this->publicPath;
    }

    public function version(): string
    {
        return self::VERSION;
    }

    /**
     * Locate the Laravel application folder.
     *
     * Supported layouts (first match wins):
     *   1. domains/example.com/public_html  +  domains/example.com/motsyomela   (recommended)
     *   2. public_html/motsyomela                                                (nested, still denied by .htaccess)
     *   3. the repository / classic layout where the app root is the parent of public/
     *   4. a flat upload where the app root is public_html itself
     */
    public function appPath(): ?string
    {
        if ($this->appPathResolved) {
            return $this->appPath;
        }

        $this->appPathResolved = true;

        $parent = dirname($this->publicPath);

        $candidates = [
            $parent.'/motsyomela',
            $parent.'/MotsyoMela',
            $parent.'/motsyomela-app',
            $parent.'/app',
            $parent.'/laravel',
            $this->publicPath.'/motsyomela',
            $this->publicPath.'/MotsyoMela',
            $parent,
            $this->publicPath,
        ];

        foreach ($candidates as $candidate) {
            $candidate = rtrim(str_replace('\\', '/', $candidate), '/');

            if (
                is_file($candidate.'/bootstrap/app.php')
                && is_file($candidate.'/vendor/autoload.php')
                && is_file($candidate.'/artisan')
            ) {
                $real = realpath($candidate);
                $this->appPath = $real !== false ? str_replace('\\', '/', $real) : $candidate;

                return $this->appPath;
            }
        }

        return null;
    }

    public function appIsInsidePublicPath(): bool
    {
        $app = $this->appPath();

        if ($app === null) {
            return false;
        }

        $public = str_replace('\\', '/', $this->publicPath);

        return str_starts_with($app.'/', rtrim($public, '/').'/');
    }

    public function lockPath(): ?string
    {
        $app = $this->appPath();

        return $app === null ? null : $app.'/storage/app/installed.lock';
    }

    public function markPath(): string
    {
        return $this->publicPath.'/install/.installed';
    }

    public function isInstalled(): bool
    {
        if (is_file($this->markPath())) {
            return true;
        }

        $lock = $this->lockPath();

        return $lock !== null && is_file($lock);
    }

    /**
     * A finished/successful installation marker with the details we can show
     * on the "already installed" screen.
     *
     * @return array<string, mixed>
     */
    public function installationInfo(): array
    {
        foreach ([$this->lockPath(), $this->markPath()] as $path) {
            if ($path === null || ! is_file($path)) {
                continue;
            }

            $decoded = json_decode((string) file_get_contents($path), true);

            if (is_array($decoded)) {
                return $decoded;
            }
        }

        return [];
    }

    /**
     * The repository's own local .env should never be overwritten by a stray
     * visit to /install. Production packages ship without .env.
     */
    public function hasLocalEnvironment(): bool
    {
        $app = $this->appPath();

        if ($app === null || ! is_file($app.'/.env')) {
            return false;
        }

        $contents = (string) file_get_contents($app.'/.env');

        if (! preg_match('/^APP_ENV\s*=\s*(.+)$/m', $contents, $matches)) {
            return false;
        }

        $environment = strtolower(trim($matches[1], " \t\n\r\0\x0B\"'"));

        return in_array($environment, ['local', 'testing', 'development', 'dev'], true);
    }

    /**
     * Create the runtime folders the application needs and report what changed.
     *
     * @return list<string>
     */
    public function prepareEnvironment(): array
    {
        $app = $this->appPath();

        if ($app === null) {
            return [];
        }

        $actions = [];

        $directories = [
            'storage',
            'storage/app',
            'storage/app/public',
            'storage/app/private',
            'storage/framework',
            'storage/framework/cache',
            'storage/framework/cache/data',
            'storage/framework/sessions',
            'storage/framework/views',
            'storage/logs',
            'bootstrap/cache',
        ];

        foreach ($directories as $directory) {
            $path = $app.'/'.$directory;

            if (! is_dir($path)) {
                if (@mkdir($path, 0775, true) || is_dir($path)) {
                    $actions[] = 'Created '.$directory;
                } else {
                    $actions[] = 'Could not create '.$directory;
                }
            }

            @chmod($path, 0775);
        }

        $environmentFile = $app.'/.env';

        if (is_file($environmentFile)) {
            @chmod($environmentFile, 0600);
        }

        return $actions;
    }

    /**
     * @return list<array{title: string, items: list<array<string, mixed>>}>
     */
    public function requirements(): array
    {
        $app = $this->appPath();
        $phpOk = version_compare(PHP_VERSION, self::MIN_PHP, '>=');

        $extensions = [
            ['PDO MySQL', 'pdo_mysql', true, 'Stores all store data in MySQL.'],
            ['Multibyte strings', 'mbstring', true, 'Required for Bangla text handling.'],
            ['OpenSSL', 'openssl', true, 'Required for encryption and HTTPS.'],
            ['Tokenizer', 'tokenizer', true, 'Required by the framework.'],
            ['XML & DOM', 'dom', true, 'Required for invoice PDF generation.'],
            ['cURL', 'curl', true, 'Required for outgoing HTTP requests.'],
            ['File information', 'fileinfo', true, 'Required for image uploads.'],
            ['JSON', 'json', true, 'Required by the framework.'],
            ['Ctype', 'ctype', true, 'Required by the framework.'],
            ['Session', 'session', true, 'Required for sign-in and cart state.'],
            ['Filter', 'filter', true, 'Required by the framework.'],
            ['Hash', 'hash', true, 'Required by the framework.'],
            ['PCRE', 'pcre', true, 'Required by the framework.'],
            ['GD', 'gd', false, 'Recommended for image thumbnails.'],
            ['Internationalisation', 'intl', false, 'Recommended for number and date formatting.'],
            ['ZIP', 'zip', false, 'Recommended for archive operations.'],
            ['BCMath', 'bcmath', false, 'Recommended for precise number handling.'],
        ];

        $extensionItems = [];

        foreach ($extensions as [$label, $extension, $required, $description]) {
            if (extension_loaded($extension)) {
                $extensionItems[] = [
                    'label' => $label.' ('.$extension.')',
                    'ok' => true,
                    'required' => $required,
                    'detail' => 'Loaded.',
                ];

                continue;
            }

            $extensionItems[] = [
                'label' => $label.' ('.$extension.')',
                'ok' => false,
                'required' => $required,
                'detail' => $required
                    ? $description.' Ask Hostinger support to enable the '.$extension.' extension for PHP '.PHP_MAJOR_VERSION.'.'.PHP_MINOR_VERSION.'.'
                    : $description.' Optional — the site works without it, but enabling it is recommended.',
            ];
        }

        $symlinkAvailable = function_exists('symlink') && $this->functionIsEnabled('symlink');

        $serverItems = [
            [
                'label' => 'PHP '.self::MIN_PHP.' or newer',
                'ok' => $phpOk,
                'required' => true,
                'detail' => 'Detected PHP '.PHP_VERSION.'. Select PHP 8.3 or 8.4 in Hostinger hPanel → Advanced → PHP Configuration.',
            ],
            [
                'label' => 'MySQL 5.7+ / MariaDB 10.2+',
                'ok' => true,
                'required' => true,
                'detail' => 'Checked automatically on the database step.',
            ],
            [
                'label' => 'Apache mod_rewrite (or LiteSpeed equivalent)',
                'ok' => $this->rewriteLooksAvailable(),
                'required' => false,
                'detail' => 'Needed for clean URLs. Hostinger enables URL rewriting by default.',
            ],
            [
                'label' => 'Symbolic links allowed',
                'ok' => $symlinkAvailable,
                'required' => false,
                'detail' => $symlinkAvailable
                    ? 'Uploaded product images can be published at /storage.'
                    : 'The PHP symlink() function is disabled. Image uploads will be stored but may not be publicly visible until symlinks are enabled.',
            ],
            [
                'label' => 'Memory limit 128 MB or more',
                'ok' => $this->iniAtLeast('memory_limit', 128),
                'required' => false,
                'detail' => 'Current: '.$this->iniValue('memory_limit').'.',
            ],
            [
                'label' => 'Max execution time 300 seconds or unlimited',
                'ok' => $this->executionTimeOk(),
                'required' => false,
                'detail' => 'Current: '.$this->iniValue('max_execution_time').' seconds. Installation may need more time on slow servers.',
            ],
            [
                'label' => 'Upload limit 8 MB or more',
                'ok' => $this->iniAtLeast('upload_max_filesize', 8) && $this->iniAtLeast('post_max_size', 8),
                'required' => false,
                'detail' => 'Current upload_max_filesize: '.$this->iniValue('upload_max_filesize').', post_max_size: '.$this->iniValue('post_max_size').'. Admin image uploads allow up to 4 MB.',
            ],
        ];

        $fileItems = [];

        if ($app === null) {
            $fileItems[] = [
                'label' => 'Application folder found',
                'ok' => false,
                'required' => true,
                'detail' => 'Could not find bootstrap/app.php and vendor/autoload.php. The application folder must sit next to public_html (recommended), or inside it as a motsyomela folder.',
            ];
        } else {
            $fileItems[] = [
                'label' => 'Application folder found',
                'ok' => true,
                'required' => true,
                'detail' => $app,
            ];
            $fileItems[] = [
                'label' => 'Composer dependencies (vendor/) present',
                'ok' => is_file($app.'/vendor/autoload.php'),
                'required' => true,
                'detail' => 'The ZIP ships vendor/ pre-installed so Composer is not required on the server.',
            ];
            $fileItems[] = [
                'label' => 'Front controller present',
                'ok' => is_file($this->publicPath.'/index.php'),
                'required' => true,
                'detail' => $this->publicPath.'/index.php',
            ];

            foreach ([
                '.env (application configuration)' => $app,
                'storage/' => $app.'/storage',
                'storage/app/' => $app.'/storage/app',
                'storage/framework/' => $app.'/storage/framework',
                'storage/framework/views/' => $app.'/storage/framework/views',
                'storage/logs/' => $app.'/storage/logs',
                'bootstrap/cache/' => $app.'/bootstrap/cache',
                'public_html/ (storage link + installer)' => $this->publicPath,
                'installer folder' => $this->publicPath.'/install',
            ] as $label => $path) {
                $writable = is_dir($path) ? is_writable($path) : (is_file($path) ? is_writable($path) : is_writable(dirname($path)));

                $fileItems[] = [
                    'label' => $label.' writable',
                    'ok' => $writable,
                    'required' => true,
                    'detail' => $writable
                        ? 'Writable: '.$path
                        : 'Not writable: '.$path.'. Set the folder permission to 755 (or 775) in Hostinger File Manager.',
                ];
            }
        }

        return [
            [
                'title' => 'Server',
                'items' => $serverItems,
            ],
            [
                'title' => 'PHP extensions',
                'items' => $extensionItems,
            ],
            [
                'title' => 'Files & permissions',
                'items' => $fileItems,
            ],
        ];
    }

    /**
     * @param  list<array{title: string, items: list<array<string, mixed>>}>  $groups
     * @return list<array<string, mixed>>
     */
    public function failures(array $groups): array
    {
        $failures = [];

        foreach ($groups as $group) {
            foreach ($group['items'] as $item) {
                if ($item['required'] && ! $item['ok']) {
                    $failures[] = $item;
                }
            }
        }

        return $failures;
    }

    /**
     * Validate the database form input without opening a connection.
     *
     * @param  array<string, mixed>  $input
     * @return string|null Human-readable error, or null when the input is valid.
     */
    public function validateDatabaseInput(array $input): ?string
    {
        $host = trim((string) ($input['host'] ?? ''));
        $port = (int) ($input['port'] ?? 0);
        $database = trim((string) ($input['database'] ?? ''));
        $username = trim((string) ($input['username'] ?? ''));

        if ($host === '' || $username === '' || $database === '') {
            return 'Database host, name and username are required.';
        }

        if ($port < 1 || $port > 65535) {
            return 'The database port must be between 1 and 65535.';
        }

        if (preg_match('/^[A-Za-z0-9_$.-]+$/', $database) !== 1) {
            return 'The database name contains characters that are not allowed. Use letters, numbers, underscore or dot.';
        }

        return null;
    }

    /**
     * Connect to MySQL, optionally create the database, and inspect existing tables.
     *
     * @param  array{host: string, port: int, database: string, username: string, password: string, create: bool}  $input
     * @return array{ok: bool, error?: string, detail?: string, needs_confirmation?: bool, tables?: int, server?: string, created?: bool}
     */
    public function testDatabase(array $input): array
    {
        if (($validationError = $this->validateDatabaseInput($input)) !== null) {
            return ['ok' => false, 'error' => $validationError];
        }

        $host = trim((string) $input['host']);
        $port = (int) $input['port'];
        $database = trim((string) $input['database']);
        $username = trim((string) $input['username']);
        $password = (string) $input['password'];
        $create = (bool) $input['create'];

        try {
            $server = $this->connect($host, $port, null, $username, $password);
            $serverVersion = (string) $server->query('SELECT VERSION()')->fetchColumn();
        } catch (PDOException $exception) {
            return ['ok' => false, 'error' => $this->connectionError($exception, $host, $username)];
        }

        $exists = false;

        try {
            $statement = $server->prepare('SELECT SCHEMA_NAME FROM information_schema.SCHEMATA WHERE SCHEMA_NAME = ?');
            $statement->execute([$database]);
            $exists = $statement->fetchColumn() !== false;
        } catch (PDOException) {
            // Some restricted MySQL users cannot read information_schema; fall
            // back to connecting directly below.
        }

        $created = false;

        if (! $exists) {
            if (! $create) {
                return [
                    'ok' => false,
                    'error' => 'The database "'.$database.'" does not exist.',
                    'detail' => 'Create it in Hostinger hPanel → Websites → Manage → Databases, then attach the MySQL user to it. Or tick “Create the database if it does not exist” and try again.',
                ];
            }

            try {
                $server->exec('CREATE DATABASE IF NOT EXISTS `'.str_replace('`', '``', $database).'` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci');
                $created = true;
                $exists = true;
            } catch (PDOException $exception) {
                return [
                    'ok' => false,
                    'error' => 'The database could not be created automatically.',
                    'detail' => 'Your MySQL user does not have CREATE DATABASE permission. Create the database in Hostinger hPanel → Websites → Manage → Databases, attach the user, then try again. Server said: '.$exception->getMessage(),
                ];
            }
        }

        try {
            $connection = $this->connect($host, $port, $database, $username, $password);
        } catch (PDOException $exception) {
            return ['ok' => false, 'error' => $this->connectionError($exception, $host, $username), 'detail' => 'The server is reachable but the user cannot open this database. Attach the user to the database in hPanel and check the database name.'];
        }

        $tables = 0;

        try {
            $statement = $connection->prepare('SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = ?');
            $statement->execute([$database]);
            $tables = (int) $statement->fetchColumn();
        } catch (PDOException) {
            try {
                $tables = (int) $connection->query('SHOW TABLES')->rowCount();
            } catch (PDOException) {
                $tables = 0;
            }
        }

        $charset = (string) $connection->query('SELECT @@character_set_database')->fetchColumn();

        return [
            'ok' => true,
            'server' => $serverVersion.' (utf8mb4: '.($charset !== '' ? $charset : 'unknown').')',
            'tables' => $tables,
            'created' => $created,
            'needs_confirmation' => $tables > 0,
        ];
    }

    /**
     * Write configuration, migrate, seed and lock the installation.
     *
     * @param  array{host: string, port: int, database: string, username: string, password: string, create: bool}  $database
     * @param  array{name: string, email: string, password: string}  $admin
     * @return array{steps: list<array{label: string, detail: string}>, warnings: list<string>, stats: array<string, mixed>, lock: array<string, mixed>}
     */
    public function install(array $database, array $admin, bool $demo, string $siteName, string $siteUrl): array
    {
        $app = $this->appPath();

        if ($app === null) {
            throw new RuntimeException('The application folder could not be found. Extract public_html/ and motsyomela/ next to each other, then reload this page.');
        }

        if (! is_file($app.'/vendor/autoload.php')) {
            throw new RuntimeException('vendor/autoload.php is missing. Re-upload the application folder from the installation ZIP (the vendor folder must stay inside motsyomela/).');
        }

        if (! is_dir($this->publicPath.'/install')) {
            throw new RuntimeException('The installer folder could not be written. Check permissions on public_html/install.');
        }

        @set_time_limit(300);
        @ini_set('memory_limit', '256M');

        $this->prepareEnvironment();

        $steps = [];
        $warnings = [];

        // 1. Configuration file.
        $appKey = $this->existingAppKey($app);
        $appKey ??= 'base64:'.base64_encode(random_bytes(32));

        if (is_file($app.'/.env')) {
            $backup = $app.'/.env.backup-'.date('Ymd-His');
            @copy($app.'/.env', $backup);
        }

        $environment = $this->renderEnvironment([
            'APP_NAME' => $siteName,
            'APP_KEY' => $appKey,
            'APP_URL' => $siteUrl,
            'DB_HOST' => trim($database['host']),
            'DB_PORT' => (string) (int) $database['port'],
            'DB_DATABASE' => trim($database['database']),
            'DB_USERNAME' => trim($database['username']),
            'DB_PASSWORD' => (string) $database['password'],
            'SESSION_SECURE_COOKIE' => str_starts_with(strtolower($siteUrl), 'https://'),
        ]);

        if (@file_put_contents($app.'/.env', $environment, LOCK_EX) === false) {
            throw new RuntimeException('Could not write '.$app.'/.env. Make the application folder writable (755/775) in Hostinger File Manager.');
        }

        @chmod($app.'/.env', 0600);

        $steps[] = ['label' => 'Configuration written', 'detail' => 'APP_KEY generated and .env saved outside the web root.'];

        // 2. Remove stale caches from an earlier attempt or a copied build.
        foreach (glob($app.'/bootstrap/cache/*.php') ?: [] as $cacheFile) {
            @unlink($cacheFile);
        }

        foreach (glob($app.'/storage/framework/views/*.php') ?: [] as $viewCache) {
            @unlink($viewCache);
        }

        // 3. Boot Laravel with the new configuration.
        require_once $app.'/vendor/autoload.php';

        /** @var \Illuminate\Foundation\Application $laravel */
        $laravel = require $app.'/bootstrap/app.php';
        $kernel = $laravel->make(\Illuminate\Contracts\Console\Kernel::class);
        $kernel->bootstrap();

        $steps[] = ['label' => 'Framework booted', 'detail' => 'Laravel '.$laravel->version().' started with the new .env.'];

        // 4. Migrate.
        try {
            $exitCode = \Illuminate\Support\Facades\Artisan::call('migrate', ['--force' => true]);
        } catch (Throwable $exception) {
            throw new RuntimeException('Database migration failed: '.$exception->getMessage(), 0, $exception);
        }

        $migrationOutput = trim(\Illuminate\Support\Facades\Artisan::output());

        if ($exitCode !== 0) {
            throw new RuntimeException("Database migration failed (exit code {$exitCode}).\n".$migrationOutput);
        }

        $migrationCount = (int) \Illuminate\Support\Facades\DB::table('migrations')->count();
        $steps[] = ['label' => 'Database tables created', 'detail' => $migrationCount.' migrations applied.'];

        // 5. Seed.
        $seeders = [
            \Database\Seeders\SettingSeeder::class => 'Default site settings',
            \Database\Seeders\TranslationSeeder::class => 'Bangla / English translations',
            \Database\Seeders\MenuItemSeeder::class => 'Header and footer menu',
            \Database\Seeders\PageSeeder::class => 'Delivery and refund policy pages',
            \Database\Seeders\DeliverySeeder::class => 'Delivery zones and time slots',
        ];

        if ($demo) {
            $seeders += [
                \Database\Seeders\CategorySeeder::class => 'Demo categories',
                \Database\Seeders\ProductSeeder::class => 'Demo products',
                \Database\Seeders\CouponSeeder::class => 'Demo coupons',
                \Database\Seeders\ComboPackSeeder::class => 'Demo combo packs',
                \Database\Seeders\ContentSeeder::class => 'Demo FAQs, reviews and announcement',
            ];
        }

        foreach ($seeders as $class => $label) {
            try {
                /** @var \Illuminate\Database\Seeder $seeder */
                $seeder = new $class();
                $seeder->setContainer($laravel);
                $seeder->run();
            } catch (Throwable $exception) {
                throw new RuntimeException('Seeding failed while running '.$label.': '.$exception->getMessage(), 0, $exception);
            }

            $steps[] = ['label' => $label, 'detail' => 'Installed.'];
        }

        // 6. Administrator account.
        \App\Models\Admin::query()->updateOrCreate(
            ['email' => $admin['email']],
            [
                'name' => $admin['name'],
                'password' => $admin['password'],
                'role' => 'super',
            ]
        );

        \App\Models\Setting::put('site_name', $siteName);
        \App\Models\Setting::put('mail_admin_email', $admin['email']);

        $steps[] = ['label' => 'Administrator account created', 'detail' => $admin['email'].' (super admin).'];
        $steps[] = ['label' => 'Site name applied', 'detail' => $siteName];

        // 7. Public storage link for uploaded images.
        $link = $this->publicPath.'/storage';
        $target = $app.'/storage/app/public';

        if (! is_dir($target)) {
            @mkdir($target, 0775, true);
        }

        $this->writeStorageProtection($target);

        if (! is_link($link) && ! file_exists($link)) {
            try {
                \Illuminate\Support\Facades\Artisan::call('storage:link', ['--force' => true]);
            } catch (Throwable) {
                // Fall back to a direct symlink below.
            }

            if (! is_link($link) && ! file_exists($link)) {
                @symlink($target, $link);
            }
        }

        if (is_link($link) || file_exists($link)) {
            $steps[] = ['label' => 'Public image folder linked', 'detail' => 'public_html/storage → storage/app/public.'];
        } else {
            $warnings[] = 'The public storage link could not be created. Uploaded images will not appear until symlinks are enabled. Ask Hostinger support to enable symlink() or run "php artisan storage:link" over SSH.';
        }

        // 8. Verify.
        $adminExists = \App\Models\Admin::query()->where('email', $admin['email'])->exists();
        $settingsCount = (int) \App\Models\Setting::query()->count();

        if (! $adminExists) {
            throw new RuntimeException('The administrator account could not be verified after installation.');
        }

        if ($settingsCount === 0) {
            throw new RuntimeException('Default settings were not written. Check that the database user has INSERT privileges.');
        }

        $stats = [
            'products' => (int) \App\Models\Product::query()->count(),
            'categories' => (int) \App\Models\Category::query()->count(),
            'translations' => (int) \App\Models\Translation::query()->count(),
            'zones' => (int) \App\Models\DeliveryZone::query()->count(),
            'settings' => $settingsCount,
            'migrations' => $migrationCount,
        ];

        // 9. Lock the installer.
        $lock = [
            'version' => self::VERSION,
            'installed_at' => date('c'),
            'site_url' => $siteUrl,
            'admin_email' => $admin['email'],
            'database' => trim($database['database']),
            'demo_data' => $demo,
            'layout' => $this->appIsInsidePublicPath() ? 'nested' : 'split',
        ];

        $lockJson = json_encode($lock, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $lockPath = $app.'/storage/app/installed.lock';

        if (@file_put_contents($lockPath, $lockJson) === false) {
            $warnings[] = 'The installation finished but the lock file could not be written. Delete the install folder manually so nobody can run the installer again.';
        }

        @file_put_contents($this->markPath(), $lockJson);
        @file_put_contents($app.'/storage/logs/install-'.date('Y-m-d').'.log', $this->installLog($lock, $steps), FILE_APPEND);

        // Keep the application out of debug mode regardless of the build.
        @chmod($app.'/storage/app/installed.lock', 0644);

        return [
            'steps' => $steps,
            'warnings' => array_values(array_unique($warnings)),
            'stats' => $stats,
            'lock' => $lock,
        ];
    }

    /**
     * Render the .env file written during installation.
     *
     * Values that are not safe bare tokens are single-quoted and escaped so
     * database passwords, site names and URLs with special characters survive
     * phpdotenv parsing intact.
     *
     * @param  array<string, string|bool>  $values
     */
    public function renderEnvironment(array $values): string
    {
        $quote = static function (string $value): string {
            if ($value === '') {
                return '';
            }

            if (preg_match('/^[A-Za-z0-9_.\-\/:@]+$/', $value) === 1) {
                return $value;
            }

            // phpdotenv only understands backslash escapes inside double quotes.
            // Single-quoted values end at the first apostrophe, so a password
            // such as p@ss'word would break the file.
            $escaped = str_replace(
                ['\\', '"', '$', "\r", "\n", "\t"],
                ['\\\\', '\\"', '\\$', '\\r', '\\n', '\\t'],
                $value
            );

            return '"'.$escaped.'"';
        };

        $appName = (string) $values['APP_NAME'];
        $secureCookie = (bool) $values['SESSION_SECURE_COOKIE'];

        $lines = [
            '# MotsyoMela — generated by the web installer on '.date('Y-m-d H:i:s'),
            '# Keep this file outside public_html. It contains secrets.',
            '',
            'APP_NAME='.$quote($appName),
            'APP_ENV=production',
            'APP_KEY='.$values['APP_KEY'],
            'APP_DEBUG=false',
            'APP_URL='.$quote(rtrim((string) $values['APP_URL'], '/')),
            'APP_TIMEZONE=Asia/Dhaka',
            '',
            'APP_LOCALE=bn',
            'APP_FALLBACK_LOCALE=en',
            'APP_FAKER_LOCALE=bn_BD',
            '',
            'APP_MAINTENANCE_DRIVER=file',
            '',
            'BCRYPT_ROUNDS=12',
            '',
            'LOG_CHANNEL=stack',
            'LOG_STACK=single',
            'LOG_LEVEL=warning',
            '',
            'DB_CONNECTION=mysql',
            'DB_HOST='.$quote((string) $values['DB_HOST']),
            'DB_PORT='.$values['DB_PORT'],
            'DB_DATABASE='.$quote((string) $values['DB_DATABASE']),
            'DB_USERNAME='.$quote((string) $values['DB_USERNAME']),
            'DB_PASSWORD='.$quote((string) $values['DB_PASSWORD']),
            '',
            'SESSION_DRIVER=database',
            'SESSION_LIFETIME=120',
            'SESSION_ENCRYPT=false',
            'SESSION_PATH=/',
            'SESSION_DOMAIN=null',
        ];

        if ($secureCookie) {
            $lines[] = 'SESSION_SECURE_COOKIE=true';
        }

        $lines = array_merge($lines, [
            '',
            'BROADCAST_CONNECTION=log',
            'FILESYSTEM_DISK=public',
            'QUEUE_CONNECTION=database',
            'CACHE_STORE=database',
            '',
            'MAIL_MAILER=log',
            'MAIL_FROM_ADDRESS="hello@example.com"',
            'MAIL_FROM_NAME="${APP_NAME}"',
            '',
        ]);

        return implode("\n", $lines);
    }

    private function existingAppKey(string $app): ?string
    {
        if (! is_file($app.'/.env')) {
            return null;
        }

        $contents = (string) file_get_contents($app.'/.env');

        if (! preg_match('/^APP_KEY\s*=\s*(.+)$/m', $contents, $matches)) {
            return null;
        }

        $key = trim($matches[1], " \t\n\r\0\x0B\"'");

        return str_starts_with($key, 'base64:') && strlen($key) > 20 ? $key : null;
    }

    private function connect(string $host, int $port, ?string $database, string $username, string $password): PDO
    {
        $dsn = 'mysql:host='.$host.';port='.$port.';charset=utf8mb4';

        if ($database !== null) {
            $dsn .= ';dbname='.$database;
        }

        return new PDO($dsn, $username, $password, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_TIMEOUT => 8,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }

    private function connectionError(PDOException $exception, string $host, string $username): string
    {
        $code = isset($exception->errorInfo[1]) ? (int) $exception->errorInfo[1] : 0;

        return match ($code) {
            1045 => 'MySQL rejected the username or password for "'.$username.'". Copy the exact values from Hostinger hPanel → Websites → Manage → Databases (the username is usually prefixed with your account ID).',
            1044 => 'The MySQL user "'.$username.'" does not have access to this database. Attach the user to the database in hPanel.',
            1049 => 'The database does not exist yet.',
            1130, 2002, 2003 => 'Could not reach the MySQL server at "'.$host.'". On Hostinger the host is normally "localhost" (not 127.0.0.1) and the port is 3306.',
            default => 'Could not connect to MySQL: '.$exception->getMessage(),
        };
    }

    private function writeStorageProtection(string $directory): void
    {
        if (! is_dir($directory)) {
            return;
        }

        $rules = <<<'HTACCESS'
# Uploaded images only — never execute scripts from this folder.
<FilesMatch "\.(?i:php\d*|phtml|phar|pl|py|cgi|sh)$">
    Require all denied
</FilesMatch>
Options -Indexes

HTACCESS;

        if (! is_file($directory.'/.htaccess')) {
            @file_put_contents($directory.'/.htaccess', $rules);
        }
    }

    /**
     * @param  array<string, mixed>  $lock
     * @param  list<array{label: string, detail: string}>  $steps
     */
    private function installLog(array $lock, array $steps): string
    {
        $lines = ['['.date('c').'] Installed MotsyoMela '.self::VERSION.' via web installer'];

        foreach ($steps as $step) {
            $lines[] = '  - '.$step['label'].': '.$step['detail'];
        }

        $lines[] = '  Site: '.($lock['site_url'] ?? '');
        $lines[] = '  Admin: '.($lock['admin_email'] ?? '');
        $lines[] = '';

        return implode("\n", $lines)."\n";
    }

    private function functionIsEnabled(string $function): bool
    {
        $disabled = array_map('trim', explode(',', (string) ini_get('disable_functions')));

        return ! in_array($function, $disabled, true);
    }

    private function rewriteLooksAvailable(): bool
    {
        if (is_file($this->publicPath.'/.htaccess')) {
            return true;
        }

        if (function_exists('apache_get_modules')) {
            return in_array('mod_rewrite', apache_get_modules(), true);
        }

        return true;
    }

    private function executionTimeOk(): bool
    {
        $limit = (int) ini_get('max_execution_time');

        return $limit === 0 || $limit >= 300;
    }

    private function iniValue(string $key): string
    {
        $value = trim((string) ini_get($key));

        return $value === '' ? 'unknown' : $value;
    }

    private function iniAtLeast(string $key, int $megabytes): bool
    {
        $value = trim((string) ini_get($key));

        if ($value === '' || $value === '-1') {
            return true;
        }

        $bytes = $this->toBytes($value);

        return $bytes >= $megabytes * 1024 * 1024;
    }

    private function toBytes(string $value): int
    {
        $value = trim($value);
        $number = (int) $value;
        $unit = strtolower(substr($value, -1));

        return match ($unit) {
            'g' => $number * 1024 * 1024 * 1024,
            'm' => $number * 1024 * 1024,
            'k' => $number * 1024,
            default => $number,
        };
    }
}
