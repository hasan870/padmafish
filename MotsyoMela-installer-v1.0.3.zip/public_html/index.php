<?php

use Illuminate\Foundation\Application;
use Illuminate\Http\Request;

define('LARAVEL_START', microtime(true));

if (PHP_VERSION_ID < 80300) {
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>PHP upgrade required</title>'
        .'<body style="font:16px/1.6 system-ui,sans-serif;max-width:680px;margin:8vh auto;padding:0 24px;color:#153">'
        .'<h1>PHP 8.3 or newer is required</h1>'
        .'<p>This server is running PHP '.PHP_VERSION.'. In Hostinger hPanel open <strong>Advanced → PHP Configuration</strong>, '
        .'select PHP 8.3 (or 8.4), save, then reload this page.</p></body></html>';
    exit;
}

/*
|--------------------------------------------------------------------------
| Locate the application folder
|--------------------------------------------------------------------------
|
| The application normally lives next to public_html (../motsyomela). When
| the ZIP is extracted inside public_html instead, it is found in
| ./motsyomela. An explicit MOTSYOMELA_APP_PATH environment variable (set
| through .htaccess SetEnv) always wins.
|
*/

$appPath = getenv('MOTSYOMELA_APP_PATH') ?: null;

if (! is_string($appPath) || ! is_file($appPath.'/vendor/autoload.php')) {
    $candidates = [
        __DIR__.'/../motsyomela',
        __DIR__.'/../MotsyoMela',
        __DIR__.'/motsyomela',
        __DIR__.'/MotsyoMela',
        __DIR__.'/..',
        __DIR__,
    ];

    $appPath = null;

    foreach ($candidates as $candidate) {
        if (is_file($candidate.'/vendor/autoload.php') && is_file($candidate.'/bootstrap/app.php')) {
            $appPath = realpath($candidate) ?: $candidate;
            break;
        }
    }
}

if (! is_string($appPath) || $appPath === '') {
    http_response_code(503);
    header('Content-Type: text/html; charset=utf-8');
    header('Retry-After: 300');
    echo '<!doctype html><html lang="en"><meta charset="utf-8"><title>Setup required</title>'
        .'<body style="font:16px/1.6 system-ui,sans-serif;max-width:680px;margin:8vh auto;padding:0 24px;color:#153">'
        .'<h1>Application files not found</h1>'
        .'<p>The web server is running, but the <code>motsyomela</code> application folder is missing.</p>'
        .'<p>Extract the installation ZIP so that <code>public_html</code> and <code>motsyomela</code> are next to each other, '
        .'then reload this page and open <a href="/install/">/install/</a>.</p></body></html>';
    exit;
}

// Fresh upload: send visitors to the setup wizard instead of a 500 error.
if (! is_file($appPath.'/.env') && is_file(__DIR__.'/install/index.php')) {
    header('Location: '.rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/index.php'))), '/').'/install/', true, 302);
    exit;
}

// Put the application into maintenance mode with: php artisan down
if (file_exists($maintenance = $appPath.'/storage/framework/maintenance.php')) {
    require $maintenance;
}

require $appPath.'/vendor/autoload.php';

/** @var Application $app */
$app = require_once $appPath.'/bootstrap/app.php';

$app->usePublicPath(__DIR__);

$app->handleRequest(Request::capture());
