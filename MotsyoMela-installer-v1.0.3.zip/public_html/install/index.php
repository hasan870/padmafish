<?php

declare(strict_types=1);

/**
 * MotsyoMela web installer.
 *
 * Runs without Laravel, Composer or a configured .env. It checks the server,
 * tests the MySQL connection, writes configuration, migrates and seeds the
 * database, creates the administrator and locks itself when finished.
 */

if (PHP_VERSION_ID < 80100) {
    http_response_code(500);
    echo '<!doctype html><meta charset="utf-8"><title>PHP upgrade required</title>'
        .'<body style="font:16px system-ui;padding:40px;max-width:720px;margin:auto">'
        .'<h1>PHP 8.3 or newer is required</h1>'
        .'<p>This server is running PHP '.PHP_VERSION.'. In Hostinger hPanel open '
        .'<strong>Advanced → PHP Configuration</strong> and select PHP 8.3 (or 8.4), then reload this page.</p></body>';
    exit;
}

require __DIR__.'/lib/Installer.php';

use MotsyoMela\Installer\Installer;

/* -------------------------------------------------------------------------
 | Small helpers (prefixed so they can never clash with Laravel helpers).
 * ---------------------------------------------------------------------- */

function mi_h(mixed $value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function mi_redirect(string $location): never
{
    header('Location: '.$location, true, 302);
    exit;
}

function mi_flash(string $key, mixed $value): void
{
    $_SESSION['_flash'][$key] = $value;
}

function mi_pull(string $key, mixed $default = null): mixed
{
    $value = $_SESSION['_flash'][$key] ?? $default;
    unset($_SESSION['_flash'][$key]);

    return $value;
}

function mi_delete_directory(string $directory): bool
{
    if (! is_dir($directory)) {
        return false;
    }

    $items = new RecursiveIteratorIterator(
        new RecursiveDirectoryIterator($directory, FilesystemIterator::SKIP_DOTS),
        RecursiveIteratorIterator::CHILD_FIRST
    );

    foreach ($items as $item) {
        if ($item->isDir() && ! $item->isLink()) {
            @rmdir($item->getPathname());
        } else {
            @unlink($item->getPathname());
        }
    }

    return @rmdir($directory);
}

/* -------------------------------------------------------------------------
 | Session, request context
 * ---------------------------------------------------------------------- */

$https = (! empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off')
    || strtolower((string) ($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '')) === 'https'
    || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443;

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => $https,
    'httponly' => true,
    'samesite' => 'Lax',
]);

session_name('motsyomela_installer');
session_start();

if (! isset($_SESSION['csrf']) || ! is_string($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
}

$csrf = $_SESSION['csrf'];

$publicPath = dirname(__DIR__);
$installer = new Installer($publicPath);

$actions = $installer->prepareEnvironment();

$scheme = $https ? 'https' : 'http';
$host = (string) ($_SERVER['HTTP_HOST'] ?? 'localhost');
$script = str_replace('\\', '/', (string) ($_SERVER['SCRIPT_NAME'] ?? '/install/index.php'));
$installDirectory = str_replace('\\', '/', dirname($script));
$basePath = rtrim(str_replace('\\', '/', dirname($installDirectory)), '/');
$siteUrlGuess = $scheme.'://'.$host.$basePath;
$selfUrl = $script;

$isInstalled = $installer->isInstalled();
$installation = $installer->installationInfo();
$localEnvironment = $installer->hasLocalEnvironment();
$appPath = $installer->appPath();

$requestedStep = isset($_GET['step']) ? (string) $_GET['step'] : null;

/* -------------------------------------------------------------------------
 | POST actions
 * ---------------------------------------------------------------------- */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = (string) ($_POST['_token'] ?? '');

    if (! hash_equals($csrf, $token)) {
        http_response_code(419);
        echo '<!doctype html><meta charset="utf-8"><title>Session expired</title>'
            .'<body style="font:16px system-ui;padding:40px;max-width:640px;margin:auto">'
            .'<h1>Session expired</h1><p>Reload the installer and try again. Cookies must be enabled for this domain.</p>'
            .'<p><a href="'.mi_h($selfUrl).'">Reload installer</a></p></body>';
        exit;
    }

    $action = (string) ($_POST['action'] ?? '');

    if ($action === 'recheck') {
        mi_redirect($selfUrl.'?step=requirements');
    }

    if ($action === 'database') {
        $input = [
            'host' => trim((string) ($_POST['host'] ?? '')),
            'port' => (int) ($_POST['port'] ?? 3306),
            'database' => trim((string) ($_POST['database'] ?? '')),
            'username' => trim((string) ($_POST['username'] ?? '')),
            'password' => (string) ($_POST['password'] ?? ''),
            'create' => isset($_POST['create']),
        ];

        mi_flash('db_old', [
            'host' => $input['host'],
            'port' => $input['port'],
            'database' => $input['database'],
            'username' => $input['username'],
            'create' => $input['create'],
        ]);

        if ($localEnvironment) {
            mi_flash('error', 'The installer is disabled because this server already has a local .env configuration.');
            mi_redirect($selfUrl.'?step=database');
        }

        $result = $installer->testDatabase($input);

        if (! $result['ok']) {
            mi_flash('error', (string) $result['error']);
            mi_flash('detail', (string) ($result['detail'] ?? ''));
            mi_redirect($selfUrl.'?step=database');
        }

        if (! empty($result['needs_confirmation'])) {
            $_SESSION['pending_db'] = $input;
            $_SESSION['pending_db_meta'] = [
                'server' => (string) ($result['server'] ?? ''),
                'tables' => (int) ($result['tables'] ?? 0),
                'created' => (bool) ($result['created'] ?? false),
            ];
            mi_redirect($selfUrl.'?step=database&confirm=1');
        }

        $_SESSION['db'] = $input;
        $_SESSION['db_meta'] = [
            'server' => (string) ($result['server'] ?? ''),
            'tables' => (int) ($result['tables'] ?? 0),
            'created' => (bool) ($result['created'] ?? false),
        ];
        unset($_SESSION['pending_db'], $_SESSION['pending_db_meta']);

        mi_redirect($selfUrl.'?step=administrator');
    }

    if ($action === 'confirm_database') {
        $pending = $_SESSION['pending_db'] ?? null;

        if (! is_array($pending)) {
            mi_flash('error', 'The pending database connection expired. Enter the connection details again.');
            mi_redirect($selfUrl.'?step=database');
        }

        $_SESSION['db'] = $pending;
        $_SESSION['db_meta'] = $_SESSION['pending_db_meta'] ?? [];
        unset($_SESSION['pending_db'], $_SESSION['pending_db_meta']);

        mi_redirect($selfUrl.'?step=administrator');
    }

    if ($action === 'cancel_database') {
        unset($_SESSION['pending_db'], $_SESSION['pending_db_meta']);
        mi_redirect($selfUrl.'?step=database');
    }

    if ($action === 'install') {
        $database = $_SESSION['db'] ?? null;

        if (! is_array($database)) {
            mi_flash('error', 'The database connection was not verified. Enter the database details first.');
            mi_redirect($selfUrl.'?step=database');
        }

        $siteName = trim((string) ($_POST['site_name'] ?? ''));
        $siteUrl = rtrim(trim((string) ($_POST['site_url'] ?? '')), '/');
        $adminName = trim((string) ($_POST['admin_name'] ?? ''));
        $adminEmail = trim((string) ($_POST['admin_email'] ?? ''));
        $password = (string) ($_POST['admin_password'] ?? '');
        $passwordConfirmation = (string) ($_POST['admin_password_confirmation'] ?? '');
        $demo = isset($_POST['demo']);

        mi_flash('old', [
            'site_name' => $siteName,
            'site_url' => $siteUrl,
            'admin_name' => $adminName,
            'admin_email' => $adminEmail,
            'demo' => $demo,
        ]);

        $errors = [];

        if (mb_strlen($siteName) < 2 || mb_strlen($siteName) > 80) {
            $errors[] = 'The site name must be between 2 and 80 characters.';
        }

        if (! filter_var($siteUrl, FILTER_VALIDATE_URL) || ! in_array((string) parse_url($siteUrl, PHP_URL_SCHEME), ['http', 'https'], true)) {
            $errors[] = 'The site URL must start with https:// (or http://) and be a valid address, for example https://example.com.';
        }

        if (mb_strlen($adminName) < 2 || mb_strlen($adminName) > 80) {
            $errors[] = 'The administrator name must be between 2 and 80 characters.';
        }

        if (! filter_var($adminEmail, FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Enter a valid administrator email address.';
        }

        if (mb_strlen($password) < 8) {
            $errors[] = 'The administrator password must be at least 8 characters long.';
        }

        if ($password !== $passwordConfirmation) {
            $errors[] = 'The two administrator passwords do not match.';
        }

        if ($errors !== []) {
            mi_flash('error', $errors[0]);
            mi_flash('detail', implode(' ', array_slice($errors, 1)));
            mi_redirect($selfUrl.'?step=administrator');
        }

        try {
            $result = $installer->install(
                $database,
                ['name' => $adminName, 'email' => $adminEmail, 'password' => $password],
                $demo,
                $siteName,
                $siteUrl
            );
        } catch (Throwable $exception) {
            mi_flash('error', $exception->getMessage());
            mi_flash('detail', 'The installer stopped before finishing. Fix the problem above and submit again — migrations and seeders are safe to run twice. Your administrator password was not stored.');
            mi_redirect($selfUrl.'?step=administrator');
        }

        $_SESSION['result'] = $result + [
            'site_name' => $siteName,
            'site_url' => $siteUrl,
            'admin_email' => $adminEmail,
            'admin_url' => $siteUrl.'/admin',
            'demo' => $demo,
            'database' => (string) $database['database'],
        ];

        unset($_SESSION['db'], $_SESSION['db_meta'], $_SESSION['pending_db'], $_SESSION['pending_db_meta']);

        mi_redirect($selfUrl.'?step=finish');
    }

    if ($action === 'remove_installer') {
        if (! $installer->isInstalled()) {
            mi_flash('error', 'The installer can only be removed after a successful installation.');
            mi_redirect($selfUrl);
        }

        // Only the browser session that completed the installation may delete
        // the folder. Later visitors get manual instructions instead.
        if (! isset($_SESSION['result']) || ! is_array($_SESSION['result'])) {
            mi_flash('error', 'For safety, the installer can only delete itself immediately after installation. Delete public_html/install in Hostinger File Manager.');
            mi_redirect($selfUrl);
        }

        if (($_POST['confirm_remove'] ?? '') !== 'yes') {
            mi_flash('error', 'Tick the confirmation box to remove the installer folder.');
            mi_redirect($selfUrl.'?step=finish');
        }

        $removed = mi_delete_directory(__DIR__);

        // Some servers keep the directory handle open while the script runs;
        // if index.php is gone, the installer is effectively removed.
        if ($removed || ! is_file(__DIR__.'/index.php')) {
            mi_redirect(rtrim($siteUrlGuess, '/').'/');
        }

        mi_flash('error', 'Some installer files could not be removed automatically (this is normal on Windows servers). Delete the public_html/install folder with File Manager.');
        mi_redirect($selfUrl.'?step=finish');
    }

    mi_redirect($selfUrl);
}

/* -------------------------------------------------------------------------
 | Read-only state
 * ---------------------------------------------------------------------- */

$requirements = $installer->requirements();
$failures = $installer->failures($requirements);
$requirementsPassed = $failures === [] && $appPath !== null;

$dbMeta = $_SESSION['db_meta'] ?? [];
$pendingDb = isset($_SESSION['pending_db']) && is_array($_SESSION['pending_db']) ? $_SESSION['pending_db'] : null;
$pendingMeta = $_SESSION['pending_db_meta'] ?? [];
$pendingDatabase = $pendingDb !== null;
$hasDatabase = isset($_SESSION['db']) && is_array($_SESSION['db']);
$result = isset($_SESSION['result']) && is_array($_SESSION['result']) ? $_SESSION['result'] : null;

$old = mi_pull('old', []);
$dbOld = mi_pull('db_old', []);
$flashError = mi_pull('error');
$flashDetail = mi_pull('detail');

if (! is_array($old)) {
    $old = [];
}

if (! is_array($dbOld)) {
    $dbOld = [];
}

$step = $requestedStep ?: ($hasDatabase ? 'administrator' : 'requirements');

if ($isInstalled && ! ($step === 'finish' && $result !== null)) {
    $view = 'installed';
} elseif ($localEnvironment && ! $isInstalled) {
    $view = 'blocked';
} elseif ($step === 'finish') {
    if ($result === null) {
        mi_redirect($isInstalled ? $selfUrl : $selfUrl.'?step=requirements');
    }

    $view = 'finish';
} elseif ($step === 'administrator') {
    if (! $hasDatabase) {
        mi_flash('error', 'Verify the database connection before creating the administrator account.');
        mi_redirect($selfUrl.'?step=database');
    }

    $view = 'administrator';
} elseif ($step === 'database') {
    $view = 'database';
} else {
    $view = 'requirements';
}

$dbDefaults = $dbOld + [
    'host' => 'localhost',
    'port' => 3306,
    'database' => '',
    'username' => '',
    'create' => true,
];

$siteUrlDefault = (string) (($old['site_url'] ?? $siteUrlGuess) ?: 'https://example.com');

$stepper = [
    1 => ['label' => 'Requirements', 'view' => 'requirements'],
    2 => ['label' => 'Database', 'view' => 'database'],
    3 => ['label' => 'Administrator', 'view' => 'administrator'],
    4 => ['label' => 'Finish', 'view' => 'finish'],
];

$currentStepNumber = match ($view) {
    'requirements' => 1,
    'database' => 2,
    'administrator' => 3,
    'finish' => 4,
    default => 0,
};

$lede = match ($view) {
    'requirements' => 'The installer checks PHP, required extensions and folder permissions before writing anything. Missing runtime folders are created automatically.',
    'database' => 'Enter the MySQL database Hostinger created for this domain. The connection is tested before the configuration is written.',
    'administrator' => 'Choose the store name, public address and the first administrator account. Demo content is optional.',
    'finish' => 'The store is installed. Complete the short checklist below, then delete the installer folder.',
    'installed' => 'This copy of MotsyoMela is already installed and the installer is locked.',
    default => 'The installer is not available on this copy of the application.',
};

$pageTitle = match ($view) {
    'requirements' => 'Server requirements',
    'database' => $pendingDatabase ? 'Confirm existing database' : 'Database connection',
    'administrator' => 'Administrator account',
    'finish' => 'Installation complete',
    'installed' => 'Already installed',
    default => 'Installer disabled',
};

$installerVersion = $installer->version();
$demoAvailable = true;

/* -------------------------------------------------------------------------
 | Render
 * ---------------------------------------------------------------------- */

ob_start();
require __DIR__.'/views/'.$view.'.php';
$content = (string) ob_get_clean();

require __DIR__.'/views/layout.php';
