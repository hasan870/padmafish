<?php
/** @var array{host: string, port: int, database: string, username: string, create: bool} $dbDefaults */
/** @var array{host: string, port: int, database: string, username: string, password: string, create: bool}|null $pendingDb */
/** @var array{server?: string, tables?: int, created?: bool} $pendingMeta */
/** @var array{server?: string, tables?: int, created?: bool} $dbMeta */
/** @var bool $pendingDatabase */
/** @var string $selfUrl */
/** @var string $csrf */
/** @var string $siteUrlGuess */
?>

<?php if ($pendingDatabase): ?>
    <div class="alert alert-warn">
        <strong>This database already contains data</strong>
        <code><?= mi_h($pendingDb['database']) ?></code> has
        <strong><?= mi_h((string) ($pendingMeta['tables'] ?? 0)) ?> existing tables</strong>.
        Continuing will run the new migrations and seed the default settings. Existing orders, products and customers are
        <strong>not deleted</strong>, but demo sample records may be refreshed.
    </div>

    <div class="summary">
        <h2 class="summary-title">Connection that was verified</h2>
        <dl class="kv">
            <dt>MySQL host</dt>
            <dd><code><?= mi_h($pendingDb['host']) ?>:<?= mi_h((string) ($pendingDb['port'] ?? 3306)) ?></code></dd>
            <dt>Database name</dt>
            <dd><code><?= mi_h($pendingDb['database']) ?></code></dd>
            <dt>Username</dt>
            <dd><code><?= mi_h($pendingDb['username']) ?></code></dd>
            <dt>Server</dt>
            <dd><?= mi_h((string) ($pendingMeta['server'] ?? 'MySQL')) ?></dd>
            <dt>Existing tables</dt>
            <dd><?= mi_h((string) ($pendingMeta['tables'] ?? 0)) ?></dd>
        </dl>
    </div>

    <div class="alert alert-info" style="margin-top:18px">
        <strong>Is this the right database?</strong>
        If this database belongs to another website or application, cancel and create a separate database in Hostinger hPanel.
        Migrations are additive, but the installer must not be pointed at a database you do not own.
    </div>

    <div class="actions">
        <form method="post" action="<?= mi_h($selfUrl) ?>" style="margin:0">
            <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
            <input type="hidden" name="action" value="confirm_database">
            <button type="submit" class="btn btn-primary">Use this database &amp; continue →</button>
        </form>
        <form method="post" action="<?= mi_h($selfUrl) ?>" style="margin:0">
            <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
            <input type="hidden" name="action" value="cancel_database">
            <button type="submit" class="btn btn-secondary">Choose another database</button>
        </form>
    </div>
<?php else: ?>
    <form method="post" action="<?= mi_h($selfUrl) ?>" autocomplete="off">
        <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
        <input type="hidden" name="action" value="database">

        <div class="grid-2">
            <div class="field">
                <label for="host">MySQL host</label>
                <input type="text" id="host" name="host" value="<?= mi_h((string) $dbDefaults['host']) ?>" placeholder="localhost" required>
                <p class="help">Hostinger uses <code>localhost</code>. Use <code>127.0.0.1</code> only if your host requires it.</p>
            </div>

            <div class="field">
                <label for="port">Port</label>
                <input type="number" id="port" name="port" value="<?= mi_h((string) $dbDefaults['port']) ?>" min="1" max="65535" required>
                <p class="help">The default MySQL port is <code>3306</code>.</p>
            </div>
        </div>

        <div class="field">
            <label for="database">Database name</label>
            <input type="text" id="database" name="database" value="<?= mi_h((string) $dbDefaults['database']) ?>" placeholder="u123456_motsyomela" required>
            <p class="help">Copy the full name from hPanel, including the <code>u123456_</code> prefix.</p>
        </div>

        <div class="grid-2">
            <div class="field">
                <label for="username">MySQL username</label>
                <input type="text" id="username" name="username" value="<?= mi_h((string) $dbDefaults['username']) ?>" placeholder="u123456_motsyomela" required>
                <p class="help">Usually the same prefix as the database.</p>
            </div>

            <div class="field">
                <label for="password">MySQL password</label>
                <input type="password" id="password" name="password" value="" placeholder="Database user password" autocomplete="new-password">
                <p class="help">Not your Hostinger account password. It is saved in <code>.env</code>, outside the web root.</p>
            </div>
        </div>

        <label class="checkbox" for="create">
            <input type="checkbox" id="create" name="create" value="1" <?= ! empty($dbDefaults['create']) ? 'checked' : '' ?>>
            <span>
                <strong>Create the database automatically if it does not exist</strong><br>
                Only works when the MySQL user has CREATE permission. If your host does not allow it, create the database
                first in hPanel and leave this ticked — the installer will use the existing one.
            </span>
        </label>

        <div class="alert alert-info" style="margin:18px 0 0">
            <strong>Where to find these details on Hostinger</strong>
            <ol style="margin:8px 0 0;padding-left:18px">
                <li>Open <b>hPanel → Websites → Manage</b> for this domain.</li>
                <li>Go to <b>Databases → MySQL Databases</b>.</li>
                <li>Create a database and a database user, then attach the user to the database.</li>
                <li>Copy the host (<code>localhost</code>), database name, username and password into this form.</li>
            </ol>
            <p style="margin:8px 0 0">The connection is tested before anything is written. If the database has existing tables you will be asked to confirm first.</p>
        </div>

        <div class="actions">
            <a class="btn btn-secondary" href="<?= mi_h($selfUrl) ?>?step=requirements">← Back</a>
            <span class="spacer"></span>
            <button type="submit" class="btn btn-primary">Test connection &amp; continue →</button>
        </div>
    </form>
<?php endif; ?>
