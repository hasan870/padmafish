<?php
/** @var string $content */
/** @var string $pageTitle */
/** @var string $installerVersion */
/** @var array<int, array{label: string, view: string}> $stepper */
/** @var int $currentStepNumber */
/** @var string $view */
?><!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex, nofollow">
    <meta name="color-scheme" content="light">
    <title><?= mi_h($pageTitle) ?> · MotsyoMela Installer</title>
    <style>
        :root {
            --bg: #f4f9f9;
            --card: #ffffff;
            --ink: #0f2a2e;
            --ink-2: #446065;
            --ink-3: #789094;
            --line: #dcebea;
            --aqua: #0d9488;
            --aqua-dark: #0f766e;
            --sky: #0284c7;
            --gold: #d97706;
            --ok: #0f9d58;
            --ok-soft: #e7f7ef;
            --warn: #b45309;
            --warn-soft: #fff7e6;
            --fail: #c0392b;
            --fail-soft: #fdeceb;
            --radius: 18px;
            --shadow: 0 24px 60px -30px rgba(9, 66, 71, .45);
        }

        * { box-sizing: border-box; }

        html, body { margin: 0; padding: 0; }

        body {
            min-height: 100vh;
            font-family: "Hind Siliguri", "Noto Sans Bengali", ui-sans-serif, system-ui, -apple-system, "Segoe UI", Roboto, Arial, sans-serif;
            color: var(--ink);
            background:
                radial-gradient(900px 420px at 8% -5%, #cdf5ef 0%, rgba(205, 245, 239, 0) 60%),
                radial-gradient(760px 420px at 96% 0%, #dcefff 0%, rgba(220, 239, 255, 0) 55%),
                linear-gradient(180deg, #f8fdfd 0%, var(--bg) 100%);
            -webkit-font-smoothing: antialiased;
        }

        .shell {
            width: min(980px, calc(100% - 32px));
            margin: 0 auto;
            padding: 34px 0 56px;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 14px;
            margin-bottom: 26px;
        }

        .brand-mark {
            width: 52px;
            height: 52px;
            border-radius: 16px;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #14b8a6, #0284c7);
            box-shadow: 0 14px 30px -14px rgba(2, 132, 199, .8);
            flex: 0 0 auto;
        }

        .brand-mark svg { width: 30px; height: 30px; display: block; }

        .brand-title { font-size: 19px; font-weight: 800; letter-spacing: .2px; line-height: 1.15; }
        .brand-sub { font-size: 12.5px; color: var(--ink-3); margin-top: 3px; }

        .card {
            background: var(--card);
            border: 1px solid var(--line);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            overflow: hidden;
        }

        .card-head {
            padding: 26px 30px 22px;
            border-bottom: 1px solid var(--line);
            background: linear-gradient(180deg, #ffffff, #f9fdfd);
        }

        .eyebrow {
            font-size: 11px;
            font-weight: 800;
            letter-spacing: .14em;
            text-transform: uppercase;
            color: var(--aqua);
            margin-bottom: 8px;
        }

        h1 { font-size: clamp(22px, 3.4vw, 29px); margin: 0; letter-spacing: -.4px; line-height: 1.2; }
        .lede { color: var(--ink-2); font-size: 14px; line-height: 1.65; margin: 10px 0 0; max-width: 68ch; }

        .card-body { padding: 26px 30px 30px; }

        .stepper {
            display: flex;
            align-items: center;
            gap: 6px;
            padding: 18px 30px;
            border-bottom: 1px solid var(--line);
            background: #fbfefe;
            overflow-x: auto;
            scrollbar-width: none;
        }

        .stepper::-webkit-scrollbar { display: none; }

        .step {
            display: flex;
            align-items: center;
            gap: 9px;
            flex: 0 0 auto;
            color: var(--ink-3);
            font-size: 12.5px;
            font-weight: 700;
            padding: 4px 2px;
        }

        .step-num {
            width: 24px;
            height: 24px;
            border-radius: 50%;
            display: grid;
            place-items: center;
            background: #eef6f6;
            border: 1px solid var(--line);
            font-size: 11.5px;
            font-weight: 800;
        }

        .step.current { color: var(--ink); }
        .step.current .step-num { background: linear-gradient(135deg, #14b8a6, #0284c7); border-color: transparent; color: #fff; }
        .step.done { color: var(--aqua-dark); }
        .step.done .step-num { background: var(--ok-soft); border-color: #c7ebda; color: var(--ok); }

        .step-line { height: 1px; flex: 1 0 18px; min-width: 18px; background: var(--line); }

        .section + .section { margin-top: 26px; }

        .section-title {
            font-size: 12px;
            font-weight: 800;
            letter-spacing: .1em;
            text-transform: uppercase;
            color: var(--ink-3);
            margin: 0 0 12px;
        }

        .check-list { display: grid; gap: 8px; margin: 0; padding: 0; list-style: none; }

        .check {
            display: grid;
            grid-template-columns: 26px 1fr;
            gap: 11px;
            padding: 11px 13px;
            border: 1px solid var(--line);
            border-radius: 12px;
            background: #fcfefe;
        }

        .check-icon {
            width: 22px;
            height: 22px;
            border-radius: 50%;
            display: grid;
            place-items: center;
            font-size: 12px;
            font-weight: 900;
            margin-top: 1px;
        }

        .check.is-ok .check-icon { background: var(--ok-soft); color: var(--ok); }
        .check.is-warn .check-icon { background: var(--warn-soft); color: var(--warn); }
        .check.is-fail .check-icon { background: var(--fail-soft); color: var(--fail); }
        .check.is-fail { border-color: #f3cfcb; background: #fffafa; }

        .check-label { font-size: 13.5px; font-weight: 700; line-height: 1.45; }
        .check-detail { font-size: 12px; color: var(--ink-3); line-height: 1.55; margin-top: 2px; word-break: break-word; }

        .alert {
            border-radius: 13px;
            padding: 14px 16px;
            font-size: 13px;
            line-height: 1.6;
            border: 1px solid transparent;
            margin: 0 0 20px;
        }

        .alert strong { display: block; font-size: 13.5px; margin-bottom: 3px; }
        .alert-error { background: var(--fail-soft); border-color: #f3cfcb; color: #7f231a; }
        .alert-warn { background: var(--warn-soft); border-color: #f5dfb3; color: #6d4407; }
        .alert-ok { background: var(--ok-soft); border-color: #c7ebda; color: #0a5b39; }
        .alert-info { background: #eef7ff; border-color: #cfe7fa; color: #0b4468; }

        .alert ul { margin: 8px 0 0; padding-left: 18px; }
        .alert li + li { margin-top: 4px; }

        .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 0 16px; }
        .grid-3 { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 12px; }

        .field { margin-bottom: 17px; }

        .field > label,
        .label {
            display: block;
            font-size: 12.5px;
            font-weight: 800;
            margin-bottom: 6px;
            color: #1c3b40;
        }

        .field .help { font-size: 11.5px; color: var(--ink-3); line-height: 1.5; margin-top: 5px; }

        input[type="text"], input[type="password"], input[type="email"], input[type="url"], input[type="number"], select {
            width: 100%;
            border: 1px solid #cfe1e0;
            border-radius: 11px;
            padding: 11px 13px;
            font-size: 14px;
            font-family: inherit;
            color: var(--ink);
            background: #fff;
            transition: border-color .15s ease, box-shadow .15s ease;
        }

        input:focus, select:focus {
            outline: none;
            border-color: #14b8a6;
            box-shadow: 0 0 0 4px rgba(20, 184, 166, .14);
        }

        input::placeholder { color: #a7bdbd; }

        .checkbox {
            display: grid;
            grid-template-columns: 20px 1fr;
            gap: 10px;
            align-items: start;
            padding: 13px 14px;
            border: 1px solid var(--line);
            border-radius: 12px;
            background: #fbfefe;
            font-size: 13px;
            line-height: 1.55;
            color: var(--ink-2);
            cursor: pointer;
        }

        .checkbox input { width: 17px; height: 17px; margin: 1px 0 0; accent-color: var(--aqua); }
        .checkbox strong { color: var(--ink); }

        .actions {
            display: flex;
            flex-wrap: wrap;
            align-items: center;
            gap: 10px 14px;
            margin-top: 24px;
        }

        .actions .spacer { flex: 1 1 auto; }

        .btn {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            gap: 8px;
            padding: 12px 20px;
            border-radius: 11px;
            border: 1px solid transparent;
            font-family: inherit;
            font-size: 13.5px;
            font-weight: 800;
            cursor: pointer;
            text-decoration: none;
            line-height: 1.2;
            transition: transform .12s ease, box-shadow .15s ease, background .15s ease;
        }

        .btn-primary {
            color: #fff;
            background: linear-gradient(135deg, #14b8a6, #0284c7);
            box-shadow: 0 14px 26px -14px rgba(2, 132, 199, .75);
        }

        .btn-primary:hover { transform: translateY(-1px); box-shadow: 0 18px 30px -16px rgba(2, 132, 199, .8); }
        .btn-primary:active { transform: translateY(0); }

        .btn-secondary {
            color: #1c3b40;
            background: #fff;
            border-color: #cfe1e0;
        }

        .btn-secondary:hover { background: #f4fbfa; }

        .btn-ghost { color: var(--ink-2); background: transparent; padding-inline: 4px; }
        .btn-ghost:hover { color: var(--ink); }

        .btn-danger {
            color: #fff;
            background: #b3261e;
            box-shadow: 0 12px 24px -16px rgba(179, 38, 30, .8);
        }

        .btn[disabled], .btn[aria-disabled="true"] {
            opacity: .45;
            pointer-events: none;
            box-shadow: none;
        }

        .btn-sm { padding: 9px 14px; font-size: 12.5px; border-radius: 9px; }

        .note { font-size: 12px; color: var(--ink-3); line-height: 1.6; }
        .note a { color: var(--aqua-dark); }

        .kv {
            display: grid;
            grid-template-columns: 160px 1fr;
            gap: 2px 16px;
            font-size: 13px;
            line-height: 1.6;
        }

        .kv dt { color: var(--ink-3); font-weight: 600; }
        .kv dd { margin: 0; color: var(--ink); font-weight: 700; word-break: break-word; }

        .summary {
            border: 1px solid var(--line);
            border-radius: 14px;
            padding: 16px 18px;
            background: #fbfefe;
        }

        .summary + .summary { margin-top: 10px; }

        .summary-title { font-size: 11px; font-weight: 800; letter-spacing: .1em; text-transform: uppercase; color: var(--ink-3); margin: 0 0 10px; }

        .badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 4px 10px;
            border-radius: 999px;
            font-size: 11.5px;
            font-weight: 800;
            background: #eef6f6;
            color: var(--ink-2);
            border: 1px solid var(--line);
        }

        .badge-ok { background: var(--ok-soft); color: #0a5b39; border-color: #c7ebda; }
        .badge-warn { background: var(--warn-soft); color: #6d4407; border-color: #f5dfb3; }

        code, .mono {
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, "Liberation Mono", monospace;
            font-size: 12px;
            background: #f1f7f7;
            border: 1px solid #e0eceb;
            border-radius: 6px;
            padding: 1px 6px;
            word-break: break-all;
        }

        .path-list { margin: 0; padding: 0; list-style: none; display: grid; gap: 6px; font-size: 12px; }
        .path-list li { display: flex; gap: 8px; align-items: baseline; }
        .path-list li::before { content: "→"; color: var(--aqua); font-weight: 800; }

        .layout-diagram {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 10px;
            margin-top: 10px;
        }

        .layout-box {
            border: 1px dashed #c3dedd;
            border-radius: 12px;
            padding: 12px 14px;
            background: #fbfefe;
            font-family: ui-monospace, SFMono-Regular, Menlo, Consolas, monospace;
            font-size: 11.5px;
            line-height: 1.7;
            color: #33575c;
        }

        .layout-box b { color: var(--ink); }

        .success-hero {
            display: flex;
            gap: 16px;
            align-items: flex-start;
            padding: 18px;
            border-radius: 15px;
            background: linear-gradient(135deg, #ecfdf7, #eef7ff);
            border: 1px solid #c7ebda;
        }

        .success-mark {
            width: 44px;
            height: 44px;
            border-radius: 50%;
            display: grid;
            place-items: center;
            background: linear-gradient(135deg, #10b981, #059669);
            color: #fff;
            font-size: 20px;
            font-weight: 900;
            flex: 0 0 auto;
            box-shadow: 0 10px 22px -12px rgba(5, 150, 105, .9);
        }

        .success-hero h2 { margin: 0 0 4px; font-size: 17px; }
        .success-hero p { margin: 0; font-size: 12.5px; color: var(--ink-2); line-height: 1.55; }

        .steps-done { display: grid; gap: 6px; margin: 14px 0 0; padding: 0; list-style: none; }

        .steps-done li {
            display: grid;
            grid-template-columns: 20px 1fr;
            gap: 8px;
            font-size: 12.5px;
            line-height: 1.5;
            color: var(--ink-2);
        }

        .steps-done .tick { color: var(--ok); font-weight: 900; }
        .steps-done b { color: var(--ink); font-weight: 700; }

        .post-list { margin: 0; padding: 0; list-style: none; counter-reset: post; display: grid; gap: 9px; }

        .post-list li {
            counter-increment: post;
            display: grid;
            grid-template-columns: 24px 1fr;
            gap: 10px;
            font-size: 12.5px;
            line-height: 1.6;
            color: var(--ink-2);
        }

        .post-list li::before {
            content: counter(post);
            width: 22px;
            height: 22px;
            border-radius: 7px;
            display: grid;
            place-items: center;
            background: #eef6f6;
            border: 1px solid var(--line);
            font-size: 11px;
            font-weight: 800;
            color: var(--ink-2);
        }

        .post-list b { color: var(--ink); }

        .danger-zone {
            margin-top: 26px;
            padding: 16px 18px;
            border: 1px solid #f3cfcb;
            border-radius: 14px;
            background: #fffafa;
        }

        .danger-zone h3 { margin: 0 0 4px; font-size: 14px; color: #7f231a; }

        footer {
            margin-top: 22px;
            display: flex;
            flex-wrap: wrap;
            gap: 8px 18px;
            justify-content: space-between;
            font-size: 11.5px;
            color: var(--ink-3);
        }

        footer a { color: var(--ink-2); text-decoration: none; border-bottom: 1px dotted #b9cfce; }

        .link-row { display: flex; flex-wrap: wrap; gap: 10px; margin-top: 14px; }

        @media (max-width: 720px) {
            .shell { padding-top: 20px; }
            .card-head, .card-body { padding-left: 18px; padding-right: 18px; }
            .stepper { padding-left: 18px; padding-right: 18px; }
            .step span.step-label { display: none; }
            .step-line { flex: 1 0 10px; }
            .grid-2, .grid-3, .layout-diagram { grid-template-columns: 1fr; }
            .kv { grid-template-columns: 1fr; gap: 1px; }
            .kv dd { margin-bottom: 8px; }
        }

        .spin { display: inline-block; width: 14px; height: 14px; border: 2px solid rgba(255,255,255,.45); border-top-color: #fff; border-radius: 50%; animation: spin .8s linear infinite; }
        @keyframes spin { to { transform: rotate(360deg); } }
    </style>
</head>
<body>
<div class="shell">
    <header class="brand">
        <div class="brand-mark" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="#fff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">
                <path d="M2.5 12c3.2-4.6 7-6.9 11.4-6.9 2.2 0 4.4 1.1 6.6 3.3-1.1 2.4-1.1 4.8 0 7.2-4.4 3.1-8.4 3.1-12 0"/>
                <circle cx="8.4" cy="10.2" r=".9" fill="#fff" stroke="none"/>
                <path d="M14.5 9.4c1 .4 2 1 3 1.8"/>
            </svg>
        </div>
        <div>
            <div class="brand-title">মৎস্যমেলা <span style="font-weight:600;color:#789094">· Installer</span></div>
            <div class="brand-sub">Fresh fish store · Laravel application setup</div>
        </div>
    </header>

    <main class="card">
        <?php if ($currentStepNumber > 0): ?>
            <nav class="stepper" aria-label="Installation progress">
                <?php foreach ($stepper as $number => $item): ?>
                    <?php
                    $state = $number < $currentStepNumber ? 'done' : ($number === $currentStepNumber ? 'current' : '');
                    ?>
                    <div class="step <?= $state ?>" <?= $number === $currentStepNumber ? 'aria-current="step"' : '' ?>>
                        <span class="step-num"><?= $number < $currentStepNumber ? '✓' : $number ?></span>
                        <span class="step-label"><?= mi_h($item['label']) ?></span>
                    </div>
                    <?php if ($number < count($stepper)): ?>
                        <span class="step-line" aria-hidden="true"></span>
                    <?php endif; ?>
                <?php endforeach; ?>
            </nav>
        <?php endif; ?>

        <div class="card-head">
            <div class="eyebrow"><?= $view === 'installed' || $view === 'blocked' ? 'System status' : 'Step '.$currentStepNumber.' of '.count($stepper) ?></div>
            <h1><?= mi_h($pageTitle) ?></h1>
            <?php if (! empty($lede)): ?>
                <p class="lede"><?= mi_h($lede) ?></p>
            <?php endif; ?>
        </div>

        <div class="card-body">
            <?php if (! empty($flashError)): ?>
                <div class="alert alert-error" role="alert">
                    <strong>Installation could not continue</strong>
                    <?= nl2br(mi_h((string) $flashError)) ?>
                    <?php if (! empty($flashDetail)): ?>
                        <div style="margin-top:8px;font-size:12px;line-height:1.6;color:#8a3b32"><?= nl2br(mi_h((string) $flashDetail)) ?></div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>

            <?= $content ?>
        </div>
    </main>

    <footer>
        <span>MotsyoMela Installer v<?= mi_h($installerVersion) ?> · PHP <?= mi_h(PHP_VERSION) ?></span>
        <span>Keep the <code>motsyomela</code> folder outside <code>public_html</code>.</span>
    </footer>
</div>
<script>
    document.querySelectorAll('form[data-installing]').forEach(function (form) {
        form.addEventListener('submit', function () {
            var button = form.querySelector('button[type="submit"]');
            if (!button || button.dataset.busy === '1') {
                return;
            }
            button.dataset.busy = '1';
            button.disabled = true;
            button.innerHTML = '<span class="spin" aria-hidden="true"></span> ' + (button.dataset.busyLabel || 'Installing…');
        });
    });

    document.querySelectorAll('[data-confirm]').forEach(function (element) {
        element.addEventListener('submit', function (event) {
            if (!window.confirm(element.dataset.confirm)) {
                event.preventDefault();
            }
        });
    });
</script>
</body>
</html>
