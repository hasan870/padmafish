<?php
/** @var Installer $installer */
/** @var list<array{title: string, items: list<array<string, mixed>>}> $requirements */
/** @var list<array<string, mixed>> $failures */
/** @var bool $requirementsPassed */
/** @var list<string> $actions */
/** @var string|null $appPath */
/** @var string $publicPath */
/** @var string $siteUrlGuess */
/** @var string $selfUrl */
/** @var string $csrf */

$warnings = 0;

foreach ($requirements as $group) {
    foreach ($group['items'] as $item) {
        if (! $item['required'] && ! $item['ok']) {
            $warnings++;
        }
    }
}
?>

<?php if ($appPath === null): ?>
    <div class="alert alert-error">
        <strong>Application folder not found</strong>
        The installer can see <code><?= mi_h($publicPath) ?></code>, but the Laravel application files are not beside it.
        Extract the installation ZIP so the two folders sit together, then reload this page.
    </div>

    <div class="layout-diagram" aria-label="Expected folder layout">
        <div class="layout-box">
            <b>domains/example.com/</b><br>
            ├── <b>public_html/</b> &nbsp;<span style="color:#789094">← put these files in public_html</span><br>
            │&nbsp;&nbsp;&nbsp;├── index.php<br>
            │&nbsp;&nbsp;&nbsp;├── .htaccess<br>
            │&nbsp;&nbsp;&nbsp;└── install/
        </div>
        <div class="layout-box">
            <b>domains/example.com/</b><br>
            └── <b>motsyomela/</b> &nbsp;<span style="color:#789094">← the application</span><br>
            &nbsp;&nbsp;&nbsp;&nbsp;├── app/<br>
            &nbsp;&nbsp;&nbsp;&nbsp;├── vendor/<br>
            &nbsp;&nbsp;&nbsp;&nbsp;└── bootstrap/
        </div>
    </div>

    <div class="alert alert-info" style="margin-top:18px;margin-bottom:0">
        <strong>Extracting on Hostinger</strong>
        Upload the ZIP one level above <code>public_html</code> (inside <code>domains/yourdomain.com/</code>), extract it there,
        and keep both folders — <code>public_html</code> and <code>motsyomela</code> — as siblings.
    </div>
<?php else: ?>

    <?php if ($failures !== []): ?>
        <div class="alert alert-error">
            <strong><?= count($failures) === 1 ? 'One requirement must be fixed' : count($failures).' requirements must be fixed' ?></strong>
            <ul>
                <?php foreach ($failures as $failure): ?>
                    <li><?= mi_h($failure['label']) ?> — <?= mi_h($failure['detail']) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php else: ?>
        <div class="alert alert-ok">
            <strong>Your server is ready</strong>
            PHP <?= mi_h(PHP_VERSION) ?> and every required extension are available.<?= $warnings > 0 ? ' '.$warnings.' optional recommendation'.($warnings === 1 ? '' : 's').' can still be improved — see the amber items below.' : '' ?>
        </div>
    <?php endif; ?>

    <?php if ($actions !== []): ?>
        <div class="alert alert-info">
            <strong>Automatic setup performed</strong>
            <ul>
                <?php foreach ($actions as $action): ?>
                    <li><?= mi_h($action) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <?php foreach ($requirements as $group): ?>
        <section class="section">
            <h2 class="section-title"><?= mi_h($group['title']) ?></h2>
            <ul class="check-list">
                <?php foreach ($group['items'] as $item): ?>
                    <?php
                    if ($item['ok']) {
                        $state = 'is-ok';
                        $icon = '✓';
                    } elseif ($item['required']) {
                        $state = 'is-fail';
                        $icon = '×';
                    } else {
                        $state = 'is-warn';
                        $icon = '!';
                    }
                    ?>
                    <li class="check <?= $state ?>">
                        <span class="check-icon" aria-hidden="true"><?= $icon ?></span>
                        <span>
                            <span class="check-label"><?= mi_h($item['label']) ?></span>
                            <?php if ($state === 'is-warn'): ?>
                                <span class="badge badge-warn" style="margin-left:6px">Recommended</span>
                            <?php endif; ?>
                            <span class="check-detail"><?= mi_h($item['detail']) ?></span>
                        </span>
                    </li>
                <?php endforeach; ?>
            </ul>
        </section>
    <?php endforeach; ?>

    <section class="section">
        <h2 class="section-title">Installation target</h2>
        <div class="summary">
            <dl class="kv">
                <dt>Public folder</dt>
                <dd><code><?= mi_h($publicPath) ?></code></dd>
                <dt>Application folder</dt>
                <dd><code><?= mi_h((string) $appPath) ?></code></dd>
                <dt>Detected site URL</dt>
                <dd><?= mi_h($siteUrlGuess) ?></dd>
                <dt>Folder layout</dt>
                <dd>
                    <?php if ($installer->appIsInsidePublicPath()): ?>
                        <span class="badge badge-warn">Application inside public_html</span>
                        <div class="note" style="margin-top:6px">
                            This works because the application folder ships with an .htaccess that blocks direct access,
                            but the safer layout places <code>motsyomela</code> next to <code>public_html</code>.
                        </div>
                    <?php else: ?>
                        <span class="badge badge-ok">Recommended layout</span>
                    <?php endif; ?>
                </dd>
            </dl>
        </div>
        <p class="note" style="margin-top:10px">
            Nothing is written to the database yet. Configuration is only saved after the database and administrator steps.
        </p>
    </section>

    <div class="actions">
        <form method="post" action="<?= mi_h($selfUrl) ?>" style="margin:0">
            <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
            <input type="hidden" name="action" value="recheck">
            <button type="submit" class="btn btn-secondary">Check again</button>
        </form>

        <span class="spacer"></span>

        <?php if ($requirementsPassed): ?>
            <a class="btn btn-primary" href="<?= mi_h($selfUrl) ?>?step=database">Continue to database →</a>
        <?php else: ?>
            <span class="btn btn-primary" aria-disabled="true">Fix the items above to continue</span>
        <?php endif; ?>
    </div>
<?php endif; ?>
