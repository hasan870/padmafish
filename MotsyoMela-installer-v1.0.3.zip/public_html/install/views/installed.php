<?php
/** @var array<string, mixed> $installation */
/** @var string $selfUrl */
/** @var string $csrf */
/** @var string $siteUrlGuess */
/** @var string|null $appPath */

$siteUrl = rtrim((string) ($installation['site_url'] ?? $siteUrlGuess), '/');
$adminUrl = $siteUrl.'/admin';
$installedAt = (string) ($installation['installed_at'] ?? '');
$installedTimestamp = $installedAt !== '' ? strtotime($installedAt) : false;
?>

<div class="alert alert-ok">
    <strong>Installation locked</strong>
    MotsyoMela is already installed on this copy, so the installer will not write to the database again.
    The lock file lives in <code>motsyomela/storage/app/installed.lock</code>.
</div>

<section class="section">
    <h2 class="section-title">Installed store</h2>
    <div class="summary">
        <dl class="kv">
            <dt>Storefront</dt>
            <dd><a href="<?= mi_h($siteUrl) ?>/" target="_blank" rel="noopener"><?= mi_h($siteUrl) ?></a></dd>
            <dt>Admin panel</dt>
            <dd><a href="<?= mi_h($adminUrl) ?>" target="_blank" rel="noopener"><?= mi_h($adminUrl) ?></a></dd>
            <?php if ($installedTimestamp !== false): ?>
                <dt>Installed at</dt>
                <dd><?= mi_h(date('j F Y, H:i', $installedTimestamp)) ?></dd>
            <?php endif; ?>
            <?php if (! empty($installation['version'])): ?>
                <dt>Installer version</dt>
                <dd>v<?= mi_h((string) $installation['version']) ?></dd>
            <?php endif; ?>
        </dl>
    </div>
    <div class="link-row">
        <a class="btn btn-primary" href="<?= mi_h($adminUrl) ?>">Open admin panel →</a>
        <a class="btn btn-secondary" href="<?= mi_h($siteUrl) ?>/">Open storefront</a>
    </div>
</section>

<div class="alert alert-info">
    <strong>Need to change the database or reinstall?</strong>
    Delete <code>motsyomela/.env</code> and <code>motsyomela/storage/app/installed.lock</code> first if you really intend to run the
    installer again. Only do this on a fresh copy — running it over a live store can overwrite the administrator password.
</div>

<div class="danger-zone">
    <h3>Remove the installer</h3>
    <p class="note" style="margin:0 0 12px">
        The installation is finished, so the installer folder is no longer needed. For safety it can only delete itself
        from the browser session that completed the installation. Otherwise delete <code>public_html/install</code>
        manually in Hostinger File Manager. The store keeps working either way.
    </p>
</div>
