<?php
/** @var array<string, mixed> $old */
/** @var array<string, mixed> $dbMeta */
/** @var string $selfUrl */
/** @var string $csrf */
/** @var string $siteUrlDefault */
/** @var array<string, mixed> $result */

$database = isset($_SESSION['db']) && is_array($_SESSION['db']) ? $_SESSION['db'] : [];

$siteNameDefault = (string) ($old['site_name'] ?? 'মৎস্যমেলা');
$adminNameDefault = (string) ($old['admin_name'] ?? '');
$adminEmailDefault = (string) ($old['admin_email'] ?? '');
$demoDefault = ! isset($old['demo']) || (bool) $old['demo'];
?>

<div class="summary">
    <h2 class="summary-title">Database verified</h2>
    <dl class="kv">
        <dt>Database</dt>
        <dd>
            <code><?= mi_h((string) ($database['database'] ?? '')) ?></code>
            <?php if (! empty($dbMeta['created'])): ?>
                <span class="badge badge-ok" style="margin-left:6px">Created by installer</span>
            <?php endif; ?>
        </dd>
        <dt>User</dt>
        <dd><code><?= mi_h((string) ($database['username'] ?? '')) ?></code></dd>
        <dt>Server</dt>
        <dd><?= mi_h((string) ($dbMeta['server'] ?? 'MySQL')) ?></dd>
        <dt>Existing tables</dt>
        <dd><?= mi_h((string) ($dbMeta['tables'] ?? 0)) ?></dd>
    </dl>
    <p class="note" style="margin:10px 0 0">
        <a href="<?= mi_h($selfUrl) ?>?step=database">Change database connection</a>
    </p>
</div>

<form method="post" action="<?= mi_h($selfUrl) ?>" autocomplete="off" data-installing>
    <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
    <input type="hidden" name="action" value="install">

    <section class="section">
        <h2 class="section-title">Store</h2>

        <div class="grid-2">
            <div class="field">
                <label for="site_name">Store name</label>
                <input type="text" id="site_name" name="site_name" value="<?= mi_h($siteNameDefault) ?>" maxlength="80" required>
                <p class="help">Shown in the storefront header, page titles and invoices. Bangla or English both work.</p>
            </div>

            <div class="field">
                <label for="site_url">Public site URL</label>
                <input type="url" id="site_url" name="site_url" value="<?= mi_h((string) ($old['site_url'] ?? $siteUrlDefault)) ?>" placeholder="https://example.com" required>
                <p class="help">Use the final HTTPS address, without a trailing slash. This becomes <code>APP_URL</code>.</p>
            </div>
        </div>
    </section>

    <section class="section">
        <h2 class="section-title">First administrator</h2>

        <div class="grid-2">
            <div class="field">
                <label for="admin_name">Full name</label>
                <input type="text" id="admin_name" name="admin_name" value="<?= mi_h($adminNameDefault) ?>" maxlength="80" required>
            </div>

            <div class="field">
                <label for="admin_email">Email address</label>
                <input type="email" id="admin_email" name="admin_email" value="<?= mi_h($adminEmailDefault) ?>" maxlength="150" required>
                <p class="help">Used to sign in at <code>/admin</code> and for new-order notifications.</p>
            </div>
        </div>

        <div class="grid-2">
            <div class="field">
                <label for="admin_password">Password</label>
                <input type="password" id="admin_password" name="admin_password" minlength="8" autocomplete="new-password" required>
                <p class="help">At least 8 characters. Stored hashed — it cannot be recovered.</p>
            </div>

            <div class="field">
                <label for="admin_password_confirmation">Repeat password</label>
                <input type="password" id="admin_password_confirmation" name="admin_password_confirmation" minlength="8" autocomplete="new-password" required>
            </div>
        </div>

        <label class="checkbox" for="demo">
            <input type="checkbox" id="demo" name="demo" value="1" <?= $demoDefault ? 'checked' : '' ?>>
            <span>
                <strong>Install demo data</strong><br>
                Adds 6 demo categories, 10 fish products with sizes and photos, 2 coupons, 2 combo packs,
                sample FAQs, customer reviews and an announcement. You can edit or delete all of it from the admin panel.
                Leave this unticked for a completely clean store.
            </span>
        </label>
    </section>

    <div class="alert alert-warn" style="margin-top:22px">
        <strong>Before you continue</strong>
        The installer now creates <code>.env</code>, runs database migrations, writes the default settings and translations,
        creates the delivery zones and policy pages, and sets up your administrator. On a busy shared host this can take
        up to a minute — keep this tab open until it finishes.
    </div>

    <div class="actions">
        <a class="btn btn-secondary" href="<?= mi_h($selfUrl) ?>?step=requirements">← Back</a>
        <span class="spacer"></span>
        <button type="submit" class="btn btn-primary" data-busy-label="Installing… please keep this tab open">
            Install MotsyoMela
        </button>
    </div>
</form>
