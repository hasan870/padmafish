<?php
/** @var string $siteUrlGuess */
?>

<div class="alert alert-warn">
    <strong>Installer disabled on this copy</strong>
    An existing <code>.env</code> with <code>APP_ENV=local</code> was found, so this looks like a development checkout.
    The installer refuses to run here to avoid overwriting your local database and configuration.
</div>

<p class="note" style="font-size:13px">
    The installer is meant for a fresh copy of the release ZIP on a live host. If you really need to reinstall this
    development copy, move <code>.env</code> out of the application folder first, then reload this page.
</p>

<div class="link-row">
    <a class="btn btn-secondary" href="<?= mi_h(rtrim($siteUrlGuess, '/')) ?>/">Open the site</a>
</div>
