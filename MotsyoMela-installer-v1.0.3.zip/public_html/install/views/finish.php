<?php
/** @var array<string, mixed> $result */
/** @var string $selfUrl */
/** @var string $csrf */
/** @var string|null $appPath */

$siteUrl = (string) ($result['site_url'] ?? '');
$adminUrl = (string) ($result['admin_url'] ?? ($siteUrl !== '' ? $siteUrl.'/admin' : ''));
$warnings = is_array($result['warnings'] ?? null) ? $result['warnings'] : [];
$steps = is_array($result['steps'] ?? null) ? $result['steps'] : [];
$stats = is_array($result['stats'] ?? null) ? $result['stats'] : [];
$lock = is_array($result['lock'] ?? null) ? $result['lock'] : [];
?>

<div class="success-hero">
    <div class="success-mark" aria-hidden="true">✓</div>
    <div>
        <h2><?= mi_h((string) ($result['site_name'] ?? 'MotsyoMela')) ?> is live</h2>
        <p>
            The database was created, the storefront and admin panel are configured, and your administrator account is ready.
            The installer has locked itself — it cannot run a second time.
        </p>
    </div>
</div>

<section class="section" style="margin-top:22px">
    <h2 class="section-title">Your installation</h2>
    <div class="summary">
        <dl class="kv">
            <dt>Storefront</dt>
            <dd><a href="<?= mi_h($siteUrl) ?>" target="_blank" rel="noopener"><?= mi_h($siteUrl) ?></a></dd>
            <dt>Admin panel</dt>
            <dd><a href="<?= mi_h($adminUrl) ?>" target="_blank" rel="noopener"><?= mi_h($adminUrl) ?></a></dd>
            <dt>Admin email</dt>
            <dd><?= mi_h((string) ($result['admin_email'] ?? '')) ?></dd>
            <dt>Database</dt>
            <dd><code><?= mi_h((string) ($result['database'] ?? '')) ?></code></dd>
            <dt>Demo content</dt>
            <dd>
                <?php if (! empty($result['demo'])): ?>
                    <span class="badge badge-ok">Installed</span>
                    <?= mi_h((string) ($stats['products'] ?? 0)) ?> products ·
                    <?= mi_h((string) ($stats['categories'] ?? 0)) ?> categories
                <?php else: ?>
                    <span class="badge">Not installed — clean store</span>
                <?php endif; ?>
            </dd>
            <dt>Database tables</dt>
            <dd><?= mi_h((string) ($stats['migrations'] ?? 0)) ?> migrations · <?= mi_h((string) ($stats['settings'] ?? 0)) ?> settings · <?= mi_h((string) ($stats['translations'] ?? 0)) ?> translations</dd>
            <dt>Installed at</dt>
            <dd><?= mi_h((string) ($lock['installed_at'] ?? date('c'))) ?></dd>
        </dl>
    </div>

    <div class="link-row">
        <a class="btn btn-primary" href="<?= mi_h($adminUrl) ?>" target="_blank" rel="noopener">Open admin panel →</a>
        <a class="btn btn-secondary" href="<?= mi_h($siteUrl) ?>" target="_blank" rel="noopener">Open storefront</a>
    </div>
</section>

<?php if ($warnings !== []): ?>
    <section class="section">
        <div class="alert alert-warn" style="margin:0">
            <strong>Needs your attention</strong>
            <ul>
                <?php foreach ($warnings as $warning): ?>
                    <li><?= mi_h((string) $warning) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </section>
<?php endif; ?>

<section class="section">
    <h2 class="section-title">Finish setting up the store</h2>
    <ol class="post-list">
        <li>
            <span>
                <b>Delete the installer folder.</b> Use the button at the bottom of this page, or delete
                <code>public_html/install</code> in Hostinger File Manager. This is the single most important security step.
            </span>
        </li>
        <li>
            <span>
                <b>Sign in to the admin panel</b> with the email and password you just created, and confirm the dashboard opens.
            </span>
        </li>
        <li>
            <span>
                <b>Set up payments.</b> Open <a href="<?= mi_h($adminUrl) ?>/payments" target="_blank" rel="noopener">Payments</a>
                and enter your bKash / Nagad numbers, account type and instructions. Cash on delivery is enabled by default.
            </span>
        </li>
        <li>
            <span>
                <b>Configure email.</b> Open <a href="<?= mi_h($adminUrl) ?>/mail" target="_blank" rel="noopener">Mail settings</a>,
                choose SMTP, enter your mailbox details and send a test message. Until then, mail is only written to the log file.
            </span>
        </li>
        <li>
            <span>
                <b>Review store settings.</b> Under <a href="<?= mi_h($adminUrl) ?>/settings" target="_blank" rel="noopener">Site settings</a>
                update the hotline, WhatsApp number, delivery hours and address. Adjust
                <a href="<?= mi_h($adminUrl) ?>/zones" target="_blank" rel="noopener">delivery zones</a> and
                <a href="<?= mi_h($adminUrl) ?>/slots" target="_blank" rel="noopener">time slots</a> for your area.
            </span>
        </li>
        <li>
            <span>
                <b>Enable HTTPS.</b> Turn on the free SSL certificate in Hostinger hPanel. If your final URL is HTTPS,
                edit <code>APP_URL</code> in <code>motsyomela/.env</code> to match — it was set to
                <code><?= mi_h($siteUrl) ?></code> during this installation.
            </span>
        </li>
        <li>
            <span>
                <b>Turn on backups</b> in hPanel and schedule them. The whole store lives in the database and
                <code>motsyomela/storage/app/public</code> for uploaded images.
            </span>
        </li>
    </ol>
</section>

<?php if ($steps !== []): ?>
    <section class="section">
        <h2 class="section-title">Installer log</h2>
        <ul class="steps-done">
            <?php foreach ($steps as $step): ?>
                <li>
                    <span class="tick" aria-hidden="true">✓</span>
                    <span><b><?= mi_h((string) ($step['label'] ?? '')) ?></b> — <?= mi_h((string) ($step['detail'] ?? '')) ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
        <?php if ($appPath !== null): ?>
            <p class="note" style="margin-top:10px">
                A copy of this log is stored at <code>motsyomela/storage/logs/install-<?= mi_h(date('Y-m-d')) ?>.log</code>.
            </p>
        <?php endif; ?>
    </section>
<?php endif; ?>

<div class="danger-zone">
    <h3>Remove the installer</h3>
    <p class="note" style="margin:0 0 12px">
        This permanently deletes <code>public_html/install</code>. The store keeps working. Do this now unless you still
        need the installer log on screen.
    </p>
    <form method="post" action="<?= mi_h($selfUrl) ?>" data-confirm="Delete the installer folder now? The store will keep working, but this page will no longer be available.">
        <input type="hidden" name="_token" value="<?= mi_h($csrf) ?>">
        <input type="hidden" name="action" value="remove_installer">
        <label class="checkbox" for="confirm_remove" style="margin-bottom:12px">
            <input type="checkbox" id="confirm_remove" name="confirm_remove" value="yes" required>
            <span>I understand this cannot be undone and I have saved my administrator password somewhere safe.</span>
        </label>
        <button type="submit" class="btn btn-danger btn-sm">Delete installer folder</button>
    </form>
</div>
