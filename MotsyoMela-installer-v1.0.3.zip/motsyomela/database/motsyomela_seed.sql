
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admins` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('super','staff') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'staff',
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `admins_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (1,'MotsyoMela Admin','admin@motsyomela.local','$2y$12$/ERLQs4/n7u8czxmtaiWE.NjK4NzYHPPMk1yXl6qsu8kZcC9rK5qu','super',NULL,'2026-10-22 07:58:24','2026-10-22 09:59:56');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `announcements`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `announcements` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `text_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `announcements` WRITE;
/*!40000 ALTER TABLE `announcements` DISABLE KEYS */;
INSERT INTO `announcements` VALUES (1,'আজকের তাজা ক্যাচ: পদ্মার রূপালী ইলিশের দাম ২০০ টাকা কমল! ৩ ঘন্টার মধ্যে ঢাকায় এক্সপ্রেস ডেলিভারি।',1,1,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `announcements` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` bigint NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `categories` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
INSERT INTO `categories` VALUES (1,'river','নদীর মাছ','River Fish','fa-water text-sky-400',1,1,'2026-10-22 07:58:24','2026-10-22 07:58:24'),(2,'marine','সামুদ্রিক মাছ','Sea Fish','fa-fish-fins text-cyan-400',2,1,'2026-10-22 07:58:24','2026-10-22 07:58:24'),(3,'live','জ্যান্ত মাছ','Live Fish','fa-heart-pulse text-emerald-400',3,1,'2026-10-22 07:58:24','2026-10-22 07:58:24'),(4,'processed','প্রসেসড ও কাটা মাছ','Processed & Cut Fish','fa-scissors text-amber-400',4,1,'2026-10-22 07:58:24','2026-10-22 07:58:24'),(5,'dried','শুঁটকি মাছ','Dried Fish','fa-sun text-gold-400',5,1,'2026-10-22 07:58:24','2026-10-22 07:58:24'),(6,'offer','বিশেষ ছাড়','Special Offer','fa-percent',6,1,'2026-10-22 07:58:24','2026-10-22 07:58:24');
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `combo_packs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `combo_packs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_bn` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_count` smallint unsigned NOT NULL DEFAULT '4',
  `discount_type` enum('percent','fixed') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'percent',
  `discount_value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `badge_bn` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_bn` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `combo_packs_is_active_sort_order_index` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `combo_packs` WRITE;
/*!40000 ALTER TABLE `combo_packs` DISABLE KEYS */;
INSERT INTO `combo_packs` VALUES (1,'৪টি মাছের কম্বো','4 Fish Combo',4,'percent',10.00,'জনপ্রিয়','৪টি ভিন্ন মাছ একসাথে কিনলে ১০% ছাড়।',1,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(2,'৫টি মাছের কম্বো','5 Fish Combo',5,'percent',15.00,'সেরা সেভিংস','৫টি ভিন্ন মাছ একসাথে কিনলে ১৫% ছাড়।',1,2,'2026-10-22 09:59:56','2026-10-22 09:59:56');
/*!40000 ALTER TABLE `combo_packs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `coupons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupons` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `code` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `min_order_total` decimal(10,2) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `coupons_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `coupons` WRITE;
/*!40000 ALTER TABLE `coupons` DISABLE KEYS */;
INSERT INTO `coupons` VALUES (1,'FRESH50','fixed',50.00,NULL,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,'DESHI100','fixed',100.00,NULL,1,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `coupons` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `delivery_zones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `delivery_zones` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `charge` decimal(10,2) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `delivery_zones` WRITE;
/*!40000 ALTER TABLE `delivery_zones` DISABLE KEYS */;
INSERT INTO `delivery_zones` VALUES (1,'ঢাকা শহর (ভিতরে)',80.00,1,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,'ঢাকা উপশম/সাভার/গাজীপুর',120.00,1,2,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(3,'অন্যান্য বিভাগীয় শহর',150.00,1,3,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `delivery_zones` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`),
  KEY `failed_jobs_connection_queue_failed_at_index` (`connection`,`queue`,`failed_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `faqs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faqs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `question_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `faqs` WRITE;
/*!40000 ALTER TABLE `faqs` DISABLE KEYS */;
INSERT INTO `faqs` VALUES (1,'আপনারা কীভাবে নিশ্চিত করেন যে মাছ ফরমালিন মুক্ত?','আমরা সরাসরি নিবন্ধিত ঘাট থেকে মাছ সংগ্রহ করি। প্রতিটি ব্যাচ আমাদের নিজস্ব কোয়ালিটি কন্ট্রোল টিমের মাধ্যমে ডিজিটাল ফরমালিন ডিটেক্টর দিয়ে পরীক্ষা করা হয়। আমরা ১০০% ফরমালিন মুক্ত থাকার লিখিত গ্যারান্টি দিই।',1,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,'মাছ কেটে ও পরিষ্কার করে দেওয়ার জন্য কি অতিরিক্ত চার্জ লাগে?','না! আমাদের যেকোনো মাছের জন্য কাটাই, আঁশ ছাড়ানো ও ক্লিনিং সেবা একদম বিনামূল্যে প্রদান করা হয়। আপনি কার্টে আইটেম যোগ করার সময় আপনার পছন্দের কাটিং ধরণ বেছে নিতে পারবেন।',2,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(3,'ডেলিভারি দিতে কত সময় লাগে?','ঢাকা শহরের মধ্যে ২ থেকে ৩ ঘণ্টার মধ্যে এক্সপ্রেস ডেলিভারি দেওয়া হয়। সকাল ৮টার মধ্যে অর্ডার করলে দুপুরের রান্নার আগেই তাজা মাছ পৌঁছে যাবে আপনার ঠিকানায়।',3,1,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `faqs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` smallint unsigned NOT NULL,
  `reserved_at` int unsigned DEFAULT NULL,
  `available_at` int unsigned NOT NULL,
  `created_at` int unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `menu_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `menu_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label_bn` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `label_en` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `target` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '_self',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `menu_items_is_active_sort_order_index` (`is_active`,`sort_order`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `menu_items` WRITE;
/*!40000 ALTER TABLE `menu_items` DISABLE KEYS */;
INSERT INTO `menu_items` VALUES (1,'হোম','Home','/','fa-house','_self',1,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(2,'মাছের বাজার','Shop','/#product-section','fa-fish','_self',1,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(3,'কম্বো প্যাকেজ','Combos','/#combo-section','fa-gift','_self',1,3,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(4,'আমাদের সম্পর্কে','About','/#trust-section','fa-circle-info','_self',1,4,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(5,'সাধারণ প্রশ্ন','FAQ','/#faq-section','fa-circle-question','_self',1,5,'2026-10-22 09:59:56','2026-10-22 09:59:56');
/*!40000 ALTER TABLE `menu_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'0001_01_01_000000_create_users_table',1),(2,'0001_01_01_000001_create_cache_table',1),(3,'0001_01_01_000002_create_jobs_table',1),(4,'2026_10_22_100001_create_admins_table',1),(5,'2026_10_22_100002_create_categories_table',1),(6,'2026_10_22_100003_create_products_table',1),(7,'2026_10_22_100004_create_product_sizes_table',1),(8,'2026_10_22_100005_create_coupons_table',1),(9,'2026_10_22_100006_create_delivery_zones_table',1),(10,'2026_10_22_100007_create_time_slots_table',1),(11,'2026_10_22_100008_create_announcements_table',1),(12,'2026_10_22_100009_create_faqs_table',1),(13,'2026_10_22_100010_create_testimonials_table',1),(14,'2026_10_22_100011_create_settings_table',1),(15,'2026_10_22_100012_create_orders_table',1),(16,'2026_10_22_100013_create_order_items_table',1),(17,'2026_10_22_110001_create_combo_packs_table',2),(18,'2026_10_22_110002_create_menu_items_table',2),(19,'2026_10_22_110003_add_checkout_fields_to_orders_table',2);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_items` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_id` bigint unsigned NOT NULL,
  `product_id` bigint unsigned DEFAULT NULL,
  `name_snapshot_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size_label_snapshot` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weight_kg` decimal(4,2) NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `line_total` decimal(10,2) NOT NULL,
  `is_combo` tinyint(1) NOT NULL DEFAULT '0',
  `combo_meta` json DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `order_items_order_id_foreign` (`order_id`),
  KEY `order_items_product_id_foreign` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `order_items` WRITE;
/*!40000 ALTER TABLE `order_items` DISABLE KEYS */;
/*!40000 ALTER TABLE `order_items` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orders` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `order_number` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_email` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_address` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `delivery_zone_id` bigint unsigned NOT NULL,
  `delivery_fee` decimal(10,2) NOT NULL,
  `time_slot_label` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` enum('cod','bkash','nagad','card') COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_reference` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unpaid',
  `subtotal` decimal(10,2) NOT NULL,
  `discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `coupon_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `combo_discount_amount` decimal(10,2) NOT NULL DEFAULT '0.00',
  `grand_total` decimal(10,2) NOT NULL,
  `status` enum('pending','confirmed','delivering','delivered','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `cancel_reason` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `orders_order_number_unique` (`order_number`),
  KEY `orders_delivery_zone_id_foreign` (`delivery_zone_id`),
  KEY `orders_status_created_at_index` (`status`,`created_at`),
  KEY `orders_customer_phone_index` (`customer_phone`),
  CONSTRAINT `orders_delivery_zone_id_foreign` FOREIGN KEY (`delivery_zone_id`) REFERENCES `delivery_zones` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `orders` WRITE;
/*!40000 ALTER TABLE `orders` DISABLE KEYS */;
/*!40000 ALTER TABLE `orders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_sizes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_sizes` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `product_id` bigint unsigned NOT NULL,
  `label_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price_per_kg` decimal(10,2) NOT NULL,
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_sizes_product_id_foreign` (`product_id`),
  CONSTRAINT `product_sizes_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_sizes` WRITE;
/*!40000 ALTER TABLE `product_sizes` DISABLE KEYS */;
INSERT INTO `product_sizes` VALUES (22,1,'৮০০ গ্রাম - ৯০০ গ্রাম',1450.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(23,1,'১.০ কেজি - ১.২ কেজি',1850.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(24,1,'১.৫ কেজি+',2200.00,3,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(25,2,'১.৫ কেজি - ২.৫ কেজি',420.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(26,2,'৩.০ কেজি - ৪.৫ কেজি',520.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(27,3,'মিডিয়াম (২৫-৩০ টা/কেজি)',680.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(28,3,'বড় সাইজ (১৫-২০ টা/কেজি)',850.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(29,4,'মিডিয়াম (৩-৪ টা/কেজি)',1100.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(30,4,'বড় সাইজ (২-৩ টা/কেজি)',1350.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(31,5,'বড় সাইজ (৮-১০ টা/কেজি)',1250.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(32,5,'জ্যাম্বো (৪-৬ টা/কেজি)',1600.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(33,6,'২.৫ কেজি - ৩.৫ কেজি',480.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(34,6,'৪.০ কেজি+',580.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(35,7,'মিডিয়াম (১৮-২২ টা/কেজি)',520.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(36,7,'বড় সাইজ (১২-১৫ টা/কেজি)',650.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(37,8,'২.০ কেজি - ৩.০ কেজি',950.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(38,8,'৩.৫ কেজি+',1100.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(39,9,'৫০০ গ্রাম প্যাক',700.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(40,9,'১.০ কেজি প্যাক',650.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(41,10,'২.৫ কেজি - ৩.৫ কেজি',890.00,1,'2026-10-22 09:59:56','2026-10-22 09:59:56'),(42,10,'৪.০ কেজি+',1050.00,2,'2026-10-22 09:59:56','2026-10-22 09:59:56');
/*!40000 ALTER TABLE `product_sizes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `category_id` bigint unsigned NOT NULL,
  `name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name_en` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `origin_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge_bn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `badge_color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description_bn` text COLLATE utf8mb4_unicode_ci,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_in_stock` tinyint(1) NOT NULL DEFAULT '1',
  `is_featured` tinyint(1) NOT NULL DEFAULT '0',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `products_slug_unique` (`slug`),
  KEY `products_category_id_foreign` (`category_id`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE RESTRICT
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,1,'পদ্মার ইলিশ মাছ','Padma River Hilsa','padma-river-hilsa','পদ্মা নদী, চাঁদপুর','হট ডিল','bg-red-500','চাঁদপুর ঘাটের আসল সুস্বাদু পদ্মার ইলিশ। ডিম ছাড়া তাজা সিলভার ইলিশ।','https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',1,1,1,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,1,'দেশি নদী রুই মাছ','River Rohu (Rui)','deshi-river-rohu','মেঘনা নদী অববাহিকা','জনপ্রিয়','bg-aqua-600','মিঠা পানির লালচে পেটি রুই মাছ। ঝোল বা ফ্রাইয়ের জন্য পারফেক্ট।','https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',1,0,2,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(3,3,'দেশি লাইভ শিং মাছ','Live Shing Fish','deshi-live-shing','হাওড় এলাকা, সুনামগঞ্জ','জ্যান্ত জিয়ল','bg-emerald-600','জ্যান্ত পানিতে ডেলিভারি দেওয়া হয়। রোগী ও শিশুদের জন্য ভীষণ পুষ্টিকর।','https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80',1,0,3,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(4,2,'সাদা রূপচাঁদা মাছ','White Rupchanda','white-rupchanda','বঙ্গোপসাগর, কক্সবাজার','সামুদ্রিক','bg-sky-600','সদ্য গভীর সমুদ্র থেকে সংগৃহীত সাদা রূপচাঁদা। গ্রিল ও ফ্রাই স্পেশাল।','https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',1,0,4,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(5,1,'গলদা চিংড়ি (টাইগার)','Golda Chingri (Prawn)','golda-chingri-tiger','বাগেরহাট প্রাকৃতিক ঘের','এক্সপোর্ট কোয়ালিটি','bg-purple-600','মাথার মগজভর্তি তাজা বড় গলদা চিংড়ি। মালাইকারির জন্য সেরা।','https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80',1,0,5,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(6,1,'নদীর বড় কাতলা মাছ','River Katla Fish','river-katla','যমুনা নদী','বড় সাইজ','bg-amber-600','প্রাকৃতিক নদীর বড় কাতলা মাছ। তেলযুক্ত পেটি কাটাই কালিয়ার জন্য উপযুক্ত।','https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',1,0,6,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(7,1,'দেশি পাবদা মাছ','Deshi Pabda Fish','deshi-pabda','ময়মনসিংহ ওয়াটার ফিশারিজ','নরম মাংস','bg-teal-600','কাঁটা কম ও নরম স্বাদের দেশি পাবদা। সরষে পাবদা রান্নায় অতুলনীয়।','https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',1,0,7,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(8,2,'কোরাল / ভেটকি মাছ','Sea Bass (Koral)','sea-bass-koral','চট্টগ্রাম কোস্টাল সী','ফিলে কাট','bg-indigo-600','সাদা ফিলে মাংসের কোরাল মাছ। ফিশ ফ্রাই ও স্টিম কাটের সেরা উপাদান।','https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',1,0,8,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(9,5,'কক্সবাজার লইট্যা শুঁটকি','Loitta Dried Fish','coxbazar-loitta','কক্সবাজার সমুদ্র উপকূল','রোদ শুকানো','bg-gold-600','কেমিক্যাল ও বিষমুক্ত প্রাকৃতিকভাবে রোদে শুকানো অরজিনাল লইট্যা শুঁটকি।','https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80',1,0,9,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(10,1,'নদীর বোয়াল মাছ','Wild Boal Catfish','wild-boal','মেঘনা নদীর মোহনা','ওয়াইল্ড ক্যাচ','bg-red-600','নদীর তাজা বোয়াল মাছ। কাঁটা কম থাকায় ভুনা ও ঝোলের জন্য জনপ্রিয়।','https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',0,0,10,NULL,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `settings` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  PRIMARY KEY (`id`),
  UNIQUE KEY `settings_key_unique` (`key`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `settings` WRITE;
/*!40000 ALTER TABLE `settings` DISABLE KEYS */;
INSERT INTO `settings` VALUES (1,'combo_enabled','1'),(2,'combo_min_items','4'),(3,'combo_max_items','5'),(4,'combo_4_discount','10'),(5,'combo_5_discount','15'),(6,'site_phone','16234'),(7,'whatsapp_number','8801700000000'),(8,'delivery_hours','সকাল ৮টা - রাত ৮টা'),(9,'payment_cod_enabled','1'),(10,'payment_bkash_enabled','1'),(11,'payment_nagad_enabled','1'),(12,'site_name','মৎস্যমেলা'),(13,'site_tagline','১০০% বিশুদ্ধ ও তাজা মাছের ঘাট'),(14,'site_badge','BD'),(15,'payment_bkash_number',''),(16,'payment_bkash_type','personal'),(17,'payment_bkash_link',''),(18,'payment_bkash_instructions','বিকাশে Send Money করে অর্ডার নম্বরটি রেফারেন্সে লিখুন।'),(19,'payment_nagad_number',''),(20,'payment_nagad_type','personal'),(21,'payment_nagad_link',''),(22,'payment_nagad_instructions','নগদে Send Money করে অর্ডার নম্বরটি রেফারেন্সে লিখুন।'),(23,'payment_card_enabled','1'),(24,'payment_card_gateway','SSLCommerz'),(25,'payment_card_link',''),(26,'payment_card_instructions','কার্ড পেমেন্টের জন্য পেমেন্ট লিংক ব্যবহার করুন; লিংক না থাকলে হটলাইনে কল করুন।'),(27,'theme_primary','#14b8a6'),(28,'theme_secondary','#0284c7'),(29,'theme_accent','#f59e0b'),(30,'theme_font','hind-siliguri'),(31,'theme_radius','16'),(32,'theme_border_width','1'),(33,'theme_bg_style','aurora'),(34,'theme_bg_image',''),(35,'theme_bg_overlay','60'),(36,'theme_logo',''),(37,'mail_driver','log'),(38,'mail_enabled','0'),(39,'mail_admin_email',''),(40,'mail_from_address','hello@example.com'),(41,'mail_from_name','MotsyoMela'),(42,'mail_host',''),(43,'mail_port','587'),(44,'mail_username',''),(45,'mail_password',''),(46,'mail_encryption','tls');
/*!40000 ALTER TABLE `settings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `testimonials`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `testimonials` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `customer_name_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `quote_bn` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `initial_bn` varchar(8) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rating` tinyint NOT NULL DEFAULT '5',
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `testimonials` WRITE;
/*!40000 ALTER TABLE `testimonials` DISABLE KEYS */;
INSERT INTO `testimonials` VALUES (1,'নাসরিন আক্তার','ধানমণ্ডি, ঢাকা • Verified Buyer','\"পদ্মার ইলিশের সাইজ ও স্বাদ চমৎকার ছিল। আর সবচেয়ে ভালো লেগেছে এদের ফ্রি কাটাই সার্ভিস। একদম ধুয়ে সুন্দর করে প্যাক করে পাঠিয়েছে।\"','নআ',5,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,'রফিকুল ইসলাম','উত্তরা, ঢাকা • Verified Buyer','\"লাইভ শিং ও মাগুর মাছ অর্ডার করেছিলাম। পাত্রে জ্যান্ত পানিতে ডেলিভারি দিয়েছে! বাজার ঘুরে কেনার চেয়ে অনেক আরামদায়ক।\"','আর',5,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(3,'মাহমুদুল হাসান','মিরপুর, ঢাকা • Verified Buyer','\"রূপচাঁদা মাছগুলো অনেক তাজা ছিল। আইস বক্সে বরফ ঠান্ডা অবস্থায় পাইছি। ডেলিভারি বয় খুব ভদ্র ছিল। শুভকামনা মৎস্যমেলাকে।\"','এম',5,1,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `testimonials` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `time_slots`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `time_slots` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `label_bn` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int unsigned NOT NULL DEFAULT '0',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `time_slots` WRITE;
/*!40000 ALTER TABLE `time_slots` DISABLE KEYS */;
INSERT INTO `time_slots` VALUES (1,'সকাল ৮টা - ১১টা (আজকের মর্নিং ড্রাইভ)',1,1,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(2,'দুপুর ১২টা - ৩টা (দুপুরের লাঞ্চ স্পেশাল)',1,2,'2026-10-22 07:58:25','2026-10-22 07:58:25'),(3,'বিকাল ৪টা - সন্ধ্যা ৭টা (ইভনিং ডেলিভারি)',1,3,'2026-10-22 07:58:25','2026-10-22 07:58:25');
/*!40000 ALTER TABLE `time_slots` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

