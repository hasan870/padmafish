<?php

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    public function run(): void
    {
        $products = [
            [
                'slug' => 'padma-river-hilsa',
                'category' => 'river',
                'name_bn' => 'পদ্মার ইলিশ মাছ',
                'name_en' => 'Padma River Hilsa',
                'badge_bn' => 'হট ডিল',
                'badge_color' => 'bg-red-500',
                'origin_bn' => 'পদ্মা নদী, চাঁদপুর',
                'description_bn' => 'চাঁদপুর ঘাটের আসল সুস্বাদু পদ্মার ইলিশ। ডিম ছাড়া তাজা সিলভার ইলিশ।',
                'image' => 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => true,
                'sizes' => [
                    ['label_bn' => '৮০০ গ্রাম - ৯০০ গ্রাম', 'price_per_kg' => 1450],
                    ['label_bn' => '১.০ কেজি - ১.২ কেজি', 'price_per_kg' => 1850],
                    ['label_bn' => '১.৫ কেজি+', 'price_per_kg' => 2200],
                ],
            ],
            [
                'slug' => 'deshi-river-rohu',
                'category' => 'river',
                'name_bn' => 'দেশি নদী রুই মাছ',
                'name_en' => 'River Rohu (Rui)',
                'badge_bn' => 'জনপ্রিয়',
                'badge_color' => 'bg-aqua-600',
                'origin_bn' => 'মেঘনা নদী অববাহিকা',
                'description_bn' => 'মিঠা পানির লালচে পেটি রুই মাছ। ঝোল বা ফ্রাইয়ের জন্য পারফেক্ট।',
                'image' => 'https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => '১.৫ কেজি - ২.৫ কেজি', 'price_per_kg' => 420],
                    ['label_bn' => '৩.০ কেজি - ৪.৫ কেজি', 'price_per_kg' => 520],
                ],
            ],
            [
                'slug' => 'deshi-live-shing',
                'category' => 'live',
                'name_bn' => 'দেশি লাইভ শিং মাছ',
                'name_en' => 'Live Shing Fish',
                'badge_bn' => 'জ্যান্ত জিয়ল',
                'badge_color' => 'bg-emerald-600',
                'origin_bn' => 'হাওড় এলাকা, সুনামগঞ্জ',
                'description_bn' => 'জ্যান্ত পানিতে ডেলিভারি দেওয়া হয়। রোগী ও শিশুদের জন্য ভীষণ পুষ্টিকর।',
                'image' => 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => 'মিডিয়াম (২৫-৩০ টা/কেজি)', 'price_per_kg' => 680],
                    ['label_bn' => 'বড় সাইজ (১৫-২০ টা/কেজি)', 'price_per_kg' => 850],
                ],
            ],
            [
                'slug' => 'white-rupchanda',
                'category' => 'marine',
                'name_bn' => 'সাদা রূপচাঁদা মাছ',
                'name_en' => 'White Rupchanda',
                'badge_bn' => 'সামুদ্রিক',
                'badge_color' => 'bg-sky-600',
                'origin_bn' => 'বঙ্গোপসাগর, কক্সবাজার',
                'description_bn' => 'সদ্য গভীর সমুদ্র থেকে সংগৃহীত সাদা রূপচাঁদা। গ্রিল ও ফ্রাই স্পেশাল।',
                'image' => 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => 'মিডিয়াম (৩-৪ টা/কেজি)', 'price_per_kg' => 1100],
                    ['label_bn' => 'বড় সাইজ (২-৩ টা/কেজি)', 'price_per_kg' => 1350],
                ],
            ],
            [
                'slug' => 'golda-chingri-tiger',
                'category' => 'river',
                'name_bn' => 'গলদা চিংড়ি (টাইগার)',
                'name_en' => 'Golda Chingri (Prawn)',
                'badge_bn' => 'এক্সপোর্ট কোয়ালিটি',
                'badge_color' => 'bg-purple-600',
                'origin_bn' => 'বাগেরহাট প্রাকৃতিক ঘের',
                'description_bn' => 'মাথার মগজভর্তি তাজা বড় গলদা চিংড়ি। মালাইকারির জন্য সেরা।',
                'image' => 'https://images.unsplash.com/photo-1565680018434-b513d5e5fd47?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => 'বড় সাইজ (৮-১০ টা/কেজি)', 'price_per_kg' => 1250],
                    ['label_bn' => 'জ্যাম্বো (৪-৬ টা/কেজি)', 'price_per_kg' => 1600],
                ],
            ],
            [
                'slug' => 'river-katla',
                'category' => 'river',
                'name_bn' => 'নদীর বড় কাতলা মাছ',
                'name_en' => 'River Katla Fish',
                'badge_bn' => 'বড় সাইজ',
                'badge_color' => 'bg-amber-600',
                'origin_bn' => 'যমুনা নদী',
                'description_bn' => 'প্রাকৃতিক নদীর বড় কাতলা মাছ। তেলযুক্ত পেটি কাটাই কালিয়ার জন্য উপযুক্ত।',
                'image' => 'https://images.unsplash.com/photo-1534483509719-3feaee7c30da?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => '২.৫ কেজি - ৩.৫ কেজি', 'price_per_kg' => 480],
                    ['label_bn' => '৪.০ কেজি+', 'price_per_kg' => 580],
                ],
            ],
            [
                'slug' => 'deshi-pabda',
                'category' => 'river',
                'name_bn' => 'দেশি পাবদা মাছ',
                'name_en' => 'Deshi Pabda Fish',
                'badge_bn' => 'নরম মাংস',
                'badge_color' => 'bg-teal-600',
                'origin_bn' => 'ময়মনসিংহ ওয়াটার ফিশারিজ',
                'description_bn' => 'কাঁটা কম ও নরম স্বাদের দেশি পাবদা। সরষে পাবদা রান্নায় অতুলনীয়।',
                'image' => 'https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => 'মিডিয়াম (১৮-২২ টা/কেজি)', 'price_per_kg' => 520],
                    ['label_bn' => 'বড় সাইজ (১২-১৫ টা/কেজি)', 'price_per_kg' => 650],
                ],
            ],
            [
                'slug' => 'sea-bass-koral',
                'category' => 'marine',
                'name_bn' => 'কোরাল / ভেটকি মাছ',
                'name_en' => 'Sea Bass (Koral)',
                'badge_bn' => 'ফিলে কাট',
                'badge_color' => 'bg-indigo-600',
                'origin_bn' => 'চট্টগ্রাম কোস্টাল সী',
                'description_bn' => 'সাদা ফিলে মাংসের কোরাল মাছ। ফিশ ফ্রাই ও স্টিম কাটের সেরা উপাদান।',
                'image' => 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => '২.০ কেজি - ৩.০ কেজি', 'price_per_kg' => 950],
                    ['label_bn' => '৩.৫ কেজি+', 'price_per_kg' => 1100],
                ],
            ],
            [
                'slug' => 'coxbazar-loitta',
                'category' => 'dried',
                'name_bn' => 'কক্সবাজার লইট্যা শুঁটকি',
                'name_en' => 'Loitta Dried Fish',
                'badge_bn' => 'রোদ শুকানো',
                'badge_color' => 'bg-gold-600',
                'origin_bn' => 'কক্সবাজার সমুদ্র উপকূল',
                'description_bn' => 'কেমিক্যাল ও বিষমুক্ত প্রাকৃতিকভাবে রোদে শুকানো অরজিনাল লইট্যা শুঁটকি।',
                'image' => 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => true,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => '৫০০ গ্রাম প্যাক', 'price_per_kg' => 700],
                    ['label_bn' => '১.০ কেজি প্যাক', 'price_per_kg' => 650],
                ],
            ],
            [
                'slug' => 'wild-boal',
                'category' => 'river',
                'name_bn' => 'নদীর বোয়াল মাছ',
                'name_en' => 'Wild Boal Catfish',
                'badge_bn' => 'ওয়াইল্ড ক্যাচ',
                'badge_color' => 'bg-red-600',
                'origin_bn' => 'মেঘনা নদীর মোহনা',
                'description_bn' => 'নদীর তাজা বোয়াল মাছ। কাঁটা কম থাকায় ভুনা ও ঝোলের জন্য জনপ্রিয়।',
                'image' => 'https://images.unsplash.com/photo-1524704654690-b56c05c78a00?auto=format&fit=crop&w=600&q=80',
                'is_in_stock' => false,
                'is_featured' => false,
                'sizes' => [
                    ['label_bn' => '২.৫ কেজি - ৩.৫ কেজি', 'price_per_kg' => 890],
                    ['label_bn' => '৪.০ কেজি+', 'price_per_kg' => 1050],
                ],
            ],
        ];

        foreach ($products as $index => $data) {
            $sizes = $data['sizes'];
            unset($data['sizes'], $data['category']);

            $product = Product::query()->updateOrCreate(
                ['slug' => $data['slug']],
                $data + [
                    'category_id' => \App\Models\Category::query()->where('slug', $products[$index]['category'])->value('id'),
                    'sort_order' => $index + 1,
                ]
            );

            $product->sizes()->delete();

            foreach ($sizes as $sizeIndex => $size) {
                $product->sizes()->create($size + ['sort_order' => $sizeIndex + 1]);
            }
        }
    }
}
