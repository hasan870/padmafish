<?php

namespace Database\Seeders;

use App\Models\Page;
use Illuminate\Database\Seeder;

class PageSeeder extends Seeder
{
    public function run(): void
    {
        $pages = [
            [
                'slug' => 'delivery-policy',
                'title_bn' => 'ডেলিভারি পলিসি',
                'title_en' => 'Delivery policy',
                'show_in_footer' => true,
                'sort_order' => 1,
                'content_bn' => <<<'HTML'
<h2>ডেলিভারি এলাকা ও সময়</h2>
<p>ঢাকা শহরের ভিতরে অর্ডার নিশ্চিত হওয়ার পর সাধারণত <strong>২–৩ ঘণ্টার মধ্যে</strong> ডেলিভারি দেওয়া হয়। ঢাকা উপশহর, সাভার ও গাজীপুরে একই দিনে এবং অন্যান্য বিভাগীয় শহরে ২৪–৪৮ ঘণ্টার মধ্যে ডেলিভারি পৌঁছে যায়।</p>
<ul>
    <li>সকাল ৮টার আগে অর্ডার করলে দুপুরের রান্নার আগেই মাছ পৌঁছে যাবে।</li>
    <li>চেকআউটে আপনার সুবিধামত সময় স্লট বেছে নিতে পারবেন।</li>
    <li>প্রতিটি অর্ডার ফুড-গ্রেড আইস বক্সে প্যাক করে পাঠানো হয়।</li>
</ul>
<h2>ডেলিভারি চার্জ</h2>
<p>চার্জ এলাকা অনুযায়ী নির্ধারিত হয় এবং চেকআউটে অর্ডার নিশ্চিত করার আগেই দেখানো হয়। নির্দিষ্ট অর্ডার মূল্যের উপরে কুপন থাকলে সেটি প্রয়োগ করতে পারবেন।</p>
<h2>ডেলিভারি গ্রহণ</h2>
<p>ডেলিভারির সময় মাছের ওজন ও মান যাচাই করে নিন। কোনো সমস্যা থাকলে ডেলিভারি ম্যানের সামনেই জানান — আমরা দ্রুত সমাধান করব।</p>
HTML,
                'content_en' => <<<'HTML'
<h2>Delivery areas and timing</h2>
<p>Inside Dhaka city, orders are usually delivered within <strong>2–3 hours</strong> of confirmation. Dhaka suburbs, Savar and Gazipur receive same-day delivery, while other divisional cities receive it within 24–48 hours.</p>
<ul>
    <li>Order before 8am and your fish arrives before lunch.</li>
    <li>Choose a convenient time slot at checkout.</li>
    <li>Every order is packed in a food-grade ice box.</li>
</ul>
<h2>Delivery charge</h2>
<p>The charge depends on your zone and is shown at checkout before you confirm the order. Coupons can be applied above the minimum order value.</p>
<h2>Receiving your order</h2>
<p>Please check the weight and quality when the order arrives. If anything is wrong, tell the delivery rider right away and we will fix it quickly.</p>
HTML,
            ],
            [
                'slug' => 'refund-return-policy',
                'title_bn' => 'রিফান্ড ও রিটার্ন নীতি',
                'title_en' => 'Refund & return policy',
                'show_in_footer' => true,
                'sort_order' => 2,
                'content_bn' => <<<'HTML'
<h2>আমাদের গ্যারান্টি</h2>
<p>আমরা ১০০% কেমিক্যাল ও ফরমালিনমুক্ত তাজা মাছ সরবরাহ করি। মান বা ওজনে সন্তুষ্ট না হলে ডেলিভারির সময়েই জানালে <strong>সম্পূর্ণ রিফান্ড</strong> বা মাছ বদলে দেওয়া হয়।</p>
<h2>রিফান্ডের শর্ত</h2>
<ul>
    <li>অভিযোগ ডেলিভারির দিনেই জানাতে হবে।</li>
    <li>মাছের একটি ছবি বা ভিডিও দিলে যাচাই দ্রুত হয়।</li>
    <li>কাটা বা প্রসেস করা মাছের ক্ষেত্রে ডেলিভারির সময়েই জানাতে হবে।</li>
</ul>
<h2>কীভাবে রিফান্ড পাবেন</h2>
<p>হটলাইনে কল করুন অথবা হোয়াটসঅ্যাপে অর্ডার নম্বরসহ যোগাযোগ করুন। যাচাই শেষে ৩–৭ কর্মদিবসের মধ্যে বিকাশ, নগদ বা মূল পেমেন্ট মাধ্যমে টাকা ফেরত দেওয়া হয়।</p>
<h2>বাতিলকরণ</h2>
<p>অর্ডার প্রস্তুত হওয়ার আগে পর্যন্ত বিনা খরচে বাতিল করা যাবে। ডেলিভারির জন্য বেরিয়ে গেলে বাতিলের ক্ষেত্রে ডেলিভারি চার্জ প্রযোজ্য হতে পারে।</p>
HTML,
                'content_en' => <<<'HTML'
<h2>Our guarantee</h2>
<p>We deliver 100% chemical and formalin-free fresh fish. If you are not satisfied with the quality or weight, tell us at delivery and we will arrange a <strong>full refund</strong> or a replacement.</p>
<h2>Refund conditions</h2>
<ul>
    <li>Report the issue on the delivery day.</li>
    <li>A photo or video of the fish helps us verify quickly.</li>
    <li>For cut or processed fish, report it at the time of delivery.</li>
</ul>
<h2>How to get a refund</h2>
<p>Call the hotline or message us on WhatsApp with your order number. After verification, the amount is returned through bKash, Nagad or your original payment method within 3–7 working days.</p>
<h2>Cancellations</h2>
<p>You can cancel free of charge until the order is prepared. If the rider has already left, the delivery charge may apply when cancelling.</p>
HTML,
            ],
        ];

        foreach ($pages as $page) {
            Page::query()->updateOrCreate(['slug' => $page['slug']], $page + ['is_active' => true]);
        }
    }
}
