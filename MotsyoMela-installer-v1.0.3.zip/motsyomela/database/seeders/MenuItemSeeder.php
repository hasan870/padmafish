<?php

namespace Database\Seeders;

use App\Models\MenuItem;
use Illuminate\Database\Seeder;

class MenuItemSeeder extends Seeder
{
    public function run(): void
    {
        $items = [
            ['label_bn' => 'হোম', 'label_en' => 'Home', 'url' => '/', 'icon' => 'fa-house', 'sort_order' => 1],
            ['label_bn' => 'মাছের বাজার', 'label_en' => 'Shop', 'url' => '/#product-section', 'icon' => 'fa-fish', 'sort_order' => 2],
            ['label_bn' => 'কম্বো প্যাকেজ', 'label_en' => 'Combos', 'url' => '/#combo-section', 'icon' => 'fa-gift', 'sort_order' => 3],
            ['label_bn' => 'আমাদের সম্পর্কে', 'label_en' => 'About', 'url' => '/#about-section', 'icon' => 'fa-circle-info', 'sort_order' => 4],
            ['label_bn' => 'সাধারণ প্রশ্ন', 'label_en' => 'FAQ', 'url' => '/#faq-section', 'icon' => 'fa-circle-question', 'sort_order' => 5],
        ];

        foreach ($items as $item) {
            MenuItem::query()->updateOrCreate(
                ['label_bn' => $item['label_bn']],
                $item + ['target' => '_self', 'is_active' => true]
            );
        }
    }
}
