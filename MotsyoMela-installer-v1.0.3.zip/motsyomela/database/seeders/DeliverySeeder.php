<?php

namespace Database\Seeders;

use App\Models\DeliveryZone;
use App\Models\TimeSlot;
use Illuminate\Database\Seeder;

class DeliverySeeder extends Seeder
{
    public function run(): void
    {
        $zones = [
            ['name_bn' => 'ঢাকা শহর (ভিতরে)', 'name_en' => 'Dhaka city (inside)', 'charge' => 80, 'sort_order' => 1],
            ['name_bn' => 'ঢাকা উপশম/সাভার/গাজীপুর', 'name_en' => 'Dhaka suburbs / Savar / Gazipur', 'charge' => 120, 'sort_order' => 2],
            ['name_bn' => 'অন্যান্য বিভাগীয় শহর', 'name_en' => 'Other divisional cities', 'charge' => 150, 'sort_order' => 3],
        ];

        foreach ($zones as $zone) {
            DeliveryZone::query()->updateOrCreate(
                ['name_bn' => $zone['name_bn']],
                $zone + ['is_active' => true]
            );
        }

        $slots = [
            ['label_bn' => 'সকাল ৮টা - ১১টা (আজকের মর্নিং ড্রাইভ)', 'label_en' => '8am - 11am (today morning drive)', 'sort_order' => 1],
            ['label_bn' => 'দুপুর ১২টা - ৩টা (দুপুরের লাঞ্চ স্পেশাল)', 'label_en' => '12pm - 3pm (lunch special)', 'sort_order' => 2],
            ['label_bn' => 'বিকাল ৪টা - সন্ধ্যা ৭টা (ইভনিং ডেলিভারি)', 'label_en' => '4pm - 7pm (evening delivery)', 'sort_order' => 3],
        ];

        foreach ($slots as $slot) {
            TimeSlot::query()->updateOrCreate(
                ['label_bn' => $slot['label_bn']],
                $slot + ['is_active' => true]
            );
        }
    }
}
