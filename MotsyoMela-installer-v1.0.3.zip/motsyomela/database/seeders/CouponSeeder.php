<?php

namespace Database\Seeders;

use App\Models\Coupon;
use Illuminate\Database\Seeder;

class CouponSeeder extends Seeder
{
    public function run(): void
    {
        Coupon::query()->updateOrCreate(
            ['code' => 'FRESH50'],
            ['type' => 'fixed', 'value' => 50, 'min_order_total' => null, 'is_active' => true]
        );

        Coupon::query()->updateOrCreate(
            ['code' => 'DESHI100'],
            ['type' => 'fixed', 'value' => 100, 'min_order_total' => null, 'is_active' => true]
        );
    }
}
