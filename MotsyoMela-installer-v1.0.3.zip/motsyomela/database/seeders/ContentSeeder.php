<?php

namespace Database\Seeders;

use App\Models\Announcement;
use App\Models\Faq;
use App\Models\Testimonial;
use Illuminate\Database\Seeder;

class ContentSeeder extends Seeder
{
    public function run(): void
    {
        Announcement::query()->updateOrCreate(
            ['text_bn' => 'আজকের তাজা ক্যাচ: পদ্মার রূপালী ইলিশের দাম ২০০ টাকা কমল! ৩ ঘন্টার মধ্যে ঢাকায় এক্সপ্রেস ডেলিভারি।'],
            ['is_active' => true, 'sort_order' => 1]
        );

        $faqs = [
            [
                'question_bn' => 'আপনারা কীভাবে নিশ্চিত করেন যে মাছ ফরমালিন মুক্ত?',
                'answer_bn' => 'আমরা সরাসরি নিবন্ধিত ঘাট থেকে মাছ সংগ্রহ করি। প্রতিটি ব্যাচ আমাদের নিজস্ব কোয়ালিটি কন্ট্রোল টিমের মাধ্যমে ডিজিটাল ফরমালিন ডিটেক্টর দিয়ে পরীক্ষা করা হয়। আমরা ১০০% ফরমালিন মুক্ত থাকার লিখিত গ্যারান্টি দিই।',
                'sort_order' => 1,
            ],
            [
                'question_bn' => 'মাছ কেটে ও পরিষ্কার করে দেওয়ার জন্য কি অতিরিক্ত চার্জ লাগে?',
                'answer_bn' => 'না! আমাদের যেকোনো মাছের জন্য কাটাই, আঁশ ছাড়ানো ও ক্লিনিং সেবা একদম বিনামূল্যে প্রদান করা হয়। আপনি কার্টে আইটেম যোগ করার সময় আপনার পছন্দের কাটিং ধরণ বেছে নিতে পারবেন।',
                'sort_order' => 2,
            ],
            [
                'question_bn' => 'ডেলিভারি দিতে কত সময় লাগে?',
                'answer_bn' => 'ঢাকা শহরের মধ্যে ২ থেকে ৩ ঘণ্টার মধ্যে এক্সপ্রেস ডেলিভারি দেওয়া হয়। সকাল ৮টার মধ্যে অর্ডার করলে দুপুরের রান্নার আগেই তাজা মাছ পৌঁছে যাবে আপনার ঠিকানায়।',
                'sort_order' => 3,
            ],
        ];

        foreach ($faqs as $faq) {
            Faq::query()->updateOrCreate(['question_bn' => $faq['question_bn']], $faq + ['is_active' => true]);
        }

        $testimonials = [
            [
                'customer_name_bn' => 'নাসরিন আক্তার',
                'location_bn' => 'ধানমণ্ডি, ঢাকা • Verified Buyer',
                'quote_bn' => '"পদ্মার ইলিশের সাইজ ও স্বাদ চমৎকার ছিল। আর সবচেয়ে ভালো লেগেছে এদের ফ্রি কাটাই সার্ভিস। একদম ধুয়ে সুন্দর করে প্যাক করে পাঠিয়েছে।"',
                'initial_bn' => 'নআ',
                'rating' => 5,
            ],
            [
                'customer_name_bn' => 'রফিকুল ইসলাম',
                'location_bn' => 'উত্তরা, ঢাকা • Verified Buyer',
                'quote_bn' => '"লাইভ শিং ও মাগুর মাছ অর্ডার করেছিলাম। পাত্রে জ্যান্ত পানিতে ডেলিভারি দিয়েছে! বাজার ঘুরে কেনার চেয়ে অনেক আরামদায়ক।"',
                'initial_bn' => 'আর',
                'rating' => 5,
            ],
            [
                'customer_name_bn' => 'মাহমুদুল হাসান',
                'location_bn' => 'মিরপুর, ঢাকা • Verified Buyer',
                'quote_bn' => '"রূপচাঁদা মাছগুলো অনেক তাজা ছিল। আইস বক্সে বরফ ঠান্ডা অবস্থায় পাইছি। ডেলিভারি বয় খুব ভদ্র ছিল। শুভকামনা মৎস্যমেলাকে।"',
                'initial_bn' => 'এম',
                'rating' => 5,
            ],
        ];

        foreach ($testimonials as $testimonial) {
            Testimonial::query()->updateOrCreate(
                ['customer_name_bn' => $testimonial['customer_name_bn']],
                $testimonial + ['is_active' => true]
            );
        }
    }
}
