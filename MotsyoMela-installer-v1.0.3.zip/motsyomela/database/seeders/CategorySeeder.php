<?php

namespace Database\Seeders;

use App\Models\Category;
use Illuminate\Database\Seeder;

class CategorySeeder extends Seeder
{
    public function run(): void
    {
        $categories = [
            ['slug' => 'river', 'name_bn' => 'নদীর মাছ', 'name_en' => 'River Fish', 'icon' => 'fa-water text-sky-400', 'sort_order' => 1],
            ['slug' => 'marine', 'name_bn' => 'সামুদ্রিক মাছ', 'name_en' => 'Sea Fish', 'icon' => 'fa-fish-fins text-cyan-400', 'sort_order' => 2],
            ['slug' => 'live', 'name_bn' => 'জ্যান্ত মাছ', 'name_en' => 'Live Fish', 'icon' => 'fa-heart-pulse text-emerald-400', 'sort_order' => 3],
            ['slug' => 'processed', 'name_bn' => 'প্রসেসড ও কাটা মাছ', 'name_en' => 'Processed & Cut Fish', 'icon' => 'fa-scissors text-amber-400', 'sort_order' => 4],
            ['slug' => 'dried', 'name_bn' => 'শুঁটকি মাছ', 'name_en' => 'Dried Fish', 'icon' => 'fa-sun text-gold-400', 'sort_order' => 5],
            ['slug' => 'offer', 'name_bn' => 'বিশেষ ছাড়', 'name_en' => 'Special Offer', 'icon' => 'fa-percent', 'sort_order' => 6],
        ];

        foreach ($categories as $category) {
            Category::query()->updateOrCreate(['slug' => $category['slug']], $category + ['is_active' => true]);
        }
    }
}
