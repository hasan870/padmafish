<?php

namespace Database\Seeders;

use App\Models\Admin;
use Illuminate\Database\Seeder;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        Admin::query()->updateOrCreate(
            ['email' => 'admin@motsyomela.local'],
            [
                'name' => 'MotsyoMela Admin',
                'password' => 'ChangeMe123!',
                'role' => 'super',
            ]
        );
    }
}
