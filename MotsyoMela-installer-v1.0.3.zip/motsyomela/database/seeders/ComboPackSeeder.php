<?php

namespace Database\Seeders;

use App\Models\ComboPack;
use Illuminate\Database\Seeder;

class ComboPackSeeder extends Seeder
{
    public function run(): void
    {
        $packs = [
            [
                'name_bn' => '৪টি মাছের কম্বো',
                'name_en' => '4 Fish Combo',
                'item_count' => 4,
                'discount_type' => 'percent',
                'discount_value' => 10,
                'badge_bn' => 'জনপ্রিয়',
                'description_bn' => '৪টি ভিন্ন মাছ একসাথে কিনলে ১০% ছাড়।',
                'sort_order' => 1,
            ],
            [
                'name_bn' => '৫টি মাছের কম্বো',
                'name_en' => '5 Fish Combo',
                'item_count' => 5,
                'discount_type' => 'percent',
                'discount_value' => 15,
                'badge_bn' => 'সেরা সেভিংস',
                'description_bn' => '৫টি ভিন্ন মাছ একসাথে কিনলে ১৫% ছাড়।',
                'sort_order' => 2,
            ],
        ];

        foreach ($packs as $pack) {
            ComboPack::query()->updateOrCreate(
                ['name_bn' => $pack['name_bn']],
                $pack + ['is_active' => true]
            );
        }
    }
}
