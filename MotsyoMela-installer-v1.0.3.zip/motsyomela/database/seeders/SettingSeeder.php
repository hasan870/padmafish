<?php

namespace Database\Seeders;

use App\Models\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    public function run(): void
    {
        $settings = [
            'combo_enabled' => '1',
            'combo_min_items' => '4',
            'combo_max_items' => '5',
            'combo_4_discount' => '10',
            'combo_5_discount' => '15',

            'site_name' => 'মৎস্যমেলা',
            'site_tagline' => '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট',
            'site_badge' => 'BD',
            'site_phone' => '16234',
            'whatsapp_number' => '8801700000000',
            'delivery_hours' => 'সকাল ৮টা - রাত ৮টা',

            'payment_cod_enabled' => '1',
            'payment_bkash_enabled' => '1',
            'payment_bkash_number' => '',
            'payment_bkash_type' => 'personal',
            'payment_bkash_link' => '',
            'payment_bkash_instructions' => 'বিকাশে Send Money করে অর্ডার নম্বরটি রেফারেন্সে লিখুন।',
            'payment_nagad_enabled' => '1',
            'payment_nagad_number' => '',
            'payment_nagad_type' => 'personal',
            'payment_nagad_link' => '',
            'payment_nagad_instructions' => 'নগদে Send Money করে অর্ডার নম্বরটি রেফারেন্সে লিখুন।',
            'payment_card_enabled' => '1',
            'payment_card_gateway' => 'SSLCommerz',
            'payment_card_link' => '',
            'payment_card_instructions' => 'কার্ড পেমেন্টের জন্য পেমেন্ট লিংক ব্যবহার করুন; লিংক না থাকলে হটলাইনে কল করুন।',
            'payment_bkash_qr' => '',
            'payment_bkash_qr_note' => 'bKash অ্যাপে QR স্ক্যান করে পেমেন্ট করুন।',

            'theme_primary' => '#14b8a6',
            'theme_secondary' => '#0284c7',
            'theme_accent' => '#f59e0b',
            'theme_font' => 'hind-siliguri',
            'theme_font_bangla' => 'hind-siliguri',
            'theme_font_english' => 'inter',
            'theme_font_size' => '16',
            'theme_h1_scale' => '100',
            'theme_h2_scale' => '100',
            'theme_h3_scale' => '100',
            'theme_text_scale' => '100',
            'theme_icon_scale' => '100',
            'theme_text_color' => '',
            'theme_radius' => '16',
            'theme_border_width' => '1',
            'theme_bg_style' => 'aurora',
            'theme_bg_image' => '',
            'theme_bg_overlay' => '60',
            'theme_logo' => '',
            'theme_logo_mode' => 'image',
            'combo_thumb_shape' => 'square',
            'show_cutting_preference' => '1',
            'review_enabled' => '1',

            'about_title' => 'আমাদের সম্পর্কে',
            'about_subtitle' => 'মৎস্যমেলা — তাজা মাছের বিশ্বস্ত ঠিকানা',
            'about_text' => 'মৎস্যমেলা শুরু হয়েছিল একটি সহজ লক্ষ্য নিয়ে — শহরের মানুষের কাছে সরাসরি ঘাট থেকে তাজা, ফরমালিনমুক্ত মাছ পৌঁছে দেওয়া। আমাদের নিজস্ব কোয়ালিটি টিম প্রতিদিন মাছ যাচাই করে, পরিষ্কার করে এবং ফুড-গ্রেড আইস বক্সে প্যাক করে আপনার দরজায় পৌঁছে দেয়।',
            'about_points' => "সরাসরি ঘাট ও নিবন্ধিত খামার থেকে সংগ্রহ\nপ্রতিটি ব্যাচে ফরমালিন টেস্ট ও মান যাচাই\nবিনামূল্যে কাটাই, পরিষ্কার ও ফুড-গ্রেড প্যাকিং\nঢাকায় ২–৩ ঘণ্টায় এক্সপ্রেস ডেলিভারি",
            'about_image' => '',

            'hero_promo_enabled' => '1',
            'hero_promo_badge' => 'হট ডিল',
            'hero_promo_eyebrow' => 'আজকের সেরা অফার',
            'hero_promo_title' => 'চাঁদপুরের তাজা পদ্মার ইলিশ',
            'hero_promo_description' => 'স্বাদে ও গন্ধে অতুলনীয়, বড় সাইজ (১.২ কেজি - ১.৫ কেজি)। আজই স্পেশাল কম্বো অফারে সংগ্রহ করুন!',
            'hero_promo_regular_price' => '৳২,১০০/কেজি',
            'hero_promo_offer_price' => '৳১,৮৫০ / কেজি',
            'hero_promo_cta_label' => 'অফারটি নিন',
            'hero_promo_cta_url' => '',
            'hero_promo_media_type' => 'none',
            'hero_promo_media_only' => '0',
            'hero_promo_image' => '',
            'hero_promo_video' => '',
            'hero_promo_video_url' => '',

            'footer_about_text' => 'বাংলাদেশের প্রিমিয়াম অনলাইন মাছের বাজার। কেমিক্যালমুক্ত তাজা মাছ নিয়ে আমরা আছি আপনার পাশে।',
            'footer_address' => 'কারওয়ান বাজার, গাবতলী, গুলশান ও চট্টগ্রাম পোর্ট',
            'footer_hotline_note' => '(সকাল ৭টা - রাত ৯টা)',
            'footer_payment_note' => 'ক্যাশ অন ডেলিভারি ও মোবাইল ব্যাংকিং/কার্ডে নিরাপদ পেমেন্ট করুন',
            'footer_copyright' => 'সর্বস্বত্ব সংরক্ষিত। কেমিক্যালমুক্ত তাজা মাছের নির্ভরযোগ্য বিশ্বস্ত প্রতিষ্ঠান।',
            'footer_facebook_url' => '',
            'footer_youtube_url' => '',
            'footer_instagram_url' => '',
            'footer_whatsapp_url' => '',

            'seo_meta_title' => '',
            'seo_meta_description' => '',
            'seo_meta_keywords' => '',
            'seo_robots' => 'index,follow',
            'seo_og_image' => '',
            'seo_google_verification' => '',
            'seo_ga4_id' => '',
            'seo_ga_enabled' => '0',

            'banner_slot_1_image' => '',
            'banner_slot_1_link' => '',
            'banner_slot_1_html' => '',
            'banner_slot_1_active' => '0',
            'banner_slot_2_image' => '',
            'banner_slot_2_link' => '',
            'banner_slot_2_html' => '',
            'banner_slot_2_active' => '0',

            'mail_driver' => 'log',
            'mail_enabled' => '0',
            'mail_admin_email' => '',
            'mail_from_address' => 'hello@example.com',
            'mail_from_name' => 'MotsyoMela',
            'mail_host' => '',
            'mail_port' => '587',
            'mail_username' => '',
            'mail_password' => '',
            'mail_encryption' => 'tls',
        ];

        foreach ($settings as $key => $value) {
            Setting::put($key, $value);
        }
    }
}
