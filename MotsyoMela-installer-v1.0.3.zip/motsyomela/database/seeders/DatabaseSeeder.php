<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    public function run(): void
    {
        $this->call([
            AdminSeeder::class,
            CategorySeeder::class,
            ProductSeeder::class,
            CouponSeeder::class,
            DeliverySeeder::class,
            ContentSeeder::class,
            ComboPackSeeder::class,
            MenuItemSeeder::class,
            PageSeeder::class,
            SettingSeeder::class,
            TranslationSeeder::class,
        ]);
    }
}
