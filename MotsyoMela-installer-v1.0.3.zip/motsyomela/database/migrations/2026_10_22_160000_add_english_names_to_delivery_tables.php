<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('delivery_zones', function (Blueprint $table) {
            $table->string('name_en', 150)->nullable()->after('name_bn');
        });

        Schema::table('time_slots', function (Blueprint $table) {
            $table->string('label_en', 150)->nullable()->after('label_bn');
        });
    }

    public function down(): void
    {
        Schema::table('delivery_zones', function (Blueprint $table) {
            $table->dropColumn('name_en');
        });

        Schema::table('time_slots', function (Blueprint $table) {
            $table->dropColumn('label_en');
        });
    }
};
