<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('customer_email', 150)->nullable()->after('customer_phone');
            $table->string('payment_status', 20)->default('unpaid')->after('payment_reference');
        });

        if (DB::connection()->getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE orders MODIFY payment_method ENUM('cod','bkash','nagad','card') NOT NULL");
        }
    }

    public function down(): void
    {
        if (DB::connection()->getDriverName() === 'mysql') {
            DB::statement("ALTER TABLE orders MODIFY payment_method ENUM('cod','bkash','nagad') NOT NULL");
        }

        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['customer_email', 'payment_status']);
        });
    }
};
