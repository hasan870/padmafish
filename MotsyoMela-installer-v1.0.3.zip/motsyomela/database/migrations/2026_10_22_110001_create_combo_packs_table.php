<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('combo_packs', function (Blueprint $table) {
            $table->id();
            $table->string('name_bn', 150);
            $table->string('name_en', 150)->nullable();
            $table->unsignedSmallInteger('item_count')->default(4);
            $table->enum('discount_type', ['percent', 'fixed'])->default('percent');
            $table->decimal('discount_value', 10, 2)->default(0);
            $table->string('badge_bn', 50)->nullable();
            $table->string('description_bn', 500)->nullable();
            $table->boolean('is_active')->default(true);
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();

            $table->index(['is_active', 'sort_order']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('combo_packs');
    }
};
