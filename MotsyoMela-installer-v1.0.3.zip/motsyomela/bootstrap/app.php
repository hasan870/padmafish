<?php

use Illuminate\Foundation\Application;
use Illuminate\Foundation\Configuration\Exceptions;
use Illuminate\Foundation\Configuration\Middleware;
use Illuminate\Http\Request;

// Variables are kept inside closures: the web installer require()s this file.
return tap(Application::configure(basePath: dirname(__DIR__))
    ->withRouting(
        web: __DIR__.'/../routes/web.php',
        commands: __DIR__.'/../routes/console.php',
        health: '/up',
    )
    ->withMiddleware(function (Middleware $middleware): void {
        // Hostinger CDN / LiteSpeed terminate HTTPS in front of PHP.
        $middleware->trustProxies(at: '*');

        $middleware->alias([
            'admin.super' => \App\Http\Middleware\EnsureSuperAdmin::class,
        ]);

        $middleware->web(append: [
            \App\Http\Middleware\SetLocale::class,
        ]);

        $middleware->redirectGuestsTo(
            fn (Request $request) => $request->is('admin*') ? route('admin.login') : route('account.login')
        );

        $middleware->redirectUsersTo(fn () => route('account.index'));
    })
    ->withExceptions(function (Exceptions $exceptions): void {
        $exceptions->shouldRenderJsonWhen(
            fn (Request $request) => $request->is('api/*') || $request->expectsJson(),
        );
    })->create(), function (Application $app): void {
    // The web root is public_html, next to this folder (or its parent when the
    // app was extracted inside public_html). Needed for CLI commands such as
    // "php artisan storage:link"; public_html/index.php sets it for web requests.
    $parent = dirname(__DIR__, 2);

    foreach ([$parent.'/public_html', $parent] as $publicPath) {
        if (basename($publicPath) === 'public_html' && is_file($publicPath.'/index.php')) {
            $app->usePublicPath($publicPath);
            break;
        }
    }
});
