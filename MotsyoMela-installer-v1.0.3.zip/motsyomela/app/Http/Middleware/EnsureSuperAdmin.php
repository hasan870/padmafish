<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class EnsureSuperAdmin
{
    public function handle(Request $request, Closure $next): Response
    {
        $admin = Auth::guard('admin')->user();

        abort_unless($admin && $admin->isSuper(), 403, 'এই অংশটি শুধু সুপার অ্যাডমিনের জন্য সংরক্ষিত।');

        return $next($request);
    }
}
