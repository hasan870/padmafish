<?php

namespace App\Http\Middleware;

use App\Models\Translation;
use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Symfony\Component\HttpFoundation\Response;

class SetLocale
{
    public const SUPPORTED = ['bn', 'en'];

    public function handle(Request $request, Closure $next): Response
    {
        Translation::flush();

        $sessionKey = $request->is('admin*') ? 'admin_locale' : 'locale';
        $locale = $request->session()->get($sessionKey, 'bn');

        if (! in_array($locale, self::SUPPORTED, true)) {
            $locale = 'bn';
        }

        App::setLocale($locale);

        return $next($request);
    }
}
