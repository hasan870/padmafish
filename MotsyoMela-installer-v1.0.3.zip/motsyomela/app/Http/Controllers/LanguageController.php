<?php

namespace App\Http\Controllers;

use App\Http\Middleware\SetLocale;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class LanguageController extends Controller
{
    public function switch(Request $request, string $locale): RedirectResponse
    {
        return $this->store($request, $locale, 'locale');
    }

    public function switchAdmin(Request $request, string $locale): RedirectResponse
    {
        return $this->store($request, $locale, 'admin_locale');
    }

    private function store(Request $request, string $locale, string $sessionKey): RedirectResponse
    {
        abort_unless(in_array($locale, SetLocale::SUPPORTED, true), 404);

        $request->session()->put($sessionKey, $locale);

        return back();
    }
}
