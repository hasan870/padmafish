<?php

namespace App\Http\Controllers;

use App\Mail\OrderMail;
use App\Models\ComboPack;
use App\Models\Coupon;
use App\Models\DeliveryZone;
use App\Models\Order;
use App\Models\Product;
use App\Models\Setting;
use App\Models\TimeSlot;
use App\Support\ReviewLink;
use Illuminate\Database\QueryException;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;
use Throwable;

class CheckoutController extends Controller
{
    public function store(Request $request): JsonResponse
    {
        $request->merge([
            'customer_phone' => normalize_bd_phone($request->input('customer_phone')),
            'coupon_code' => $request->filled('coupon_code') ? strtoupper(trim((string) $request->input('coupon_code'))) : null,
        ]);

        $validated = $request->validate([
            'customer_name' => ['required', 'string', 'max:100'],
            'customer_phone' => ['required', 'regex:/^01[3-9]\d{8}$/'],
            'customer_email' => ['nullable', 'email', 'max:150'],
            'customer_address' => ['required', 'string', 'max:500'],
            'zone_id' => ['required', 'integer'],
            'time_slot' => ['required', 'string', 'max:150'],
            'payment_method' => ['required', 'in:cod,bkash,nagad,card'],
            'coupon_code' => ['nullable', 'string', 'max:50'],
            'items' => ['nullable', 'array', 'max:50'],
            'items.*.product_id' => ['required', 'integer'],
            'items.*.size_id' => ['required', 'integer'],
            'items.*.weight_kg' => ['required', 'numeric', 'min:0.5', 'max:50'],
            'combo' => ['nullable', 'array'],
            'combos' => ['nullable', 'array', 'max:10'],
            'combos.*.combo_pack_id' => ['nullable', 'integer'],
            'combos.*.target' => ['nullable', 'integer'],
            'combos.*.quantity' => ['nullable', 'integer', 'min:1', 'max:9'],
            'combos.*.items' => ['required', 'array', 'max:10'],
        ], [
            'customer_name.required' => 'আপনার পূর্ণ নাম লিখুন।',
            'customer_name.max' => 'নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'customer_phone.required' => 'মোবাইল নম্বর লিখুন।',
            'customer_phone.regex' => 'সঠিক ১১ ডিজিটের মোবাইল নম্বর দিন (যেমন: 017XXXXXXXX)।',
            'customer_email.email' => 'ইমেইল ঠিকানাটি সঠিক নয়।',
            'customer_address.required' => 'পূর্ণাঙ্গ ঠিকানা লিখুন।',
            'customer_address.max' => 'ঠিকানা ৫০০ অক্ষরের মধ্যে হতে হবে।',
            'zone_id.required' => 'ডেলিভারি এলাকা নির্বাচন করুন।',
            'zone_id.integer' => 'ডেলিভারি এলাকা সঠিক নয়।',
            'time_slot.required' => 'ডেলিভারি সময় নির্বাচন করুন।',
            'payment_method.required' => 'পেমেন্ট মেথড নির্বাচন করুন।',
            'payment_method.in' => 'পেমেন্ট মেথড সঠিক নয়।',
            'items.*.product_id.required' => 'কার্টে একটি পণ্যের তথ্য অনুপস্থিত।',
            'items.*.size_id.required' => 'কার্টে একটি পণ্যের সাইজ অনুপস্থিত।',
            'items.*.weight_kg.required' => 'কার্টে একটি পণ্যের ওজন অনুপস্থিত।',
            'items.*.weight_kg.numeric' => 'পণ্যের ওজন সঠিক নয়।',
            'items.*.weight_kg.min' => 'সর্বনিম্ন ০.৫ কেজি পরিমাণ নির্বাচন করুন।',
            'items.*.weight_kg.max' => 'সর্বোচ্চ ৫০ কেজি পরিমাণ গ্রহণযোগ্য।',
            'combos.*.items.required' => 'কম্বো প্যাকেজে কোনো মাছ নেই।',
            'combos.*.items.max' => 'একটি কম্বোতে সর্বোচ্চ ১০টি মাছ রাখা যাবে।',
            'combos.*.quantity.max' => 'একটি কম্বো প্যাকেজ সর্বোচ্চ ৯ বার যোগ করা যাবে।',
        ]);

        $fail = function (string $message): never {
            throw ValidationException::withMessages(['checkout' => $message]);
        };

        $zone = DeliveryZone::query()->where('is_active', true)->find($validated['zone_id']);
        if (! $zone) {
            $fail('নির্বাচিত ডেলিভারি এলাকাটি সঠিক নয়।');
        }

        $slot = TimeSlot::query()
            ->where('is_active', true)
            ->where('label_bn', $validated['time_slot'])
            ->first();
        if (! $slot) {
            $fail('নির্বাচিত ডেলিভারি সময়টি সঠিক নয়।');
        }

        if (Setting::get('payment_'.$validated['payment_method'].'_enabled', '1') !== '1') {
            $fail('নির্বাচিত পেমেন্ট মেথডটি এই মুহূর্তে বন্ধ রয়েছে।');
        }

        $rawCombos = $validated['combos'] ?? [];
        if (! is_array($rawCombos) || $rawCombos === []) {
            $rawCombos = isset($validated['combo']) && is_array($validated['combo']) ? [$validated['combo']] : [];
        }

        $allProductIds = collect($validated['items'] ?? [])
            ->pluck('product_id')
            ->merge(
                collect($rawCombos)->flatMap(
                    fn ($combo) => is_array($combo) && is_array($combo['items'] ?? null)
                        ? collect($combo['items'])->pluck('product_id')
                        : collect()
                )
            )
            ->filter()
            ->map(fn ($id) => (int) $id)
            ->unique()
            ->values();

        $products = Product::query()
            ->with('sizes')
            ->whereIn('id', $allProductIds)
            ->get()
            ->keyBy('id');

        $lineItems = [];
        $normalRaw = 0.0;
        $comboTotalSum = 0;
        $comboDiscountSum = 0;

        foreach ($validated['items'] ?? [] as $item) {
            $product = $products->get((int) $item['product_id']);
            if (! $product) {
                $fail('পণ্যটি আর পাওয়া যাচ্ছে না। পেজ রিফ্রেশ করে আবার চেষ্টা করুন।');
            }

            $size = $product->sizes->firstWhere('id', (int) $item['size_id']);
            if (! $size) {
                $fail($product->name_bn.' এর নির্বাচিত সাইজটি সঠিক নয়।');
            }

            $weight = round((float) $item['weight_kg'], 2);
            $unitPrice = (float) $size->price_per_kg;
            $lineTotal = $unitPrice * $weight;
            $normalRaw += $lineTotal;

            $lineItems[] = [
                'product_id' => $product->id,
                'name_snapshot_bn' => $product->name_bn,
                'size_label_snapshot' => $size->label_bn,
                'weight_kg' => $weight,
                'unit_price' => $unitPrice,
                'line_total' => round($lineTotal, 2),
                'is_combo' => false,
                'combo_meta' => null,
            ];
        }

        if ($rawCombos !== []) {
            if (Setting::get('combo_enabled', '1') !== '1') {
                $fail('কম্বো প্যাকেজ এই মুহূর্তে বন্ধ রয়েছে।');
            }

            $activePacks = ComboPack::query()
                ->where('is_active', true)
                ->orderBy('sort_order')
                ->orderBy('id')
                ->get()
                ->keyBy('id');

            if ($activePacks->isEmpty()) {
                $fail('এই মুহূর্তে কোনো কম্বো প্যাকেজ পাওয়া যাচ্ছে না।');
            }

            foreach ($rawCombos as $combo) {
                if (! is_array($combo)) {
                    $fail('কম্বো প্যাকেজের তথ্য সঠিক নয়।');
                }

                $packId = (int) ($combo['combo_pack_id'] ?? 0);
                $legacyTarget = (int) ($combo['target'] ?? 0);
                $pack = $packId > 0
                    ? $activePacks->get($packId)
                    : $activePacks->firstWhere('item_count', $legacyTarget);

                if (! $pack) {
                    $fail('নির্বাচিত কম্বো প্যাকেজটি আর পাওয়া যাচ্ছে না। পেজ রিফ্রেশ করে আবার চেষ্টা করুন।');
                }

                $target = (int) $pack->item_count;
                $comboItems = $combo['items'] ?? null;
                if (! is_array($comboItems) || count($comboItems) !== $target) {
                    $fail('"'.$pack->name_bn.'" প্যাকেজে ঠিক '.bn_num($target).'টি ভিন্ন মাছ থাকতে হবে।');
                }

                $seen = [];
                $comboRaw = 0.0;
                $meta = [];

                foreach ($comboItems as $comboItem) {
                    if (! is_array($comboItem)) {
                        $fail('কম্বো প্যাকেজের তথ্য সঠিক নয়।');
                    }

                    $productId = (int) ($comboItem['product_id'] ?? 0);
                    $product = $products->get($productId);
                    if (! $product) {
                        $fail('কম্বোর একটি পণ্য আর পাওয়া যাচ্ছে না।');
                    }
                    if (! $product->is_in_stock) {
                        $fail($product->name_bn.' বর্তমানে স্টকে নেই, কম্বোতে যোগ করা যাবে না।');
                    }
                    if (isset($seen[$productId])) {
                        $fail('কম্বো প্যাকেজে একই মাছ একাধিকবার রাখা যাবে না।');
                    }
                    $seen[$productId] = true;

                    $size = $product->sizes->firstWhere('id', (int) ($comboItem['size_id'] ?? 0));
                    if (! $size) {
                        $fail($product->name_bn.' এর নির্বাচিত সাইজটি সঠিক নয়।');
                    }

                    $weight = round((float) ($comboItem['weight_kg'] ?? 0), 2);
                    if ($weight < 0.5 || $weight > 5) {
                        $fail('কম্বোর প্রতিটি মাছের ওজন ০.৫ থেকে ৫ কেজির মধ্যে হতে হবে।');
                    }

                    $unitPrice = (float) $size->price_per_kg;
                    $lineTotal = $unitPrice * $weight;
                    $comboRaw += $lineTotal;

                    $meta[] = [
                        'product_id' => $product->id,
                        'name_bn' => $product->name_bn,
                        'size_label' => $size->label_bn,
                        'weight_kg' => $weight,
                        'price_per_kg' => $unitPrice,
                        'line_total' => round($lineTotal, 2),
                    ];
                }

                $comboSubtotal = (int) round($comboRaw);
                $comboDiscount = $pack->discountAmount($comboSubtotal);
                $comboTotal = max(0, $comboSubtotal - $comboDiscount);

                // One combo line may hold several identical packs; weight_kg stores the pack count.
                $quantity = max(1, (int) ($combo['quantity'] ?? 1));
                $comboLineTotal = $comboTotal * $quantity;

                $comboTotalSum += $comboLineTotal;
                $comboDiscountSum += $comboDiscount * $quantity;

                $lineItems[] = [
                    'product_id' => null,
                    'name_snapshot_bn' => $pack->name_bn,
                    'size_label_snapshot' => bn_num($target).'টি ভিন্ন মাছ একসাথে • '.$pack->discountLabelBn(),
                    'weight_kg' => $quantity,
                    'unit_price' => $comboTotal,
                    'line_total' => $comboLineTotal,
                    'is_combo' => true,
                    'combo_meta' => [
                        'pack_id' => $pack->id,
                        'pack_name' => $pack->name_bn,
                        'item_count' => $target,
                        'quantity' => $quantity,
                        'discount_type' => $pack->discount_type,
                        'discount_value' => (float) $pack->discount_value,
                        'discount_label' => $pack->discountLabelBn(),
                        'items' => $meta,
                    ],
                ];
            }
        }

        if ($lineItems === []) {
            $fail('আপনার কার্টে কোনো পণ্য নেই। প্রথমে মাছ যোগ করুন।');
        }

        $subtotal = (int) round($normalRaw + $comboTotalSum);

        $couponDiscount = 0;
        $appliedCouponCode = null;

        if (! empty($validated['coupon_code'])) {
            $coupon = Coupon::query()
                ->where('code', $validated['coupon_code'])
                ->where('is_active', true)
                ->first();

            if (! $coupon) {
                $fail('কুপন কোডটি সঠিক নয় অথবা মেয়াদোত্তীর্ণ।');
            }

            if ($coupon->min_order_total !== null && $subtotal < (float) $coupon->min_order_total) {
                $fail('এই কুপনের জন্য সর্বনিম্ন ৳'.bn_num((int) $coupon->min_order_total).' অর্ডার প্রয়োজন।');
            }

            $couponDiscount = $coupon->type === 'percent'
                ? (int) round($subtotal * ((float) $coupon->value / 100))
                : (int) round((float) $coupon->value);

            $couponDiscount = max(0, min($couponDiscount, $subtotal));
            $appliedCouponCode = $coupon->code;
        }

        $deliveryFee = (int) round((float) $zone->charge);
        $grandTotal = max(0, $subtotal - $couponDiscount) + $deliveryFee;
        $paymentStatus = $validated['payment_method'] === 'cod' ? 'unpaid' : 'pending';

        $attempt = 0;
        $order = null;

        while ($order === null) {
            $attempt++;

            try {
                $order = DB::transaction(function () use (
                    $validated, $zone, $deliveryFee, $subtotal, $couponDiscount,
                    $appliedCouponCode, $comboDiscountSum, $grandTotal, $lineItems, $paymentStatus
                ) {
                    $order = Order::query()->create([
                        'customer_id' => auth('web')->id(),
                        'order_number' => Order::generateOrderNumber(),
                        'customer_name' => $validated['customer_name'],
                        'customer_phone' => $validated['customer_phone'],
                        'customer_email' => $validated['customer_email'] ?? null,
                        'customer_address' => $validated['customer_address'],
                        'delivery_zone_id' => $zone->id,
                        'delivery_fee' => $deliveryFee,
                        'time_slot_label' => $validated['time_slot'],
                        'payment_method' => $validated['payment_method'],
                        'payment_status' => $paymentStatus,
                        'subtotal' => $subtotal,
                        'discount_amount' => $couponDiscount,
                        'coupon_code' => $appliedCouponCode,
                        'combo_discount_amount' => $comboDiscountSum,
                        'grand_total' => $grandTotal,
                        'status' => 'pending',
                    ]);

                    $order->items()->createMany($lineItems);

                    return $order;
                });
            } catch (QueryException $exception) {
                if ($attempt >= 5 || ! str_contains($exception->getMessage(), 'Duplicate')) {
                    throw $exception;
                }
            }
        }

        $emailSent = $this->sendOrderEmails($order);

        $paymentLink = (string) Setting::get('payment_'.$order->payment_method.'_link', '');
        $paymentNumber = in_array($order->payment_method, ['bkash', 'nagad'], true)
            ? (string) Setting::get('payment_'.$order->payment_method.'_number', '')
            : '';
        $paymentInstructions = $order->payment_method === 'cod'
            ? 'ডেলিভারির সময় পণ্য হাতে পেয়ে পেমেন্ট করুন।'
            : (string) Setting::get('payment_'.$order->payment_method.'_instructions', '');
        $paymentIconPath = (string) Setting::get('payment_'.$order->payment_method.'_icon', '');
        $paymentIcon = $paymentIconPath !== '' ? Storage::url($paymentIconPath) : null;

        $whatsappMessage = 'হ্যালো, আমার অর্ডার '.$order->order_number.'। মোট ৳'.(int) $order->grand_total
            .'। পেমেন্ট সম্পর্কে কনফার্ম করতে চাই।';

        return response()->json([
            'order_number' => $order->order_number,
            'customer_name' => $order->customer_name,
            'time_slot_label' => $order->time_slot_label,
            'payment_method' => $order->payment_method,
            'payment_label' => $order->paymentLabelBn(),
            'payment_status' => $order->payment_status,
            'payment_number' => $paymentNumber,
            'payment_link' => $paymentLink,
            'payment_instructions' => $paymentInstructions,
            'payment_icon' => $paymentIcon,
            'whatsapp_link' => whatsapp_url(Setting::get('whatsapp_number', ''), $whatsappMessage),
            'review_url' => ReviewLink::for($order),
            'email_sent' => $emailSent,
            'subtotal' => (int) $order->subtotal,
            'discount' => (int) $order->discount_amount,
            'delivery_fee' => (int) $order->delivery_fee,
            'grand_total' => (int) $order->grand_total,
        ], 201);
    }

    private function sendOrderEmails(Order $order): bool
    {
        if (Setting::get('mail_enabled', '0') !== '1') {
            return false;
        }

        $order->loadMissing(['items', 'zone']);
        $customerSent = false;

        if ($order->customer_email) {
            try {
                Mail::to($order->customer_email)->send(new OrderMail($order, 'customer'));
                $customerSent = true;
            } catch (Throwable $exception) {
                report($exception);
            }
        }

        $adminEmail = trim((string) Setting::get('mail_admin_email', ''));
        if ($adminEmail !== '') {
            try {
                Mail::to($adminEmail)->send(new OrderMail($order, 'admin'));
            } catch (Throwable $exception) {
                report($exception);
            }
        }

        return $customerSent;
    }
}
