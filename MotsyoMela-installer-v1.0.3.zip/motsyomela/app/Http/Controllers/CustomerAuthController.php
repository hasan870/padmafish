<?php

namespace App\Http\Controllers;

use App\Models\Setting;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rules\Password;

class CustomerAuthController extends Controller
{
    public function showLogin(): View
    {
        return view('account.auth.login', [
            'settings' => Setting::map(),
        ]);
    }

    public function login(Request $request): RedirectResponse
    {
        $credentials = $request->validate([
            'email' => ['required', 'email', 'max:150'],
            'password' => ['required', 'string'],
        ], [
            'email.required' => 'ইমেইল ঠিকানা লিখুন।',
            'email.email' => 'ইমেইল ঠিকানাটি সঠিক নয়।',
            'password.required' => 'পাসওয়ার্ড লিখুন।',
        ], [
            'email' => 'ইমেইল',
            'password' => 'পাসওয়ার্ড',
        ]);

        if (! Auth::guard('web')->attempt($credentials, $request->boolean('remember'))) {
            return back()
                ->withErrors(['email' => 'ইমেইল বা পাসওয়ার্ড সঠিক নয়।'])
                ->onlyInput('email');
        }

        $request->session()->regenerate();

        return redirect()
            ->intended(route('account.index'))
            ->with('status', 'স্বাগতম! আপনি সফলভাবে লগইন করেছেন।');
    }

    public function showRegister(): View
    {
        return view('account.auth.register', [
            'settings' => Setting::map(),
        ]);
    }

    public function register(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150', 'unique:users,email'],
            'password' => ['required', 'confirmed', Password::min(8)],
        ], [
            'name.required' => 'আপনার নাম লিখুন।',
            'name.max' => 'নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'email.required' => 'ইমেইল ঠিকানা লিখুন।',
            'email.email' => 'ইমেইল ঠিকানাটি সঠিক নয়।',
            'email.unique' => 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে।',
            'password.required' => 'পাসওয়ার্ড দিন।',
            'password.confirmed' => 'দুটি পাসওয়ার্ড মিলছে না।',
            'password.min' => 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।',
        ], [
            'name' => 'নাম',
            'email' => 'ইমেইল',
            'password' => 'পাসওয়ার্ড',
        ]);

        $user = User::query()->create([
            'name' => $validated['name'],
            'email' => $validated['email'],
            'password' => $validated['password'],
        ]);

        Auth::guard('web')->login($user);
        $request->session()->regenerate();

        return redirect()
            ->route('account.index')
            ->with('status', 'আপনার অ্যাকাউন্ট তৈরি হয়েছে। এখন করা অর্ডারগুলো এখানে দেখতে পাবেন।');
    }

    public function logout(Request $request): RedirectResponse
    {
        Auth::guard('web')->logout();

        $request->session()->invalidate();
        $request->session()->regenerateToken();

        return redirect()
            ->route('home')
            ->with('status', 'আপনি লগআউট করেছেন।');
    }
}
