<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Setting;
use App\Models\User;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;

class AccountController extends Controller
{
    public function index(): View
    {
        /** @var User $user */
        $user = Auth::guard('web')->user();

        $orders = Order::query()
            ->where('customer_id', $user->id)
            ->withCount('items')
            ->latest('id')
            ->paginate(10);

        $totalOrders = Order::query()->where('customer_id', $user->id)->count();
        $activeOrders = Order::query()
            ->where('customer_id', $user->id)
            ->whereIn('status', ['pending', 'confirmed', 'delivering'])
            ->count();

        return view('account.index', [
            'settings' => Setting::map(),
            'user' => $user,
            'orders' => $orders,
            'totalOrders' => $totalOrders,
            'activeOrders' => $activeOrders,
        ]);
    }

    public function updateProfile(Request $request): RedirectResponse
    {
        /** @var User $user */
        $user = Auth::guard('web')->user();

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150', Rule::unique('users', 'email')->ignore($user->id)],
        ], [
            'name.required' => 'আপনার নাম লিখুন।',
            'name.max' => 'নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'email.required' => 'ইমেইল ঠিকানা লিখুন।',
            'email.email' => 'ইমেইল ঠিকানাটি সঠিক নয়।',
            'email.unique' => 'এই ইমেইল অন্য একটি অ্যাকাউন্টে ব্যবহৃত হচ্ছে।',
        ], [
            'name' => 'নাম',
            'email' => 'ইমেইল',
        ]);

        $user->update($validated);

        return back()->with('status', 'প্রোফাইলের তথ্য আপডেট করা হয়েছে।');
    }

    public function order(Order $order): View
    {
        /** @var User $user */
        $user = Auth::guard('web')->user();

        abort_unless((int) $order->customer_id === (int) $user->id, 404);

        $order->load(['items', 'zone']);

        return view('account.orders.show', [
            'settings' => Setting::map(),
            'order' => $order,
        ]);
    }
}
