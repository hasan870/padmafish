<?php

namespace App\Http\Controllers;

use App\Models\Announcement;
use App\Models\Category;
use App\Models\ComboPack;
use App\Models\Coupon;
use App\Models\DeliveryZone;
use App\Models\Faq;
use App\Models\MenuItem;
use App\Models\Product;
use App\Models\Setting;
use App\Models\Testimonial;
use App\Models\TimeSlot;
use Illuminate\Contracts\View\View;

class HomeController extends Controller
{
    public function index(): View
    {
        return view('home', self::storefrontData());
    }

    /**
     * Data every storefront layout needs (header, footer, cart, checkout, scripts).
     */
    public static function storefrontData(): array
    {
        $categories = Category::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $products = Product::query()
            ->with(['sizes', 'category'])
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $zones = DeliveryZone::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $slots = TimeSlot::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $coupons = Coupon::query()
            ->where('is_active', true)
            ->orderBy('id')
            ->get();

        $announcements = Announcement::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $faqs = Faq::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $testimonials = Testimonial::query()
            ->where('is_active', true)
            ->orderBy('id')
            ->get();

        $settings = Setting::map();

        $comboPacks = ComboPack::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $menuItems = MenuItem::query()
            ->where('is_active', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();

        $combo = [
            'enabled' => ($settings['combo_enabled'] ?? '1') === '1' && $comboPacks->isNotEmpty(),
            'min' => (int) ($settings['combo_min_items'] ?? 4),
            'max' => (int) ($settings['combo_max_items'] ?? 5),
            'd4' => (int) ($settings['combo_4_discount'] ?? 10),
            'd5' => (int) ($settings['combo_5_discount'] ?? 15),
        ];

        $data = [
            'products' => $products->map(fn (Product $product) => [
                'id' => $product->id,
                'nameBng' => $product->name_bn,
                'nameEng' => $product->name_en ?? '',
                'category' => $product->category?->slug ?? '',
                'badge' => $product->badge_bn ?? '',
                'badgeColor' => $product->badge_color ?? 'bg-aqua-600',
                'origin' => $product->origin_bn ?? '',
                'sizes' => $product->sizes->map(fn ($size) => [
                    'id' => $size->id,
                    'label' => $size->label_bn,
                    'pricePerKg' => (float) $size->price_per_kg,
                ])->values(),
                'inStock' => $product->is_in_stock,
                'featured' => $product->is_featured,
                'image' => $product->image_url,
                'desc' => $product->description_bn ?? '',
            ])->values(),
            'coupons' => $coupons->map(fn (Coupon $coupon) => [
                'code' => $coupon->code,
                'type' => $coupon->type,
                'value' => (float) $coupon->value,
                'min_order_total' => $coupon->min_order_total !== null ? (float) $coupon->min_order_total : null,
            ])->values(),
            'comboPacks' => $comboPacks->map(fn (ComboPack $pack) => [
                'id' => $pack->id,
                'nameBn' => $pack->name_bn,
                'nameEn' => $pack->name_en ?? '',
                'itemCount' => $pack->item_count,
                'discountType' => $pack->discount_type,
                'discountValue' => (float) $pack->discount_value,
                'discountLabel' => $pack->discountLabelBn(),
                'badge' => $pack->badge_bn ?? '',
                'description' => $pack->description_bn ?? '',
            ])->values(),
            // Hero promo copy is rendered server-side only; keep it out of the JS payload.
            'settings' => array_filter(
                $settings,
                fn ($key) => ! str_starts_with((string) $key, 'hero_promo_'),
                ARRAY_FILTER_USE_KEY
            ),
            'locale' => app()->getLocale(),
        ];

        $tickerMessage = $announcements->pluck('text_bn')->implode(' 🐟 ');

        return compact(
            'categories', 'products', 'zones', 'slots', 'coupons',
            'announcements', 'faqs', 'testimonials', 'settings', 'combo',
            'comboPacks', 'menuItems', 'tickerMessage', 'data'
        );
    }
}
