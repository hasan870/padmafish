<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Setting;
use App\Models\Testimonial;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ReviewController extends Controller
{
    public function show(Request $request, Order $order): View
    {
        return view('review.show', [
            'order' => $order,
            'settings' => Setting::map(),
            'submitted' => $this->alreadyReviewed($order),
            'reviewUrl' => $request->fullUrl(),
        ]);
    }

    public function store(Request $request, Order $order): RedirectResponse
    {
        if ($this->alreadyReviewed($order)) {
            return redirect()->to($request->fullUrl())
                ->with('review_status', 'এই অর্ডারের জন্য আপনি ইতিমধ্যে রিভিউ জমা দিয়েছেন। ধন্যবাদ!');
        }

        $validated = $request->validate([
            'customer_name_bn' => ['required', 'string', 'max:100'],
            'location_bn' => ['nullable', 'string', 'max:100'],
            'quote_bn' => ['required', 'string', 'min:10', 'max:1000'],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
        ], [
            'customer_name_bn.required' => 'আপনার নাম লিখুন।',
            'customer_name_bn.max' => 'নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'location_bn.max' => 'এলাকার নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'quote_bn.required' => 'আপনার মতামত লিখুন।',
            'quote_bn.min' => 'মতামত কমপক্ষে ১০ অক্ষরের হতে হবে।',
            'quote_bn.max' => 'মতামত ১০০০ অক্ষরের মধ্যে হতে হবে।',
            'rating.required' => 'রেটিং নির্বাচন করুন।',
            'rating.min' => 'রেটিং ১ থেকে ৫ এর মধ্যে হতে হবে।',
            'rating.max' => 'রেটিং ১ থেকে ৫ এর মধ্যে হতে হবে।',
        ], [
            'customer_name_bn' => 'নাম',
            'location_bn' => 'এলাকা',
            'quote_bn' => 'মতামত',
            'rating' => 'রেটিং',
        ]);

        Testimonial::query()->create([
            'customer_name_bn' => $validated['customer_name_bn'],
            'location_bn' => $validated['location_bn'] ?? null,
            'quote_bn' => $validated['quote_bn'],
            'initial_bn' => mb_substr(trim($validated['customer_name_bn']), 0, 1),
            'rating' => (int) $validated['rating'],
            // Customer reviews stay hidden on the storefront until an admin activates them.
            'is_active' => false,
            'order_number' => $order->order_number,
        ]);

        return redirect()->to($request->fullUrl())
            ->with('review_status', 'ধন্যবাদ! আপনার রিভিউটি পেয়েছি — অনুমোদনের পর স্টোরফ্রন্টে দেখা যাবে।');
    }

    private function alreadyReviewed(Order $order): bool
    {
        return Testimonial::query()->where('order_number', $order->order_number)->exists();
    }
}
