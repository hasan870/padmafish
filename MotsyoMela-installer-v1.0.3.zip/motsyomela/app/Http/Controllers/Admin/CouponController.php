<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Coupon;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CouponController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('q')->toString());

        $coupons = Coupon::query()
            ->when($search !== '', fn ($query) => $query->where('code', 'like', "%{$search}%"))
            ->latest('id')
            ->paginate(15)
            ->withQueryString();

        return view('admin.coupons.index', compact('coupons', 'search'));
    }

    public function create(): View
    {
        $coupon = new Coupon(['type' => 'fixed', 'is_active' => true]);

        return view('admin.coupons.form', compact('coupon'));
    }

    public function store(Request $request): RedirectResponse
    {
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $this->validateCoupon($request);

        Coupon::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.coupons.index')->with('status', 'নতুন কুপন যোগ করা হয়েছে।');
    }

    public function edit(Coupon $coupon): View
    {
        return view('admin.coupons.form', compact('coupon'));
    }

    public function update(Request $request, Coupon $coupon): RedirectResponse
    {
        $request->merge(['code' => strtoupper(trim((string) $request->input('code')))]);
        $validated = $this->validateCoupon($request, $coupon);

        $coupon->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.coupons.index')->with('status', 'কুপন আপডেট করা হয়েছে।');
    }

    public function destroy(Coupon $coupon): RedirectResponse
    {
        $coupon->delete();

        return redirect()->route('admin.coupons.index')->with('status', 'কুপন ডিলিট করা হয়েছে।');
    }

    private function validateCoupon(Request $request, ?Coupon $coupon = null): array
    {
        return $request->validate([
            'code' => ['required', 'string', 'max:50', 'regex:/^[A-Z0-9_-]+$/', Rule::unique('coupons', 'code')->ignore($coupon?->id)],
            'type' => ['required', 'in:fixed,percent'],
            'value' => ['required', 'numeric', 'min:0.01', $request->input('type') === 'percent' ? 'max:100' : 'max:999999'],
            'min_order_total' => ['nullable', 'numeric', 'min:0', 'max:999999'],
        ], [
            'code.required' => 'কুপন কোড লিখুন।',
            'code.regex' => 'কুপন কোডে শুধু ইংরেজি বড় হাতের অক্ষর, সংখ্যা, হাইফেন ও আন্ডারস্কোর ব্যবহার করুন।',
            'code.unique' => 'এই কুপন কোড আগেই ব্যবহৃত হয়েছে।',
            'type.required' => 'কুপনের ধরন নির্বাচন করুন।',
            'type.in' => 'কুপনের ধরন সঠিক নয়।',
            'value.required' => 'কুপনের মান লিখুন।',
            'value.numeric' => 'কুপনের মান একটি সংখ্যা হতে হবে।',
            'value.min' => 'কুপনের মান ০ এর চেয়ে বেশি হতে হবে।',
            'value.max' => 'কুপনের মান সীমার মধ্যে হতে হবে।',
            'min_order_total.numeric' => 'সর্বনিম্ন অর্ডার মূল্য একটি সংখ্যা হতে হবে।',
            'min_order_total.min' => 'সর্বনিম্ন অর্ডার মূল্য ঋণাত্মক হতে পারবে না।',
        ], [
            'code' => 'কুপন কোড',
            'type' => 'ধরন',
            'value' => 'মান',
            'min_order_total' => 'সর্বনিম্ন অর্ডার মূল্য',
        ]);
    }
}
