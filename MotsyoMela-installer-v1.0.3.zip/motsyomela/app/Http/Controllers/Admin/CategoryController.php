<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index(): View
    {
        $categories = Category::query()
            ->withCount(['products' => fn ($query) => $query->withTrashed()])
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate(15);

        return view('admin.categories.index', compact('categories'));
    }

    public function create(): View
    {
        $category = new Category(['is_active' => true]);

        return view('admin.categories.form', compact('category'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateCategory($request);

        Category::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.categories.index')->with('status', 'নতুন ক্যাটাগরি যোগ করা হয়েছে।');
    }

    public function edit(Category $category): View
    {
        return view('admin.categories.form', compact('category'));
    }

    public function update(Request $request, Category $category): RedirectResponse
    {
        $validated = $this->validateCategory($request, $category);

        $category->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.categories.index')->with('status', 'ক্যাটাগরি আপডেট করা হয়েছে।');
    }

    public function destroy(Category $category): RedirectResponse
    {
        if ($category->products()->withTrashed()->exists()) {
            return back()->with('error', 'এই ক্যাটাগরির অধীনে পণ্য রয়েছে। আগে পণ্যগুলো অন্য ক্যাটাগরিতে সরান বা ডিলিট করুন।');
        }

        $category->delete();

        return redirect()->route('admin.categories.index')->with('status', 'ক্যাটাগরি ডিলিট করা হয়েছে।');
    }

    private function validateCategory(Request $request, ?Category $category = null): array
    {
        return $request->validate([
            'slug' => ['required', 'string', 'max:50', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', Rule::unique('categories', 'slug')->ignore($category?->id)],
            'name_bn' => ['required', 'string', 'max:100'],
            'name_en' => ['nullable', 'string', 'max:100'],
            'icon' => ['nullable', 'string', 'max:100'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'slug.required' => 'ক্যাটাগরি স্লাগ লিখুন।',
            'slug.regex' => 'স্লাগে শুধু ইংরেজি ছোট হাতের অক্ষর, সংখ্যা ও হাইফেন ব্যবহার করুন।',
            'slug.unique' => 'এই স্লাগ আগেই ব্যবহৃত হয়েছে।',
            'name_bn.required' => 'ক্যাটাগরির বাংলা নাম লিখুন।',
            'name_bn.max' => 'ক্যাটাগরির নাম ১০০ অক্ষরের মধ্যে হতে হবে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'slug' => 'স্লাগ',
            'name_bn' => 'বাংলা নাম',
            'name_en' => 'ইংরেজি নাম',
            'icon' => 'আইকন',
            'sort_order' => 'ক্রম',
        ]);
    }
}
