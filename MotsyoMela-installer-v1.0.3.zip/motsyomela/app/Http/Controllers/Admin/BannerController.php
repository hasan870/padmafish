<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class BannerController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();

        return view('admin.banners.edit', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'banner_slot_1_html' => ['nullable', 'string', 'max:5000'],
            'banner_slot_2_html' => ['nullable', 'string', 'max:5000'],
            'banner_slot_1_link' => ['nullable', 'url', 'max:500'],
            'banner_slot_2_link' => ['nullable', 'url', 'max:500'],
            'banner_slot_1_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:3072'],
            'banner_slot_2_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:3072'],
        ], [
            'banner_slot_1_html.max' => 'প্রথম ব্যানারের HTML ৫০০০ অক্ষরের মধ্যে হতে হবে।',
            'banner_slot_2_html.max' => 'দ্বিতীয় ব্যানারের HTML ৫০০০ অক্ষরের মধ্যে হতে হবে।',
            'banner_slot_1_link.url' => 'প্রথম ব্যানারের লিংকটি সঠিক URL নয়।',
            'banner_slot_2_link.url' => 'দ্বিতীয় ব্যানারের লিংকটি সঠিক URL নয়।',
            'banner_slot_1_image.image' => 'প্রথম ব্যানারের ছবিটি সঠিক নয়।',
            'banner_slot_2_image.image' => 'দ্বিতীয় ব্যানারের ছবিটি সঠিক নয়।',
            'banner_slot_1_image.max' => 'প্রথম ব্যানারের ছবি সর্বোচ্চ ৩MB হতে পারবে।',
            'banner_slot_2_image.max' => 'দ্বিতীয় ব্যানারের ছবি সর্বোচ্চ ৩MB হতে পারবে।',
        ], [
            'banner_slot_1_html' => 'প্রথম ব্যানারের HTML',
            'banner_slot_2_html' => 'দ্বিতীয় ব্যানারের HTML',
            'banner_slot_1_link' => 'প্রথম ব্যানারের লিংক',
            'banner_slot_2_link' => 'দ্বিতীয় ব্যানারের লিংক',
            'banner_slot_1_image' => 'প্রথম ব্যানারের ছবি',
            'banner_slot_2_image' => 'দ্বিতীয় ব্যানারের ছবি',
        ]);

        $textKeys = [
            'banner_slot_1_html', 'banner_slot_2_html',
            'banner_slot_1_link', 'banner_slot_2_link',
        ];

        foreach ($textKeys as $key) {
            Setting::put($key, $validated[$key] ?? '');
        }

        foreach ([1, 2] as $slot) {
            $key = 'banner_slot_'.$slot.'_image';
            $current = (string) Setting::get($key, '');

            if ($request->boolean($key.'_remove')) {
                if ($current !== '') {
                    Storage::disk('public')->delete($current);
                }
                Setting::put($key, '');

                continue;
            }

            if ($request->hasFile($key)) {
                if ($current !== '') {
                    Storage::disk('public')->delete($current);
                }
                Setting::put($key, $request->file($key)->store('banners', 'public'));
            }
        }

        foreach ([1, 2] as $slot) {
            Setting::put(
                'banner_slot_'.$slot.'_active',
                $request->boolean('banner_slot_'.$slot.'_active') ? '1' : '0'
            );
        }

        return back()->with('status', 'ব্যানার সেটিংস আপডেট করা হয়েছে।');
    }
}
