<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class HeroPromoController extends Controller
{
    public const MEDIA_TYPES = [
        'none' => 'শুধু টেক্সট কার্ড',
        'image' => 'ছবি',
        'video' => 'ভিডিও',
    ];

    public const IMAGE_EXTENSIONS = ['jpg', 'jpeg', 'png', 'webp', 'gif'];

    public const VIDEO_EXTENSIONS = ['mp4', 'webm', 'mov'];

    public const TEXT_FIELDS = [
        'hero_promo_badge',
        'hero_promo_eyebrow',
        'hero_promo_title',
        'hero_promo_description',
        'hero_promo_regular_price',
        'hero_promo_offer_price',
        'hero_promo_cta_label',
        'hero_promo_cta_url',
        'hero_promo_video_url',
    ];

    public function edit(): View
    {
        $settings = Setting::map();
        $mediaTypes = self::MEDIA_TYPES;
        $mediaLibrary = $this->mediaLibrary();

        return view('admin.hero-promo.edit', compact('settings', 'mediaTypes', 'mediaLibrary'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'hero_promo_badge' => ['nullable', 'string', 'max:40'],
            'hero_promo_eyebrow' => ['nullable', 'string', 'max:80'],
            'hero_promo_title' => ['nullable', 'string', 'max:150'],
            'hero_promo_description' => ['nullable', 'string', 'max:500'],
            'hero_promo_regular_price' => ['nullable', 'string', 'max:60'],
            'hero_promo_offer_price' => ['nullable', 'string', 'max:60'],
            'hero_promo_cta_label' => ['nullable', 'string', 'max:60'],
            'hero_promo_cta_url' => ['nullable', 'url', 'max:255'],
            'hero_promo_video_url' => ['nullable', 'url', 'max:500'],
            'hero_promo_media_type' => ['required', 'in:'.implode(',', array_keys(self::MEDIA_TYPES))],
            'hero_promo_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
            'hero_promo_video' => ['nullable', 'file', 'mimes:mp4,webm,mov', 'max:20480'],
            'hero_promo_image_pick' => ['nullable', 'string', 'max:255'],
            'hero_promo_video_pick' => ['nullable', 'string', 'max:255'],
        ], [
            'hero_promo_badge.max' => 'ব্যাজ লেখা ৪০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_eyebrow.max' => 'উপরের ছোট লেখা ৮০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_title.max' => 'শিরোনাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_description.max' => 'বিবরণ ৫০০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_regular_price.max' => 'নিয়মিত মূল্য ৬০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_offer_price.max' => 'অফার মূল্য ৬০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_cta_label.max' => 'বাটনের লেখা ৬০ অক্ষরের মধ্যে হতে হবে।',
            'hero_promo_cta_url.url' => 'বাটনের লিংকটি সঠিক URL হতে হবে।',
            'hero_promo_video_url.url' => 'ভিডিও লিংকটি সঠিক URL হতে হবে।',
            'hero_promo_media_type.in' => 'মিডিয়া ধরন সঠিক নয়।',
            'hero_promo_image.image' => 'প্রোমো ছবিটি সঠিক ইমেজ নয়।',
            'hero_promo_image.max' => 'ছবিটি সর্বোচ্চ ৪ মেগাবাইট হতে পারবে।',
            'hero_promo_video.mimes' => 'ভিডিও অবশ্যই MP4, WebM বা MOV ফরম্যাটে হতে হবে।',
            'hero_promo_video.max' => 'ভিডিও সর্বোচ্চ ২০ মেগাবাইট হতে পারবে।',
        ], [
            'hero_promo_badge' => 'ব্যাজ লেখা',
            'hero_promo_eyebrow' => 'উপরের ছোট লেখা',
            'hero_promo_title' => 'শিরোনাম',
            'hero_promo_description' => 'বিবরণ',
            'hero_promo_regular_price' => 'নিয়মিত মূল্য',
            'hero_promo_offer_price' => 'অফার মূল্য',
            'hero_promo_cta_label' => 'বাটনের লেখা',
            'hero_promo_cta_url' => 'বাটনের লিংক',
            'hero_promo_video_url' => 'ভিডিও লিংক',
            'hero_promo_media_type' => 'মিডিয়া ধরন',
            'hero_promo_image' => 'প্রোমো ছবি',
            'hero_promo_video' => 'প্রোমো ভিডিও',
        ]);

        foreach (self::TEXT_FIELDS as $key) {
            Setting::put($key, $validated[$key] ?? '');
        }

        Setting::put('hero_promo_media_type', $validated['hero_promo_media_type']);
        Setting::put('hero_promo_enabled', $request->boolean('hero_promo_enabled') ? '1' : '0');
        Setting::put('hero_promo_media_only', $request->boolean('hero_promo_media_only') ? '1' : '0');

        $this->applyMedia($request, 'hero_promo_image', 'hero', self::IMAGE_EXTENSIONS);
        $this->applyMedia($request, 'hero_promo_video', 'hero', self::VIDEO_EXTENSIONS);

        return back()->with('status', 'হিরো প্রোমো সেটিংস আপডেট করা হয়েছে।');
    }

    /**
     * Resolve the current image/video: a new upload wins, then a file picked from
     * the storage library, then an explicit remove. Files are never deleted here
     * because the same file can be reused by several pages.
     */
    private function applyMedia(Request $request, string $key, string $folder, array $extensions): void
    {
        if ($request->hasFile($key)) {
            Setting::put($key, $request->file($key)->store($folder, 'public'));

            return;
        }

        $pick = trim((string) $request->input($key.'_pick', ''));
        if ($pick !== '' && $this->isStoredMedia($pick, $extensions)) {
            Setting::put($key, $pick);

            return;
        }

        if ($request->boolean($key.'_remove')) {
            Setting::put($key, '');
        }
    }

    private function isStoredMedia(string $path, array $extensions): bool
    {
        if ($path === '' || str_contains($path, '..') || str_starts_with($path, '/')) {
            return false;
        }

        if (! in_array(strtolower(pathinfo($path, PATHINFO_EXTENSION)), $extensions, true)) {
            return false;
        }

        return Storage::disk('public')->exists($path);
    }

    /**
     * Every image/video already in the public storage disk, newest first.
     *
     * @return array{images: array<int, array<string, mixed>>, videos: array<int, array<string, mixed>>}
     */
    private function mediaLibrary(): array
    {
        $disk = Storage::disk('public');
        $library = ['images' => [], 'videos' => []];

        foreach ($disk->allFiles() as $path) {
            $extension = strtolower(pathinfo($path, PATHINFO_EXTENSION));

            if (in_array($extension, self::IMAGE_EXTENSIONS, true)) {
                $kind = 'images';
            } elseif (in_array($extension, self::VIDEO_EXTENSIONS, true)) {
                $kind = 'videos';
            } else {
                continue;
            }

            try {
                $bytes = $disk->size($path);
                $modified = $disk->lastModified($path);
            } catch (\Throwable) {
                continue;
            }

            $folder = dirname($path);

            $library[$kind][] = [
                'path' => $path,
                'url' => $disk->url($path),
                'name' => basename($path),
                'folder' => $folder === '.' ? '' : trim($folder, '/'),
                'size' => $this->humanSize($bytes),
                'modified' => $modified,
            ];
        }

        foreach ($library as $kind => $files) {
            usort($files, fn (array $a, array $b) => $b['modified'] <=> $a['modified']);
            $library[$kind] = array_slice($files, 0, 120);
        }

        return $library;
    }

    private function humanSize(int $bytes): string
    {
        if ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 1).' MB';
        }

        if ($bytes >= 1024) {
            return number_format($bytes / 1024).' KB';
        }

        return $bytes.' B';
    }
}
