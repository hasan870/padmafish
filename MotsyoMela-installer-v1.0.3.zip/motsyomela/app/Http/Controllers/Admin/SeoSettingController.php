<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\Rule;

class SeoSettingController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();

        return view('admin.seo.edit', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'seo_meta_title' => ['nullable', 'string', 'max:160'],
            'seo_meta_description' => ['nullable', 'string', 'max:300'],
            'seo_meta_keywords' => ['nullable', 'string', 'max:300'],
            'seo_robots' => ['required', Rule::in(['index,follow', 'noindex,follow', 'index,nofollow', 'noindex,nofollow'])],
            'seo_google_verification' => ['nullable', 'string', 'max:160'],
            'seo_ga4_id' => ['nullable', 'string', 'max:40', 'regex:/^(G|UA|GT)-[A-Za-z0-9-]+$/'],
            'seo_og_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
        ], [
            'seo_meta_title.max' => 'মেটা টাইটেল ১৬০ অক্ষরের মধ্যে হতে হবে।',
            'seo_meta_description.max' => 'মেটা ডেসক্রিপশন ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'seo_meta_keywords.max' => 'কীওয়ার্ড ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'seo_robots.in' => 'রোবট সেটিং সঠিক নয়।',
            'seo_ga4_id.regex' => 'Google Analytics আইডি সঠিক নয় (যেমন: G-XXXXXXXXXX)।',
            'seo_og_image.image' => 'শেয়ার ছবি অবশ্যই একটি ছবি হতে হবে।',
            'seo_og_image.max' => 'শেয়ার ছবি সর্বোচ্চ ২ মেগাবাইট হতে পারে।',
        ], [
            'seo_meta_title' => 'মেটা টাইটেল',
            'seo_meta_description' => 'মেটা ডেসক্রিপশন',
            'seo_meta_keywords' => 'কীওয়ার্ড',
            'seo_robots' => 'রোবট সেটিং',
            'seo_google_verification' => 'গুগল ভেরিফিকেশন কোড',
            'seo_ga4_id' => 'Google Analytics আইডি',
            'seo_og_image' => 'শেয়ার ছবি',
        ]);

        foreach (['seo_meta_title', 'seo_meta_description', 'seo_meta_keywords', 'seo_robots', 'seo_google_verification', 'seo_ga4_id'] as $key) {
            Setting::put($key, $validated[$key] ?? '');
        }

        Setting::put('seo_ga_enabled', $request->boolean('seo_ga_enabled') ? '1' : '0');

        $currentImage = (string) Setting::get('seo_og_image', '');

        if ($request->boolean('seo_og_image_remove')) {
            if ($currentImage !== '') {
                Storage::disk('public')->delete($currentImage);
            }
            Setting::put('seo_og_image', '');
        } elseif ($request->hasFile('seo_og_image')) {
            if ($currentImage !== '') {
                Storage::disk('public')->delete($currentImage);
            }
            Setting::put('seo_og_image', $request->file('seo_og_image')->store('seo', 'public'));
        }

        return back()->with('status', 'SEO ও Google Analytics সেটিংস আপডেট করা হয়েছে।');
    }
}
