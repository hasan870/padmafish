<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Announcement;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class AnnouncementController extends Controller
{
    public function index(): View
    {
        $announcements = Announcement::query()->orderBy('sort_order')->orderBy('id')->paginate(15);

        return view('admin.announcements.index', compact('announcements'));
    }

    public function create(): View
    {
        $announcement = new Announcement(['is_active' => true]);

        return view('admin.announcements.form', compact('announcement'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateAnnouncement($request);

        Announcement::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.announcements.index')->with('status', 'নতুন ঘোষণা যোগ করা হয়েছে।');
    }

    public function edit(Announcement $announcement): View
    {
        return view('admin.announcements.form', compact('announcement'));
    }

    public function update(Request $request, Announcement $announcement): RedirectResponse
    {
        $validated = $this->validateAnnouncement($request);

        $announcement->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.announcements.index')->with('status', 'ঘোষণা আপডেট করা হয়েছে।');
    }

    public function destroy(Announcement $announcement): RedirectResponse
    {
        $announcement->delete();

        return redirect()->route('admin.announcements.index')->with('status', 'ঘোষণা ডিলিট করা হয়েছে।');
    }

    private function validateAnnouncement(Request $request): array
    {
        return $request->validate([
            'text_bn' => ['required', 'string', 'max:300'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'text_bn.required' => 'ঘোষণার লেখা লিখুন।',
            'text_bn.max' => 'ঘোষণা ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'text_bn' => 'ঘোষণা',
            'sort_order' => 'ক্রম',
        ]);
    }
}
