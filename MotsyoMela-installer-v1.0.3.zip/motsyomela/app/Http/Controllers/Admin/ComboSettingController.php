<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ComboPack;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class ComboSettingController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();
        $packCount = ComboPack::query()->where('is_active', true)->count();

        return view('admin.combo.edit', compact('settings', 'packCount'));
    }

    public function update(Request $request): RedirectResponse
    {
        Setting::put('combo_enabled', $request->boolean('combo_enabled') ? '1' : '0');

        return back()->with('status', 'কম্বো সেটিংস আপডেট করা হয়েছে।');
    }
}
