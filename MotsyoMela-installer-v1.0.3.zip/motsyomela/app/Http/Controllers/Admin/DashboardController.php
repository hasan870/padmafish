<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Contracts\View\View;
use Illuminate\Support\Facades\DB;

class DashboardController extends Controller
{
    public function index(): View
    {
        $today = now()->startOfDay();

        $todayOrders = Order::query()->where('created_at', '>=', $today)->count();

        $todayRevenue = Order::query()
            ->where('created_at', '>=', $today)
            ->where('status', '!=', 'cancelled')
            ->sum('grand_total');

        $pendingOrders = Order::query()->where('status', 'pending')->count();

        $outOfStock = Product::query()->where('is_in_stock', false)->count();

        $start = now()->subDays(6)->startOfDay();

        $daily = Order::query()
            ->selectRaw('DATE(created_at) as day, COUNT(*) as total')
            ->where('created_at', '>=', $start)
            ->groupBy('day')
            ->pluck('total', 'day');

        $weekLabels = [];
        $weekValues = [];

        for ($i = 6; $i >= 0; $i--) {
            $date = now()->subDays($i);
            $key = $date->toDateString();
            $weekLabels[] = $date->format('d M');
            $weekValues[] = (int) ($daily[$key] ?? 0);
        }

        $latestOrders = Order::query()
            ->withCount('items')
            ->latest()
            ->take(10)
            ->get();

        $weekRevenue = Order::query()
            ->where('created_at', '>=', $start)
            ->where('status', '!=', 'cancelled')
            ->sum('grand_total');

        $statusCounts = Order::query()
            ->select('status', DB::raw('COUNT(*) as total'))
            ->groupBy('status')
            ->pluck('total', 'status');

        return view('admin.dashboard', compact(
            'todayOrders', 'todayRevenue', 'pendingOrders', 'outOfStock',
            'weekLabels', 'weekValues', 'latestOrders', 'weekRevenue', 'statusCounts'
        ));
    }
}
