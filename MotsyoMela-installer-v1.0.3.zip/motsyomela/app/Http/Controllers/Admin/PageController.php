<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Page;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class PageController extends Controller
{
    public function index(): View
    {
        $pages = Page::query()->orderBy('sort_order')->orderBy('id')->paginate(15);

        return view('admin.pages.index', compact('pages'));
    }

    public function create(): View
    {
        $page = new Page(['is_active' => true, 'show_in_footer' => true]);

        return view('admin.pages.form', compact('page'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validatePage($request);

        Page::query()->create($validated + [
            'is_active' => $request->boolean('is_active'),
            'show_in_footer' => $request->boolean('show_in_footer'),
        ]);

        return redirect()->route('admin.pages.index')->with('status', 'নতুন পেজ তৈরি করা হয়েছে।');
    }

    public function edit(Page $page): View
    {
        return view('admin.pages.form', compact('page'));
    }

    public function update(Request $request, Page $page): RedirectResponse
    {
        $validated = $this->validatePage($request, $page);

        $page->update($validated + [
            'is_active' => $request->boolean('is_active'),
            'show_in_footer' => $request->boolean('show_in_footer'),
        ]);

        return redirect()->route('admin.pages.index')->with('status', 'পেজ আপডেট করা হয়েছে।');
    }

    public function destroy(Page $page): RedirectResponse
    {
        $page->delete();

        return redirect()->route('admin.pages.index')->with('status', 'পেজ ডিলিট করা হয়েছে।');
    }

    private function validatePage(Request $request, ?Page $page = null): array
    {
        $request->merge([
            'slug' => Str::slug((string) $request->input('slug') ?: (string) $request->input('title_en')),
        ]);

        return $request->validate([
            'slug' => [
                'required', 'string', 'max:120', 'alpha_dash',
                Rule::unique('pages', 'slug')->ignore($page?->id),
            ],
            'title_bn' => ['required', 'string', 'max:150'],
            'title_en' => ['nullable', 'string', 'max:150'],
            'content_bn' => ['nullable', 'string', 'max:200000'],
            'content_en' => ['nullable', 'string', 'max:200000'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'slug.required' => 'পেজের ঠিকানা (slug) লিখুন। ইংরেজি নাম দিলে সেটি থেকেও তৈরি হবে।',
            'slug.alpha_dash' => 'slug-এ শুধু ইংরেজি অক্ষর, সংখ্যা ও হাইফেন ব্যবহার করুন।',
            'slug.unique' => 'এই slug আগেই ব্যবহার করা হয়েছে।',
            'title_bn.required' => 'পেজের শিরোনাম লিখুন।',
            'title_bn.max' => 'শিরোনাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'title_en.max' => 'ইংরেজি শিরোনাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'content_bn.max' => 'HTML কনটেন্ট অনেক বড় হয়ে গেছে।',
            'content_en.max' => 'ইংরেজি HTML কনটেন্ট অনেক বড় হয়ে গেছে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'slug' => 'slug',
            'title_bn' => 'শিরোনাম',
            'title_en' => 'ইংরেজি শিরোনাম',
            'content_bn' => 'HTML কনটেন্ট',
            'content_en' => 'ইংরেজি HTML কনটেন্ট',
            'sort_order' => 'ক্রম',
        ]);
    }
}
