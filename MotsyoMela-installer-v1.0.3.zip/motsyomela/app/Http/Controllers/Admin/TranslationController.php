<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Translation;
use App\Support\TranslationScanner;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class TranslationController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('q')->toString());
        $group = $request->string('group')->toString();

        $translations = Translation::query()
            ->when($search !== '', function ($query) use ($search) {
                $query->where(function ($inner) use ($search) {
                    $inner->where('key', 'like', "%{$search}%")
                        ->orWhere('value_en', 'like', "%{$search}%");
                });
            })
            ->when($group !== '', fn ($query) => $query->where('group', $group))
            ->orderBy('group')
            ->orderBy('key')
            ->paginate(25)
            ->withQueryString();

        $groups = Translation::groups();

        return view('admin.translations.index', compact('translations', 'search', 'group', 'groups'));
    }

    public function sync(): RedirectResponse
    {
        $found = TranslationScanner::collect();
        $existing = Translation::query()->pluck('id', 'key');
        $added = 0;
        $filled = 0;

        foreach ($found as $key => $pair) {
            if ($existing->has($key)) {
                $updated = Translation::query()
                    ->where('key', $key)
                    ->where(fn ($query) => $query->whereNull('value_en')->orWhere('value_en', ''))
                    ->update(['value_en' => $pair['value_en']]);

                $filled += $updated;

                continue;
            }

            Translation::query()->create($pair);
            $added++;
        }

        Translation::flush();

        if ($added === 0 && $filled === 0) {
            return redirect()->route('admin.translations.index')
                ->with('status', 'সব লেবেল আগেই অনুবাদের তালিকায় আছে। নতুন কিছু পাওয়া যায়নি।');
        }

        return redirect()->route('admin.translations.index')->with(
            'status',
            'লেবেল স্ক্যান সম্পন্ন — নতুন '.bn_num($added).' টি যোগ ও '.bn_num($filled).' টি খালি অনুবাদ পূরণ করা হয়েছে।'
        );
    }

    public function create(): View
    {
        $translation = new Translation(['group' => 'general']);
        $groups = Translation::groups();

        return view('admin.translations.form', compact('translation', 'groups'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateTranslation($request);

        Translation::query()->create($validated);

        return redirect()->route('admin.translations.index')->with('status', 'নতুন অনুবাদ যোগ করা হয়েছে।');
    }

    public function edit(Translation $translation): View
    {
        $groups = Translation::groups();

        return view('admin.translations.form', compact('translation', 'groups'));
    }

    public function update(Request $request, Translation $translation): RedirectResponse
    {
        $validated = $this->validateTranslation($request, $translation);

        $translation->update($validated);

        return redirect()->route('admin.translations.index')->with('status', 'অনুবাদ আপডেট করা হয়েছে।');
    }

    public function destroy(Translation $translation): RedirectResponse
    {
        $translation->delete();

        return redirect()->route('admin.translations.index')->with('status', 'অনুবাদ ডিলিট করা হয়েছে।');
    }

    private function validateTranslation(Request $request, ?Translation $translation = null): array
    {
        return $request->validate([
            'key' => [
                'required', 'string', 'max:255',
                Rule::unique('translations', 'key')->ignore($translation?->id),
            ],
            'value_en' => ['nullable', 'string', 'max:500'],
            'group' => ['required', 'in:'.implode(',', array_keys(Translation::groups()))],
        ], [
            'key.required' => 'বাংলা লেবেল/বাক্য লিখুন।',
            'key.max' => 'লেবেল ২৫৫ অক্ষরের মধ্যে হতে হবে।',
            'key.unique' => 'এই লেবেলের অনুবাদ আগেই যোগ করা হয়েছে।',
            'value_en.max' => 'ইংরেজি অনুবাদ ৫০০ অক্ষরের মধ্যে হতে হবে।',
            'group.required' => 'বিভাগ নির্বাচন করুন।',
            'group.in' => 'বিভাগ সঠিক নয়।',
        ], [
            'key' => 'বাংলা লেবেল',
            'value_en' => 'ইংরেজি অনুবাদ',
            'group' => 'বিভাগ',
        ]);
    }
}
