<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Category;
use App\Models\Product;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    public function index(Request $request): View
    {
        $search = trim($request->string('q')->toString());
        $categoryId = $request->integer('category');

        $query = Product::query()->with('category')->withCount('sizes')->latest('id');

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('name_bn', 'like', "%{$search}%")
                    ->orWhere('name_en', 'like', "%{$search}%")
                    ->orWhere('origin_bn', 'like', "%{$search}%");
            });
        }

        if ($categoryId > 0) {
            $query->where('category_id', $categoryId);
        }

        $products = $query->paginate(12)->withQueryString();
        $categories = Category::query()->orderBy('sort_order')->orderBy('id')->get();

        return view('admin.products.index', compact('products', 'categories', 'search', 'categoryId'));
    }

    public function create(): View
    {
        $categories = Category::query()->orderBy('sort_order')->orderBy('id')->get();
        $product = new Product(['is_in_stock' => true]);

        return view('admin.products.form', compact('categories', 'product'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateProduct($request);

        $imagePath = $request->hasFile('image')
            ? $request->file('image')->store('products', 'public')
            : null;

        $product = Product::query()->create([
            'category_id' => $validated['category_id'],
            'name_bn' => $validated['name_bn'],
            'name_en' => $validated['name_en'] ?? null,
            'slug' => ($validated['slug'] ?? null) ?: $this->uniqueSlug($validated['name_en'] ?? $validated['name_bn']),
            'origin_bn' => $validated['origin_bn'] ?? null,
            'badge_bn' => $validated['badge_bn'] ?? null,
            'badge_color' => $validated['badge_color'] ?? null,
            'description_bn' => $validated['description_bn'] ?? null,
            'image' => $imagePath,
            'is_in_stock' => $request->boolean('is_in_stock'),
            'is_featured' => $request->boolean('is_featured'),
            'sort_order' => (int) ($validated['sort_order'] ?? 0),
        ]);

        $this->syncSizes($product, $validated['sizes']);

        return redirect()->route('admin.products.index')->with('status', 'নতুন পণ্য "'.$product->name_bn.'" সফলভাবে যোগ করা হয়েছে।');
    }

    public function edit(Product $product): View
    {
        $product->load('sizes');
        $categories = Category::query()->orderBy('sort_order')->orderBy('id')->get();

        return view('admin.products.form', compact('categories', 'product'));
    }

    public function update(Request $request, Product $product): RedirectResponse
    {
        $validated = $this->validateProduct($request, $product);

        $imagePath = $product->image;

        if ($request->hasFile('image')) {
            if ($product->image && ! str_starts_with($product->image, 'http')) {
                Storage::disk('public')->delete($product->image);
            }
            $imagePath = $request->file('image')->store('products', 'public');
        }

        $slug = $validated['slug'] ?? null;
        if (! $slug) {
            $slug = $product->slug ?: $this->uniqueSlug($validated['name_en'] ?? $validated['name_bn'], $product->id);
        }

        $product->update([
            'category_id' => $validated['category_id'],
            'name_bn' => $validated['name_bn'],
            'name_en' => $validated['name_en'] ?? null,
            'slug' => $slug,
            'origin_bn' => $validated['origin_bn'] ?? null,
            'badge_bn' => $validated['badge_bn'] ?? null,
            'badge_color' => $validated['badge_color'] ?? null,
            'description_bn' => $validated['description_bn'] ?? null,
            'image' => $imagePath,
            'is_in_stock' => $request->boolean('is_in_stock'),
            'is_featured' => $request->boolean('is_featured'),
            'sort_order' => (int) ($validated['sort_order'] ?? 0),
        ]);

        $product->sizes()->delete();
        $this->syncSizes($product, $validated['sizes']);

        return redirect()->route('admin.products.index')->with('status', 'পণ্য "'.$product->name_bn.'" আপডেট করা হয়েছে।');
    }

    public function destroy(Product $product): RedirectResponse
    {
        if ($product->orderItems()->exists()) {
            return redirect()->route('admin.products.index')
                ->with('error', 'এই পণ্যটি এক বা একাধিক অর্ডারে ব্যবহৃত হয়েছে। তাই ডিলিট করা যাবে না — বরং স্টক বন্ধ করুন।');
        }

        $name = $product->name_bn;
        $product->delete();

        return redirect()->route('admin.products.index')->with('status', 'পণ্য "'.$name.'" ডিলিট করা হয়েছে।');
    }

    private function validateProduct(Request $request, ?Product $product = null): array
    {
        return $request->validate([
            'category_id' => ['required', 'integer', 'exists:categories,id'],
            'name_bn' => ['required', 'string', 'max:150'],
            'name_en' => ['nullable', 'string', 'max:150'],
            'slug' => ['nullable', 'string', 'max:180', 'regex:/^[a-z0-9]+(?:-[a-z0-9]+)*$/', 'unique:products,slug'.($product ? ','.$product->id : '')],
            'origin_bn' => ['nullable', 'string', 'max:100'],
            'badge_bn' => ['nullable', 'string', 'max:50'],
            'badge_color' => ['nullable', 'string', 'max:50'],
            'description_bn' => ['nullable', 'string', 'max:1000'],
            'image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'is_in_stock' => ['nullable', 'boolean'],
            'is_featured' => ['nullable', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
            'sizes' => ['required', 'array', 'min:1', 'max:20'],
            'sizes.*.label_bn' => ['required', 'string', 'max:100'],
            'sizes.*.price_per_kg' => ['required', 'numeric', 'min:0.01', 'max:999999'],
        ], [
            'category_id.required' => 'ক্যাটাগরি নির্বাচন করুন।',
            'category_id.exists' => 'নির্বাচিত ক্যাটাগরি সঠিক নয়।',
            'name_bn.required' => 'পণ্যের বাংলা নাম লিখুন।',
            'name_bn.max' => 'বাংলা নাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'slug.regex' => 'স্লাগে শুধু ইংরেজি ছোট হাতের অক্ষর, সংখ্যা ও হাইফেন ব্যবহার করুন।',
            'slug.unique' => 'এই স্লাগটি আগেই ব্যবহৃত হয়েছে।',
            'image.image' => 'ছবি ফাইলটি সঠিক ইমেজ নয়।',
            'image.mimes' => 'ছবি অবশ্যই JPG, PNG অথবা WebP ফরম্যাটে হতে হবে।',
            'image.max' => 'ছবির সাইজ সর্বোচ্চ ২ মেগাবাইট হতে পারবে।',
            'sizes.required' => 'কমপক্ষে একটি সাইজ ও মূল্য যোগ করুন।',
            'sizes.min' => 'কমপক্ষে একটি সাইজ ও মূল্য যোগ করুন।',
            'sizes.*.label_bn.required' => 'প্রতিটি সাইজের বাংলা নাম লিখুন।',
            'sizes.*.price_per_kg.required' => 'প্রতিটি সাইজের প্রতি কেজির মূল্য লিখুন।',
            'sizes.*.price_per_kg.numeric' => 'মূল্য সঠিক সংখ্যা হতে হবে।',
            'sizes.*.price_per_kg.min' => 'মূল্য ০ এর চেয়ে বেশি হতে হবে।',
        ], [
            'category_id' => 'ক্যাটাগরি',
            'name_bn' => 'পণ্যের বাংলা নাম',
            'name_en' => 'পণ্যের ইংরেজি নাম',
            'slug' => 'স্লাগ',
            'origin_bn' => 'উৎস',
            'badge_bn' => 'ব্যাজ',
            'badge_color' => 'ব্যাজ রঙ',
            'description_bn' => 'বিবরণ',
            'image' => 'পণ্যের ছবি',
            'sort_order' => 'ক্রম',
            'sizes' => 'সাইজ তালিকা',
        ]);
    }

    private function syncSizes(Product $product, array $sizes): void
    {
        $rows = [];

        foreach (array_values($sizes) as $index => $size) {
            $rows[] = [
                'label_bn' => $size['label_bn'],
                'price_per_kg' => $size['price_per_kg'],
                'sort_order' => $index + 1,
            ];
        }

        $product->sizes()->createMany($rows);
    }

    private function uniqueSlug(string $source, ?int $ignoreId = null): string
    {
        $base = Str::slug($source);
        if ($base === '') {
            $base = 'product-'.Str::lower(Str::random(6));
        }

        $slug = $base;
        $counter = 2;

        while (
            Product::withTrashed()
                ->where('slug', $slug)
                ->when($ignoreId, fn ($query) => $query->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $slug = $base.'-'.$counter;
            $counter++;
        }

        return $slug;
    }
}
