<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class FooterSettingController extends Controller
{
    public const FIELDS = [
        'footer_about_text',
        'footer_address',
        'footer_hotline_note',
        'footer_payment_note',
        'footer_copyright',
        'footer_facebook_url',
        'footer_youtube_url',
        'footer_instagram_url',
        'footer_whatsapp_url',
    ];

    public function edit(): View
    {
        $settings = Setting::map();

        return view('admin.footer.edit', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'footer_about_text' => ['nullable', 'string', 'max:500'],
            'footer_address' => ['nullable', 'string', 'max:300'],
            'footer_hotline_note' => ['nullable', 'string', 'max:100'],
            'footer_payment_note' => ['nullable', 'string', 'max:300'],
            'footer_copyright' => ['nullable', 'string', 'max:300'],
            'footer_facebook_url' => ['nullable', 'url', 'max:255'],
            'footer_youtube_url' => ['nullable', 'url', 'max:255'],
            'footer_instagram_url' => ['nullable', 'url', 'max:255'],
            'footer_whatsapp_url' => ['nullable', 'url', 'max:255'],
        ], [
            'footer_about_text.max' => 'ফুটারের বিবরণ ৫০০ অক্ষরের মধ্যে হতে হবে।',
            'footer_address.max' => 'ঠিকানা ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'footer_hotline_note.max' => 'হটলাইনের সময় ১০০ অক্ষরের মধ্যে হতে হবে।',
            'footer_payment_note.max' => 'পেমেন্ট নোট ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'footer_copyright.max' => 'কপিরাইট লেখা ৩০০ অক্ষরের মধ্যে হতে হবে।',
            'footer_facebook_url.url' => 'ফেসবুক লিংকটি সঠিক URL হতে হবে (যেমন: https://facebook.com/yourpage)।',
            'footer_youtube_url.url' => 'ইউটিউব লিংকটি সঠিক URL হতে হবে।',
            'footer_instagram_url.url' => 'ইনস্টাগ্রাম লিংকটি সঠিক URL হতে হবে।',
            'footer_whatsapp_url.url' => 'হোয়াটসঅ্যাপ লিংকটি সঠিক URL হতে হবে।',
        ], [
            'footer_about_text' => 'ফুটারের বিবরণ',
            'footer_address' => 'ঠিকানা',
            'footer_hotline_note' => 'হটলাইনের সময়',
            'footer_payment_note' => 'পেমেন্ট নোট',
            'footer_copyright' => 'কপিরাইট লেখা',
            'footer_facebook_url' => 'ফেসবুক লিংক',
            'footer_youtube_url' => 'ইউটিউব লিংক',
            'footer_instagram_url' => 'ইনস্টাগ্রাম লিংক',
            'footer_whatsapp_url' => 'হোয়াটসঅ্যাপ লিংক',
        ]);

        foreach (self::FIELDS as $key) {
            Setting::put($key, $validated[$key] ?? '');
        }

        return back()->with('status', 'ফুটার সেটিংস আপডেট করা হয়েছে।');
    }
}
