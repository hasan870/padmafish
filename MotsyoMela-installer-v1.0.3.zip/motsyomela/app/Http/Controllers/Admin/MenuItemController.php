<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\MenuItem;
use Closure;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class MenuItemController extends Controller
{
    public function index(): View
    {
        $items = MenuItem::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate(20);

        return view('admin.menu.index', compact('items'));
    }

    public function create(): View
    {
        $item = new MenuItem(['is_active' => true, 'target' => '_self']);

        return view('admin.menu.form', compact('item'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateItem($request);

        MenuItem::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.menu-items.index')->with('status', 'নতুন হেডার মেনু আইটেম যোগ করা হয়েছে।');
    }

    public function edit(MenuItem $menuItem): View
    {
        return view('admin.menu.form', ['item' => $menuItem]);
    }

    public function update(Request $request, MenuItem $menuItem): RedirectResponse
    {
        $validated = $this->validateItem($request);

        $menuItem->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.menu-items.index')->with('status', 'মেনু আইটেম আপডেট করা হয়েছে।');
    }

    public function destroy(MenuItem $menuItem): RedirectResponse
    {
        $name = $menuItem->label_bn;
        $menuItem->delete();

        return redirect()->route('admin.menu-items.index')->with('status', 'মেনু আইটেম "'.$name.'" ডিলিট করা হয়েছে।');
    }

    private function validateItem(Request $request): array
    {
        $safeUrl = function (string $attribute, mixed $value, Closure $fail): void {
            $url = trim((string) $value);

            if (preg_match('/^\s*(javascript|data|vbscript):/i', $url)) {
                $fail('এই ধরনের লিংক অনুমোদিত নয়।');

                return;
            }

            if (! preg_match('#^(https?://|/|\#|tel:|mailto:)#i', $url)) {
                $fail('লিংকটি http(s)://, /, #, tel: অথবা mailto: দিয়ে শুরু করুন।');
            }
        };

        return $request->validate([
            'label_bn' => ['required', 'string', 'max:100'],
            'label_en' => ['nullable', 'string', 'max:100'],
            'url' => ['required', 'string', 'max:500', $safeUrl],
            'icon' => ['nullable', 'string', 'max:100', 'regex:/^fa-[a-z0-9-]+$/i'],
            'target' => ['required', 'in:_self,_blank'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'label_bn.required' => 'মেনুর বাংলা লেবেল লিখুন।',
            'label_bn.max' => 'লেবেল ১০০ অক্ষরের মধ্যে হতে হবে।',
            'url.required' => 'মেনু লিংক লিখুন।',
            'url.max' => 'লিংক ৫০০ অক্ষরের মধ্যে হতে হবে।',
            'icon.regex' => 'আইকন ক্লাস সঠিক নয় (যেমন: fa-house)।',
            'target.in' => 'লিংক খোলার ধরন সঠিক নয়।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'label_bn' => 'বাংলা লেবেল',
            'label_en' => 'ইংরেজি লেবেল',
            'url' => 'লিংক',
            'icon' => 'আইকন',
            'target' => 'টার্গেট',
            'sort_order' => 'ক্রম',
        ]);
    }
}
