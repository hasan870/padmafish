<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\TimeSlot;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class TimeSlotController extends Controller
{
    public function index(): View
    {
        $slots = TimeSlot::query()->orderBy('sort_order')->orderBy('id')->paginate(15);

        return view('admin.slots.index', compact('slots'));
    }

    public function create(): View
    {
        $slot = new TimeSlot(['is_active' => true]);

        return view('admin.slots.form', compact('slot'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateSlot($request);

        TimeSlot::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.slots.index')->with('status', 'নতুন ডেলিভারি সময় যোগ করা হয়েছে।');
    }

    public function edit(TimeSlot $slot): View
    {
        return view('admin.slots.form', compact('slot'));
    }

    public function update(Request $request, TimeSlot $slot): RedirectResponse
    {
        $validated = $this->validateSlot($request);

        $slot->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.slots.index')->with('status', 'ডেলিভারি সময় আপডেট করা হয়েছে।');
    }

    public function destroy(TimeSlot $slot): RedirectResponse
    {
        $slot->delete();

        return redirect()->route('admin.slots.index')->with('status', 'ডেলিভারি সময় ডিলিট করা হয়েছে।');
    }

    private function validateSlot(Request $request): array
    {
        return $request->validate([
            'label_bn' => ['required', 'string', 'max:150'],
            'label_en' => ['nullable', 'string', 'max:150'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'label_bn.required' => 'ডেলিভারি সময়ের বিবরণ লিখুন।',
            'label_bn.max' => 'ডেলিভারি সময় ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'label_en.max' => 'ইংরেজি লেবেল ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'label_bn' => 'ডেলিভারি সময়',
            'label_en' => 'ইংরেজি লেবেল',
            'sort_order' => 'ক্রম',
        ]);
    }
}
