<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class ThemeSettingController extends Controller
{
    public const BACKGROUNDS = [
        'aurora' => 'অরোরা গ্লো (ডিফল্ট)',
        'gradient' => 'থিম গ্রেডিয়েন্ট',
        'solid' => 'সলিড ব্যাকগ্রাউন্ড',
        'image' => 'কাস্টম ছবি',
    ];

    public const LOGO_MODES = [
        'image' => 'ছবি + নাম লোগো (ডিফল্ট) — লোগোর পাশে সাইটের নাম ও ব্যাজ',
        'image_only' => 'শুধু ছবি লোগো — নাম, ব্যাজ ও ট্যাগলাইন দেখাবে না',
        'text' => 'টেক্সট লোগো — শুধু সাইটের নাম দেখাবে',
    ];

    public const THUMB_SHAPES = [
        'square' => 'স্কয়ার (গোলাকার কোণা)',
        'circle' => 'সার্কুলার (গোল)',
    ];

    public function edit(): View
    {
        $settings = Setting::map();
        $fonts = storefront_fonts();
        $englishFonts = storefront_english_fonts();
        $backgrounds = self::BACKGROUNDS;
        $logoModes = self::LOGO_MODES;
        $thumbShapes = self::THUMB_SHAPES;

        return view('admin.theme.edit', compact('settings', 'fonts', 'englishFonts', 'backgrounds', 'logoModes', 'thumbShapes'));
    }

    public function update(Request $request): RedirectResponse
    {
        $banglaFontKeys = array_keys(storefront_fonts());
        $englishFontKeys = array_keys(storefront_english_fonts());

        $validated = $request->validate([
            'site_name' => ['required', 'string', 'max:100'],
            'site_tagline' => ['required', 'string', 'max:150'],
            'site_badge' => ['nullable', 'string', 'max:10'],
            'theme_primary' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'theme_secondary' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'theme_accent' => ['required', 'regex:/^#[0-9a-fA-F]{6}$/'],
            // Legacy single-font key: still accepted and used as the Bangla font.
            'theme_font' => ['nullable', 'in:'.implode(',', $banglaFontKeys)],
            'theme_font_bangla' => ['nullable', 'in:'.implode(',', $banglaFontKeys)],
            'theme_font_english' => ['nullable', 'in:'.implode(',', $englishFontKeys)],
            'theme_font_size' => ['nullable', 'integer', 'min:13', 'max:22'],
            'theme_h1_scale' => ['nullable', 'integer', 'min:70', 'max:150'],
            'theme_h2_scale' => ['nullable', 'integer', 'min:70', 'max:150'],
            'theme_h3_scale' => ['nullable', 'integer', 'min:70', 'max:150'],
            'theme_text_scale' => ['nullable', 'integer', 'min:80', 'max:130'],
            'theme_icon_scale' => ['nullable', 'integer', 'min:70', 'max:150'],
            'theme_text_color' => ['nullable', 'regex:/^#[0-9a-fA-F]{6}$/'],
            'theme_radius' => ['required', 'integer', 'min:0', 'max:32'],
            'theme_border_width' => ['required', 'integer', 'min:0', 'max:3'],
            'theme_bg_style' => ['required', 'in:'.implode(',', array_keys(self::BACKGROUNDS))],
            'theme_bg_overlay' => ['required', 'integer', 'min:0', 'max:90'],
            'theme_logo_mode' => ['required', 'in:'.implode(',', array_keys(self::LOGO_MODES))],
            'combo_thumb_shape' => ['required', 'in:'.implode(',', array_keys(self::THUMB_SHAPES))],
            'theme_logo' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'theme_bg_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:4096'],
        ], [
            'site_name.required' => 'সাইটের নাম লিখুন।',
            'site_tagline.required' => 'সাইটের ট্যাগলাইন লিখুন।',
            'theme_primary.regex' => 'প্রাইমারি রঙ সঠিক hex কোড হতে হবে (যেমন: #14b8a6)।',
            'theme_secondary.regex' => 'সেকেন্ডারি রঙ সঠিক hex কোড হতে হবে।',
            'theme_accent.regex' => 'অ্যাকসেন্ট রঙ সঠিক hex কোড হতে হবে।',
            'theme_font.in' => 'নির্বাচিত ফন্ট সঠিক নয়।',
            'theme_font_bangla.in' => 'বাংলা ফন্ট সঠিক নয়।',
            'theme_font_english.in' => 'ইংরেজি ফন্ট সঠিক নয়।',
            'theme_font_size.integer' => 'মূল ফন্ট সাইজ পূর্ণসংখ্যা হতে হবে।',
            'theme_font_size.min' => 'মূল ফন্ট সাইজ সর্বনিম্ন ১৩ পিক্সেল।',
            'theme_font_size.max' => 'মূল ফন্ট সাইজ সর্বোচ্চ ২২ পিক্সেল।',
            'theme_h1_scale.*' => 'H1 সাইজ ৭০% থেকে ১৫০% এর মধ্যে হতে হবে।',
            'theme_h2_scale.*' => 'H2 সাইজ ৭০% থেকে ১৫০% এর মধ্যে হতে হবে।',
            'theme_h3_scale.*' => 'H3 সাইজ ৭০% থেকে ১৫০% এর মধ্যে হতে হবে।',
            'theme_text_scale.*' => 'সাধারণ লেখার সাইজ ৮০% থেকে ১৩০% এর মধ্যে হতে হবে।',
            'theme_icon_scale.*' => 'আইকনের সাইজ ৭০% থেকে ১৫০% এর মধ্যে হতে হবে।',
            'theme_text_color.regex' => 'লেখার রঙ সঠিক hex কোড হতে হবে (যেমন: #e2f0f9)।',
            'theme_radius.min' => 'বর্ডার রেডিয়াস ০ থেকে ৩২ পিক্সেলের মধ্যে হতে হবে।',
            'theme_border_width.max' => 'বর্ডারের পুরুত্ব সর্বোচ্চ ৩ পিক্সেল হতে পারবে।',
            'theme_bg_style.in' => 'ব্যাকগ্রাউন্ড স্টাইল সঠিক নয়।',
            'theme_logo_mode.in' => 'লোগোর ধরন সঠিক নয়।',
            'combo_thumb_shape.in' => 'কম্বো থাম্বনেইলের আকৃতি সঠিক নয়।',
            'theme_logo.image' => 'লোগো অবশ্যই একটি ছবি হতে হবে।',
            'theme_logo.max' => 'লোগো সর্বোচ্চ ২ মেগাবাইট হতে পারবে।',
            'theme_bg_image.image' => 'ব্যাকগ্রাউন্ড অবশ্যই একটি ছবি হতে হবে।',
            'theme_bg_image.max' => 'ব্যাকগ্রাউন্ড ছবি সর্বোচ্চ ৪ মেগাবাইট হতে পারবে।',
        ], [
            'site_name' => 'সাইটের নাম',
            'site_tagline' => 'ট্যাগলাইন',
            'site_badge' => 'ব্যাজ',
            'theme_primary' => 'প্রাইমারি রঙ',
            'theme_secondary' => 'সেকেন্ডারি রঙ',
            'theme_accent' => 'অ্যাকসেন্ট রঙ',
            'theme_font' => 'ফন্ট',
            'theme_font_bangla' => 'বাংলা ফন্ট',
            'theme_font_english' => 'ইংরেজি ফন্ট',
            'theme_font_size' => 'মূল ফন্ট সাইজ',
            'theme_h1_scale' => 'H1 সাইজ',
            'theme_h2_scale' => 'H2 সাইজ',
            'theme_h3_scale' => 'H3 সাইজ',
            'theme_text_scale' => 'সাধারণ লেখার সাইজ',
            'theme_icon_scale' => 'আইকনের সাইজ',
            'theme_text_color' => 'লেখার রঙ',
            'theme_radius' => 'বর্ডার রেডিয়াস',
            'theme_border_width' => 'বর্ডার পুরুত্ব',
            'theme_bg_style' => 'ব্যাকগ্রাউন্ড স্টাইল',
            'theme_bg_overlay' => 'ব্যাকগ্রাউন্ড ওভারলে',
            'theme_logo_mode' => 'লোগোর ধরন',
            'combo_thumb_shape' => 'কম্বো থাম্বনেইল আকৃতি',
            'theme_logo' => 'লোগো',
            'theme_bg_image' => 'ব্যাকগ্রাউন্ড ছবি',
        ]);

        $currentLogo = (string) Setting::get('theme_logo', '');
        $currentBg = (string) Setting::get('theme_bg_image', '');
        $removeBg = $request->boolean('theme_bg_image_remove');

        if ($validated['theme_bg_style'] === 'image'
            && ! $request->hasFile('theme_bg_image')
            && ($removeBg || $currentBg === '')) {
            throw ValidationException::withMessages([
                'theme_bg_image' => 'কাস্টম ছবি ব্যাকগ্রাউন্ড ব্যবহার করতে একটি ছবি আপলোড করুন।',
            ]);
        }

        $newLogo = $currentLogo;
        if ($request->hasFile('theme_logo')) {
            $newLogo = $request->file('theme_logo')->store('theme', 'public');
            $this->deleteStoredFile($currentLogo);
        } elseif ($request->boolean('theme_logo_remove')) {
            $this->deleteStoredFile($currentLogo);
            $newLogo = '';
        }

        $newBg = $currentBg;
        if ($request->hasFile('theme_bg_image')) {
            $newBg = $request->file('theme_bg_image')->store('theme', 'public');
            $this->deleteStoredFile($currentBg);
        } elseif ($removeBg) {
            $this->deleteStoredFile($currentBg);
            $newBg = '';
        }

        foreach (['site_name', 'site_tagline', 'site_badge', 'theme_primary', 'theme_secondary', 'theme_accent',
            'theme_radius', 'theme_border_width', 'theme_bg_style', 'theme_bg_overlay',
            'theme_logo_mode', 'combo_thumb_shape', 'theme_font_english', 'theme_font_size',
            'theme_h1_scale', 'theme_h2_scale', 'theme_h3_scale', 'theme_text_scale', 'theme_icon_scale',
            'theme_text_color'] as $key) {
            // New typography keys are optional so older partial submissions keep
            // their stored values instead of wiping them.
            if (array_key_exists($key, $validated)) {
                Setting::put($key, $validated[$key] ?? '');
            }
        }

        // The Bangla font is stored under its own key; theme_font stays in sync
        // for older templates and saved data.
        $banglaFont = $validated['theme_font_bangla'] ?? $validated['theme_font'] ?? null;
        if ($banglaFont !== null) {
            Setting::put('theme_font_bangla', $banglaFont);
            Setting::put('theme_font', $banglaFont);
        }

        Setting::put('show_cutting_preference', $request->boolean('show_cutting_preference') ? '1' : '0');
        Setting::put('theme_logo', $newLogo);
        Setting::put('theme_bg_image', $newBg);

        return back()->with('status', 'স্টোরফ্রন্ট থিম আপডেট করা হয়েছে।');
    }

    private function deleteStoredFile(?string $path): void
    {
        if ($path && ! str_starts_with($path, 'http')) {
            Storage::disk('public')->delete($path);
        }
    }
}
