<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Validation\ValidationException;

class PaymentSettingController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();

        return view('admin.payments.edit', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $iconRules = [];
        foreach (['cod', 'bkash', 'nagad', 'card'] as $method) {
            $iconRules['payment_'.$method.'_icon'] = ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:1024'];
        }

        $validated = $request->validate($iconRules + [
            'payment_bkash_number' => ['nullable', 'string', 'max:50'],
            'payment_bkash_type' => ['required', 'in:personal,merchant'],
            'payment_bkash_link' => ['nullable', 'url', 'max:500'],
            'payment_bkash_instructions' => ['nullable', 'string', 'max:500'],
            'payment_bkash_qr' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'payment_nagad_number' => ['nullable', 'string', 'max:50'],
            'payment_nagad_type' => ['required', 'in:personal,merchant'],
            'payment_nagad_link' => ['nullable', 'url', 'max:500'],
            'payment_nagad_instructions' => ['nullable', 'string', 'max:500'],
            'payment_card_gateway' => ['nullable', 'string', 'max:100'],
            'payment_card_link' => ['nullable', 'url', 'max:500'],
            'payment_card_instructions' => ['nullable', 'string', 'max:500'],
        ], [
            'payment_bkash_type.in' => 'বিকাশ অ্যাকাউন্টের ধরন সঠিক নয়।',
            'payment_bkash_link.url' => 'বিকাশ পেমেন্ট লিংকটি সঠিক URL নয়।',
            'payment_bkash_qr.image' => 'বিকাশ QR কোড অবশ্যই একটি ছবি হতে হবে।',
            'payment_bkash_qr.max' => 'QR কোডের ছবি সর্বোচ্চ ২ মেগাবাইট হতে পারবে।',
            'payment_nagad_type.in' => 'নগদ অ্যাকাউন্টের ধরন সঠিক নয়।',
            'payment_nagad_link.url' => 'নগদ পেমেন্ট লিংকটি সঠিক URL নয়।',
            'payment_card_link.url' => 'কার্ড পেমেন্ট লিংকটি সঠিক URL নয়।',
            'max' => ':attribute ৫০০ অক্ষরের মধ্যে হতে হবে।',
        ], [
            'payment_bkash_number' => 'বিকাশ নম্বর',
            'payment_bkash_link' => 'বিকাশ পেমেন্ট লিংক',
            'payment_bkash_instructions' => 'বিকাশ নির্দেশনা',
            'payment_bkash_qr' => 'বিকাশ QR কোড',
            'payment_nagad_number' => 'নগদ নম্বর',
            'payment_nagad_link' => 'নগদ পেমেন্ট লিংক',
            'payment_nagad_instructions' => 'নগদ নির্দেশনা',
            'payment_card_gateway' => 'কার্ড গেটওয়ে',
            'payment_card_link' => 'কার্ড পেমেন্ট লিংক',
            'payment_card_instructions' => 'কার্ড নির্দেশনা',
        ]);

        $methods = ['cod', 'bkash', 'nagad', 'card'];
        $enabled = [];

        foreach ($methods as $method) {
            $enabled[$method] = $request->boolean('payment_'.$method.'_enabled');
        }

        if (! in_array(true, $enabled, true)) {
            throw ValidationException::withMessages([
                'payment_methods' => 'কমপক্ষে একটি পেমেন্ট মেথড সক্রিয় রাখতে হবে।',
            ]);
        }

        foreach ($enabled as $method => $isEnabled) {
            Setting::put('payment_'.$method.'_enabled', $isEnabled ? '1' : '0');
        }

        unset($validated['payment_bkash_qr']);

        foreach ($validated as $key => $value) {
            Setting::put($key, $value ?? '');
        }

        foreach (['cod', 'bkash', 'nagad', 'card'] as $method) {
            $key = 'payment_'.$method.'_icon';
            $current = (string) Setting::get($key, '');

            if ($request->boolean($key.'_remove')) {
                if ($current !== '') {
                    Storage::disk('public')->delete($current);
                }
                Setting::put($key, '');

                continue;
            }

            if ($request->hasFile($key)) {
                if ($current !== '') {
                    Storage::disk('public')->delete($current);
                }
                Setting::put($key, $request->file($key)->store('payments', 'public'));
            }
        }

        $qrKey = 'payment_bkash_qr';
        $currentQr = (string) Setting::get($qrKey, '');

        if ($request->boolean($qrKey.'_remove')) {
            if ($currentQr !== '') {
                Storage::disk('public')->delete($currentQr);
            }
            Setting::put($qrKey, '');
        } elseif ($request->hasFile($qrKey)) {
            if ($currentQr !== '') {
                Storage::disk('public')->delete($currentQr);
            }
            Setting::put($qrKey, $request->file($qrKey)->store('payments', 'public'));
        }

        return back()->with('status', 'পেমেন্ট গেটওয়ে সেটিংস আপডেট করা হয়েছে।');
    }
}
