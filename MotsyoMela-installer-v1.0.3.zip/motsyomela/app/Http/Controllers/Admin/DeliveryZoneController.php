<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\DeliveryZone;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class DeliveryZoneController extends Controller
{
    public function index(): View
    {
        $zones = DeliveryZone::query()
            ->withCount('orders')
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate(15);

        return view('admin.zones.index', compact('zones'));
    }

    public function create(): View
    {
        $zone = new DeliveryZone(['is_active' => true]);

        return view('admin.zones.form', compact('zone'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateZone($request);

        DeliveryZone::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.zones.index')->with('status', 'নতুন ডেলিভারি এলাকা যোগ করা হয়েছে।');
    }

    public function edit(DeliveryZone $zone): View
    {
        return view('admin.zones.form', compact('zone'));
    }

    public function update(Request $request, DeliveryZone $zone): RedirectResponse
    {
        $validated = $this->validateZone($request);

        $zone->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.zones.index')->with('status', 'ডেলিভারি এলাকা আপডেট করা হয়েছে।');
    }

    public function destroy(DeliveryZone $zone): RedirectResponse
    {
        if ($zone->orders()->exists()) {
            return back()->with('error', 'এই এলাকার অধীনে অর্ডার রয়েছে। তাই ডিলিট করা যাবে না — নিষ্ক্রিয় করে দিন।');
        }

        $zone->delete();

        return redirect()->route('admin.zones.index')->with('status', 'ডেলিভারি এলাকা ডিলিট করা হয়েছে।');
    }

    private function validateZone(Request $request): array
    {
        return $request->validate([
            'name_bn' => ['required', 'string', 'max:150'],
            'name_en' => ['nullable', 'string', 'max:150'],
            'charge' => ['required', 'numeric', 'min:0', 'max:99999'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'name_bn.required' => 'এলাকার নাম লিখুন।',
            'name_bn.max' => 'এলাকার নাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'name_en.max' => 'ইংরেজি নাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'charge.required' => 'ডেলিভারি চার্জ লিখুন।',
            'charge.numeric' => 'ডেলিভারি চার্জ একটি সংখ্যা হতে হবে।',
            'charge.min' => 'ডেলিভারি চার্জ ঋণাত্মক হতে পারবে না।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'name_bn' => 'এলাকার নাম',
            'name_en' => 'ইংরেজি নাম',
            'charge' => 'ডেলিভারি চার্জ',
            'sort_order' => 'ক্রম',
        ]);
    }
}
