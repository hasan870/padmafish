<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Testimonial;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class TestimonialController extends Controller
{
    public function index(): View
    {
        $testimonials = Testimonial::query()->latest('id')->paginate(15);

        return view('admin.testimonials.index', compact('testimonials'));
    }

    public function create(): View
    {
        $testimonial = new Testimonial(['rating' => 5, 'is_active' => true]);

        return view('admin.testimonials.form', compact('testimonial'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateTestimonial($request);

        Testimonial::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.testimonials.index')->with('status', 'নতুন রিভিউ যোগ করা হয়েছে।');
    }

    public function edit(Testimonial $testimonial): View
    {
        return view('admin.testimonials.form', compact('testimonial'));
    }

    public function update(Request $request, Testimonial $testimonial): RedirectResponse
    {
        $validated = $this->validateTestimonial($request);

        $testimonial->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.testimonials.index')->with('status', 'রিভিউ আপডেট করা হয়েছে।');
    }

    public function destroy(Testimonial $testimonial): RedirectResponse
    {
        $testimonial->delete();

        return redirect()->route('admin.testimonials.index')->with('status', 'রিভিউ ডিলিট করা হয়েছে।');
    }

    private function validateTestimonial(Request $request): array
    {
        return $request->validate([
            'customer_name_bn' => ['required', 'string', 'max:100'],
            'location_bn' => ['nullable', 'string', 'max:100'],
            'quote_bn' => ['required', 'string', 'max:1000'],
            'initial_bn' => ['nullable', 'string', 'max:5'],
            'rating' => ['required', 'integer', 'min:1', 'max:5'],
        ], [
            'customer_name_bn.required' => 'কাস্টমারের নাম লিখুন।',
            'quote_bn.required' => 'রিভিউয়ের লেখা লিখুন।',
            'rating.required' => 'রেটিং নির্বাচন করুন।',
            'rating.min' => 'রেটিং ১ থেকে ৫ এর মধ্যে হতে হবে।',
            'rating.max' => 'রেটিং ১ থেকে ৫ এর মধ্যে হতে হবে।',
        ], [
            'customer_name_bn' => 'কাস্টমারের নাম',
            'location_bn' => 'এলাকা',
            'quote_bn' => 'রিভিউ',
            'initial_bn' => 'ইনিশিয়াল',
            'rating' => 'রেটিং',
        ]);
    }
}
