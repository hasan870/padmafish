<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class SiteSettingController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();

        return view('admin.settings.edit', compact('settings'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'site_phone' => ['required', 'string', 'max:50'],
            'whatsapp_number' => ['nullable', 'string', 'max:50'],
            'delivery_hours' => ['required', 'string', 'max:150'],
            'about_title' => ['nullable', 'string', 'max:120'],
            'about_subtitle' => ['nullable', 'string', 'max:160'],
            'about_text' => ['nullable', 'string', 'max:3000'],
            'about_points' => ['nullable', 'string', 'max:1000'],
            'about_image' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:3072'],
        ], [
            'site_phone.required' => 'সাইটের হটলাইন নম্বর লিখুন।',
            'site_phone.max' => 'হটলাইন নম্বর ৫০ অক্ষরের মধ্যে হতে হবে।',
            'whatsapp_number.max' => 'হোয়াটসঅ্যাপ নম্বর ৫০ অক্ষরের মধ্যে হতে হবে।',
            'delivery_hours.required' => 'ডেলিভারি সময়ের লেখা দিন।',
            'delivery_hours.max' => 'ডেলিভারি সময় ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'about_title.max' => 'শিরোনাম ১২০ অক্ষরের মধ্যে হতে হবে।',
            'about_subtitle.max' => 'সাব-শিরোনাম ১৬০ অক্ষরের মধ্যে হতে হবে।',
            'about_text.max' => 'বিবরণ ৩০০০ অক্ষরের মধ্যে হতে হবে।',
            'about_image.image' => 'আমাদের সম্পর্কে ছবি অবশ্যই একটি ছবি হতে হবে।',
            'about_image.max' => 'ছবিটি সর্বোচ্চ ৩ মেগাবাইট হতে পারবে।',
        ], [
            'site_phone' => 'হটলাইন নম্বর',
            'whatsapp_number' => 'হোয়াটসঅ্যাপ নম্বর',
            'delivery_hours' => 'ডেলিভারি সময়',
            'about_title' => 'শিরোনাম',
            'about_subtitle' => 'সাব-শিরোনাম',
            'about_text' => 'বিবরণ',
            'about_points' => 'বুলেট পয়েন্ট',
            'about_image' => 'আমাদের সম্পর্কে ছবি',
        ]);

        Setting::put('site_phone', $validated['site_phone']);
        Setting::put('whatsapp_number', $validated['whatsapp_number'] ?? '');
        Setting::put('delivery_hours', $validated['delivery_hours']);
        Setting::put('review_enabled', $request->boolean('review_enabled') ? '1' : '0');

        foreach (['about_title', 'about_subtitle', 'about_text', 'about_points'] as $key) {
            Setting::put($key, $validated[$key] ?? '');
        }

        $currentAboutImage = (string) Setting::get('about_image', '');

        if ($request->boolean('about_image_remove')) {
            if ($currentAboutImage !== '') {
                Storage::disk('public')->delete($currentAboutImage);
            }
            Setting::put('about_image', '');
        } elseif ($request->hasFile('about_image')) {
            if ($currentAboutImage !== '') {
                Storage::disk('public')->delete($currentAboutImage);
            }
            Setting::put('about_image', $request->file('about_image')->store('about', 'public'));
        }

        return back()->with('status', 'সাইট সেটিংস আপডেট করা হয়েছে।');
    }
}
