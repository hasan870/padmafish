<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Admin;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class AdminUserController extends Controller
{
    public function index(): View
    {
        $admins = Admin::query()->orderBy('id')->paginate(15);

        return view('admin.admins.index', compact('admins'));
    }

    public function create(): View
    {
        $admin = new Admin(['role' => 'staff']);

        return view('admin.admins.form', compact('admin'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150', 'unique:admins,email'],
            'role' => ['required', 'in:super,staff'],
            'password' => ['required', 'string', 'min:8', 'max:100', 'confirmed'],
        ], [
            'name.required' => 'অ্যাডমিনের নাম লিখুন।',
            'email.required' => 'ইমেইল অ্যাড্রেস লিখুন।',
            'email.email' => 'সঠিক ইমেইল অ্যাড্রেস লিখুন।',
            'email.unique' => 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে।',
            'role.required' => 'রোল নির্বাচন করুন।',
            'role.in' => 'রোল সঠিক নয়।',
            'password.required' => 'পাসওয়ার্ড দিন।',
            'password.min' => 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।',
            'password.confirmed' => 'পাসওয়ার্ড নিশ্চিতকরণ মেলেনি।',
        ], [
            'name' => 'নাম',
            'email' => 'ইমেইল',
            'role' => 'রোল',
            'password' => 'পাসওয়ার্ড',
        ]);

        Admin::query()->create($validated);

        return redirect()->route('admin.admins.index')->with('status', 'নতুন অ্যাডমিন অ্যাকাউন্ট তৈরি করা হয়েছে।');
    }

    public function edit(Admin $admin): View
    {
        return view('admin.admins.form', compact('admin'));
    }

    public function update(Request $request, Admin $admin): RedirectResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:100'],
            'email' => ['required', 'email', 'max:150', Rule::unique('admins', 'email')->ignore($admin->id)],
            'role' => ['required', 'in:super,staff'],
            'password' => ['nullable', 'string', 'min:8', 'max:100', 'confirmed'],
        ], [
            'name.required' => 'অ্যাডমিনের নাম লিখুন।',
            'email.required' => 'ইমেইল অ্যাড্রেস লিখুন।',
            'email.email' => 'সঠিক ইমেইল অ্যাড্রেস লিখুন।',
            'email.unique' => 'এই ইমেইল দিয়ে ইতিমধ্যে একটি অ্যাকাউন্ট আছে।',
            'role.required' => 'রোল নির্বাচন করুন।',
            'role.in' => 'রোল সঠিক নয়।',
            'password.min' => 'পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে।',
            'password.confirmed' => 'পাসওয়ার্ড নিশ্চিতকরণ মেলেনি।',
        ], [
            'name' => 'নাম',
            'email' => 'ইমেইল',
            'role' => 'রোল',
            'password' => 'পাসওয়ার্ড',
        ]);

        if ($admin->isSuper() && $validated['role'] !== 'super' && Admin::query()->where('role', 'super')->count() <= 1) {
            return back()->withInput()->with('error', 'শেষ সুপার অ্যাডমিনের রোল পরিবর্তন করা যাবে না।');
        }

        if (auth('admin')->id() === $admin->id && $validated['role'] !== 'super') {
            return back()->withInput()->with('error', 'নিজের সুপার অ্যাডমিন রোল পরিবর্তন করা যাবে না।');
        }

        $admin->name = $validated['name'];
        $admin->email = $validated['email'];
        $admin->role = $validated['role'];
        if (! empty($validated['password'])) {
            $admin->password = $validated['password'];
        }
        $admin->save();

        return redirect()->route('admin.admins.index')->with('status', 'অ্যাডমিন অ্যাকাউন্ট আপডেট করা হয়েছে।');
    }

    public function destroy(Admin $admin): RedirectResponse
    {
        if (auth('admin')->id() === $admin->id) {
            return back()->with('error', 'নিজের অ্যাকাউন্ট ডিলিট করা যাবে না।');
        }

        if ($admin->isSuper() && Admin::query()->where('role', 'super')->count() <= 1) {
            return back()->with('error', 'শেষ সুপার অ্যাডমিনকে ডিলিট করা যাবে না।');
        }

        $admin->delete();

        return redirect()->route('admin.admins.index')->with('status', 'অ্যাডমিন অ্যাকাউন্ট ডিলিট করা হয়েছে।');
    }
}
