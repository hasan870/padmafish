<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Setting;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\Facades\Mail;

class MailSettingController extends Controller
{
    public function edit(): View
    {
        $settings = Setting::map();
        $hasPassword = (string) Setting::get('mail_password', '') !== '';

        return view('admin.mail.edit', compact('settings', 'hasPassword'));
    }

    public function update(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'mail_driver' => ['required', 'in:log,smtp'],
            'mail_admin_email' => ['nullable', 'email', 'max:150'],
            'mail_from_address' => ['required', 'email', 'max:150'],
            'mail_from_name' => ['required', 'string', 'max:100'],
            'mail_host' => ['nullable', 'required_if:mail_driver,smtp', 'string', 'max:255'],
            'mail_port' => ['nullable', 'required_if:mail_driver,smtp', 'integer', 'min:1', 'max:65535'],
            'mail_username' => ['nullable', 'string', 'max:255'],
            'mail_password' => ['nullable', 'string', 'max:255'],
            'mail_encryption' => ['required', 'in:tls,ssl,none'],
        ], [
            'mail_driver.in' => 'মেইল ড্রাইভার সঠিক নয়।',
            'mail_admin_email.email' => 'অ্যাডমিন ইমেইল সঠিক নয়।',
            'mail_from_address.required' => 'প্রেরকের ইমেইল ঠিকানা লিখুন।',
            'mail_from_address.email' => 'প্রেরকের ইমেইল ঠিকানা সঠিক নয়।',
            'mail_from_name.required' => 'প্রেরকের নাম লিখুন।',
            'mail_host.required_if' => 'SMTP হোস্ট লিখুন।',
            'mail_port.required_if' => 'SMTP পোর্ট লিখুন।',
            'mail_port.integer' => 'পোর্ট একটি সংখ্যা হতে হবে।',
            'mail_port.max' => 'পোর্ট ৬৫৫৩৫ এর মধ্যে হতে হবে।',
            'mail_encryption.in' => 'এনক্রিপশন ধরন সঠিক নয়।',
        ], [
            'mail_driver' => 'মেইল ড্রাইভার',
            'mail_admin_email' => 'অ্যাডমিন ইমেইল',
            'mail_from_address' => 'প্রেরকের ইমেইল',
            'mail_from_name' => 'প্রেরকের নাম',
            'mail_host' => 'SMTP হোস্ট',
            'mail_port' => 'SMTP পোর্ট',
            'mail_username' => 'SMTP ইউজারনেম',
            'mail_password' => 'SMTP পাসওয়ার্ড',
            'mail_encryption' => 'এনক্রিপশন',
        ]);

        Setting::put('mail_enabled', $request->boolean('mail_enabled') ? '1' : '0');
        Setting::put('mail_driver', $validated['mail_driver']);
        Setting::put('mail_admin_email', $validated['mail_admin_email'] ?? '');
        Setting::put('mail_from_address', $validated['mail_from_address']);
        Setting::put('mail_from_name', $validated['mail_from_name']);
        Setting::put('mail_host', $validated['mail_host'] ?? '');
        Setting::put('mail_port', (string) ($validated['mail_port'] ?? 587));
        Setting::put('mail_username', $validated['mail_username'] ?? '');
        Setting::put('mail_encryption', $validated['mail_encryption']);

        if ($request->boolean('mail_password_clear')) {
            Setting::put('mail_password', '');
        } elseif (! empty($validated['mail_password'])) {
            Setting::put('mail_password', Crypt::encryptString($validated['mail_password']));
        }

        return back()->with('status', 'ইমেইল সেটিংস আপডেট করা হয়েছে।');
    }

    public function test(Request $request): RedirectResponse
    {
        $validated = $request->validate([
            'test_email' => ['required', 'email', 'max:150'],
        ], [
            'test_email.required' => 'টেস্ট ইমেইল ঠিকানা লিখুন।',
            'test_email.email' => 'টেস্ট ইমেইল ঠিকানা সঠিক নয়।',
        ]);

        try {
            Mail::raw(
                "মৎস্যমেলা ইমেইল সেটআপ সফলভাবে কাজ করছে।\n\nসময়: ".now()->format('d/m/Y h:i A')."\n",
                fn ($message) => $message->to($validated['test_email'])->subject('মৎস্যমেলা — টেস্ট ইমেইল')
            );
        } catch (\Throwable $exception) {
            report($exception);

            return back()->with('error', 'টেস্ট ইমেইল পাঠানো যায়নি: '.$exception->getMessage());
        }

        return back()->with('status', 'টেস্ট ইমেইল পাঠানো হয়েছে ('.$validated['test_email'].')।');
    }
}
