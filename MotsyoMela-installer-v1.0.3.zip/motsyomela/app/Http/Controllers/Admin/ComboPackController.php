<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\ComboPack;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class ComboPackController extends Controller
{
    public function index(): View
    {
        $packs = ComboPack::query()
            ->orderBy('sort_order')
            ->orderBy('id')
            ->paginate(15);

        return view('admin.combo-packs.index', compact('packs'));
    }

    public function create(): View
    {
        $pack = new ComboPack(['is_active' => true, 'discount_type' => 'percent']);

        return view('admin.combo-packs.form', compact('pack'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validatePack($request);

        ComboPack::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.combo-packs.index')->with('status', 'নতুন কম্বো প্যাক যোগ করা হয়েছে।');
    }

    public function edit(ComboPack $comboPack): View
    {
        return view('admin.combo-packs.form', ['pack' => $comboPack]);
    }

    public function update(Request $request, ComboPack $comboPack): RedirectResponse
    {
        $validated = $this->validatePack($request, $comboPack);

        $comboPack->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.combo-packs.index')->with('status', 'কম্বো প্যাক আপডেট করা হয়েছে।');
    }

    public function destroy(ComboPack $comboPack): RedirectResponse
    {
        $name = $comboPack->name_bn;
        $comboPack->delete();

        return redirect()->route('admin.combo-packs.index')->with('status', 'কম্বো প্যাক "'.$name.'" ডিলিট করা হয়েছে।');
    }

    private function validatePack(Request $request, ?ComboPack $pack = null): array
    {
        $discountMax = $request->input('discount_type') === 'fixed' ? 100000 : 90;

        return $request->validate([
            'name_bn' => ['required', 'string', 'max:150'],
            'name_en' => ['nullable', 'string', 'max:150'],
            'item_count' => ['required', 'integer', 'min:2', 'max:10', Rule::unique('combo_packs', 'item_count')->ignore($pack?->id)],
            'discount_type' => ['required', 'in:percent,fixed'],
            'discount_value' => ['required', 'numeric', 'min:0.01', 'max:'.$discountMax],
            'badge_bn' => ['nullable', 'string', 'max:50'],
            'description_bn' => ['nullable', 'string', 'max:500'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'name_bn.required' => 'কম্বো প্যাকের বাংলা নাম লিখুন।',
            'name_bn.max' => 'নাম ১৫০ অক্ষরের মধ্যে হতে হবে।',
            'item_count.required' => 'কম্বোতে কতটি মাছ থাকবে তা লিখুন।',
            'item_count.min' => 'কম্বোতে কমপক্ষে ২টি মাছ থাকতে হবে।',
            'item_count.max' => 'কম্বোতে সর্বোচ্চ ১০টি মাছ রাখা যাবে।',
            'item_count.unique' => 'এই সংখ্যার একটি কম্বো প্যাক ইতিমধ্যে আছে। আগে সেটি এডিট করুন বা ডিলিট করুন।',
            'discount_type.in' => 'ছাড়ের ধরন সঠিক নয়।',
            'discount_value.required' => 'ছাড়ের পরিমাণ লিখুন।',
            'discount_value.numeric' => 'ছাড়ের পরিমাণ একটি সংখ্যা হতে হবে।',
            'discount_value.min' => 'ছাড়ের পরিমাণ শূন্যের বেশি হতে হবে।',
            'discount_value.max' => 'শতকরা ছাড় সর্বোচ্চ ৯০% হতে পারবে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'name_bn' => 'বাংলা নাম',
            'name_en' => 'ইংরেজি নাম',
            'item_count' => 'মাছের সংখ্যা',
            'discount_type' => 'ছাড়ের ধরন',
            'discount_value' => 'ছাড়ের পরিমাণ',
            'badge_bn' => 'ব্যাজ',
            'description_bn' => 'বিবরণ',
            'sort_order' => 'ক্রম',
        ]);
    }
}
