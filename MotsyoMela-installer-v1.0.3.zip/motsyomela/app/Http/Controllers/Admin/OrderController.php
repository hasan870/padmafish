<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Mail\OrderMail;
use App\Models\Order;
use App\Models\Setting;
use App\Models\Testimonial;
use App\Support\ReviewLink;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;

class OrderController extends Controller
{
    public function index(Request $request): View
    {
        $status = $request->string('status')->toString();
        $search = trim($request->string('q')->toString());

        $query = Order::query()->withCount('items')->with('zone')->latest();

        if ($status !== '' && in_array($status, Order::STATUSES, true)) {
            $query->where('status', $status);
        }

        if ($search !== '') {
            $query->where(function ($q) use ($search) {
                $q->where('order_number', 'like', "%{$search}%")
                    ->orWhere('customer_phone', 'like', "%{$search}%")
                    ->orWhere('customer_name', 'like', "%{$search}%");
            });
        }

        $orders = $query->paginate(15)->withQueryString();

        $statusCounts = Order::query()
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return view('admin.orders.index', compact('orders', 'status', 'search', 'statusCounts'));
    }

    public function show(Order $order): View
    {
        $order->load(['items', 'zone']);

        $whatsappLink = whatsapp_url(
            Setting::get('whatsapp_number', ''),
            'হ্যালো '.$order->customer_name.', আপনার মৎস্যমেলা অর্ডার '.$order->order_number.' সম্পর্কে যোগাযোগ করছি।'
        );

        $reviewUrl = ReviewLink::for($order);

        // One-tap WhatsApp message that carries the order summary and the review link
        // straight to the customer's own number.
        $customerWhatsappLink = whatsapp_url(
            $order->customer_phone,
            trim(
                'হ্যালো '.$order->customer_name.', '.Setting::get('site_name', 'মৎস্যমেলা')
                .' থেকে আপনার অর্ডার '.$order->order_number.' নিশ্চিত হয়েছে। মোট '.bn_money($order->grand_total).'।'
                .($reviewUrl ? "\n\nআপনার অভিজ্ঞতা জানাতে ভিজিট করুন: ".$reviewUrl : '')
            )
        );

        $review = Testimonial::query()->where('order_number', $order->order_number)->first();

        return view('admin.orders.show', compact('order', 'whatsappLink', 'reviewUrl', 'customerWhatsappLink', 'review'));
    }

    public function advanceStatus(Order $order): RedirectResponse
    {
        $next = $order->nextStatus();

        if ($next === null) {
            return back()->with('error', 'এই অর্ডারের জন্য পরবর্তী কোনো স্ট্যাটাস নেই।');
        }

        $order->update(['status' => $next]);

        return back()->with('status', 'অর্ডার স্ট্যাটাস "'.$order->statusLabelBn().'" এ পরিবর্তন করা হয়েছে।');
    }

    public function cancel(Request $request, Order $order): RedirectResponse
    {
        $validated = $request->validate([
            'cancel_reason' => ['required', 'string', 'min:3', 'max:255'],
        ], [
            'cancel_reason.required' => 'অর্ডার বাতিলের কারণ লিখুন।',
            'cancel_reason.min' => 'বাতিলের কারণ কমপক্ষে ৩ অক্ষরের হতে হবে।',
            'cancel_reason.max' => 'বাতিলের কারণ ২৫৫ অক্ষরের মধ্যে হতে হবে।',
        ]);

        if (in_array($order->status, ['delivered', 'cancelled'], true)) {
            return back()->with('error', 'সম্পন্ন বা ইতিমধ্যে বাতিলকৃত অর্ডার বাতিল করা যাবে না।');
        }

        $order->update([
            'status' => 'cancelled',
            'cancel_reason' => $validated['cancel_reason'],
        ]);

        return back()->with('status', 'অর্ডারটি বাতিল করা হয়েছে।');
    }

    public function destroy(Order $order): RedirectResponse
    {
        $number = $order->order_number;

        $order->delete();

        return redirect()
            ->route('admin.orders.index')
            ->with('status', 'অর্ডার '.$number.' এবং এর সব আইটেম ডিলিট করা হয়েছে।');
    }

    public function invoice(Order $order): View
    {
        $order->load(['items', 'zone']);

        $settings = Setting::map();

        return view('admin.orders.invoice', compact('order', 'settings'));
    }

    public function updatePayment(Request $request, Order $order): RedirectResponse
    {
        $validated = $request->validate([
            'payment_status' => ['required', 'in:'.implode(',', Order::PAYMENT_STATUSES)],
            'payment_reference' => ['nullable', 'string', 'max:100'],
        ], [
            'payment_status.required' => 'পেমেন্ট স্ট্যাটাস নির্বাচন করুন।',
            'payment_status.in' => 'পেমেন্ট স্ট্যাটাস সঠিক নয়।',
            'payment_reference.max' => 'পেমেন্ট রেফারেন্স ১০০ অক্ষরের মধ্যে হতে হবে।',
        ], [
            'payment_status' => 'পেমেন্ট স্ট্যাটাস',
            'payment_reference' => 'পেমেন্ট রেফারেন্স',
        ]);

        $order->update($validated);

        return back()->with('status', 'পেমেন্ট তথ্য আপডেট করা হয়েছে।');
    }

    public function emailInvoice(Request $request, Order $order): RedirectResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email', 'max:150'],
        ], [
            'email.required' => 'ইমেইল ঠিকানা লিখুন।',
            'email.email' => 'ইমেইল ঠিকানা সঠিক নয়।',
        ]);

        $order->load(['items', 'zone']);

        try {
            Mail::to($validated['email'])->send(new OrderMail($order, 'invoice'));
        } catch (\Throwable $exception) {
            report($exception);

            return back()->with('error', 'ইনভয়েস ইমেইল পাঠানো যায়নি: '.$exception->getMessage());
        }

        return back()->with('status', 'ইনভয়েস ইমেইল পাঠানো হয়েছে ('.$validated['email'].')।');
    }
}
