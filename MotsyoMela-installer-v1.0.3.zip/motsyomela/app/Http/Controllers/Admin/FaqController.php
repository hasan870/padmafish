<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Faq;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class FaqController extends Controller
{
    public function index(): View
    {
        $faqs = Faq::query()->orderBy('sort_order')->orderBy('id')->paginate(15);

        return view('admin.faqs.index', compact('faqs'));
    }

    public function create(): View
    {
        $faq = new Faq(['is_active' => true]);

        return view('admin.faqs.form', compact('faq'));
    }

    public function store(Request $request): RedirectResponse
    {
        $validated = $this->validateFaq($request);

        Faq::query()->create($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.faqs.index')->with('status', 'নতুন প্রশ্ন যোগ করা হয়েছে।');
    }

    public function edit(Faq $faq): View
    {
        return view('admin.faqs.form', compact('faq'));
    }

    public function update(Request $request, Faq $faq): RedirectResponse
    {
        $validated = $this->validateFaq($request);

        $faq->update($validated + ['is_active' => $request->boolean('is_active')]);

        return redirect()->route('admin.faqs.index')->with('status', 'প্রশ্ন আপডেট করা হয়েছে।');
    }

    public function destroy(Faq $faq): RedirectResponse
    {
        $faq->delete();

        return redirect()->route('admin.faqs.index')->with('status', 'প্রশ্ন ডিলিট করা হয়েছে।');
    }

    private function validateFaq(Request $request): array
    {
        return $request->validate([
            'question_bn' => ['required', 'string', 'max:250'],
            'answer_bn' => ['required', 'string', 'max:2000'],
            'sort_order' => ['nullable', 'integer', 'min:0', 'max:9999'],
        ], [
            'question_bn.required' => 'প্রশ্ন লিখুন।',
            'question_bn.max' => 'প্রশ্ন ২৫০ অক্ষরের মধ্যে হতে হবে।',
            'answer_bn.required' => 'উত্তর লিখুন।',
            'answer_bn.max' => 'উত্তর ২০০০ অক্ষরের মধ্যে হতে হবে।',
            'sort_order.integer' => 'ক্রম একটি সংখ্যা হতে হবে।',
        ], [
            'question_bn' => 'প্রশ্ন',
            'answer_bn' => 'উত্তর',
            'sort_order' => 'ক্রম',
        ]);
    }
}
