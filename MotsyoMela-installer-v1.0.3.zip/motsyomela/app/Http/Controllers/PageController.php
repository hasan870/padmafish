<?php

namespace App\Http\Controllers;

use App\Models\Page;
use Illuminate\Contracts\View\View;

class PageController extends Controller
{
    public function show(Page $page): View
    {
        abort_unless($page->is_active, 404);

        $data = HomeController::storefrontData();
        $data['page'] = $page;

        return view('storefront.page', $data);
    }
}
