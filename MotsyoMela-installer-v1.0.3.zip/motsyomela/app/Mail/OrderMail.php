<?php

namespace App\Mail;

use App\Models\Order;
use App\Models\Setting;
use App\Support\InvoicePdf;
use App\Support\ReviewLink;
use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Attachment;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class OrderMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct(
        public Order $order,
        public string $audience = 'customer',
    ) {
        $this->order->loadMissing(['items', 'zone']);
    }

    public function envelope(): Envelope
    {
        $subject = match ($this->audience) {
            'admin' => 'নতুন অর্ডার — '.$this->order->order_number,
            'invoice' => 'ইনভয়েস — '.$this->order->order_number,
            default => 'অর্ডার নিশ্চিত হয়েছে — '.$this->order->order_number,
        };

        return new Envelope(subject: $subject);
    }

    public function content(): Content
    {
        $method = $this->order->payment_method;
        $instructions = $method === 'cod'
            ? 'ডেলিভারির সময় পণ্য হাতে পেয়ে পেমেন্ট করুন।'
            : (string) Setting::get('payment_'.$method.'_instructions', '');
        $paymentNumber = in_array($method, ['bkash', 'nagad'], true)
            ? (string) Setting::get('payment_'.$method.'_number', '')
            : '';
        $paymentLink = $method === 'cod' ? '' : (string) Setting::get('payment_'.$method.'_link', '');

        $whatsappMessage = 'হ্যালো, আমার অর্ডার '.$this->order->order_number.' সম্পর্কে জানতে চাই।';

        return new Content(
            view: 'emails.order',
            with: [
                'settings' => Setting::map(),
                'paymentInstructions' => $instructions,
                'paymentNumber' => $paymentNumber,
                'paymentLink' => $paymentLink,
                'whatsappLink' => whatsapp_url(Setting::get('whatsapp_number', ''), $whatsappMessage),
                'reviewUrl' => ReviewLink::for($this->order),
            ],
        );
    }

    /**
     * Attach the invoice PDF to customer-facing order emails.
     */
    public function attachments(): array
    {
        if (! in_array($this->audience, ['customer', 'invoice'], true)) {
            return [];
        }

        $pdf = InvoicePdf::render($this->order);

        if ($pdf === null) {
            return [];
        }

        return [
            Attachment::fromData(fn () => $pdf, $this->order->order_number.'.pdf')
                ->withMime('application/pdf'),
        ];
    }
}
