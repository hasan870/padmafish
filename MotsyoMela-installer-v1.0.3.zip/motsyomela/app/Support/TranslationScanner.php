<?php

namespace App\Support;

use Symfony\Component\Finder\Finder;

class TranslationScanner
{
    /**
     * Collect every tr('বাংলা', 'English') pair used in views and app code.
     *
     * @return array<string, array{key: string, value_en: string, group: string}>
     */
    public static function collect(): array
    {
        $roots = [resource_path('views'), app_path()];
        $pairs = [];

        foreach ($roots as $root) {
            if (! is_dir($root)) {
                continue;
            }

            foreach (Finder::create()->files()->in($root)->name(['*.php', '*.blade.php']) as $file) {
                $source = (string) file_get_contents($file->getRealPath());
                $group = self::groupFor($file->getRelativePathname());

                foreach (self::matches($source) as $key => $english) {
                    if (! isset($pairs[$key])) {
                        $pairs[$key] = ['key' => $key, 'value_en' => $english, 'group' => $group];
                    }
                }
            }
        }

        return $pairs;
    }

    /**
     * @return array<string, string>
     */
    public static function matches(string $source): array
    {
        $pattern = "/\btr\(\s*'((?:[^'\\\\]|\\\\.)*)'\s*,\s*'((?:[^'\\\\]|\\\\.)*)'\s*[,)]/u";

        if (! preg_match_all($pattern, $source, $matches, PREG_SET_ORDER)) {
            return [];
        }

        $pairs = [];

        foreach ($matches as $match) {
            $key = self::unescape($match[1]);
            $english = self::unescape($match[2]);

            if ($key === '' || $english === '' || $key === $english) {
                continue;
            }

            $pairs[$key] = $english;
        }

        return $pairs;
    }

    private static function unescape(string $value): string
    {
        return str_replace(["\\'", '\\\\'], ["'", '\\'], trim($value));
    }

    private static function groupFor(string $relativePath): string
    {
        $path = str_replace('\\', '/', $relativePath);

        if (str_starts_with($path, 'admin/') || str_contains($path, '/Admin/')) {
            return 'admin';
        }

        $basename = basename($path);

        return match (true) {
            str_contains($path, 'storefront/partials/header'),
            str_contains($path, 'storefront/partials/footer'),
            str_contains($path, 'storefront/partials/mobile-nav') => 'nav',
            str_contains($path, 'storefront/partials/cart'),
            str_contains($path, 'storefront/partials/checkout'),
            str_contains($path, 'storefront/partials/success') => 'cart',
            str_contains($path, 'storefront/partials/catalog'),
            str_contains($path, 'storefront/partials/combo'),
            str_contains($path, 'storefront/partials/hero') => 'catalog',
            str_contains($path, 'account') => 'account',
            str_contains($path, 'emails/') => 'general',
            default => in_array($basename, ['header.blade.php', 'footer.blade.php'], true) ? 'nav' : 'general',
        };
    }
}
