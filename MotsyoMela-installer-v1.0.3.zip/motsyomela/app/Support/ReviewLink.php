<?php

namespace App\Support;

use App\Models\Order;
use App\Models\Setting;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\URL;

class ReviewLink
{
    /**
     * Reviews are only offered when the shop has review collection enabled.
     */
    public static function enabled(): bool
    {
        return Setting::get('review_enabled', '1') === '1';
    }

    /**
     * Temporary signed URL that lets the customer review this order without logging in.
     */
    public static function for(Order $order, int $days = 30): ?string
    {
        if (! self::enabled()) {
            return null;
        }

        // Anchor the expiry to the order date so every place that builds the link
        // (checkout response, email, admin page) produces the exact same signed URL.
        $expiresAt = ($order->created_at ?? Carbon::now())->copy()->addDays($days);

        if ($expiresAt->isPast()) {
            $expiresAt = Carbon::now()->addDays(7);
        }

        // Sign only the path so an emailed link keeps working when the store is
        // reached through another host (localhost, a vhost, http vs https).
        $relative = URL::temporarySignedRoute(
            'review.show',
            $expiresAt,
            ['order' => $order->getKey()],
            false
        );

        return url($relative);
    }
}
