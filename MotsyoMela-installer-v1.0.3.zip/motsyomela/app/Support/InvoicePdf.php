<?php

namespace App\Support;

use App\Models\Order;
use App\Models\Setting;
use Dompdf\Dompdf;
use Dompdf\Options;
use Illuminate\Support\Facades\File;
use Throwable;

class InvoicePdf
{
    /**
     * Render the customer invoice as a PDF binary. Returns null when the PDF
     * engine fails so that order email delivery is never blocked by it.
     */
    public static function render(Order $order): ?string
    {
        try {
            $order->loadMissing(['items', 'zone']);

            $fonts = str_replace('\\', '/', resource_path('fonts'));
            $cache = storage_path('fonts');
            File::ensureDirectoryExists($cache);

            $settings = Setting::map();

            $html = view('admin.orders.invoice-pdf', [
                'order' => $order,
                'settings' => $settings,
                'logoData' => self::imageDataUri((string) ($settings['theme_logo'] ?? '')),
                'qrData' => self::imageDataUri((string) ($settings['payment_bkash_qr'] ?? '')),
                // "file://" + absolute path: dompdf strips the scheme and runs realpath(),
                // which needs "file://C:/..." on Windows and "file:///..." on Linux.
                'fontRegular' => 'file://'.$fonts.'/HindSiliguri-Regular.ttf',
                'fontBold' => 'file://'.$fonts.'/HindSiliguri-Bold.ttf',
            ])->render();

            $options = new Options;
            $options->set('defaultFont', 'HindSiliguri');
            $options->set('isRemoteEnabled', false);
            $options->set('isFontSubsettingEnabled', true);
            $options->set('chroot', [resource_path('fonts')]);
            $options->set('fontDir', $cache);
            $options->set('fontCache', $cache);
            $options->set('tempDir', sys_get_temp_dir());

            $pdf = new Dompdf($options);
            $pdf->loadHtml($html, 'UTF-8');
            $pdf->setPaper('a4');
            $pdf->render();

            return $pdf->output();
        } catch (Throwable $exception) {
            report($exception);

            return null;
        }
    }

    public static function fileExists(string $path): bool
    {
        return $path !== ''
            && ! str_starts_with($path, 'http')
            && File::exists(storage_path('app/public/'.$path));
    }

    /**
     * Inline an uploaded image as a data URI so the PDF needs no remote access.
     */
    private static function imageDataUri(string $path): ?string
    {
        if (! self::fileExists($path)) {
            return null;
        }

        $absolute = storage_path('app/public/'.$path);
        $mime = File::mimeType($absolute) ?: 'image/png';

        return 'data:'.$mime.';base64,'.base64_encode((string) File::get($absolute));
    }
}
