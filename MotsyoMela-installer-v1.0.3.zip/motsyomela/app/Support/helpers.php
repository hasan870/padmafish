<?php

if (! function_exists('tr')) {
    /**
     * Translate a Bengali UI label for the current locale. English values come
     * from the admin translation manager, then from the inline fallback.
     */
    function tr(string $bn, string $en = ''): string
    {
        if (\Illuminate\Support\Facades\App::getLocale() !== 'en') {
            return $bn;
        }

        return \App\Models\Translation::englishFor($bn) ?? ($en !== '' ? $en : $bn);
    }
}

if (! function_exists('localized')) {
    /**
     * Pick the English content value when the storefront is in English mode.
     */
    function localized(?string $bn, ?string $en): string
    {
        if (\Illuminate\Support\Facades\App::getLocale() === 'en' && is_string($en) && trim($en) !== '') {
            return $en;
        }

        return (string) $bn;
    }
}

if (! function_exists('bn_num')) {
    /**
     * Convert western digits to Bengali digits, preserving separators.
     * English mode keeps western digits.
     */
    function bn_num(mixed $value): string
    {
        $string = (string) $value;

        if (\Illuminate\Support\Facades\App::getLocale() === 'en') {
            return $string;
        }

        $digits = ['0' => '০', '1' => '১', '2' => '২', '3' => '৩', '4' => '৪', '5' => '৫', '6' => '৬', '7' => '৭', '8' => '৮', '9' => '৯'];

        return strtr($string, $digits);
    }
}

if (! function_exists('bn_money')) {
    function bn_money(mixed $value, int $decimals = 0): string
    {
        return '৳'.bn_num(number_format((float) $value, $decimals));
    }
}

if (! function_exists('bn_kg')) {
    function bn_kg(mixed $value): string
    {
        $formatted = number_format((float) $value, 2, '.', '');
        $formatted = rtrim(rtrim($formatted, '0'), '.');

        return bn_num($formatted).tr(' কেজি', ' kg');
    }
}

if (! function_exists('order_status_classes')) {
    function order_status_classes(string $status): string
    {
        return match ($status) {
            'pending' => 'bg-amber-500/15 text-amber-500 border-amber-500/30',
            'confirmed' => 'bg-sky-500/15 text-sky-500 border-sky-500/30',
            'delivering' => 'bg-violet-500/15 text-violet-400 border-violet-500/30',
            'delivered' => 'bg-emerald-500/15 text-emerald-500 border-emerald-500/30',
            'cancelled' => 'bg-rose-500/15 text-rose-500 border-rose-500/30',
            default => 'bg-card2 text-ink2 border-line',
        };
    }
}

if (! function_exists('payment_status_classes')) {
    function payment_status_classes(string $status): string
    {
        return match ($status) {
            'unpaid' => 'bg-amber-500/15 text-amber-500 border-amber-500/30',
            'pending' => 'bg-sky-500/15 text-sky-500 border-sky-500/30',
            'paid' => 'bg-emerald-500/15 text-emerald-500 border-emerald-500/30',
            'refunded' => 'bg-rose-500/15 text-rose-400 border-rose-500/30',
            default => 'bg-card2 text-ink2 border-line',
        };
    }
}

if (! function_exists('normalize_bd_phone')) {
    /**
     * Normalize Bengali digits and common separators in a Bangladeshi phone number.
     */
    function normalize_bd_phone(?string $phone): string
    {
        $phone = trim((string) $phone);
        $phone = strtr($phone, ['০' => '0', '১' => '1', '২' => '2', '৩' => '3', '৪' => '4', '৫' => '5', '৬' => '6', '৭' => '7', '৮' => '8', '৯' => '9']);
        $phone = preg_replace('/[^0-9]/', '', $phone ?? '');

        if (str_starts_with($phone, '8801')) {
            $phone = '0'.substr($phone, 3);
        }

        return $phone ?? '';
    }
}

if (! function_exists('storefront_fonts')) {
    /**
     * Bengali font choices for the storefront "Bangla font family" setting.
     */
    function storefront_fonts(): array
    {
        return [
            'hind-siliguri' => ['label' => 'হিন্দ শিলিগুড়ি (Hind Siliguri)', 'family' => 'Hind Siliguri', 'weights' => '300;400;500;600;700'],
            'noto-sans-bengali' => ['label' => 'নোটো সান্স বাংলা (Noto Sans Bengali)', 'family' => 'Noto Sans Bengali', 'weights' => '300;400;500;600;700'],
            'noto-serif-bengali' => ['label' => 'নোটো সেরিফ বাংলা (Noto Serif Bengali)', 'family' => 'Noto Serif Bengali', 'weights' => '400;500;600;700'],
            'baloo-da-2' => ['label' => 'বালু দা ২ (Baloo Da 2)', 'family' => 'Baloo Da 2', 'weights' => '400;500;600;700;800'],
            'tiro-bangla' => ['label' => 'তিরো বাংলা (Tiro Bangla)', 'family' => 'Tiro Bangla', 'weights' => '400'],
        ];
    }
}

if (! function_exists('storefront_english_fonts')) {
    /**
     * English (Latin) font choices. The Latin font is applied first so Latin
     * glyphs use it and Bengali glyphs fall back to the Bengali font.
     */
    function storefront_english_fonts(): array
    {
        return [
            'inter' => ['label' => 'ইন্টার (Inter)', 'family' => 'Inter', 'weights' => '400;500;600;700;800'],
            'poppins' => ['label' => 'পপিন্স (Poppins)', 'family' => 'Poppins', 'weights' => '300;400;500;600;700;800'],
            'roboto' => ['label' => 'রোবোটো (Roboto)', 'family' => 'Roboto', 'weights' => '400;500;700;900'],
            'montserrat' => ['label' => 'মন্তসেরাত (Montserrat)', 'family' => 'Montserrat', 'weights' => '400;500;600;700;800'],
            'open-sans' => ['label' => 'ওপেন সান্স (Open Sans)', 'family' => 'Open Sans', 'weights' => '400;500;600;700;800'],
            'lato' => ['label' => 'লাতো (Lato)', 'family' => 'Lato', 'weights' => '400;700;900'],
            'nunito' => ['label' => 'নুনিতো (Nunito)', 'family' => 'Nunito', 'weights' => '400;600;700;800'],
            'work-sans' => ['label' => 'ওয়ার্ক সান্স (Work Sans)', 'family' => 'Work Sans', 'weights' => '400;500;600;700'],
        ];
    }
}

if (! function_exists('google_fonts_url')) {
    /**
     * Build one Google Fonts request for the selected Bengali + English fonts.
     */
    function google_fonts_url(string $banglaFamily, string $englishFamily, array $fontOptions, array $englishOptions): string
    {
        $requested = [];

        foreach ([$banglaFamily, $englishFamily] as $family) {
            foreach ([$fontOptions, $englishOptions] as $group) {
                $option = collect($group)->firstWhere('family', $family);
                if ($option !== null) {
                    $requested[$family] = $option['weights'] ?? '400;700';
                    break;
                }
            }
        }

        if ($requested === []) {
            return 'https://fonts.googleapis.com/css2?family=Inter&display=swap';
        }

        $parts = [];
        foreach ($requested as $family => $weights) {
            $parts[] = 'family='.urlencode($family).':wght@'.$weights;
        }

        return 'https://fonts.googleapis.com/css2?'.implode('&', $parts).'&display=swap';
    }
}

if (! function_exists('theme_palette')) {
    /**
     * Build a Tailwind-like 50–900 palette (as "r g b" triplets) from one hex color.
     */
    function theme_palette(string $hex): array
    {
        $hex = ltrim(trim($hex), '#');
        if (! preg_match('/^[0-9a-fA-F]{6}$/', $hex)) {
            $hex = '14b8a6';
        }

        $base = [hexdec(substr($hex, 0, 2)), hexdec(substr($hex, 2, 2)), hexdec(substr($hex, 4, 2))];

        $mix = static function (array $color, array $target, float $ratio): string {
            $r = (int) round($color[0] + ($target[0] - $color[0]) * $ratio);
            $g = (int) round($color[1] + ($target[1] - $color[1]) * $ratio);
            $b = (int) round($color[2] + ($target[2] - $color[2]) * $ratio);

            return $r.' '.$g.' '.$b;
        };

        $white = [255, 255, 255];
        $black = [0, 0, 0];

        return [
            50 => $mix($base, $white, 0.95),
            100 => $mix($base, $white, 0.88),
            200 => $mix($base, $white, 0.72),
            300 => $mix($base, $white, 0.52),
            400 => $mix($base, $white, 0.26),
            500 => implode(' ', $base),
            600 => $mix($base, $black, 0.15),
            700 => $mix($base, $black, 0.3),
            800 => $mix($base, $black, 0.45),
            900 => $mix($base, $black, 0.6),
        ];
    }
}

if (! function_exists('payment_icon_url')) {
    /**
     * Public URL of the admin-uploaded icon for a payment gateway, if any.
     */
    function payment_icon_url(array $settings, string $method): ?string
    {
        $path = (string) ($settings['payment_'.$method.'_icon'] ?? '');

        return $path !== '' ? \Illuminate\Support\Facades\Storage::url($path) : null;
    }
}

if (! function_exists('video_embed_url')) {
    /**
     * Turn a YouTube or Vimeo watch/share link into a player URL.
     * Returns null for anything else, so direct video files keep using <video>.
     */
    function video_embed_url(?string $url): ?string
    {
        $url = trim((string) $url);
        if ($url === '' || ! str_contains($url, '://')) {
            return null;
        }

        $parts = parse_url($url);
        if (! is_array($parts) || empty($parts['host'])) {
            return null;
        }

        $host = strtolower(preg_replace('/^www\./', '', $parts['host']) ?? '');
        $path = $parts['path'] ?? '';

        if ($host === 'youtu.be') {
            $id = trim($path, '/');

            return preg_match('/^[A-Za-z0-9_-]{6,}$/', $id) === 1
                ? 'https://www.youtube.com/embed/'.$id.'?rel=0'
                : null;
        }

        if (in_array($host, ['youtube.com', 'm.youtube.com', 'music.youtube.com', 'youtube-nocookie.com'], true)) {
            parse_str($parts['query'] ?? '', $query);
            $id = is_string($query['v'] ?? null) ? $query['v'] : '';

            if ($id === '' && preg_match('#^/(?:embed|shorts|live|v)/([A-Za-z0-9_-]{6,})#', $path, $matches) === 1) {
                $id = $matches[1];
            }

            return preg_match('/^[A-Za-z0-9_-]{6,}$/', (string) $id) === 1
                ? 'https://www.youtube.com/embed/'.$id.'?rel=0'
                : null;
        }

        if (in_array($host, ['vimeo.com', 'player.vimeo.com'], true) && preg_match('#/(\d{5,})#', $path, $matches) === 1) {
            return 'https://player.vimeo.com/video/'.$matches[1];
        }

        return null;
    }
}

if (! function_exists('whatsapp_url')) {
    function whatsapp_url(?string $number, string $message = ''): string
    {
        $normalized = normalize_bd_phone($number);
        if ($normalized === '') {
            return '';
        }

        $international = preg_replace('/\D+/', '', $normalized);
        if (str_starts_with($international, '01')) {
            $international = '88'.$international;
        }

        return 'https://wa.me/'.$international.($message !== '' ? '?text='.rawurlencode($message) : '');
    }
}
