<?php

namespace App\Providers;

use App\Models\Setting;
use Illuminate\Support\Facades\Crypt;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        $this->applyMailSettings();
    }

    private function applyMailSettings(): void
    {
        try {
            $driver = Setting::get('mail_driver');

            if ($driver === 'smtp') {
                $password = '';

                if ($stored = Setting::get('mail_password')) {
                    try {
                        $password = Crypt::decryptString($stored);
                    } catch (\Throwable) {
                        $password = '';
                    }
                }

                config([
                    'mail.default' => 'smtp',
                    'mail.mailers.smtp.host' => Setting::get('mail_host', '127.0.0.1'),
                    'mail.mailers.smtp.port' => (int) Setting::get('mail_port', 587),
                    'mail.mailers.smtp.username' => Setting::get('mail_username', ''),
                    'mail.mailers.smtp.password' => $password,
                    'mail.mailers.smtp.scheme' => Setting::get('mail_encryption', 'tls') === 'ssl' ? 'smtps' : null,
                ]);
            } elseif ($driver === 'log') {
                config(['mail.default' => 'log']);
            }

            if ($from = Setting::get('mail_from_address')) {
                config(['mail.from.address' => $from]);
            }

            if ($fromName = Setting::get('mail_from_name')) {
                config(['mail.from.name' => $fromName]);
            }
        } catch (\Throwable) {
            // Database may not be ready during install/migrations.
        }
    }
}
