<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Translation extends Model
{
    protected $fillable = ['key', 'value_en', 'group'];

    protected static ?array $englishMap = null;

    public static function flush(): void
    {
        static::$englishMap = null;
    }

    public static function englishFor(string $key): ?string
    {
        if (static::$englishMap === null) {
            try {
                static::$englishMap = static::query()
                    ->whereNotNull('value_en')
                    ->where('value_en', '!=', '')
                    ->pluck('value_en', 'key')
                    ->all();
            } catch (\Throwable) {
                static::$englishMap = [];
            }
        }

        $value = static::$englishMap[$key] ?? null;

        return is_string($value) && $value !== '' ? $value : null;
    }

    public static function groups(): array
    {
        return [
            'general' => 'সাধারণ',
            'nav' => 'নেভিগেশন',
            'catalog' => 'ক্যাটালগ',
            'cart' => 'কার্ট ও চেকআউট',
            'footer' => 'ফুটার',
            'account' => 'অ্যাকাউন্ট',
            'admin' => 'অ্যাডমিন',
        ];
    }
}
