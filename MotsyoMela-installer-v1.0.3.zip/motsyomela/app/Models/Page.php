<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Page extends Model
{
    protected $fillable = [
        'slug', 'title_bn', 'title_en', 'content_bn', 'content_en',
        'show_in_footer', 'is_active', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'show_in_footer' => 'boolean',
            'is_active' => 'boolean',
        ];
    }
}
