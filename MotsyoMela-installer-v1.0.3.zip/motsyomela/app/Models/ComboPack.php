<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ComboPack extends Model
{
    protected $fillable = [
        'name_bn', 'name_en', 'item_count', 'discount_type', 'discount_value',
        'badge_bn', 'description_bn', 'is_active', 'sort_order',
    ];

    protected function casts(): array
    {
        return [
            'item_count' => 'integer',
            'discount_value' => 'decimal:2',
            'is_active' => 'boolean',
            'sort_order' => 'integer',
        ];
    }

    public function discountLabelBn(): string
    {
        return $this->discount_type === 'percent'
            ? bn_num((int) $this->discount_value).'% ছাড়'
            : bn_money($this->discount_value).' ছাড়';
    }

    public function discountAmount(int $subtotal): int
    {
        $value = (float) $this->discount_value;

        $discount = $this->discount_type === 'percent'
            ? $subtotal * ($value / 100)
            : $value;

        return max(0, min((int) round($discount), $subtotal));
    }
}
