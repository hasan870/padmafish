<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Order extends Model
{
    use HasFactory;

    public const STATUSES = ['pending', 'confirmed', 'delivering', 'delivered', 'cancelled'];

    public const PAYMENT_STATUSES = ['unpaid', 'pending', 'paid', 'refunded'];

    protected $fillable = [
        'customer_id', 'order_number', 'customer_name', 'customer_phone', 'customer_email', 'customer_address',
        'delivery_zone_id', 'delivery_fee', 'time_slot_label', 'payment_method',
        'payment_reference', 'payment_status', 'subtotal', 'discount_amount', 'coupon_code',
        'combo_discount_amount', 'grand_total', 'status', 'cancel_reason',
    ];

    protected function casts(): array
    {
        return [
            'delivery_fee' => 'decimal:2',
            'subtotal' => 'decimal:2',
            'discount_amount' => 'decimal:2',
            'combo_discount_amount' => 'decimal:2',
            'grand_total' => 'decimal:2',
        ];
    }

    public function zone(): BelongsTo
    {
        return $this->belongsTo(DeliveryZone::class, 'delivery_zone_id');
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(User::class, 'customer_id');
    }

    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    public static function generateOrderNumber(): string
    {
        $date = now()->format('ymd');
        $prefix = 'MM-'.$date.'-';

        $last = static::query()
            ->where('order_number', 'like', $prefix.'%')
            ->orderByDesc('order_number')
            ->lockForUpdate()
            ->value('order_number');

        $sequence = $last ? ((int) substr($last, -4)) + 1 : 1;

        return $prefix.str_pad((string) $sequence, 4, '0', STR_PAD_LEFT);
    }

    public function nextStatus(): ?string
    {
        return match ($this->status) {
            'pending' => 'confirmed',
            'confirmed' => 'delivering',
            'delivering' => 'delivered',
            default => null,
        };
    }

    /**
     * Stored slot label, or its English name when the store is in English mode.
     */
    public function timeSlotLabel(): string
    {
        if (\Illuminate\Support\Facades\App::getLocale() === 'en') {
            $english = TimeSlot::query()
                ->where('label_bn', $this->time_slot_label)
                ->value('label_en');

            if (is_string($english) && $english !== '') {
                return $english;
            }
        }

        return (string) $this->time_slot_label;
    }

    public function statusLabelBn(): string
    {
        return match ($this->status) {
            'pending' => tr('অপেক্ষমাণ', 'Pending'),
            'confirmed' => tr('নিশ্চিত', 'Confirmed'),
            'delivering' => tr('ডেলিভারিতে', 'Out for delivery'),
            'delivered' => tr('সম্পন্ন', 'Delivered'),
            'cancelled' => tr('বাতিল', 'Cancelled'),
            default => $this->status,
        };
    }

    public function paymentLabelBn(): string
    {
        return match ($this->payment_method) {
            'cod' => tr('ক্যাশ অন ডেলিভারি', 'Cash on delivery'),
            'bkash' => 'bKash',
            'nagad' => 'Nagad',
            'card' => tr('কার্ড পেমেন্ট', 'Card payment'),
            default => $this->payment_method,
        };
    }

    public function paymentStatusLabelBn(): string
    {
        return match ($this->payment_status) {
            'unpaid' => tr('অপরিশোধিত', 'Unpaid'),
            'pending' => tr('যাচাইয়ের অপেক্ষায়', 'Awaiting verification'),
            'paid' => tr('পরিশোধিত', 'Paid'),
            'refunded' => tr('ফেরত দেওয়া হয়েছে', 'Refunded'),
            default => $this->payment_status,
        };
    }
}
