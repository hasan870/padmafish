<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Testimonial extends Model
{
    use HasFactory;

    protected $fillable = ['customer_name_bn', 'location_bn', 'quote_bn', 'initial_bn', 'rating', 'is_active', 'order_number'];

    protected function casts(): array
    {
        return [
            'rating' => 'integer',
            'is_active' => 'boolean',
        ];
    }

    public function getInitialsAttribute(): string
    {
        if ($this->initial_bn) {
            return $this->initial_bn;
        }

        $words = preg_split('/\s+/u', trim($this->customer_name_bn));

        return mb_substr($words[0] ?? '', 0, 1).mb_substr($words[1] ?? '', 0, 1);
    }
}
