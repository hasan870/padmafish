<?php

use App\Http\Controllers\Admin\AdminUserController;
use App\Http\Controllers\AccountController;
use App\Http\Controllers\Admin\AnnouncementController;
use App\Http\Controllers\Admin\AuthController;
use App\Http\Controllers\Admin\BannerController;
use App\Http\Controllers\Admin\CategoryController;
use App\Http\Controllers\Admin\ComboPackController;
use App\Http\Controllers\Admin\ComboSettingController;
use App\Http\Controllers\Admin\CouponController;
use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\DeliveryZoneController;
use App\Http\Controllers\Admin\FaqController;
use App\Http\Controllers\Admin\FooterSettingController;
use App\Http\Controllers\Admin\HeroPromoController;
use App\Http\Controllers\Admin\MailSettingController;
use App\Http\Controllers\Admin\MenuItemController;
use App\Http\Controllers\Admin\OrderController;
use App\Http\Controllers\Admin\PageController as AdminPageController;
use App\Http\Controllers\Admin\PaymentSettingController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\SeoSettingController;
use App\Http\Controllers\Admin\SiteSettingController;
use App\Http\Controllers\Admin\TestimonialController;
use App\Http\Controllers\Admin\ThemeSettingController;
use App\Http\Controllers\Admin\TimeSlotController;
use App\Http\Controllers\CheckoutController;
use App\Http\Controllers\CustomerAuthController;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\LanguageController;
use App\Http\Controllers\PageController;
use App\Http\Controllers\ReviewController;
use App\Http\Controllers\Admin\TranslationController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Storage;

Route::get('/', [HomeController::class, 'index'])->name('home');

// Only reached when public_html/storage is missing (symlink() disabled on the
// host): stream uploaded images straight from storage/app/public.
Route::get('storage/{path}', function (string $path) {
    abort_unless(preg_match('/\.(jpe?g|png|webp|gif|ico)$/i', $path) === 1, 404);
    abort_unless(Storage::disk('public')->exists($path), 404);

    return Storage::disk('public')->response($path, null, ['Cache-Control' => 'public, max-age=604800']);
})->where('path', '.*')->name('storage.fallback');

// Admin-authored HTML pages (delivery policy, refund policy, ...) rendered with
// the storefront header and footer.
Route::get('page/{page:slug}', [PageController::class, 'show'])->name('page.show');

Route::get('/csrf-token', fn () => response()
    ->json(['token' => csrf_token()])
    ->header('Cache-Control', 'no-store, no-cache, must-revalidate'))
    ->name('csrf.token');

// Optional customer accounts — signing in is never required to place an order.
Route::prefix('account')->name('account.')->group(function () {
    Route::middleware('guest:web')->group(function () {
        Route::get('login', [CustomerAuthController::class, 'showLogin'])->name('login');
        Route::post('login', [CustomerAuthController::class, 'login'])->middleware('throttle:10,1')->name('login.store');
        Route::get('register', [CustomerAuthController::class, 'showRegister'])->name('register');
        Route::post('register', [CustomerAuthController::class, 'register'])->middleware('throttle:10,1')->name('register.store');
    });

    Route::middleware('auth:web')->group(function () {
        Route::get('/', [AccountController::class, 'index'])->name('index');
        Route::put('profile', [AccountController::class, 'updateProfile'])->name('profile.update');
        Route::get('orders/{order}', [AccountController::class, 'order'])->name('orders.show');
        Route::post('logout', [CustomerAuthController::class, 'logout'])->name('logout');
    });
});

Route::post('/language/{locale}', [LanguageController::class, 'switch'])
    ->middleware('throttle:30,1')
    ->name('language.switch');

Route::post('/checkout', [CheckoutController::class, 'store'])
    ->middleware('throttle:30,1')
    ->name('checkout.store');

// Customer review page — reachable only through the temporary signed link that
// is emailed / shared on WhatsApp after an order.
Route::get('/review/{order}', [ReviewController::class, 'show'])
    ->middleware('signed:relative')
    ->name('review.show');

Route::post('/review/{order}', [ReviewController::class, 'store'])
    ->middleware(['signed:relative', 'throttle:10,1'])
    ->name('review.store');

Route::prefix('admin')->name('admin.')->group(function () {
    Route::get('login', [AuthController::class, 'showLogin'])->name('login');
    Route::post('login', [AuthController::class, 'login'])->name('login.store');
    Route::post('logout', [AuthController::class, 'logout'])->middleware('auth:admin')->name('logout');

    Route::middleware('auth:admin')->group(function () {
        Route::get('/', [DashboardController::class, 'index'])->name('dashboard');

        Route::get('orders', [OrderController::class, 'index'])->name('orders.index');
        Route::get('orders/{order}', [OrderController::class, 'show'])->name('orders.show');
        Route::patch('orders/{order}/status', [OrderController::class, 'advanceStatus'])->name('orders.status');
        Route::patch('orders/{order}/cancel', [OrderController::class, 'cancel'])->name('orders.cancel');
        Route::patch('orders/{order}/payment', [OrderController::class, 'updatePayment'])->name('orders.payment');
        Route::post('orders/{order}/email', [OrderController::class, 'emailInvoice'])->name('orders.email');
        Route::get('orders/{order}/invoice', [OrderController::class, 'invoice'])->name('orders.invoice');
        Route::delete('orders/{order}', [OrderController::class, 'destroy'])->name('orders.destroy');

        Route::resource('products', ProductController::class)->except(['show']);
        Route::resource('categories', CategoryController::class)->except(['show']);
        Route::resource('coupons', CouponController::class)->except(['show']);
        Route::resource('zones', DeliveryZoneController::class)->except(['show']);
        Route::resource('slots', TimeSlotController::class)->except(['show']);
        Route::resource('announcements', AnnouncementController::class)->except(['show']);
        Route::resource('faqs', FaqController::class)->except(['show']);
        Route::resource('testimonials', TestimonialController::class)->except(['show']);

        Route::resource('combo-packs', ComboPackController::class)->except(['show'])->parameters(['combo-packs' => 'comboPack']);
        Route::resource('menu-items', MenuItemController::class)->except(['show'])->parameters(['menu-items' => 'menuItem']);
        Route::resource('pages', AdminPageController::class)->except(['show']);

        Route::get('combo', [ComboSettingController::class, 'edit'])->name('combo.edit');
        Route::put('combo', [ComboSettingController::class, 'update'])->name('combo.update');

        Route::get('settings', [SiteSettingController::class, 'edit'])->name('settings.edit');
        Route::put('settings', [SiteSettingController::class, 'update'])->name('settings.update');

        Route::get('payments', [PaymentSettingController::class, 'edit'])->name('payments.edit');
        Route::put('payments', [PaymentSettingController::class, 'update'])->name('payments.update');

        Route::get('theme', [ThemeSettingController::class, 'edit'])->name('theme.edit');
        Route::put('theme', [ThemeSettingController::class, 'update'])->name('theme.update');

        Route::post('language/{locale}', [LanguageController::class, 'switchAdmin'])->name('language.switch');

        Route::post('translations/sync', [TranslationController::class, 'sync'])->name('translations.sync');
        Route::resource('translations', TranslationController::class)->except(['show']);

        Route::get('hero-promo', [HeroPromoController::class, 'edit'])->name('hero-promo.edit');
        Route::put('hero-promo', [HeroPromoController::class, 'update'])->name('hero-promo.update');

        Route::get('footer', [FooterSettingController::class, 'edit'])->name('footer.edit');
        Route::put('footer', [FooterSettingController::class, 'update'])->name('footer.update');

        Route::get('banners', [BannerController::class, 'edit'])->name('banners.edit');
        Route::put('banners', [BannerController::class, 'update'])->name('banners.update');

        Route::get('seo', [SeoSettingController::class, 'edit'])->name('seo.edit');
        Route::put('seo', [SeoSettingController::class, 'update'])->name('seo.update');

        Route::get('mail', [MailSettingController::class, 'edit'])->name('mail.edit');
        Route::put('mail', [MailSettingController::class, 'update'])->name('mail.update');
        Route::post('mail/test', [MailSettingController::class, 'test'])->name('mail.test');

        Route::middleware('admin.super')->group(function () {
            Route::resource('admins', AdminUserController::class)->except(['show']);
        });
    });
});
