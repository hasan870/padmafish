<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>{{ $order->order_number }}</title>
</head>
<body style="margin:0;padding:0;background:#eef4f6;font-family:'Hind Siliguri',Arial,sans-serif;color:#0f2430;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#eef4f6;padding:24px 12px;">
        <tr>
            <td align="center">
                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:640px;background:#ffffff;border-radius:18px;overflow:hidden;border:1px solid #d9e6eb;">
                    <tr>
                        <td style="background:linear-gradient(135deg,#0d9488,#0284c7);padding:26px 28px;color:#ffffff;">
                            <div style="font-size:24px;font-weight:800;letter-spacing:.3px;">{{ $settings['site_name'] ?? 'মৎস্যমেলা' }}</div>
                            <div style="font-size:12px;opacity:.9;margin-top:3px;">{{ $settings['site_tagline'] ?? '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট' }}</div>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:28px;">
                            @if ($audience === 'admin')
                                <h1 style="font-size:18px;margin:0 0 8px;">নতুন অর্ডার এসেছে</h1>
                                <p style="font-size:13px;color:#47616f;margin:0 0 20px;line-height:1.7;">অ্যাডমিন প্যানেল থেকে অর্ডারটি দ্রুত যাচাই করে কাস্টমারকে কল করুন।</p>
                            @elseif ($audience === 'invoice')
                                <h1 style="font-size:18px;margin:0 0 8px;">আপনার অর্ডারের ইনভয়েস</h1>
                                <p style="font-size:13px;color:#47616f;margin:0 0 20px;line-height:1.7;">নিচে আপনার অর্ডারের সম্পূর্ণ বিবরণ দেওয়া হলো। কোনো প্রশ্ন থাকলে আমাদের হটলাইনে যোগাযোগ করুন।</p>
                            @else
                                <h1 style="font-size:18px;margin:0 0 8px;">আপনার অর্ডার নিশ্চিত হয়েছে</h1>
                                <p style="font-size:13px;color:#47616f;margin:0 0 20px;line-height:1.7;">ধন্যবাদ! আমরা আপনার অর্ডারটি পেয়েছি। আমাদের প্রতিনিধি শীঘ্রই ডেলিভারি নিশ্চিত করতে যোগাযোগ করবেন।</p>
                            @endif

                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f9fa;border:1px solid #d9e6eb;border-radius:12px;margin-bottom:20px;">
                                <tr>
                                    <td style="padding:14px 16px;font-size:13px;line-height:1.9;">
                                        <strong>অর্ডার নম্বর:</strong> {{ $order->order_number }}<br>
                                        <strong>অর্ডারের সময়:</strong> {{ bn_num($order->created_at->format('d/m/Y, h:i A')) }}<br>
                                        <strong>স্ট্যাটাস:</strong> {{ $order->statusLabelBn() }}<br>
                                        <strong>পেমেন্ট:</strong> {{ $order->paymentLabelBn() }} ({{ $order->paymentStatusLabelBn() }})
                                    </td>
                                </tr>
                            </table>

                            <h2 style="font-size:14px;margin:0 0 10px;color:#0f2430;">অর্ডারকৃত পণ্য</h2>
                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="border-collapse:collapse;font-size:12px;margin-bottom:18px;">
                                <tr style="background:#f4f9fa;color:#47616f;">
                                    <th align="left" style="padding:8px 6px;border-bottom:1px solid #d9e6eb;">পণ্য</th>
                                    <th align="center" style="padding:8px 6px;border-bottom:1px solid #d9e6eb;">পরিমাণ</th>
                                    <th align="right" style="padding:8px 6px;border-bottom:1px solid #d9e6eb;">মোট</th>
                                </tr>
                                @foreach ($order->items as $item)
                                    <tr>
                                        <td style="padding:9px 6px;border-bottom:1px solid #eef4f6;">
                                            <strong>{{ $item->name_snapshot_bn }}</strong><br>
                                            <span style="color:#6a8297;font-size:11px;">{{ $item->size_label_snapshot }}</span>
                                        </td>
                                        <td align="center" style="padding:9px 6px;border-bottom:1px solid #eef4f6;">
                                            {{ $item->is_combo ? bn_num($item->weight_kg).' প্যাক' : bn_kg($item->weight_kg) }}
                                        </td>
                                        <td align="right" style="padding:9px 6px;border-bottom:1px solid #eef4f6;font-weight:700;">{{ bn_money($item->line_total) }}</td>
                                    </tr>
                                    @if ($item->is_combo)
                                        @php
                                            $metaItems = is_array($item->combo_meta) ? ($item->combo_meta['items'] ?? $item->combo_meta) : [];
                                        @endphp
                                        <tr>
                                            <td colspan="3" style="padding:0 6px 10px;border-bottom:1px solid #eef4f6;color:#6a8297;font-size:11px;line-height:1.7;">
                                                @foreach ($metaItems as $meta)
                                                    • {{ $meta['name_bn'] ?? '' }} ({{ $meta['size_label'] ?? '' }}) — {{ bn_kg($meta['weight_kg'] ?? 0) }}<br>
                                                @endforeach
                                            </td>
                                        </tr>
                                    @endif
                                @endforeach
                            </table>

                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="font-size:13px;margin-bottom:20px;">
                                <tr>
                                    <td style="padding:3px 0;color:#47616f;">সাবটোটাল</td>
                                    <td align="right" style="padding:3px 0;">{{ bn_money($order->subtotal) }}</td>
                                </tr>
                                @if ((float) $order->discount_amount > 0)
                                    <tr>
                                        <td style="padding:3px 0;color:#47616f;">কুপন ছাড় {{ $order->coupon_code ? '('.$order->coupon_code.')' : '' }}</td>
                                        <td align="right" style="padding:3px 0;color:#059669;">− {{ bn_money($order->discount_amount) }}</td>
                                    </tr>
                                @endif
                                <tr>
                                    <td style="padding:3px 0;color:#47616f;">ডেলিভারি চার্জ</td>
                                    <td align="right" style="padding:3px 0;">{{ bn_money($order->delivery_fee) }}</td>
                                </tr>
                                <tr>
                                    <td style="padding:10px 0 0;border-top:1px solid #d9e6eb;font-weight:800;">সর্বমোট</td>
                                    <td align="right" style="padding:10px 0 0;border-top:1px solid #d9e6eb;font-weight:800;color:#0d9488;font-size:16px;">{{ bn_money($order->grand_total) }}</td>
                                </tr>
                            </table>

                            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f4f9fa;border:1px solid #d9e6eb;border-radius:12px;margin-bottom:18px;">
                                <tr>
                                    <td style="padding:14px 16px;font-size:12px;line-height:1.9;">
                                        <strong>ডেলিভারি তথ্য</strong><br>
                                        নাম: {{ $order->customer_name }}<br>
                                        মোবাইল: {{ $order->customer_phone }}<br>
                                        @if ($order->customer_email)
                                            ইমেইল: {{ $order->customer_email }}<br>
                                        @endif
                                        ঠিকানা: {{ $order->customer_address }}<br>
                                        এলাকা: {{ $order->zone?->name_bn ?? '—' }}<br>
                                        সময়: {{ $order->time_slot_label }}
                                    </td>
                                </tr>
                            </table>

                            @if ($audience !== 'admin' && $order->payment_method !== 'cod' && ($paymentInstructions || $paymentNumber || $paymentLink))
                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#fffbeb;border:1px solid #fde68a;border-radius:12px;margin-bottom:18px;">
                                    <tr>
                                        <td style="padding:14px 16px;font-size:12px;line-height:1.8;color:#92400e;">
                                            <strong>পেমেন্ট নির্দেশনা</strong><br>
                                            @if ($paymentInstructions)
                                                {!! nl2br(e($paymentInstructions)) !!}<br>
                                            @endif
                                            @if ($paymentNumber)
                                                <strong>পেমেন্ট নম্বর:</strong> {{ $paymentNumber }}<br>
                                            @endif
                                            @if ($paymentLink)
                                                <a href="{{ $paymentLink }}" style="display:inline-block;margin-top:6px;background:#0d9488;color:#ffffff;text-decoration:none;padding:7px 14px;border-radius:8px;font-weight:700;">পেমেন্ট লিংক খুলুন</a>
                                            @endif
                                        </td>
                                    </tr>
                                </table>
                            @endif

                            @if ($audience !== 'admin' && ! empty($reviewUrl))
                                <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#effbf9;border:1px solid #b9d6d3;border-radius:12px;margin-bottom:18px;">
                                    <tr>
                                        <td style="padding:14px 16px;font-size:12px;line-height:1.8;color:#0f766e;text-align:center;">
                                            <strong>আপনার অভিজ্ঞতা শেয়ার করুন</strong><br>
                                            <span style="color:#33525f;">আপনার মতামত আমাদের সেবা আরও ভালো করতে সাহায্য করে।</span><br>
                                            <a href="{{ $reviewUrl }}" style="display:inline-block;margin-top:8px;background:#0d9488;color:#ffffff;text-decoration:none;padding:8px 16px;border-radius:8px;font-weight:700;">রিভিউ দিন</a>
                                        </td>
                                    </tr>
                                </table>
                            @endif

                            @if ($audience !== 'admin')
                                <p style="font-size:11px;color:#6a8297;margin:0 0 14px;text-align:center;">
                                    ইনভয়েস PDF এই ইমেইলে সংযুক্ত করা হয়েছে।
                                </p>
                            @endif

                            <p style="font-size:12px;color:#6a8297;line-height:1.8;margin:0;">
                                হটলাইন: {{ bn_num($settings['site_phone'] ?? '16234') }}<br>
                                হোয়াটসঅ্যাপ:
                                @if (! empty($whatsappLink))
                                    <a href="{{ $whatsappLink }}" style="color:#0d9488;text-decoration:none;">{{ $settings['whatsapp_number'] ?? '' }} — চ্যাট করুন</a>
                                @else
                                    {{ $settings['whatsapp_number'] ?? '' }}
                                @endif
                                <br>
                                ডেলিভারি সময়: {{ $settings['delivery_hours'] ?? '' }}
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:16px 28px;background:#f4f9fa;border-top:1px solid #d9e6eb;color:#6a8297;font-size:11px;text-align:center;">
                            &copy; {{ bn_num(date('Y')) }} {{ $settings['site_name'] ?? 'মৎস্যমেলা' }} — সর্বস্বত্ব সংরক্ষিত।
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
