<!DOCTYPE html>
<html lang="bn" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>অ্যাডমিন লগইন | মৎস্যমেলা</title>

    <script>
        (function () {
            try {
                var saved = localStorage.getItem('mm-admin-theme');
                var theme = saved || 'dark';
                document.documentElement.setAttribute('data-theme', theme);
                if (theme === 'dark') document.documentElement.classList.add('dark');
            } catch (e) { /* noop */ }
        })();
    </script>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        aqua: { 300: '#5eead4', 400: '#2dd4bf', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e' },
                        sky: { 500: '#0ea5e9', 600: '#0284c7' },
                        app: 'rgb(var(--app) / <alpha-value>)',
                        card: 'rgb(var(--card) / <alpha-value>)',
                        card2: 'rgb(var(--card2) / <alpha-value>)',
                        ink: 'rgb(var(--ink) / <alpha-value>)',
                        ink2: 'rgb(var(--ink2) / <alpha-value>)',
                        ink3: 'rgb(var(--ink3) / <alpha-value>)',
                        line: 'rgb(var(--line) / <alpha-value>)'
                    },
                    fontFamily: { bangla: ['Hind Siliguri', 'Inter', 'sans-serif'], sans: ['Inter', 'Hind Siliguri', 'sans-serif'] }
                }
            }
        }
    </script>
    <style>
        :root, html[data-theme='dark'] {
            color-scheme: dark;
            --app: 4 10 20; --card: 13 25 44; --card2: 21 36 58;
            --ink: 226 240 249; --ink2: 152 175 194; --ink3: 106 130 151; --line: 40 60 86;
            --glass: rgba(14, 28, 50, 0.55); --glass-strong: rgba(9, 19, 36, 0.9);
            --glass-border: rgba(126, 190, 238, 0.14); --glass-hi: rgba(255, 255, 255, 0.08);
            --shadow-card: 0 10px 40px -14px rgba(2, 8, 20, 0.6);
        }
        html[data-theme='light'] {
            color-scheme: light;
            --app: 234 245 248; --card: 255 255 255; --card2: 240 247 250;
            --ink: 9 33 46; --ink2: 71 97 111; --ink3: 116 141 154; --line: 213 229 235;
            --glass: rgba(255, 255, 255, 0.65); --glass-strong: rgba(255, 255, 255, 0.94);
            --glass-border: rgba(2, 116, 110, 0.14); --glass-hi: rgba(255, 255, 255, 0.95);
            --shadow-card: 0 12px 36px -16px rgba(9, 60, 73, 0.22);
        }
        html { background: rgb(var(--app)); }
        body { font-family: 'Hind Siliguri', 'Inter', sans-serif; color: rgb(var(--ink)); background:
            radial-gradient(900px 500px at 85% -10%, rgba(14,165,233,.18), transparent 60%),
            radial-gradient(800px 480px at 5% 110%, rgba(20,184,166,.16), transparent 60%),
            rgb(var(--app));
        }
        .glass {
            background: var(--glass); backdrop-filter: blur(18px) saturate(170%);
            -webkit-backdrop-filter: blur(18px) saturate(170%);
            border: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi), var(--shadow-card);
        }
        .form-input {
            width: 100%; background: rgb(var(--card2) / .7); border: 1px solid rgb(var(--line));
            border-radius: .85rem; padding: .7rem .95rem; font-size: .9rem; color: rgb(var(--ink));
            outline: none; transition: border-color .18s ease, box-shadow .18s ease;
        }
        .form-input:focus { border-color: #14b8a6; box-shadow: 0 0 0 3px rgba(20,184,166,.16); }
        .form-input::placeholder { color: rgb(var(--ink3)); }
        .form-error { color: #fb7185; font-size: .74rem; margin-top: .35rem; font-weight: 600; }
        .btn-primary {
            display: inline-flex; align-items: center; justify-content: center; gap: .55rem;
            background: linear-gradient(90deg, #0d9488, #0284c7); color: #fff; font-weight: 700;
            padding: .75rem 1.2rem; border-radius: .85rem; font-size: .9rem;
            box-shadow: 0 14px 30px -14px rgba(13,148,136,.9); transition: all .18s ease;
        }
        .btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); }
    </style>
</head>
<body class="min-h-screen font-bangla flex items-center justify-center p-4">
    <div class="w-full max-w-md">
        <div class="text-center mb-7">
            <span class="inline-flex w-16 h-16 rounded-3xl bg-gradient-to-br from-aqua-500 to-sky-600 items-center justify-center text-white text-3xl shadow-xl shadow-aqua-600/30">
                <i class="fa-solid fa-fish"></i>
            </span>
            <h1 class="mt-4 text-2xl font-extrabold text-ink">মৎস্যমেলা অ্যাডমিন</h1>
            <p class="text-sm text-ink2 mt-1">আপনার অ্যাডমিন অ্যাকাউন্টে লগইন করুন</p>
        </div>

        <div class="glass rounded-3xl p-6 sm:p-8">
            @if (session('status'))
                <div class="mb-5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3.5 py-2.5 text-xs font-semibold text-emerald-400 flex items-center gap-2">
                    <i class="fa-solid fa-circle-check"></i> {{ session('status') }}
                </div>
            @endif

            @if ($errors->any())
                <div class="mb-5 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3.5 py-2.5 text-xs font-semibold text-rose-400 flex items-start gap-2">
                    <i class="fa-solid fa-circle-exclamation mt-0.5"></i>
                    <span>{{ $errors->first() }}</span>
                </div>
            @endif

            <form method="POST" action="{{ route('admin.login.store') }}" class="space-y-4">
                @csrf
                <div>
                    <label for="email" class="block text-xs font-bold text-ink2 mb-1.5">ইমেইল অ্যাড্রেস <span class="text-ink3 font-medium">(Email)</span></label>
                    <div class="relative">
                        <i class="fa-solid fa-envelope absolute left-3.5 top-1/2 -translate-y-1/2 text-ink3 text-sm"></i>
                        <input id="email" name="email" type="email" value="{{ old('email') }}" required autofocus autocomplete="username"
                               class="form-input !pl-10" placeholder="admin@motsyomela.local">
                    </div>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label for="password" class="block text-xs font-bold text-ink2 mb-1.5">পাসওয়ার্ড <span class="text-ink3 font-medium">(Password)</span></label>
                    <div class="relative">
                        <i class="fa-solid fa-lock absolute left-3.5 top-1/2 -translate-y-1/2 text-ink3 text-sm"></i>
                        <input id="password" name="password" type="password" required autocomplete="current-password"
                               class="form-input !pl-10" placeholder="••••••••">
                    </div>
                    @error('password') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <label class="flex items-center gap-2 text-xs font-semibold text-ink2 cursor-pointer">
                    <input type="checkbox" name="remember" value="1" class="accent-teal-500 w-4 h-4 rounded">
                    আমাকে মনে রাখুন
                </label>

                <button type="submit" class="btn-primary w-full">
                    <i class="fa-solid fa-right-to-bracket"></i> লগইন করুন
                </button>
            </form>

            <div class="mt-6 pt-5 border-t border-line/70 flex items-center justify-between text-[11px] text-ink3">
                <a href="{{ url('/') }}" class="hover:text-aqua-400 transition-colors"><i class="fa-solid fa-arrow-left mr-1"></i>স্টোরফ্রন্টে ফিরুন</a>
                <span>সুরক্ষিত অ্যাডমিন অ্যাক্সেস</span>
            </div>
        </div>

        <p class="text-center text-[11px] text-ink3 mt-5">© {{ bn_num(date('Y')) }} মৎস্যমেলা · সর্বস্বত্ব সংরক্ষিত</p>
    </div>
</body>
</html>
