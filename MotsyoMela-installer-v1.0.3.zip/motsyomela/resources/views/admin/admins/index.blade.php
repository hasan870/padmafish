@extends('admin.layouts.app')

@section('title', tr('অ্যাডমিন ইউজার', 'Admin users'))
@section('subtitle', tr('সুপার অ্যাডমিন ও স্টাফ অ্যাকাউন্ট নিয়ন্ত্রণ', 'Manage super admin and staff accounts'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($admins->total()) }} {{ tr('টি অ্যাকাউন্ট', 'accounts') }} · {{ tr('শুধু সুপার অ্যাডমিন এই অংশ দেখতে পান', 'only super admins can see this section') }}</p>
        <a href="{{ route('admin.admins.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন অ্যাডমিন', 'New admin') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[700px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('নাম', 'Name') }}</th>
                        <th>{{ tr('ইমেইল', 'Email') }}</th>
                        <th>{{ tr('রোল', 'Role') }}</th>
                        <th>{{ tr('তৈরি', 'Created') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($admins as $adminUser)
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <span class="w-9 h-9 rounded-xl bg-gradient-to-br from-aqua-500 to-sky-600 text-white flex items-center justify-center font-bold text-sm">{{ mb_substr($adminUser->name, 0, 1) }}</span>
                                    <div>
                                        <p class="font-bold text-ink">{{ $adminUser->name }}</p>
                                        @if (auth('admin')->id() === $adminUser->id)
                                            <span class="text-[10px] text-aqua-400 font-bold">{{ tr('আপনি', 'You') }}</span>
                                        @endif
                                    </div>
                                </div>
                            </td>
                            <td class="text-[11px] text-ink2">{{ $adminUser->email }}</td>
                            <td>
                                @if ($adminUser->isSuper())
                                    <span class="badge border-gold-500/30 bg-gold-500/10 text-gold-400"><i class="fa-solid fa-shield-halved text-[9px]"></i> {{ tr('সুপার অ্যাডমিন', 'Super admin') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink2">{{ tr('স্টাফ', 'Staff') }}</span>
                                @endif
                            </td>
                            <td class="text-[11px] text-ink3">{{ bn_num($adminUser->created_at->format('d/m/Y')) }}</td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.admins.edit', $adminUser) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                @if (auth('admin')->id() !== $adminUser->id)
                                    <form method="POST" action="{{ route('admin.admins.destroy', $adminUser) }}" class="inline-block" data-confirm="অ্যাডমিন {{ $adminUser->name }} ডিলিট করা হবে। নিশ্চিত?">
                                        @csrf
                                        @method('DELETE')
                                        <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                    </form>
                                @endif
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
        @if ($admins->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $admins->links() }}</div>
        @endif
    </div>
@endsection
