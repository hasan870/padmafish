@extends('admin.layouts.app')

@section('title', $admin->exists ? tr('অ্যাডমিন এডিট', 'Edit admin') : tr('নতুন অ্যাডমিন', 'New admin'))
@section('subtitle', tr('অ্যাকাউন্ট তথ্য ও রোল', 'Account details and role'))

@section('content')
    <form method="POST" action="{{ $admin->exists ? route('admin.admins.update', $admin) : route('admin.admins.store') }}" class="max-w-2xl">
        @csrf
        @if ($admin->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('নাম', 'Name') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="name" value="{{ old('name', $admin->name) }}" class="form-input" required>
                    @error('name') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ইমেইল', 'Email') }} <span class="text-rose-400">*</span></label>
                    <input type="email" name="email" value="{{ old('email', $admin->email) }}" class="form-input" required>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('রোল', 'Role') }} <span class="text-rose-400">*</span></label>
                    <select name="role" class="form-input" required>
                        <option value="staff" @selected(old('role', $admin->role) === 'staff')>{{ tr('স্টাফ (Staff)', 'Staff') }}</option>
                        <option value="super" @selected(old('role', $admin->role) === 'super')>{{ tr('সুপার অ্যাডমিন (Super Admin)', 'Super admin') }}</option>
                    </select>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('স্টাফ অ্যাডমিন ইউজার ম্যানেজমেন্ট দেখতে পাবেন না।', 'Staff admins cannot see user management.') }}</p>
                    @error('role') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('পাসওয়ার্ড', 'Password') }} {{ $admin->exists ? '(' . tr('খালি রাখলে অপরিবর্তিত', 'leave empty to keep current') . ')' : '*' }}</label>
                    <input type="password" name="password" class="form-input" autocomplete="new-password" {{ $admin->exists ? '' : 'required' }}>
                    @error('password') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('পাসওয়ার্ড নিশ্চিতকরণ', 'Confirm password') }}</label>
                    <input type="password" name="password_confirmation" class="form-input" autocomplete="new-password">
                </div>
            </div>

            <div class="rounded-xl border border-line bg-card2/40 p-3 text-[11px] text-ink3">
                <i class="fa-solid fa-circle-info text-aqua-400 mr-1"></i>
                {{ tr('পাসওয়ার্ড কমপক্ষে ৮ অক্ষরের হতে হবে। নিরাপদ পাসওয়ার্ড ব্যবহার করুন এবং প্রথম লগইনের পর ডিফল্ট পাসওয়ার্ড পরিবর্তন করুন।', 'Password must be at least 8 characters. Use a strong password and change the default after the first login.') }}
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.admins.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
