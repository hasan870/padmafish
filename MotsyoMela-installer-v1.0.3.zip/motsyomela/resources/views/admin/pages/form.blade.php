@extends('admin.layouts.app')

@section('title', $page->exists ? tr('পেজ এডিট', 'Edit page') : tr('নতুন HTML পেজ', 'New HTML page'))
@section('subtitle', tr('হেডার ও ফুটারসহ আলাদা ট্যাবে খোলে', 'Opens in a new tab with the site header and footer'))

@section('content')
    <form method="POST" action="{{ $page->exists ? route('admin.pages.update', $page) : route('admin.pages.store') }}" class="max-w-4xl">
        @csrf
        @if ($page->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('শিরোনাম (বাংলা)', 'Title (Bengali)') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="title_bn" value="{{ old('title_bn', $page->title_bn) }}" class="form-input" placeholder="{{ tr('যেমন: ডেলিভারি পলিসি', 'e.g. Delivery policy') }}" required>
                    @error('title_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('শিরোনাম (ইংরেজি)', 'Title (English)') }}</label>
                    <input type="text" name="title_en" value="{{ old('title_en', $page->title_en) }}" class="form-input" placeholder="e.g. Delivery policy">
                    @error('title_en') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('পেজের ঠিকানা (slug)', 'Page slug') }} <span class="text-rose-400">*</span></label>
                    <div class="flex items-center gap-1.5">
                        <span class="text-[11px] text-ink3 font-mono shrink-0">/page/</span>
                        <input type="text" name="slug" value="{{ old('slug', $page->slug) }}" class="form-input font-mono" placeholder="delivery-policy" required>
                    </div>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('শুধু ইংরেজি অক্ষর, সংখ্যা ও হাইফেন। খালি রাখলে ইংরেজি শিরোনাম থেকে তৈরি হবে।', 'English letters, numbers and hyphens only. Generated from the English title when left empty.') }}</p>
                    @error('slug') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div class="max-w-[180px]">
                    <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                    <input type="number" min="0" max="9999" name="sort_order" value="{{ old('sort_order', $page->sort_order ?? 0) }}" class="form-input">
                    @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <div>
                <label class="form-label">{{ tr('HTML কনটেন্ট (বাংলা)', 'HTML content (Bengali)') }}</label>
                <textarea name="content_bn" rows="14" class="form-input font-mono !text-[12px]" placeholder="&lt;h2&gt;ডেলিভারি পলিসি&lt;/h2&gt; ...">{{ old('content_bn', $page->content_bn) }}</textarea>
                <p class="text-[10px] text-ink3 mt-1">{{ tr('HTML সাপোর্টেড: h2, p, ul, ol, table, a, strong, img ইত্যাদি।', 'HTML supported: h2, p, ul, ol, table, a, strong, img and more.') }}</p>
                @error('content_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <div>
                <label class="form-label">{{ tr('HTML কনটেন্ট (ইংরেজি)', 'HTML content (English)') }}</label>
                <textarea name="content_en" rows="10" class="form-input font-mono !text-[12px]" placeholder="&lt;h2&gt;Delivery policy&lt;/h2&gt; ...">{{ old('content_en', $page->content_en) }}</textarea>
                <p class="text-[10px] text-ink3 mt-1">{{ tr('ইংরেজি মোডে এই কনটেন্ট দেখানো হবে। খালি থাকলে বাংলা কনটেন্টই দেখাবে।', 'Shown in English mode. The Bengali content is used when this is empty.') }}</p>
                @error('content_en') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <input type="hidden" name="is_active" value="0">
            <input type="hidden" name="show_in_footer" value="0">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <label class="flex items-center justify-between gap-3 cursor-pointer rounded-xl border border-line bg-card2/40 px-4 py-3">
                    <span>
                        <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }}</span>
                        <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় পেজ ভিজিটর দেখতে পাবে না', 'Inactive pages are not visible to visitors') }}</span>
                    </span>
                    <span class="switch">
                        <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $page->is_active))>
                        <span class="track"></span>
                    </span>
                </label>
                <label class="flex items-center justify-between gap-3 cursor-pointer rounded-xl border border-line bg-card2/40 px-4 py-3">
                    <span>
                        <span class="block text-xs font-bold text-ink">{{ tr('ফুটারে দেখান', 'Show in footer') }}</span>
                        <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('ফুটারের গ্রাহক সেবা তালিকায় লিংক যুক্ত হবে', 'Adds a link to the footer customer care list') }}</span>
                    </span>
                    <span class="switch">
                        <input type="checkbox" name="show_in_footer" value="1" @checked(old('show_in_footer', $page->show_in_footer))>
                        <span class="track"></span>
                    </span>
                </label>
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                @if ($page->exists)
                    <a href="{{ route('page.show', $page->slug) }}" target="_blank" rel="noopener" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('প্রিভিউ', 'Preview') }}</a>
                @endif
                <a href="{{ route('admin.pages.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
