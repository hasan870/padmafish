@extends('admin.layouts.app')

@section('title', tr('HTML পেজ', 'HTML pages'))
@section('subtitle', tr('ডেলিভারি পলিসি, রিফান্ড নীতি বা যেকোনো কাস্টম পেজ তৈরি করুন', 'Create delivery policy, refund policy or any custom page'))

@section('content')
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($pages->total()) }} {{ tr('টি পেজ', 'pages') }}</p>
        <a href="{{ route('admin.pages.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন পেজ', 'New page') }}</a>
    </div>

    <div class="mb-4 rounded-xl border border-aqua-500/25 bg-aqua-500/5 px-4 py-3 text-[11px] text-ink2 flex items-start gap-2">
        <i class="fa-solid fa-circle-info text-aqua-400 mt-0.5"></i>
        <span>{{ tr('প্রতিটি পেজ স্টোরফ্রন্টের হেডার ও ফুটারসহ আলাদা ট্যাবে খোলে। “ফুটারে দেখান” চালু থাকলে পেজটি ফুটারের গ্রাহক সেবা তালিকায় লিংক হিসেবে যুক্ত হয়।', 'Every page opens in a new tab with the storefront header and footer. When “Show in footer” is on, the page is linked from the footer customer care list.') }}</span>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[720px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('পেজ', 'Page') }}</th>
                        <th>{{ tr('ঠিকানা (slug)', 'Slug') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($pages as $page)
                        <tr>
                            <td class="max-w-xs">
                                <p class="font-bold text-ink"><i class="fa-solid fa-file-lines text-aqua-400 text-xs mr-2"></i>{{ localized($page->title_bn, $page->title_en) }}</p>
                                <p class="text-[11px] text-ink3 mt-1">
                                    @if ($page->show_in_footer)
                                        <span class="text-emerald-400"><i class="fa-solid fa-link text-[9px]"></i> {{ tr('ফুটারে দেখানো হচ্ছে', 'Shown in footer') }}</span>
                                    @else
                                        {{ tr('ফুটারে নেই', 'Not in footer') }}
                                    @endif
                                </p>
                            </td>
                            <td>
                                <a href="{{ route('page.show', $page->slug) }}" target="_blank" rel="noopener" class="text-[11px] font-mono text-aqua-400 hover:underline">/page/{{ $page->slug }}</a>
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($page->sort_order) }}</td>
                            <td>
                                @if ($page->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('page.show', $page->slug) }}" target="_blank" rel="noopener" class="btn-soft !px-2.5 !py-1.5 !text-[11px]" title="{{ tr('প্রিভিউ', 'Preview') }}"><i class="fa-solid fa-eye"></i></a>
                                <a href="{{ route('admin.pages.edit', $page) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.pages.destroy', $page) }}" class="inline-block" data-confirm="পেজ &quot;{{ $page->title_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="5" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো পেজ নেই', 'No pages yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($pages->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $pages->links() }}</div>
        @endif
    </div>
@endsection
