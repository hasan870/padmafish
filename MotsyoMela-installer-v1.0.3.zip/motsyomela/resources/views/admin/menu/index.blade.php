@extends('admin.layouts.app')

@section('title', tr('হেডার মেনু', 'Header menu'))
@section('subtitle', tr('স্টোরফ্রন্ট হেডারের মেনু লিংক যোগ, এডিট ও ডিলিট করুন', 'Add, edit and delete storefront header menu links'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($items->total()) }} {{ tr('টি মেনু আইটেম', 'menu items') }}</p>
        <a href="{{ route('admin.menu-items.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন মেনু আইটেম', 'New menu item') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[720px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('লেবেল', 'Label') }}</th>
                        <th>{{ tr('লিংক', 'Link') }}</th>
                        <th>{{ tr('আইকন', 'Icon') }}</th>
                        <th class="text-center">{{ tr('টার্গেট', 'Target') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($items as $item)
                        <tr>
                            <td>
                                <p class="font-bold text-ink">{{ localized($item->label_bn, $item->label_en) }}</p>
                                <p class="text-[11px] text-ink3">{{ $item->label_en ?: '—' }}</p>
                            </td>
                            <td class="text-[11px] font-mono text-aqua-400 max-w-[220px] truncate">{{ $item->url }}</td>
                            <td>
                                @if ($item->icon)
                                    <span class="w-8 h-8 rounded-lg bg-card2 border border-line inline-flex items-center justify-center text-aqua-400 text-sm"><i class="fa-solid {{ $item->icon }}"></i></span>
                                @else
                                    <span class="text-ink3">—</span>
                                @endif
                            </td>
                            <td class="text-center text-[11px] text-ink2">{{ $item->target === '_blank' ? tr('নতুন ট্যাব', 'New tab') : tr('একই পেজ', 'Same page') }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($item->sort_order) }}</td>
                            <td>
                                @if ($item->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.menu-items.edit', $item) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.menu-items.destroy', $item) }}" class="inline-block" data-confirm="মেনু আইটেম &quot;{{ $item->label_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো মেনু আইটেম নেই', 'No menu items yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($items->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $items->links() }}</div>
        @endif
    </div>

    <div class="mt-4 rounded-2xl border border-line bg-card2/40 p-4 text-[11px] text-ink3 leading-relaxed">
        <p><i class="fa-solid fa-circle-info text-aqua-400 mr-1"></i> {{ tr('এই লিংকগুলো হেডারের ক্যাটাগরি ট্যাবের পাশে দেখাবে। একই পেজের সেকশনে যেতে', 'These links appear next to the header category tabs. To jump to a section on the same page use') }} <span class="font-mono text-ink2">/#product-section</span> {{ tr('বা', 'or') }} <span class="font-mono text-ink2">/#combo-section</span>.</p>
    </div>
@endsection
