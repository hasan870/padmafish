@extends('admin.layouts.app')

@section('title', $item->exists ? tr('মেনু আইটেম এডিট', 'Edit menu item') : tr('নতুন মেনু আইটেম', 'New menu item'))
@section('subtitle', tr('হেডারে দেখানো লিংকের নাম, আইকন ও অবস্থান', 'Header link label, icon and position'))

@section('content')
    <form method="POST" action="{{ $item->exists ? route('admin.menu-items.update', $item) : route('admin.menu-items.store') }}" class="max-w-2xl">
        @csrf
        @if ($item->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('বাংলা লেবেল', 'Bengali label') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="label_bn" value="{{ old('label_bn', $item->label_bn) }}" class="form-input" placeholder="{{ tr('যেমন: মাছের বাজার', 'e.g. Fish market') }}" required>
                    @error('label_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ইংরেজি লেবেল', 'English label') }}</label>
                    <input type="text" name="label_en" value="{{ old('label_en', $item->label_en) }}" class="form-input" placeholder="Shop">
                    @error('label_en') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div class="sm:col-span-2">
                    <label class="form-label">{{ tr('লিংক', 'Link') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="url" value="{{ old('url', $item->url) }}" class="form-input font-mono text-xs" placeholder="/#product-section" required>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('সাপোর্টেড', 'Supported') }}: https://, /, #, tel:, mailto:</p>
                    @error('url') <p class="form-error">{{ $message }}</p> @enderror
                    <div class="flex flex-wrap items-center gap-1.5 mt-2">
                        <span class="text-[10px] font-bold text-ink3">{{ tr('দ্রুত পেজ লিংক:', 'Quick page links:') }}</span>
                        @foreach ([
                            tr('হোম', 'Home') => '/',
                            tr('মাছের বাজার', 'Fish market') => '/#product-section',
                            tr('কম্বো প্যাকেজ', 'Combo packages') => '/#combo-section',
                            tr('আমাদের সম্পর্কে', 'About us') => '/#about-section',
                            tr('সাধারণ প্রশ্ন', 'FAQ') => '/#faq-section',
                        ] as $presetLabel => $presetUrl)
                            <button type="button" onclick="setMenuUrl('{{ $presetUrl }}')" class="px-2 py-1 rounded-lg border border-line bg-card2/60 text-[10px] font-bold text-ink2 hover:text-ink hover:border-aqua-500/50 transition-colors">{{ $presetLabel }}</button>
                        @endforeach
                    </div>
                </div>
                <div>
                    <label class="form-label">{{ tr('FontAwesome আইকন', 'FontAwesome icon') }}</label>
                    <input type="text" name="icon" value="{{ old('icon', $item->icon) }}" class="form-input" placeholder="fa-fish">
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('যেমন', 'e.g.') }}: fa-house, fa-fish, fa-gift, fa-phone</p>
                    @error('icon') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('লিংক খোলার ধরন', 'Link target') }} <span class="text-rose-400">*</span></label>
                    <select name="target" class="form-input" required>
                        <option value="_self" @selected(old('target', $item->target) === '_self')>{{ tr('একই পেজে', 'Same page') }}</option>
                        <option value="_blank" @selected(old('target', $item->target) === '_blank')>{{ tr('নতুন ট্যাবে', 'New tab') }}</option>
                    </select>
                    @error('target') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', $item->sort_order ?? 0) }}" min="0" max="9999" class="form-input">
                    @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer pt-1">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় আইটেম হেডারে দেখা যাবে না', 'Inactive items are hidden from the header') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $item->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.menu-items.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>

    <script>
        function setMenuUrl(url) {
            const input = document.querySelector('input[name="url"]');
            if (input) {
                input.value = url;
                input.focus();
            }
        }
    </script>
@endsection
