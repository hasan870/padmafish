@extends('admin.layouts.app')

@section('title', tr('ক্যাটাগরি ব্যবস্থাপনা', 'Category management'))
@section('subtitle', tr('স্টোরফ্রন্টের ক্যাটাগরি ট্যাব ও ক্রম নিয়ন্ত্রণ করুন', 'Manage storefront category tabs and their order'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($categories->total()) }} {{ tr('টি ক্যাটাগরি', 'categories') }}</p>
        <a href="{{ route('admin.categories.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন ক্যাটাগরি', 'New category') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[760px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('ক্যাটাগরি', 'Category') }}</th>
                        <th>{{ tr('স্লাগ', 'Slug') }}</th>
                        <th>{{ tr('আইকন', 'Icon') }}</th>
                        <th class="text-center">{{ tr('পণ্য', 'Products') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($categories as $category)
                        <tr>
                            <td>
                                <p class="font-bold text-ink">{{ localized($category->name_bn, $category->name_en) }}</p>
                                <p class="text-[11px] text-ink3">{{ $category->name_en }}</p>
                            </td>
                            <td class="text-[11px] font-mono text-aqua-400">{{ $category->slug }}</td>
                            <td>
                                @if ($category->icon)
                                    <span class="w-8 h-8 rounded-lg bg-card2 border border-line inline-flex items-center justify-center text-aqua-400 text-sm"><i class="fa-solid {{ $category->icon }}"></i></span>
                                @else
                                    <span class="text-ink3">—</span>
                                @endif
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($category->products_count) }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($category->sort_order) }}</td>
                            <td>
                                @if ($category->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.categories.edit', $category) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.categories.destroy', $category) }}" class="inline-block" data-confirm="ক্যাটাগরি &quot;{{ $category->name_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো ক্যাটাগরি নেই', 'No categories yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($categories->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $categories->links() }}</div>
        @endif
    </div>
@endsection
