@extends('admin.layouts.app')

@section('title', $category->exists ? tr('ক্যাটাগরি এডিট', 'Edit category') : tr('নতুন ক্যাটাগরি', 'New category'))
@section('subtitle', tr('স্টোরফ্রন্টের ক্যাটাগরি তথ্য', 'Storefront category details'))

@section('content')
    <form method="POST" action="{{ $category->exists ? route('admin.categories.update', $category) : route('admin.categories.store') }}" class="max-w-2xl">
        @csrf
        @if ($category->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('বাংলা নাম', 'Bengali name') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="name_bn" value="{{ old('name_bn', $category->name_bn) }}" class="form-input" placeholder="{{ tr('যেমন: নদীর মাছ', 'e.g. River fish') }}" required>
                    @error('name_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ইংরেজি নাম', 'English name') }}</label>
                    <input type="text" name="name_en" value="{{ old('name_en', $category->name_en) }}" class="form-input" placeholder="River Fish">
                    @error('name_en') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('স্লাগ', 'Slug') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="slug" value="{{ old('slug', $category->slug) }}" class="form-input" placeholder="river" required>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('স্টোরফ্রন্ট ফিল্টারে ব্যবহৃত হয়। শুধু ইংরেজি ছোট হাতের অক্ষর।', 'Used by storefront filters. Lowercase English letters only.') }}</p>
                    @error('slug') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('FontAwesome আইকন', 'FontAwesome icon') }}</label>
                    <input type="text" name="icon" value="{{ old('icon', $category->icon) }}" class="form-input" placeholder="fa-water">
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('যেমন', 'e.g.') }}: fa-water, fa-fish, fa-shrimp</p>
                    @error('icon') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', $category->sort_order ?? 0) }}" min="0" max="9999" class="form-input">
                    @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer pt-1">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় ক্যাটাগরি স্টোরফ্রন্টে দেখা যাবে না', 'Inactive categories are hidden from the storefront') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $category->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.categories.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
