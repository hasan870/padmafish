@extends('admin.layouts.app')

@section('title', $announcement->exists ? tr('ঘোষণা এডিট', 'Edit announcement') : tr('নতুন ঘোষণা', 'New announcement'))
@section('subtitle', tr('টিকার বার্তা', 'Ticker message'))

@section('content')
    <form method="POST" action="{{ $announcement->exists ? route('admin.announcements.update', $announcement) : route('admin.announcements.store') }}" class="max-w-2xl">
        @csrf
        @if ($announcement->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div>
                <label class="form-label">{{ tr('ঘোষণার লেখা', 'Announcement text') }} <span class="text-rose-400">*</span></label>
                <textarea name="text_bn" rows="4" maxlength="300" class="form-input" placeholder="{{ tr('যেমন: পদ্মার রূপালী ইলিশ প্রোমো — আজই অর্ডার করুন!', 'e.g. Padma hilsa promo — order today!') }}" required>{{ old('text_bn', $announcement->text_bn) }}</textarea>
                <p class="text-[10px] text-ink3 mt-1">{{ tr('একাধিক সক্রিয় ঘোষণা থাকলে সবগুলো টিকারে পাশাপাশি দেখাবে।', 'When several announcements are active, all of them run in the ticker.') }}</p>
                @error('text_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div class="max-w-[180px]">
                <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                <input type="number" min="0" max="9999" name="sort_order" value="{{ old('sort_order', $announcement->sort_order ?? 0) }}" class="form-input">
                @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় ঘোষণা টিকারে দেখাবে না', 'Inactive announcements are hidden from the ticker') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $announcement->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.announcements.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
