@extends('admin.layouts.app')

@section('title', tr('ঘোষণা ব্যবস্থাপনা', 'Announcement management'))
@section('subtitle', tr('স্টোরফ্রন্টের চলমান টিকার বার্তা', 'Messages running in the storefront ticker'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($announcements->total()) }} {{ tr('টি ঘোষণা', 'announcements') }} · {{ tr('সক্রিয় ঘোষণাগুলো টিকারে দেখায়', 'active announcements appear in the ticker') }}</p>
        <a href="{{ route('admin.announcements.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন ঘোষণা', 'New announcement') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[640px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('ঘোষণা', 'Announcement') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($announcements as $announcement)
                        <tr>
                            <td class="text-ink2 max-w-md">
                                <p class="line-clamp-2"><i class="fa-solid fa-bullhorn text-aqua-400 text-xs mr-2"></i>{{ $announcement->text_bn }}</p>
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($announcement->sort_order) }}</td>
                            <td>
                                @if ($announcement->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.announcements.edit', $announcement) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.announcements.destroy', $announcement) }}" class="inline-block" data-confirm="ঘোষণাটি ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো ঘোষণা নেই', 'No announcements yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($announcements->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $announcements->links() }}</div>
        @endif
    </div>
@endsection
