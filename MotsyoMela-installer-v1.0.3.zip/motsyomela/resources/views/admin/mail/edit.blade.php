@extends('admin.layouts.app')

@section('title', tr('ইমেইল সেটিংস', 'Email settings'))
@section('subtitle', tr('অর্ডার নোটিফিকেশন ও SMTP মেইল কনফিগারেশন', 'Order notifications and SMTP mail configuration'))

@section('content')
    <div class="max-w-3xl space-y-4">
        <form method="POST" action="{{ route('admin.mail.update') }}">
            @csrf
            @method('PUT')

            <div class="glass rounded-2xl p-5 space-y-5">
                <div>
                    <h3 class="font-extrabold text-ink text-sm mb-3 flex items-center gap-2"><i class="fa-solid fa-envelope-open-text text-aqua-400"></i> {{ tr('অর্ডার নোটিফিকেশন', 'Order notifications') }}</h3>
                    <input type="hidden" name="mail_enabled" value="0">
                    <label class="flex items-center justify-between gap-3 cursor-pointer rounded-xl border border-line bg-card2/40 px-4 py-3">
                        <span>
                            <span class="block text-xs font-bold text-ink">{{ tr('স্বয়ংক্রিয় ইমেইল পাঠান', 'Send automatic emails') }}</span>
                            <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নতুন অর্ডার হলে কাস্টমার ও অ্যাডমিনকে ইমেইল পাঠানো হবে', 'Customers and admins receive an email for every new order') }}</span>
                        </span>
                        <span class="switch">
                            <input type="checkbox" name="mail_enabled" value="1" @checked(($settings['mail_enabled'] ?? '0') === '1')>
                            <span class="track"></span>
                        </span>
                    </label>
                    <div class="mt-3">
                        <label class="form-label">{{ tr('অ্যাডমিন নোটিফিকেশন ইমেইল', 'Admin notification email') }}</label>
                        <input type="email" name="mail_admin_email" value="{{ old('mail_admin_email', $settings['mail_admin_email'] ?? '') }}" class="form-input" placeholder="admin@example.com">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('নতুন অর্ডার এলে এই ঠিকানায় নোটিফিকেশন যাবে। খালি রাখলে অ্যাডমিন ইমেইল যাবে না।', 'New-order notifications go to this address. Leave it empty to disable admin emails.') }}</p>
                        @error('mail_admin_email') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>

                <div class="pt-4 border-t border-line/70">
                    <h3 class="font-extrabold text-ink text-sm mb-3 flex items-center gap-2"><i class="fa-solid fa-server text-aqua-400"></i> {{ tr('মেইল ড্রাইভার', 'Mail driver') }}</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">{{ tr('ড্রাইভার', 'Driver') }} <span class="text-rose-400">*</span></label>
                            <select name="mail_driver" id="mail-driver" class="form-input" required>
                                <option value="log" @selected(old('mail_driver', $settings['mail_driver'] ?? 'log') === 'log')>{{ tr('Log (ডেভেলপমেন্ট — মেইল ফাইলে জমা হবে)', 'Log (development — mail is written to the log)') }}</option>
                                <option value="smtp" @selected(old('mail_driver', $settings['mail_driver'] ?? 'log') === 'smtp')>{{ tr('SMTP (লাইভ মেইল পাঠাবে)', 'SMTP (sends live mail)') }}</option>
                            </select>
                            @error('mail_driver') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('এনক্রিপশন', 'Encryption') }} <span class="text-rose-400">*</span></label>
                            <select name="mail_encryption" class="form-input" required>
                                <option value="tls" @selected(old('mail_encryption', $settings['mail_encryption'] ?? 'tls') === 'tls')>{{ tr('TLS (সাধারণত পোর্ট ৫৮৭)', 'TLS (usually port 587)') }}</option>
                                <option value="ssl" @selected(old('mail_encryption', $settings['mail_encryption'] ?? 'tls') === 'ssl')>{{ tr('SSL (সাধারণত পোর্ট ৪৬৫)', 'SSL (usually port 465)') }}</option>
                                <option value="none" @selected(old('mail_encryption', $settings['mail_encryption'] ?? 'tls') === 'none')>{{ tr('কোনো এনক্রিপশন নেই', 'No encryption') }}</option>
                            </select>
                            @error('mail_encryption') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <div id="smtp-fields" class="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
                        <div class="sm:col-span-2">
                            <label class="form-label">{{ tr('SMTP হোস্ট', 'SMTP host') }}</label>
                            <input type="text" name="mail_host" value="{{ old('mail_host', $settings['mail_host'] ?? '') }}" class="form-input" placeholder="smtp.gmail.com">
                            @error('mail_host') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('পোর্ট', 'Port') }}</label>
                            <input type="number" name="mail_port" value="{{ old('mail_port', $settings['mail_port'] ?? 587) }}" min="1" max="65535" class="form-input">
                            @error('mail_port') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('ইউজারনেম', 'Username') }}</label>
                            <input type="text" name="mail_username" value="{{ old('mail_username', $settings['mail_username'] ?? '') }}" class="form-input" placeholder="your@email.com">
                            @error('mail_username') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div class="sm:col-span-2">
                            <label class="form-label">{{ tr('পাসওয়ার্ড', 'Password') }}</label>
                            <input type="password" name="mail_password" class="form-input" placeholder="{{ $hasPassword ? 'সংরক্ষিত আছে — পরিবর্তন করতে নতুন পাসওয়ার্ড লিখুন' : 'SMTP পাসওয়ার্ড / অ্যাপ পাসওয়ার্ড' }}" autocomplete="new-password">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('পাসওয়ার্ড এনক্রিপ্ট করে সংরক্ষণ করা হয়। খালি রাখলে বর্তমান পাসওয়ার্ড অপরিবর্তিত থাকবে।', 'Passwords are stored encrypted. Leave empty to keep the current password.') }}</p>
                            @if ($hasPassword)
                                <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                    <input type="checkbox" name="mail_password_clear" value="1" class="rounded border-line"> {{ tr('সংরক্ষিত পাসওয়ার্ড মুছে ফেলুন', 'Clear stored password') }}
                                </label>
                            @endif
                            @error('mail_password') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                </div>

                <div class="pt-4 border-t border-line/70">
                    <h3 class="font-extrabold text-ink text-sm mb-3 flex items-center gap-2"><i class="fa-solid fa-at text-aqua-400"></i> {{ tr('প্রেরকের পরিচয়', 'Sender identity') }}</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">{{ tr('প্রেরকের ইমেইল', 'From email') }} <span class="text-rose-400">*</span></label>
                            <input type="email" name="mail_from_address" value="{{ old('mail_from_address', $settings['mail_from_address'] ?? 'hello@example.com') }}" class="form-input" required>
                            @error('mail_from_address') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('প্রেরকের নাম', 'From name') }} <span class="text-rose-400">*</span></label>
                            <input type="text" name="mail_from_name" value="{{ old('mail_from_name', $settings['mail_from_name'] ?? 'MotsyoMela') }}" class="form-input" required>
                            @error('mail_from_name') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                </div>

                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('ইমেইল সেটিংস সংরক্ষণ করুন', 'Save email settings') }}</button>
            </div>
        </form>

        <div class="glass rounded-2xl p-5">
            <h3 class="font-extrabold text-ink text-sm mb-1 flex items-center gap-2"><i class="fa-solid fa-paper-plane text-aqua-400"></i> {{ tr('টেস্ট ইমেইল', 'Test email') }}</h3>
            <p class="text-[11px] text-ink3 mb-3">{{ tr('সেটিংস সংরক্ষণ করার পর একটি টেস্ট ইমেইল পাঠিয়ে কনফিগারেশন যাচাই করুন।', 'After saving, send a test email to verify the configuration.') }}</p>
            <form method="POST" action="{{ route('admin.mail.test') }}" class="flex flex-col sm:flex-row gap-2">
                @csrf
                <input type="email" name="test_email" value="{{ old('test_email') }}" class="form-input flex-1" placeholder="{{ tr('আপনার ইমেইল ঠিকানা', 'Your email address') }}" required>
                <button type="submit" class="btn-soft justify-center"><i class="fa-solid fa-paper-plane"></i> {{ tr('টেস্ট পাঠান', 'Send test') }}</button>
            </form>
            @error('test_email') <p class="form-error">{{ $message }}</p> @enderror

            @if (($settings['mail_driver'] ?? 'log') === 'log')
                <div class="mt-3 rounded-xl border border-gold-500/25 bg-gold-500/5 p-3 text-[11px] text-gold-500 leading-relaxed">
                    <i class="fa-solid fa-triangle-exclamation mr-1"></i> {{ tr('বর্তমানে Log ড্রাইভার সক্রিয়। মেইল আসলে পাঠানো হবে না, শুধু', 'The Log driver is active. Mail is not actually sent; it is only written to') }} <span class="font-mono">storage/logs/laravel.log</span>। {{ tr('লাইভ মেইলের জন্য SMTP নির্বাচন করুন।', 'Choose SMTP for live mail.') }}
                </div>
            @endif
        </div>
    </div>

    @push('scripts')
        <script>
            const driver = document.getElementById('mail-driver');
            const smtpFields = document.getElementById('smtp-fields');
            function syncMailDriver() {
                smtpFields.style.opacity = driver.value === 'smtp' ? '1' : '.55';
            }
            driver.addEventListener('change', syncMailDriver);
            syncMailDriver();
        </script>
    @endpush
@endsection
