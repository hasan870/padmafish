@extends('admin.layouts.app')

@section('title', tr('হিরো প্রোমো', 'Hero promo'))
@section('subtitle', tr('হোম পেজের ডান কলামের অফার কার্ড — লেখা, ছবি বা ভিডিও', 'The offer card in the homepage hero right column — text, image or video'))

@section('content')
    @php
        $imagePath = (string) ($settings['hero_promo_image'] ?? '');
        $videoPath = (string) ($settings['hero_promo_video'] ?? '');
        $mediaType = $settings['hero_promo_media_type'] ?? 'none';
    @endphp

    <form method="POST" action="{{ route('admin.hero-promo.update') }}" enctype="multipart/form-data" class="max-w-4xl">
        @csrf
        @method('PUT')

        <div class="mb-4 rounded-2xl border border-sky-500/25 bg-sky-500/5 p-4 flex items-start gap-3">
            <span class="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center text-sm shrink-0"><i class="fa-solid fa-circle-info"></i></span>
            <p class="text-[11px] text-ink2 leading-relaxed">
                {{ tr('এই কার্ডটি হোম পেজের হিরো সেকশনের ডান দিকে দেখায়। লেখা, দাম ও বাটন এখন এখান থেকে নিয়ন্ত্রণ করুন। ছবি বা ভিডিও নতুন করে আপলোড করতে পারেন, অথবা স্টোরেজে আগে থেকে থাকা ফাইল বাছাই করে পুনরায় ব্যবহার করতে পারেন।', 'This card appears on the right side of the homepage hero. Control the copy, prices and button here. Upload a new image or video, or pick a file that already exists in storage and reuse it.') }}
            </p>
        </div>

        <div class="glass rounded-2xl p-5 space-y-5">
            <input type="hidden" name="hero_promo_enabled" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('প্রোমো কার্ড দেখান', 'Show the promo card') }}</span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('বন্ধ করলে হিরোর ডান কলামে অফার কার্ড দেখাবে না।', 'When off, no offer card is shown in the hero right column.') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="hero_promo_enabled" value="1" @checked(($settings['hero_promo_enabled'] ?? '1') === '1')>
                    <span class="track"></span>
                </span>
            </label>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-align-left text-aqua-400"></i> {{ tr('কার্ডের লেখা', 'Card copy') }}</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('ব্যাজ লেখা', 'Badge text') }}</label>
                        <input type="text" name="hero_promo_badge" value="{{ old('hero_promo_badge', $settings['hero_promo_badge'] ?? '') }}" maxlength="40" class="form-input" placeholder="{{ tr('হট ডিল', 'Hot deal') }}">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('খালি রাখলে ব্যাজ দেখাবে না।', 'Leave empty to hide the badge.') }}</p>
                        @error('hero_promo_badge') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('উপরের ছোট লেখা', 'Eyebrow text') }}</label>
                        <input type="text" name="hero_promo_eyebrow" value="{{ old('hero_promo_eyebrow', $settings['hero_promo_eyebrow'] ?? '') }}" maxlength="80" class="form-input" placeholder="{{ tr('আজকের সেরা অফার', 'Best offer of the day') }}">
                        @error('hero_promo_eyebrow') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('শিরোনাম', 'Title') }}</label>
                        <input type="text" name="hero_promo_title" value="{{ old('hero_promo_title', $settings['hero_promo_title'] ?? '') }}" maxlength="150" class="form-input" placeholder="{{ tr('চাঁদপুরের তাজা পদ্মার ইলিশ', 'Fresh Padma hilsa from Chandpur') }}">
                        @error('hero_promo_title') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('বিবরণ', 'Description') }}</label>
                        <textarea name="hero_promo_description" rows="3" maxlength="500" class="form-input" placeholder="{{ tr('স্বাদে ও গন্ধে অতুলনীয়, বড় সাইজ (১.২ কেজি - ১.৫ কেজি)। আজই স্পেশাল কম্বো অফারে সংগ্রহ করুন!', 'Unmatched in taste and aroma, large size (1.2 kg - 1.5 kg). Get it today with the special combo offer!') }}">{{ old('hero_promo_description', $settings['hero_promo_description'] ?? '') }}</textarea>
                        @error('hero_promo_description') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('নিয়মিত মূল্য', 'Regular price') }}</label>
                        <input type="text" name="hero_promo_regular_price" value="{{ old('hero_promo_regular_price', $settings['hero_promo_regular_price'] ?? '') }}" maxlength="60" class="form-input" placeholder="{{ tr('৳২,১০০/কেজি', '৳2,100/kg') }}">
                        @error('hero_promo_regular_price') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('অফার মূল্য', 'Offer price') }}</label>
                        <input type="text" name="hero_promo_offer_price" value="{{ old('hero_promo_offer_price', $settings['hero_promo_offer_price'] ?? '') }}" maxlength="60" class="form-input" placeholder="{{ tr('৳১,৮৫০/কেজি', '৳1,850/kg') }}">
                        @error('hero_promo_offer_price') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('বাটনের লেখা', 'Button label') }}</label>
                        <input type="text" name="hero_promo_cta_label" value="{{ old('hero_promo_cta_label', $settings['hero_promo_cta_label'] ?? '') }}" maxlength="60" class="form-input" placeholder="{{ tr('অফারটি নিন', 'Grab the offer') }}">
                        @error('hero_promo_cta_label') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('বাটনের লিংক (ঐচ্ছিক)', 'Button link (optional)') }}</label>
                        <input type="url" name="hero_promo_cta_url" value="{{ old('hero_promo_cta_url', $settings['hero_promo_cta_url'] ?? '') }}" class="form-input font-mono text-xs" placeholder="https://example.com/offer">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('খালি রাখলে বাটনে ক্লিক করলে ফিচার্ড পণ্যটি কার্টে যোগ হবে।', 'When empty, clicking the button adds the featured product to the cart.') }}</p>
                        @error('hero_promo_cta_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-photo-film text-aqua-400"></i> {{ tr('ছবি বা ভিডিও', 'Image or video') }}</h3>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('মিডিয়া ধরন', 'Media type') }} <span class="text-rose-400">*</span></label>
                        <select name="hero_promo_media_type" id="hero-promo-media-type" class="form-input" required>
                            @foreach ($mediaTypes as $key => $label)
                                <option value="{{ $key }}" @selected(old('hero_promo_media_type', $mediaType) === $key)>{{ $label }}</option>
                            @endforeach
                        </select>
                        @error('hero_promo_media_type') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('শুধু মিডিয়া দেখান', 'Show media only') }}</label>
                        <input type="hidden" name="hero_promo_media_only" value="0">
                        <label class="flex items-center gap-2 text-[11px] text-ink2 cursor-pointer mt-2">
                            <input type="checkbox" name="hero_promo_media_only" value="1" class="rounded border-line" @checked(($settings['hero_promo_media_only'] ?? '0') === '1')>
                            {{ tr('লেখা, দাম ও বাটন লুকিয়ে শুধু ছবি/ভিডিও দেখাবে', 'Hide the copy, prices and button and show only the media') }}
                        </label>
                    </div>
                </div>

                <div id="hero-promo-image-panel" class="mt-4 space-y-2 {{ in_array(old('hero_promo_media_type', $mediaType), ['image', 'video'], true) ? '' : 'hidden' }}">
                    <label class="form-label">{{ tr('ছবি', 'Image') }}</label>
                    <div class="flex items-start gap-4">
                        <div id="hero-promo-image-preview" class="w-32 h-20 rounded-xl border border-line bg-card2/40 overflow-hidden flex items-center justify-center shrink-0">
                            @if ($imagePath !== '')
                                <img src="{{ asset('storage/'.$imagePath) }}" alt="{{ tr('প্রোমো ছবি', 'Promo image') }}" class="w-full h-full object-cover">
                            @else
                                <i class="fa-regular fa-image text-ink3"></i>
                            @endif
                        </div>
                        <div class="flex-1 min-w-0">
                            <input type="file" name="hero_promo_image" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ৪MB · ভিডিওর পোস্টার হিসেবেও ব্যবহার হবে।', 'JPG, PNG or WebP · max 4MB · also used as the video poster.') }}</p>

                            @include('admin.partials.media-picker', [
                                'key' => 'hero_promo_image',
                                'kind' => 'image',
                                'files' => $mediaLibrary['images'],
                                'label' => tr('স্টোরেজের ছবি', 'Stored images'),
                            ])

                            @if ($imagePath !== '')
                                <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                    <input type="checkbox" name="hero_promo_image_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ছবি সরিয়ে ফেলুন', 'Remove current image') }}
                                </label>
                                <p class="text-[10px] text-ink3 mt-0.5">{{ tr('ফাইলটি স্টোরেজে থেকে যাবে, পরে আবার ব্যবহার করা যাবে।', 'The file stays in storage and can be reused later.') }}</p>
                            @endif
                            @error('hero_promo_image') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                </div>

                <div id="hero-promo-video-panel" class="mt-4 space-y-3 {{ old('hero_promo_media_type', $mediaType) === 'video' ? '' : 'hidden' }}">
                    <div class="flex items-start gap-4">
                        <div id="hero-promo-video-preview" class="w-32 h-20 rounded-xl border border-line bg-card2/40 overflow-hidden flex items-center justify-center shrink-0">
                            @if ($videoPath !== '')
                                <video src="{{ asset('storage/'.$videoPath) }}" class="w-full h-full object-cover" muted preload="metadata"></video>
                            @else
                                <i class="fa-solid fa-film text-ink3"></i>
                            @endif
                        </div>
                        <div class="flex-1 min-w-0">
                            <label class="form-label">{{ tr('ভিডিও ফাইল', 'Video file') }}</label>
                            <input type="file" name="hero_promo_video" accept="video/mp4,video/webm,video/quicktime" class="form-input !py-1.5 text-xs">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('MP4, WebM বা MOV · সর্বোচ্চ ২০MB · মোবাইলে স্বয়ংক্রিয়ভাবে প্লে হবে না, কন্ট্রোল দেখাবে।', 'MP4, WebM or MOV · max 20MB · controls are shown and it will not autoplay on mobile.') }}</p>

                            @include('admin.partials.media-picker', [
                                'key' => 'hero_promo_video',
                                'kind' => 'video',
                                'files' => $mediaLibrary['videos'],
                                'label' => tr('স্টোরেজের ভিডিও', 'Stored videos'),
                            ])

                            @if ($videoPath !== '')
                                <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                    <input type="checkbox" name="hero_promo_video_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ভিডিও সরিয়ে ফেলুন', 'Remove current video') }}
                                    <span class="text-ink3 font-mono text-[10px]">({{ $videoPath }})</span>
                                </label>
                                <p class="text-[10px] text-ink3 mt-0.5">{{ tr('ফাইলটি স্টোরেজে থেকে যাবে, পরে আবার ব্যবহার করা যাবে।', 'The file stays in storage and can be reused later.') }}</p>
                            @endif
                            @error('hero_promo_video') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                    <div>
                        <label class="form-label">{{ tr('অথবা লিংক', 'Or link') }}</label>
                        <input type="url" name="hero_promo_video_url" value="{{ old('hero_promo_video_url', $settings['hero_promo_video_url'] ?? '') }}" class="form-input font-mono text-xs" placeholder="https://www.youtube.com/watch?v=...">
                        <p class="text-[10px] text-ink3 mt-1">
                            {{ tr('YouTube বা Vimeo লিংক দিলে কার্ডে সরাসরি প্লেয়ার হিসেবে চলবে। MP4/WebM ফাইলের সরাসরি লিংকও দিতে পারেন। আপলোড করা বা স্টোরেজ থেকে বাছা ফাইল থাকলে সেটিই আগে ব্যবহার হবে।', 'A YouTube or Vimeo link plays in an embedded player. A direct MP4/WebM file link also works. An uploaded or picked file takes priority over the link.') }}
                        </p>
                        @error('hero_promo_video_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
            </div>
        </div>
    </form>
@endsection

@push('scripts')
    <script>
        (function () {
            const select = document.getElementById('hero-promo-media-type');
            const imagePanel = document.getElementById('hero-promo-image-panel');
            const videoPanel = document.getElementById('hero-promo-video-panel');

            function syncPanels() {
                if (!select) return;
                const type = select.value;
                if (imagePanel) imagePanel.classList.toggle('hidden', type !== 'image' && type !== 'video');
                if (videoPanel) videoPanel.classList.toggle('hidden', type !== 'video');
            }

            if (select) select.addEventListener('change', syncPanels);
            syncPanels();

            // Storage library pickers
            function openModal(id) {
                const modal = document.getElementById(id);
                if (!modal) return;
                modal.classList.remove('hidden');
                modal.classList.add('flex');
            }

            function closeModal(id) {
                const modal = document.getElementById(id);
                if (!modal) return;
                modal.classList.add('hidden');
                modal.classList.remove('flex');
            }

            document.querySelectorAll('[data-library-open]').forEach(function (button) {
                button.addEventListener('click', function () {
                    openModal(button.dataset.libraryOpen);
                });
            });

            document.querySelectorAll('[data-library-close]').forEach(function (button) {
                button.addEventListener('click', function () {
                    closeModal(button.dataset.libraryClose);
                });
            });

            function setPickNote(key, name) {
                const note = document.getElementById(key + '-pick-note');
                const label = document.getElementById(key + '-pick-name');
                if (!note || !label) return;
                label.textContent = name;
                note.classList.toggle('hidden', !name);
                note.classList.toggle('inline-flex', !!name);
            }

            document.querySelectorAll('[data-library-file]').forEach(function (tile) {
                tile.addEventListener('click', function () {
                    const key = tile.dataset.libraryTarget;
                    const pick = document.getElementById(key + '-pick');
                    if (!pick) return;

                    pick.value = tile.dataset.libraryFile;
                    setPickNote(key, tile.dataset.libraryName);

                    const remove = document.querySelector('input[name="' + key + '_remove"]');
                    if (remove) remove.checked = false;

                    if (key === 'hero_promo_image') {
                        const preview = document.getElementById('hero-promo-image-preview');
                        if (preview) {
                            preview.innerHTML = '';
                            const img = document.createElement('img');
                            img.src = tile.dataset.libraryUrl;
                            img.alt = '';
                            img.className = 'w-full h-full object-cover';
                            preview.appendChild(img);
                        }
                    } else if (key === 'hero_promo_video') {
                        const preview = document.getElementById('hero-promo-video-preview');
                        if (preview) {
                            preview.innerHTML = '';
                            const video = document.createElement('video');
                            video.src = tile.dataset.libraryUrl;
                            video.className = 'w-full h-full object-cover';
                            video.muted = true;
                            video.preload = 'metadata';
                            preview.appendChild(video);
                        }
                    }

                    closeModal(key + '-library');
                });
            });

            document.querySelectorAll('[data-library-clear]').forEach(function (button) {
                button.addEventListener('click', function () {
                    const key = button.dataset.libraryClear;
                    const pick = document.getElementById(key + '-pick');
                    if (pick) pick.value = '';
                    setPickNote(key, '');
                });
            });
        })();
    </script>
@endpush
