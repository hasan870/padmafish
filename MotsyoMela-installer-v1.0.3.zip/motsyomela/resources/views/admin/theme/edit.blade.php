@extends('admin.layouts.app')

@section('title', tr('থিম কাস্টমাইজেশন', 'Theme customisation'))
@section('subtitle', tr('রঙ, ফন্ট, ব্যাকগ্রাউন্ড, লোগো ও বর্ডার নিয়ন্ত্রণ করুন', 'Control colours, fonts, background, logo and borders'))

@section('content')
    @php
        $themeBanglaKey = old('theme_font_bangla', $settings['theme_font_bangla'] ?? $settings['theme_font'] ?? 'hind-siliguri');
        $themeEnglishKey = old('theme_font_english', $settings['theme_font_english'] ?? 'inter');
        $themeBanglaFamily = $fonts[$themeBanglaKey]['family'] ?? 'Hind Siliguri';
        $themeEnglishFamily = $englishFonts[$themeEnglishKey]['family'] ?? 'Inter';
        $themeBaseSize = (int) old('theme_font_size', $settings['theme_font_size'] ?? 16);
        $themeH1 = (int) old('theme_h1_scale', $settings['theme_h1_scale'] ?? 100);
        $themeH2 = (int) old('theme_h2_scale', $settings['theme_h2_scale'] ?? 100);
        $themeH3 = (int) old('theme_h3_scale', $settings['theme_h3_scale'] ?? 100);
        $themeText = (int) old('theme_text_scale', $settings['theme_text_scale'] ?? 100);
        $themeIcon = (int) old('theme_icon_scale', $settings['theme_icon_scale'] ?? 100);
        $themeTextColor = (string) old('theme_text_color', $settings['theme_text_color'] ?? '');
        $previewFontsUrl = google_fonts_url($themeBanglaFamily, $themeEnglishFamily, $fonts, $englishFonts);
    @endphp

    @push('head')
        <link href="{{ $previewFontsUrl }}" rel="stylesheet">
    @endpush

    <form method="POST" action="{{ route('admin.theme.update') }}" enctype="multipart/form-data" class="max-w-5xl">
        @csrf
        @method('PUT')

        <div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
            <div class="xl:col-span-2 space-y-4">
                <div class="glass rounded-2xl p-5 space-y-4">
                    <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-palette text-aqua-400"></i> {{ tr('ব্র্যান্ড ও রঙ', 'Brand & colours') }}</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">{{ tr('সাইটের নাম', 'Site name') }} <span class="text-rose-400">*</span></label>
                            <input type="text" name="site_name" value="{{ old('site_name', $settings['site_name'] ?? 'মৎস্যমেলা') }}" class="form-input" required>
                            @error('site_name') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('ব্যাজ', 'Badge') }}</label>
                            <input type="text" name="site_badge" value="{{ old('site_badge', $settings['site_badge'] ?? 'BD') }}" class="form-input" maxlength="10" placeholder="{{ tr('খালি রাখলে ব্যাজ দেখাবে না', 'Leave empty to hide the badge') }}">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('“শুধু ছবি লোগো” মোডে ব্যাজ সবসময় লুকানো থাকে।', 'The badge is always hidden in “image only” logo mode.') }}</p>
                            @error('site_badge') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div class="sm:col-span-2">
                            <label class="form-label">{{ tr('ট্যাগলাইন', 'Tagline') }} <span class="text-rose-400">*</span></label>
                            <input type="text" name="site_tagline" value="{{ old('site_tagline', $settings['site_tagline'] ?? '') }}" class="form-input" required>
                            @error('site_tagline') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div class="sm:col-span-2">
                            <label class="form-label">{{ tr('হেডার লোগো', 'Header logo') }}</label>
                            <div class="flex items-center gap-4">
                                <div class="w-16 h-16 rounded-2xl bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                                    @if (! empty($settings['theme_logo']))
                                        <img src="{{ asset('storage/'.$settings['theme_logo']) }}" alt="{{ tr('লোগো', 'Logo') }}" class="w-full h-full object-cover">
                                    @else
                                        <i class="fa-solid fa-fish-fins text-aqua-400 text-2xl"></i>
                                    @endif
                                </div>
                                <div class="flex-1">
                                    <input type="file" name="theme_logo" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                                    <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ২MB। নিচের “লোগোর ধরন” টেক্সট হলে এই ছবি দেখানো হবে না।', 'JPG, PNG or WebP · max 2MB. This image is hidden when the logo type below is text.') }}</p>
                                    @if (! empty($settings['theme_logo']))
                                        <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                            <input type="checkbox" name="theme_logo_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান লোগো মুছে ফেলুন', 'Remove current logo') }}
                                        </label>
                                    @endif
                                    @error('theme_logo') <p class="form-error">{{ $message }}</p> @enderror
                                </div>
                            </div>
                        </div>
                        <div>
                            <label class="form-label">{{ tr('প্রাইমারি রঙ', 'Primary colour') }} <span class="text-rose-400">*</span></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="theme-primary-picker" value="{{ old('theme_primary', $settings['theme_primary'] ?? '#14b8a6') }}" class="w-10 h-10 rounded-lg border border-line bg-card2 cursor-pointer">
                                <input type="text" id="theme-primary-text" name="theme_primary" value="{{ old('theme_primary', $settings['theme_primary'] ?? '#14b8a6') }}" class="form-input font-mono" pattern="^#[0-9a-fA-F]{6}$" required>
                            </div>
                            @error('theme_primary') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('সেকেন্ডারি রঙ', 'Secondary colour') }} <span class="text-rose-400">*</span></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="theme-secondary-picker" value="{{ old('theme_secondary', $settings['theme_secondary'] ?? '#0284c7') }}" class="w-10 h-10 rounded-lg border border-line bg-card2 cursor-pointer">
                                <input type="text" id="theme-secondary-text" name="theme_secondary" value="{{ old('theme_secondary', $settings['theme_secondary'] ?? '#0284c7') }}" class="form-input font-mono" pattern="^#[0-9a-fA-F]{6}$" required>
                            </div>
                            @error('theme_secondary') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('অ্যাকসেন্ট রঙ', 'Accent colour') }} <span class="text-rose-400">*</span></label>
                            <div class="flex items-center gap-2">
                                <input type="color" id="theme-accent-picker" value="{{ old('theme_accent', $settings['theme_accent'] ?? '#f59e0b') }}" class="w-10 h-10 rounded-lg border border-line bg-card2 cursor-pointer">
                                <input type="text" id="theme-accent-text" name="theme_accent" value="{{ old('theme_accent', $settings['theme_accent'] ?? '#f59e0b') }}" class="form-input font-mono" pattern="^#[0-9a-fA-F]{6}$" required>
                            </div>
                            @error('theme_accent') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('বাংলা ফন্ট', 'Bangla font family') }} <span class="text-rose-400">*</span></label>
                            <select name="theme_font_bangla" id="theme-font-bangla" class="form-input" required>
                                @foreach ($fonts as $key => $font)
                                    <option value="{{ $key }}" data-family="{{ $font['family'] }}" data-weights="{{ $font['weights'] ?? '400;700' }}" @selected($themeBanglaKey === $key)>{{ $font['label'] }}</option>
                                @endforeach
                            </select>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('বাংলা লেখায় ব্যবহার হবে।', 'Used for Bengali text.') }}</p>
                            @error('theme_font_bangla') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('ইংরেজি ফন্ট', 'English font family') }} <span class="text-rose-400">*</span></label>
                            <select name="theme_font_english" id="theme-font-english" class="form-input" required>
                                @foreach ($englishFonts as $key => $font)
                                    <option value="{{ $key }}" data-family="{{ $font['family'] }}" data-weights="{{ $font['weights'] ?? '400;700' }}" @selected($themeEnglishKey === $key)>{{ $font['label'] }}</option>
                                @endforeach
                            </select>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('ইংরেজি লেখা ও সংখ্যায় ব্যবহার হবে।', 'Used for Latin text and numbers.') }}</p>
                            @error('theme_font_english') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                </div>

                <div class="glass rounded-2xl p-5 space-y-4">
                    <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-font text-aqua-400"></i> {{ tr('টাইপোগ্রাফি ও আইকন', 'Typography & icons') }}</h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label flex items-center justify-between">
                                <span>{{ tr('মূল ফন্ট সাইজ', 'Base font size') }}</span>
                                <span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_font_size">{{ $themeBaseSize }}</span> px</span>
                            </label>
                            <input type="range" name="theme_font_size" id="theme-font-size" min="13" max="22" step="1" value="{{ $themeBaseSize }}" class="w-full accent-aqua-500">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('পুরো সাইটের লেখা ও আইকনের ভিত্তি (ডিফল্ট ১৬px)।', 'The base for all site text and icons (default 16px).') }}</p>
                            @error('theme_font_size') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label flex items-center justify-between">
                                <span>{{ tr('আইকনের সাইজ', 'Icon size') }}</span>
                                <span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_icon_scale">{{ $themeIcon }}</span>%</span>
                            </label>
                            <input type="range" name="theme_icon_scale" id="theme-icon-scale" min="70" max="150" step="5" value="{{ $themeIcon }}" class="w-full accent-aqua-500">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('সব ফন্ট অউসাম আইকনের আকার (১০০% = স্বাভাবিক)।', 'Scales every Font Awesome icon (100% = normal).') }}</p>
                            @error('theme_icon_scale') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-3">
                        <div>
                            <label class="form-label flex items-center justify-between"><span>H1</span><span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_h1_scale">{{ $themeH1 }}</span>%</span></label>
                            <input type="range" name="theme_h1_scale" id="theme-h1-scale" min="70" max="150" step="5" value="{{ $themeH1 }}" class="w-full accent-aqua-500">
                            @error('theme_h1_scale') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label flex items-center justify-between"><span>H2</span><span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_h2_scale">{{ $themeH2 }}</span>%</span></label>
                            <input type="range" name="theme_h2_scale" id="theme-h2-scale" min="70" max="150" step="5" value="{{ $themeH2 }}" class="w-full accent-aqua-500">
                            @error('theme_h2_scale') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label flex items-center justify-between"><span>H3</span><span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_h3_scale">{{ $themeH3 }}</span>%</span></label>
                            <input type="range" name="theme_h3_scale" id="theme-h3-scale" min="70" max="150" step="5" value="{{ $themeH3 }}" class="w-full accent-aqua-500">
                            @error('theme_h3_scale') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label flex items-center justify-between"><span>{{ tr('লেখা', 'Body text') }}</span><span class="text-ink3 font-mono text-[10px]"><span data-scale-value="theme_text_scale">{{ $themeText }}</span>%</span></label>
                            <input type="range" name="theme_text_scale" id="theme-text-scale" min="80" max="130" step="5" value="{{ $themeText }}" class="w-full accent-aqua-500">
                            @error('theme_text_scale') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                    <p class="text-[10px] text-ink3 -mt-1">{{ tr('H1, H2, H3 ও সাধারণ লেখার আকার শতাংশে বাড়ান/কমান করুন — মোবাইল-ডেস্কটপ দুইখানেই আপনার ডিজাইন অনুপাত ঠিক থাকবে।', 'Scale H1, H2, H3 and body text by percentage — each element keeps its own responsive size.') }}</p>

                    <div class="rounded-xl border border-line bg-card2/40 p-4 space-y-2">
                        <label class="form-label !mb-0">{{ tr('লেখার রঙ (ঐচ্ছিক)', 'Text colour (optional)') }}</label>
                        <div class="flex flex-wrap items-center gap-2">
                            <input type="color" id="theme-text-color-picker" value="{{ $themeTextColor !== '' ? $themeTextColor : '#e2f0f9' }}" class="w-10 h-10 rounded-lg border border-line bg-card2 cursor-pointer">
                            <input type="text" id="theme-text-color-text" name="theme_text_color" value="{{ $themeTextColor }}" class="form-input font-mono max-w-[11rem]" placeholder="{{ tr('ডিফল্ট (খালি)', 'Default (empty)') }}">
                            <button type="button" id="theme-text-color-clear" class="btn-soft !px-3 !py-2 text-[11px]"><i class="fa-solid fa-rotate-left"></i> {{ tr('ডিফল্ট', 'Default') }}</button>
                        </div>
                        <p class="text-[10px] text-ink3">{{ tr('খালি রাখলে ডার্ক ও লাইট থিমের নিজস্ব টেক্সট রঙ ব্যবহার হবে। রঙ দিলে দুই থিমেই সেই রঙ প্রযোজ্য হবে — খুব হালকা বা গাঢ় রঙে কন্ট্রাস্ট কমতে পারে।', 'Leave empty to keep the built-in dark/light text colours. A custom colour applies to both themes, so check the contrast.') }}</p>
                        @error('theme_text_color') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>

                <div class="glass rounded-2xl p-5 space-y-4">
                    <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-border-all text-aqua-400"></i> {{ tr('বর্ডার ও ব্যাকগ্রাউন্ড', 'Borders & background') }}</h3>
                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">{{ tr('বর্ডার রেডিয়াস (px)', 'Border radius (px)') }} <span class="text-rose-400">*</span></label>
                            <input type="number" name="theme_radius" value="{{ old('theme_radius', $settings['theme_radius'] ?? 16) }}" min="0" max="32" class="form-input" required>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('০ = সম্পূর্ণ সোজা কোণ, ৩২ = বেশি গোলাকার।', '0 = fully square corners, 32 = most rounded.') }}</p>
                            @error('theme_radius') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('বর্ডারের পুরুত্ব (px)', 'Border width (px)') }} <span class="text-rose-400">*</span></label>
                            <input type="number" name="theme_border_width" value="{{ old('theme_border_width', $settings['theme_border_width'] ?? 1) }}" min="0" max="3" class="form-input" required>
                            @error('theme_border_width') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('ব্যাকগ্রাউন্ড স্টাইল', 'Background style') }} <span class="text-rose-400">*</span></label>
                            <select name="theme_bg_style" id="theme-bg-style" class="form-input" required>
                                @foreach ($backgrounds as $key => $label)
                                    <option value="{{ $key }}" @selected(old('theme_bg_style', $settings['theme_bg_style'] ?? 'aurora') === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                            @error('theme_bg_style') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('ব্যাকগ্রাউন্ড ওভারলে (%)', 'Background overlay (%)') }} <span class="text-rose-400">*</span></label>
                            <input type="number" name="theme_bg_overlay" value="{{ old('theme_bg_overlay', $settings['theme_bg_overlay'] ?? 60) }}" min="0" max="90" class="form-input" required>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('কাস্টম ছবির উপর কালো ওভারলের মাত্রা।', 'Amount of dark overlay over the custom image.') }}</p>
                            @error('theme_bg_overlay') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div class="sm:col-span-2">
                            <label class="form-label">{{ tr('কাস্টম ব্যাকগ্রাউন্ড ছবি', 'Custom background image') }}</label>
                            <div class="flex items-center gap-4">
                                <div class="w-24 h-16 rounded-xl bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                                    @if (! empty($settings['theme_bg_image']))
                                        <img src="{{ asset('storage/'.$settings['theme_bg_image']) }}" alt="{{ tr('ব্যাকগ্রাউন্ড', 'Background') }}" class="w-full h-full object-cover">
                                    @else
                                        <i class="fa-regular fa-image text-ink3 text-xl"></i>
                                    @endif
                                </div>
                                <div class="flex-1">
                                    <input type="file" name="theme_bg_image" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                                    <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ৪MB। "কাস্টম ছবি" স্টাইল নির্বাচন করলে ছবি প্রয়োজন।', 'JPG, PNG or WebP · max 4MB. An image is required when the custom image style is selected.') }}</p>
                                    @if (! empty($settings['theme_bg_image']))
                                        <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                            <input type="checkbox" name="theme_bg_image_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ছবি মুছে ফেলুন', 'Remove current image') }}
                                        </label>
                                    @endif
                                    @error('theme_bg_image') <p class="form-error">{{ $message }}</p> @enderror
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="glass rounded-2xl p-5 space-y-4">
                    <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-sliders text-aqua-400"></i> {{ tr('স্টোরফ্রন্ট অপশন', 'Storefront options') }}</h3>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="form-label">{{ tr('লোগোর ধরন', 'Logo type') }} <span class="text-rose-400">*</span></label>
                            <select name="theme_logo_mode" class="form-input" required>
                                @foreach ($logoModes as $key => $label)
                                    <option value="{{ $key }}" @selected(old('theme_logo_mode', $settings['theme_logo_mode'] ?? 'image') === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('আপলোড করা ছবি কোনো গ্রেডিয়েন্ট বক্স বা শ্যাডো ছাড়াই দেখানো হয়। “শুধু ছবি লোগো” নির্বাচন করলে সাইটের নাম ও ব্যাজ দেখাবে না — ছবিটিই পুরো ব্র্যান্ড হিসেবে থাকবে (ছবি না থাকলে নাম দেখাবে)।', 'The uploaded image is shown without a gradient box or shadow. “Image only” hides the site name and badge so the image is the whole brand (the name is shown when no image exists).') }}</p>
                            @error('theme_logo_mode') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="form-label">{{ tr('কম্বো মাছের থাম্বনেইল আকৃতি', 'Combo fish thumbnail shape') }} <span class="text-rose-400">*</span></label>
                            <select name="combo_thumb_shape" class="form-input" required>
                                @foreach ($thumbShapes as $key => $label)
                                    <option value="{{ $key }}" @selected(old('combo_thumb_shape', $settings['combo_thumb_shape'] ?? 'square') === $key)>{{ $label }}</option>
                                @endforeach
                            </select>
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('কম্বো বিল্ডারের মাছ বাছাই গ্রিডে প্রযোজ্য।', 'Applies to the fish picker grid in the combo builder.') }}</p>
                            @error('combo_thumb_shape') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <input type="hidden" name="show_cutting_preference" value="0">
                    <label class="flex items-center justify-between gap-3 cursor-pointer rounded-xl border border-line bg-card2/40 px-4 py-3">
                        <span>
                            <span class="block text-xs font-bold text-ink">{{ tr('প্রোডাক্ট কার্ডে “কাটিং পছন্দ (ফ্রি)” দেখান', 'Show “cutting preference (free)” on product cards') }}</span>
                            <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('বন্ধ করলে কাটিং সিলেক্টর লুকানো থাকবে এবং অর্ডারে ডিফল্ট কাটিং যুক্ত হবে।', 'When off, the cutting selector is hidden and the default cut is added to orders.') }}</span>
                        </span>
                        <span class="switch">
                            <input type="checkbox" name="show_cutting_preference" value="1" @checked(old('show_cutting_preference', $settings['show_cutting_preference'] ?? '1') === '1')>
                            <span class="track"></span>
                        </span>
                    </label>
                </div>

                <div class="flex items-center gap-2">
                    <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('থিম সংরক্ষণ করুন', 'Save theme') }}</button>
                    <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট দেখুন', 'View storefront') }}</a>
                </div>
            </div>

            <div class="space-y-4">
                <div class="glass rounded-2xl p-5">
                    <h3 class="font-extrabold text-ink text-sm mb-3">{{ tr('লাইভ প্রিভিউ', 'Live preview') }}</h3>
                    <div id="theme-preview" class="rounded-2xl p-4 border transition-all duration-300" style="background:rgb(var(--card2));border-color:{{ old('theme_primary', $settings['theme_primary'] ?? '#14b8a6') }}66;">
                        <div class="flex items-center gap-2 mb-3">
                            <span id="preview-logo" class="w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg" style="background:linear-gradient(135deg, {{ old('theme_primary', $settings['theme_primary'] ?? '#14b8a6') }}, {{ old('theme_secondary', $settings['theme_secondary'] ?? '#0284c7') }});">
                                <i class="fa-solid fa-fish-fins"></i>
                            </span>
                            <div>
                                <p id="preview-name" class="font-extrabold text-ink text-sm leading-tight">{{ old('site_name', $settings['site_name'] ?? 'মৎস্যমেলা') }}</p>
                                <p id="preview-tagline" class="text-[9px] text-ink3">{{ old('site_tagline', $settings['site_tagline'] ?? '') }}</p>
                            </div>
                        </div>
                        <div class="rounded-xl border border-line bg-card p-3">
                            <div class="h-14 rounded-lg mb-2" style="background:linear-gradient(135deg, {{ old('theme_primary', $settings['theme_primary'] ?? '#14b8a6') }}33, {{ old('theme_secondary', $settings['theme_secondary'] ?? '#0284c7') }}33);"></div>
                            <p class="text-xs font-bold text-ink">তাজা মাছের বাজার</p>
                            <div class="flex items-center justify-between mt-1.5">
                                <span class="text-[10px] text-ink3">৳৯৯০ / কেজি</span>
                                <span id="preview-chip" class="text-[9px] font-bold px-2 py-0.5 rounded text-white" style="background:{{ old('theme_accent', $settings['theme_accent'] ?? '#f59e0b') }};">অফার</span>
                            </div>
                        </div>
                        <p class="text-[10px] text-ink3 mt-3 leading-relaxed">কালার, ফন্ট, রেডিয়াস ও ব্যাকগ্রাউন্ড স্টাইল সংরক্ষণের পর পুরো স্টোরফ্রন্টে প্রযোজ্য হবে।</p>
                    </div>
                </div>
                <div class="glass rounded-2xl p-5">
                    <h3 class="font-extrabold text-ink text-sm mb-3">{{ tr('টাইপোগ্রাফি প্রিভিউ', 'Typography preview') }}</h3>
                    <div id="typo-preview" class="rounded-xl border border-line bg-card p-4 overflow-hidden space-y-2" style="zoom: 1; font-family: '{{ $themeEnglishFamily }}', '{{ $themeBanglaFamily }}', sans-serif;">
                        <div class="flex items-center justify-between text-[9px] uppercase tracking-widest text-ink3 font-bold">
                            <span>{{ tr('লাইভ', 'Live') }}</span>
                            <span id="tp-meta" class="font-mono normal-case">{{ $themeBaseSize }}px</span>
                        </div>
                        <p id="tp-bn" class="text-xs text-ink2" style="font-family: '{{ $themeBanglaFamily }}', sans-serif;">তাজা মাছের বাজার — আজকের সেরা অফার</p>
                        <p id="tp-en" class="text-xs text-ink2" style="font-family: '{{ $themeEnglishFamily }}', sans-serif;">Fresh fish market — today's best offer</p>
                        <div class="pt-2 border-t border-line/60 space-y-1">
                            <h1 id="tp-h1" class="text-2xl font-black text-ink leading-tight" style="zoom: 1">শিরোনাম ১ / Heading 1</h1>
                            <h2 id="tp-h2" class="text-xl font-extrabold text-ink" style="zoom: 1">শিরোনাম ২ / Heading 2</h2>
                            <h3 id="tp-h3" class="text-base font-bold text-ink" style="zoom: 1">শিরোনাম ৩ / Heading 3</h3>
                            <p id="tp-p" class="text-xs text-ink2 leading-relaxed" style="zoom: 1">সাধারণ লেখা — প্রতিদিন সূর্য ওঠার আগেই তাজা মাছ সংগ্রহ করা হয়। Body text sample.</p>
                        </div>
                        <div id="tp-icons" class="flex items-center gap-3 text-aqua-400 pt-1" style="zoom: 1">
                            <i class="fa-solid fa-fish"></i>
                            <i class="fa-solid fa-fish-fins text-lg"></i>
                            <i class="fa-solid fa-cart-shopping text-2xl"></i>
                            <span class="text-[9px] text-ink3 font-bold uppercase tracking-wide">{{ tr('আইকন', 'Icons') }}</span>
                        </div>
                    </div>
                    <p class="text-[10px] text-ink3 mt-3 leading-relaxed">{{ tr('প্রিভিউতে যা দেখছেন, সংরক্ষণের পর পুরো স্টোরফ্রন্টে ঠিক তেমনই দেখাবে।', 'What you see here is what the storefront will use after saving.') }}</p>
                </div>
                <div class="rounded-2xl border border-line bg-card2/40 p-4 text-[11px] text-ink3 leading-relaxed">
                    <p class="font-bold text-ink2 mb-1"><i class="fa-solid fa-lightbulb text-gold-400 mr-1"></i> টিপস</p>
                    <p>ডার্ক ও লাইট—দুই থিমেই রঙগুলো স্বয়ংক্রিয়ভাবে ব্যবহৃত হবে। খুব হালকা রঙ নির্বাচন করলে টেক্সট কন্ট্রাস্ট কমে যেতে পারে।</p>
                </div>
            </div>
        </div>
    </form>

    @push('scripts')
        <script>
            function bindColor(pickerId, textId, previewTarget) {
                const picker = document.getElementById(pickerId);
                const text = document.getElementById(textId);
                if (!picker || !text) return;
                picker.addEventListener('input', function () {
                    text.value = picker.value;
                    updatePreview();
                });
                text.addEventListener('input', function () {
                    if (/^#[0-9a-fA-F]{6}$/.test(text.value)) {
                        picker.value = text.value;
                        updatePreview();
                    }
                });
            }
            bindColor('theme-primary-picker', 'theme-primary-text');
            bindColor('theme-secondary-picker', 'theme-secondary-text');
            bindColor('theme-accent-picker', 'theme-accent-text');
            bindColor('theme-text-color-picker', 'theme-text-color-text');

            function updatePreview() {
                const primary = document.getElementById('theme-primary-text').value;
                const secondary = document.getElementById('theme-secondary-text').value;
                const accent = document.getElementById('theme-accent-text').value;
                document.getElementById('preview-logo').style.background = 'linear-gradient(135deg, ' + primary + ', ' + secondary + ')';
                document.getElementById('preview-chip').style.background = accent;
                document.getElementById('theme-preview').style.borderColor = primary + '66';
                document.getElementById('preview-name').textContent = document.querySelector('input[name="site_name"]').value;
                document.getElementById('preview-tagline').textContent = document.querySelector('input[name="site_tagline"]').value;
                updateTypographyPreview();
            }
            document.querySelector('input[name="site_name"]').addEventListener('input', updatePreview);
            document.querySelector('input[name="site_tagline"]').addEventListener('input', updatePreview);

            // ---------- Typography & icon live preview ----------
            function ensurePreviewFont(select) {
                const option = select && select.selectedOptions[0];
                if (!option) return null;
                const family = option.dataset.family;
                const weights = option.dataset.weights || '400;700';
                if (!family) return null;

                if (!document.querySelector('link[data-preview-font="' + family + '"]')) {
                    const link = document.createElement('link');
                    link.rel = 'stylesheet';
                    link.href = 'https://fonts.googleapis.com/css2?family=' + encodeURIComponent(family).replace(/%20/g, '+') + ':wght@' + weights + '&display=swap';
                    link.dataset.previewFont = family;
                    document.head.appendChild(link);
                }

                return family;
            }

            function updateTypographyPreview() {
                const preview = document.getElementById('typo-preview');
                if (!preview) return;

                const banglaSelect = document.getElementById('theme-font-bangla');
                const englishSelect = document.getElementById('theme-font-english');
                const banglaFamily = ensurePreviewFont(banglaSelect);
                const englishFamily = ensurePreviewFont(englishSelect);

                if (banglaFamily) {
                    preview.style.fontFamily = "'" + englishFamily + "', '" + banglaFamily + "', sans-serif";
                    const bn = document.getElementById('tp-bn');
                    if (bn) bn.style.fontFamily = "'" + banglaFamily + "'";
                }
                if (englishFamily) {
                    const en = document.getElementById('tp-en');
                    if (en) en.style.fontFamily = "'" + englishFamily + "'";
                }

                const base = document.getElementById('theme-font-size');
                const h1 = document.getElementById('theme-h1-scale');
                const h2 = document.getElementById('theme-h2-scale');
                const h3 = document.getElementById('theme-h3-scale');
                const text = document.getElementById('theme-text-scale');
                const icon = document.getElementById('theme-icon-scale');
                const color = document.getElementById('theme-text-color-text');

                if (base) {
                    preview.style.zoom = (Number(base.value) / 16).toFixed(3);
                    const meta = document.getElementById('tp-meta');
                    if (meta) meta.textContent = base.value + 'px';
                }
                if (h1) document.getElementById('tp-h1').style.zoom = Number(h1.value) / 100;
                if (h2) document.getElementById('tp-h2').style.zoom = Number(h2.value) / 100;
                if (h3) document.getElementById('tp-h3').style.zoom = Number(h3.value) / 100;
                if (text) document.getElementById('tp-p').style.zoom = Number(text.value) / 100;
                if (icon) document.getElementById('tp-icons').style.zoom = Number(icon.value) / 100;

                document.querySelectorAll('[data-scale-value]').forEach(function (label) {
                    const input = document.querySelector('select[name="' + label.dataset.scaleValue + '"], input[name="' + label.dataset.scaleValue + '"]');
                    if (input) label.textContent = input.value;
                });

                if (color) {
                    preview.style.color = /^#[0-9a-fA-F]{6}$/.test(color.value.trim()) ? color.value.trim() : '';
                }
            }

            ['theme-font-bangla', 'theme-font-english', 'theme-font-size', 'theme-h1-scale', 'theme-h2-scale',
             'theme-h3-scale', 'theme-text-scale', 'theme-icon-scale', 'theme-text-color-text'
            ].forEach(function (id) {
                const input = document.getElementById(id);
                if (!input) return;
                input.addEventListener('input', updateTypographyPreview);
                input.addEventListener('change', updateTypographyPreview);
            });

            const textColorClear = document.getElementById('theme-text-color-clear');
            const textColorText = document.getElementById('theme-text-color-text');
            const textColorPicker = document.getElementById('theme-text-color-picker');
            if (textColorClear) {
                textColorClear.addEventListener('click', function () {
                    if (textColorText) textColorText.value = '';
                    if (textColorPicker) textColorPicker.value = '#e2f0f9';
                    updateTypographyPreview();
                });
            }

            updateTypographyPreview();
        </script>
    @endpush
@endsection
