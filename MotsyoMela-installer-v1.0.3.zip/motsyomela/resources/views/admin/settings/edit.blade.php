@extends('admin.layouts.app')

@section('title', tr('সাইট সেটিংস', 'Site settings'))
@section('subtitle', tr('যোগাযোগ, ডেলিভারি সময় ও আমাদের সম্পর্কে', 'Contact, delivery hours and about us'))

@section('content')
    <form method="POST" action="{{ route('admin.settings.update') }}" enctype="multipart/form-data" class="max-w-3xl">
        @csrf
        @method('PUT')

        <div class="glass rounded-2xl p-5 space-y-5">
            <div>
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-address-book text-aqua-400"></i> {{ tr('যোগাযোগের তথ্য', 'Contact information') }}</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('হটলাইন নম্বর', 'Hotline number') }} <span class="text-rose-400">*</span></label>
                        <input type="text" name="site_phone" value="{{ old('site_phone', $settings['site_phone'] ?? '') }}" class="form-input" placeholder="16234" required>
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('টিকার, ফুটার ও ইনভয়েসে দেখাবে।', 'Shown in the ticker, footer and invoices.') }}</p>
                        @error('site_phone') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('হোয়াটসঅ্যাপ নম্বর', 'WhatsApp number') }}</label>
                        <input type="text" name="whatsapp_number" value="{{ old('whatsapp_number', $settings['whatsapp_number'] ?? '') }}" class="form-input" placeholder="8801700000000">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('আন্তর্জাতিক ফরম্যাটে (৮৮০ দিয়ে শুরু)।', 'International format (starting with 880).') }}</p>
                        @error('whatsapp') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('ডেলিভারি সময়ের লেখা', 'Delivery hours text') }} <span class="text-rose-400">*</span></label>
                        <input type="text" name="delivery_hours" value="{{ old('delivery_hours', $settings['delivery_hours'] ?? '') }}" class="form-input" placeholder="{{ tr('সকাল ৮টা - রাত ৮টা', '8am - 8pm') }}" required>
                        @error('delivery_hours') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-1 flex items-center gap-2"><i class="fa-solid fa-fish-fins text-aqua-400"></i> {{ tr('আমাদের সম্পর্কে', 'About us') }}</h3>
                <p class="text-[10px] text-ink3 mb-4">{{ tr('স্টোরফ্রন্টের ফুটারের ঠিক উপরে এই সেকশনটি দেখা যাবে।', 'This section appears just above the storefront footer.') }}</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('শিরোনাম', 'Heading') }}</label>
                        <input type="text" name="about_title" value="{{ old('about_title', $settings['about_title'] ?? '') }}" class="form-input" placeholder="{{ tr('আমাদের সম্পর্কে', 'About us') }}">
                        @error('about_title') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('সাব-শিরোনাম', 'Sub-heading') }}</label>
                        <input type="text" name="about_subtitle" value="{{ old('about_subtitle', $settings['about_subtitle'] ?? '') }}" class="form-input" placeholder="মৎস্যমেলা — তাজা মাছের বিশ্বস্ত ঠিকানা">
                        @error('about_subtitle') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('বিবরণ', 'Description') }}</label>
                        <textarea name="about_text" rows="4" class="form-input" placeholder="{{ tr('আপনার প্রতিষ্ঠানের গল্প লিখুন...', 'Tell your company story...') }}">{{ old('about_text', $settings['about_text'] ?? '') }}</textarea>
                        @error('about_text') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('বুলেট পয়েন্ট', 'Bullet points') }}</label>
                        <textarea name="about_points" rows="4" class="form-input" placeholder="{{ tr('প্রতি লাইনে একটি করে পয়েন্ট লিখুন', 'Write one point per line') }}">{{ old('about_points', $settings['about_points'] ?? '') }}</textarea>
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('প্রতি লাইনে একটি করে সুবিধা/পয়েন্ট লিখুন।', 'Write one benefit/point per line.') }}</p>
                        @error('about_points') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('সেকশনের ছবি', 'Section image') }}</label>
                        <div class="flex items-center gap-4">
                            <div class="w-24 h-16 rounded-xl bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                                @if (! empty($settings['about_image']))
                                    <img src="{{ asset('storage/'.$settings['about_image']) }}" alt="{{ tr('আমাদের সম্পর্কে', 'About us') }}" class="w-full h-full object-cover">
                                @else
                                    <i class="fa-solid fa-image text-ink3"></i>
                                @endif
                            </div>
                            <div class="flex-1">
                                <input type="file" name="about_image" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                                <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ৩MB। ছবি না দিলে ব্র্যান্ড গ্রাডিয়েন্ট দেখাবে।', 'JPG, PNG or WebP · max 3MB. The brand gradient is shown when no image is set.') }}</p>
                                @if (! empty($settings['about_image']))
                                    <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                        <input type="checkbox" name="about_image_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ছবি মুছে ফেলুন', 'Remove current image') }}
                                    </label>
                                @endif
                                @error('about_image') <p class="form-error">{{ $message }}</p> @enderror
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-3 flex items-center gap-2"><i class="fa-solid fa-star text-aqua-400"></i> {{ tr('কাস্টমার রিভিউ', 'Customer reviews') }}</h3>
                <input type="hidden" name="review_enabled" value="0">
                <label class="flex items-center justify-between gap-3 cursor-pointer rounded-xl border border-line bg-card2/40 px-4 py-3">
                    <span>
                        <span class="block text-xs font-bold text-ink">{{ tr('অর্ডারের পর রিভিউ লিংক পাঠান', 'Send a review link after the order') }}</span>
                        <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('ইমেইল ও হোয়াটসঅ্যাপ বার্তায় রিভিউ লিংক যুক্ত হবে। জমা দেওয়া রিভিউ অ্যাডমিন অনুমোদনের পর স্টোরফ্রন্টে দেখাবে।', 'The review link is added to emails and WhatsApp messages. Submitted reviews appear on the storefront after admin approval.') }}</span>
                    </span>
                    <span class="switch">
                        <input type="checkbox" name="review_enabled" value="1" @checked(($settings['review_enabled'] ?? '1') === '1')>
                        <span class="track"></span>
                    </span>
                </label>
            </div>

            <div class="rounded-xl border border-aqua-500/25 bg-aqua-500/5 px-4 py-3 text-[11px] text-ink2 flex items-start gap-2">
                <i class="fa-solid fa-circle-info text-aqua-400 mt-0.5"></i>
                <span>{{ tr('বিকাশ, নগদ ও কার্ড পেমেন্টের নম্বর, লিংক ও নির্দেশনা এখন', 'bKash, Nagad and card numbers, links and instructions can now be changed on the') }} <a href="{{ route('admin.payments.edit') }}" class="font-bold text-aqua-400 underline">{{ tr('পেমেন্ট গেটওয়ে', 'Payment gateway') }}</a> {{ tr('পেজে পরিবর্তন করুন।', 'page.') }}</span>
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সেটিংস সংরক্ষণ করুন', 'Save settings') }}</button>
                <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
            </div>
        </div>
    </form>
@endsection
