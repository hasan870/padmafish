@extends('admin.layouts.app')

@section('title', tr('কম্বো প্যাক ব্যবস্থাপনা', 'Combo pack management'))
@section('subtitle', tr('কম্বো প্যাক তৈরি, এডিট ও ডিলিট করুন', 'Create, edit and delete combo packs'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($packs->total()) }} {{ tr('টি কম্বো প্যাক', 'combo packs') }}</p>
        <a href="{{ route('admin.combo-packs.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন কম্বো প্যাক', 'New combo pack') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[760px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('প্যাকেজ', 'Package') }}</th>
                        <th class="text-center">{{ tr('মাছের সংখ্যা', 'Fish count') }}</th>
                        <th>{{ tr('ছাড়', 'Discount') }}</th>
                        <th>{{ tr('ব্যাজ', 'Badge') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($packs as $pack)
                        <tr>
                            <td>
                                <div class="flex items-center gap-2">
                                    <span class="w-8 h-8 rounded-lg bg-gold-500/15 text-gold-400 inline-flex items-center justify-center text-sm"><i class="fa-solid fa-gift"></i></span>
                                    <div>
                                        <p class="font-bold text-ink">{{ localized($pack->name_bn, $pack->name_en) }}</p>
                                        <p class="text-[11px] text-ink3">{{ $pack->name_en ?: '—' }}</p>
                                    </div>
                                </div>
                            </td>
                            <td class="text-center"><span class="badge border-aqua-500/30 bg-aqua-500/10 text-aqua-400">{{ bn_num($pack->item_count) }} {{ tr('টি মাছ', 'fish') }}</span></td>
                            <td>
                                <p class="font-bold text-ink">{{ $pack->discountLabelBn() }}</p>
                                <p class="text-[10px] text-ink3">{{ $pack->discount_type === 'percent' ? tr('শতকরা ছাড়', 'Percentage discount') : tr('নির্দিষ্ট টাকা ছাড়', 'Fixed amount discount') }}</p>
                            </td>
                            <td class="text-[11px] text-ink2">{{ $pack->badge_bn ?: '—' }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($pack->sort_order) }}</td>
                            <td>
                                @if ($pack->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.combo-packs.edit', $pack) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.combo-packs.destroy', $pack) }}" class="inline-block" data-confirm="কম্বো প্যাক &quot;{{ $pack->name_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো কম্বো প্যাক নেই। একটি নতুন প্যাক যোগ করুন।', 'No combo packs yet. Add a new pack.') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($packs->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $packs->links() }}</div>
        @endif
    </div>

    <div class="mt-4 rounded-2xl border border-line bg-card2/40 p-4 text-[11px] text-ink3 leading-relaxed">
        <p><i class="fa-solid fa-circle-info text-aqua-400 mr-1"></i> {{ tr('সক্রিয় প্যাকগুলো স্টোরফ্রন্টের কম্বো বিল্ডারে প্যাক সাইজ অপশন হিসেবে দেখাবে। চেকআউটে ছাড়ের হিসাব সার্ভারে আবার যাচাই করা হয়।', 'Active packs appear as package-size options in the storefront combo builder. Discounts are re-verified on the server at checkout.') }}</p>
    </div>
@endsection
