@extends('admin.layouts.app')

@section('title', $pack->exists ? tr('কম্বো প্যাক এডিট', 'Edit combo pack') : tr('নতুন কম্বো প্যাক', 'New combo pack'))
@section('subtitle', tr('প্যাক সাইজ, ছাড় ও স্টোরফ্রন্ট প্রদর্শন নিয়ন্ত্রণ করুন', 'Manage pack size, discount and storefront display'))

@section('content')
    <form method="POST" action="{{ $pack->exists ? route('admin.combo-packs.update', $pack) : route('admin.combo-packs.store') }}" class="max-w-3xl">
        @csrf
        @if ($pack->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-5">
            <div class="flex items-start gap-3 rounded-xl border border-gold-500/25 bg-gold-500/5 p-4">
                <span class="w-10 h-10 rounded-xl bg-gold-500/15 text-gold-400 flex items-center justify-center text-lg shrink-0"><i class="fa-solid fa-gift"></i></span>
                <div>
                    <p class="text-sm font-bold text-ink">{{ tr('কম্বো প্যাকেজ', 'Combo package') }}</p>
                    <p class="text-[11px] text-ink3 mt-0.5">{{ tr('কাস্টমার নির্দিষ্ট সংখ্যক ভিন্ন মাছ বেছে নিলে এই প্যাকের ছাড়টি প্রযোজ্য হবে।', 'This pack discount applies when the customer picks the set number of different fish.') }}</p>
                </div>
            </div>

            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('বাংলা নাম', 'Bengali name') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="name_bn" value="{{ old('name_bn', $pack->name_bn) }}" class="form-input" placeholder="{{ tr('যেমন: ৪টি মাছের কম্বো', 'e.g. 4-fish combo') }}" required>
                    @error('name_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ইংরেজি নাম', 'English name') }}</label>
                    <input type="text" name="name_en" value="{{ old('name_en', $pack->name_en) }}" class="form-input" placeholder="4 Fish Combo">
                    @error('name_en') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('মাছের সংখ্যা', 'Fish count') }} <span class="text-rose-400">*</span></label>
                    <input type="number" name="item_count" value="{{ old('item_count', $pack->item_count ?? 4) }}" min="2" max="10" class="form-input" required>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('২ থেকে ১০টি। প্রতিটি সংখ্যার জন্য একটিই প্যাক তৈরি করা যাবে।', '2 to 10. Only one pack can exist for each number.') }}</p>
                    @error('item_count') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ব্যাজ / ট্যাগ', 'Badge / tag') }}</label>
                    <input type="text" name="badge_bn" value="{{ old('badge_bn', $pack->badge_bn) }}" class="form-input" placeholder="{{ tr('যেমন: জনপ্রিয়', 'e.g. Popular') }}">
                    @error('badge_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ছাড়ের ধরন', 'Discount type') }} <span class="text-rose-400">*</span></label>
                    <select name="discount_type" id="discount-type" class="form-input" required>
                        <option value="percent" @selected(old('discount_type', $pack->discount_type) === 'percent')>{{ tr('শতকরা (%)', 'Percentage (%)') }}</option>
                        <option value="fixed" @selected(old('discount_type', $pack->discount_type) === 'fixed')>{{ tr('নির্দিষ্ট টাকা (৳)', 'Fixed amount (৳)') }}</option>
                    </select>
                    @error('discount_type') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ছাড়ের পরিমাণ', 'Discount amount') }} <span class="text-rose-400">*</span></label>
                    <div class="relative">
                        <input type="number" step="0.01" name="discount_value" id="discount-value" value="{{ old('discount_value', (float) ($pack->discount_value ?? 10)) }}" min="0.01" class="form-input !pr-10" required>
                        <span id="discount-suffix" class="absolute right-3 top-1/2 -translate-y-1/2 text-ink3 font-bold">%</span>
                    </div>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('শতকরা ছাড় সর্বোচ্চ ৯০%।', 'Percentage discount is capped at 90%.') }}</p>
                    @error('discount_value') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div class="sm:col-span-2">
                    <label class="form-label">{{ tr('সংক্ষিপ্ত বিবরণ', 'Short description') }}</label>
                    <textarea name="description_bn" rows="2" class="form-input" placeholder="{{ tr('কম্বো প্যাকের সুবিধা বা শর্ত লিখুন', 'Write the combo pack benefits or conditions') }}">{{ old('description_bn', $pack->description_bn) }}</textarea>
                    @error('description_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                    <input type="number" name="sort_order" value="{{ old('sort_order', $pack->sort_order ?? 0) }}" min="0" max="9999" class="form-input">
                    @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer pt-1">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় প্যাক স্টোরফ্রন্ট ও চেকআউটে গ্রহণ করা হবে না', 'Inactive packs are rejected by the storefront and checkout') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $pack->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.combo-packs.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>

    @push('scripts')
        <script>
            const typeSelect = document.getElementById('discount-type');
            const suffix = document.getElementById('discount-suffix');
            const valueInput = document.getElementById('discount-value');
            function syncDiscountUi() {
                const isPercent = typeSelect.value === 'percent';
                suffix.textContent = isPercent ? '%' : '৳';
                valueInput.max = isPercent ? '90' : '100000';
                valueInput.step = isPercent ? '1' : '0.01';
            }
            typeSelect.addEventListener('change', syncDiscountUi);
            syncDiscountUi();
        </script>
    @endpush
@endsection
