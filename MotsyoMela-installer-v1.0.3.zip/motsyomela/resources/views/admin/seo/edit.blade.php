@extends('admin.layouts.app')

@section('title', tr('SEO ও Google Analytics', 'SEO & Google Analytics'))
@section('subtitle', tr('সার্চ ইঞ্জিন মেটা ট্যাগ, শেয়ার ছবি ও অ্যানালিটিক্স', 'Search engine meta tags, share image and analytics'))

@section('content')
    <form method="POST" action="{{ route('admin.seo.update') }}" enctype="multipart/form-data" class="max-w-3xl">
        @csrf
        @method('PUT')

        <div class="glass rounded-2xl p-5 space-y-5">
            <div>
                <h3 class="font-extrabold text-ink text-sm mb-1 flex items-center gap-2"><i class="fa-solid fa-magnifying-glass-chart text-aqua-400"></i> {{ tr('সার্চ ইঞ্জিন অপটিমাইজেশন', 'Search engine optimisation') }}</h3>
                <p class="text-[11px] text-ink3">{{ tr('খালি রাখলে সাইটের নাম ও ট্যাগলাইন ব্যবহার হবে।', 'The site name and tagline are used when left empty.') }}</p>
            </div>

            <div class="space-y-4">
                <div>
                    <label class="form-label">{{ tr('মেটা টাইটেল', 'Meta title') }}</label>
                    <input type="text" name="seo_meta_title" value="{{ old('seo_meta_title', $settings['seo_meta_title'] ?? '') }}" class="form-input" maxlength="160" placeholder="{{ ($settings['site_name'] ?? 'মৎস্যমেলা').' | '.($settings['site_tagline'] ?? '') }}">
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('ব্রাউজার ট্যাব ও গুগল সার্চে দেখা যাবে · সর্বোচ্চ ১৬০ অক্ষর।', 'Shown in the browser tab and Google search · max 160 characters.') }}</p>
                    @error('seo_meta_title') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('মেটা ডেসক্রিপশন', 'Meta description') }}</label>
                    <textarea name="seo_meta_description" rows="3" class="form-input" maxlength="300" placeholder="সাইটের সংক্ষিপ্ত বর্ণনা...">{{ old('seo_meta_description', $settings['seo_meta_description'] ?? '') }}</textarea>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('গুগল সার্চ রেজাল্টে দেখানো সংক্ষিপ্ত বর্ণনা · সর্বোচ্চ ৩০০ অক্ষর।', 'Short description shown in Google results · max 300 characters.') }}</p>
                    @error('seo_meta_description') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('কীওয়ার্ড', 'Keywords') }}</label>
                    <input type="text" name="seo_meta_keywords" value="{{ old('seo_meta_keywords', $settings['seo_meta_keywords'] ?? '') }}" class="form-input" placeholder="তাজা মাছ, ইলিশ, অনলাইন মাছের বাজার">
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('কমা দিয়ে আলাদা করুন।', 'Separate with commas.') }}</p>
                    @error('seo_meta_keywords') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('রোবট সেটিং', 'Robots setting') }} <span class="text-rose-400">*</span></label>
                        <select name="seo_robots" class="form-input" required>
                            <option value="index,follow" @selected(old('seo_robots', $settings['seo_robots'] ?? 'index,follow') === 'index,follow')>{{ tr('ইনডেক্স ও ফলো (সুপারিশকৃত)', 'Index & follow (recommended)') }}</option>
                            <option value="noindex,follow" @selected(old('seo_robots', $settings['seo_robots'] ?? '') === 'noindex,follow')>{{ tr('নো-ইনডেক্স, ফলো', 'No-index, follow') }}</option>
                            <option value="index,nofollow" @selected(old('seo_robots', $settings['seo_robots'] ?? '') === 'index,nofollow')>{{ tr('ইনডেক্স, নো-ফলো', 'Index, no-follow') }}</option>
                            <option value="noindex,nofollow" @selected(old('seo_robots', $settings['seo_robots'] ?? '') === 'noindex,nofollow')>{{ tr('নো-ইনডেক্স, নো-ফলো', 'No-index, no-follow') }}</option>
                        </select>
                        @error('seo_robots') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('Google Search Console কোড', 'Google Search Console code') }}</label>
                        <input type="text" name="seo_google_verification" value="{{ old('seo_google_verification', $settings['seo_google_verification'] ?? '') }}" class="form-input text-xs" placeholder="google-site-verification কোড">
                        @error('seo_google_verification') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
                <div>
                    <label class="form-label">{{ tr('সোশ্যাল শেয়ার ছবি (Open Graph)', 'Social share image (Open Graph)') }}</label>
                    <div class="flex items-center gap-4">
                        <div class="w-24 h-14 rounded-xl bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                            @if (! empty($settings['seo_og_image']))
                                <img src="{{ asset('storage/'.$settings['seo_og_image']) }}" alt="{{ tr('শেয়ার ছবি', 'Share image') }}" class="w-full h-full object-cover">
                            @else
                                <i class="fa-solid fa-image text-ink3"></i>
                            @endif
                        </div>
                        <div class="flex-1">
                            <input type="file" name="seo_og_image" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                            <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ২MB · ১২০০×৬৩০ হলে সবচেয়ে ভালো।', 'JPG, PNG or WebP · max 2MB · 1200×630 works best.') }}</p>
                            @if (! empty($settings['seo_og_image']))
                                <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                    <input type="checkbox" name="seo_og_image_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ছবি মুছে ফেলুন', 'Remove current image') }}
                                </label>
                            @endif
                            @error('seo_og_image') <p class="form-error">{{ $message }}</p> @enderror
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="glass rounded-2xl p-5 mt-4 space-y-4">
            <div class="flex items-center justify-between gap-3">
                <div>
                    <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-chart-line text-aqua-400"></i> {{ tr('Google Analytics', 'Google Analytics') }}</h3>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('সাইটের ভিজিটর ও কনভার্সন ট্র্যাক করতে GA4 মেজারমেন্ট আইডি দিন।', 'Add a GA4 measurement ID to track site visitors and conversions.') }}</p>
                </div>
                <span class="switch">
                    <input type="hidden" name="seo_ga_enabled" value="0">
                    <input type="checkbox" name="seo_ga_enabled" value="1" @checked(($settings['seo_ga_enabled'] ?? '0') === '1')>
                    <span class="track"></span>
                </span>
            </div>
            <div>
                <label class="form-label">{{ tr('GA4 মেজারমেন্ট আইডি', 'GA4 measurement ID') }}</label>
                <input type="text" name="seo_ga4_id" value="{{ old('seo_ga4_id', $settings['seo_ga4_id'] ?? '') }}" class="form-input font-mono" placeholder="G-XXXXXXXXXX">
                <p class="text-[10px] text-ink3 mt-1">{{ tr('Google Analytics → Admin → Data Streams থেকে আইডিটি কপি করুন। ট্র্যাকিং বন্ধ রাখতে উপরের সুইচটি বন্ধ রাখুন।', 'Copy the ID from Google Analytics → Admin → Data Streams. Turn the switch off to disable tracking.') }}</p>
                @error('seo_ga4_id') <p class="form-error">{{ $message }}</p> @enderror
            </div>
        </div>

        <div class="flex items-center gap-2 mt-5">
            <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সেটিংস সংরক্ষণ করুন', 'Save settings') }}</button>
            <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
        </div>
    </form>
@endsection
