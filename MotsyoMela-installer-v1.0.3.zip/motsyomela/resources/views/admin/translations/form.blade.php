@extends('admin.layouts.app')

@section('title', $translation->exists ? tr('অনুবাদ এডিট', 'Edit translation') : tr('নতুন অনুবাদ', 'New translation'))
@section('subtitle', tr('বাংলা লেবেল ও তার ইংরেজি অনুবাদ নির্ধারণ করুন', 'Set a Bengali label and its English translation'))

@section('content')
    <form method="POST" action="{{ $translation->exists ? route('admin.translations.update', $translation) : route('admin.translations.store') }}" class="max-w-2xl">
        @csrf
        @if ($translation->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div>
                <label class="form-label">{{ tr('বাংলা লেবেল / বাক্য', 'Bengali label / sentence') }} <span class="text-rose-400">*</span></label>
                <input type="text" name="key" value="{{ old('key', $translation->key) }}" class="form-input" placeholder="{{ tr('যেমন: কার্ট দেখুন', 'e.g. কার্ট দেখুন') }}" maxlength="255" required>
                <p class="text-[10px] text-ink3 mt-1">{{ tr('যে লেখাটি সাইটে বাংলায় দেখা যায়, ঠিক সেটিই লিখুন।', 'Enter the exact Bengali text shown on the site.') }}</p>
                @error('key') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <div>
                <label class="form-label">{{ tr('ইংরেজি অনুবাদ', 'English translation') }}</label>
                <input type="text" name="value_en" value="{{ old('value_en', $translation->value_en) }}" class="form-input" placeholder="View cart" maxlength="500">
                <p class="text-[10px] text-ink3 mt-1">{{ tr('ইংরেজি মোডে এই লেখাটি দেখানো হবে। খালি রাখলে ডিফল্ট অনুবাদ ব্যবহৃত হবে।', 'Shown in English mode. Leave empty to use the built-in default.') }}</p>
                @error('value_en') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <div>
                <label class="form-label">{{ tr('বিভাগ', 'Group') }} <span class="text-rose-400">*</span></label>
                <select name="group" class="form-input" required>
                    @foreach ($groups as $key => $label)
                        <option value="{{ $key }}" @selected(old('group', $translation->group) === $key)>{{ $label }}</option>
                    @endforeach
                </select>
                @error('group') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.translations.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
