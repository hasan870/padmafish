@extends('admin.layouts.app')

@section('title', tr('ভাষা ও অনুবাদ', 'Language & translations'))
@section('subtitle', tr('স্টোরফ্রন্ট ও অ্যাডমিনের লেবেলের ইংরেজি অনুবাদ', 'English translations for storefront and admin labels'))

@section('content')
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-4">
        <form method="GET" action="{{ route('admin.translations.index') }}" class="flex flex-wrap items-center gap-2">
            <div class="relative">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-xs"></i>
                <input type="search" name="q" value="{{ $search }}" placeholder="{{ tr('লেবেল বা অনুবাদ খুঁজুন', 'Search label or translation') }}" class="form-input !py-2 !pl-8 !text-xs w-60">
            </div>
            <select name="group" class="form-input !py-2 !text-xs w-40">
                <option value="">{{ tr('সব বিভাগ', 'All groups') }}</option>
                @foreach ($groups as $key => $label)
                    <option value="{{ $key }}" @selected($group === $key)>{{ $label }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn-soft !py-2">{{ tr('খুঁজুন', 'Search') }}</button>
            @if ($search !== '' || $group !== '')
                <a href="{{ route('admin.translations.index') }}" class="btn-soft !py-2" title="{{ tr('রিসেট', 'Reset') }}"><i class="fa-solid fa-rotate-left"></i></a>
            @endif
        </form>

        <div class="flex items-center gap-2">
            <form method="POST" action="{{ route('admin.translations.sync') }}" data-confirm="কোডে ব্যবহৃত সব tr() লেবেল স্ক্যান করে অনুবাদ তালিকায় যোগ করা হবে। নিশ্চিত?">
                @csrf
                <button type="submit" class="btn-soft" title="{{ tr('কোডের সব লেবেল স্ক্যান করে তালিকায় যোগ করুন', 'Scan the code for labels and add them to the list') }}">
                    <i class="fa-solid fa-wand-magic-sparkles"></i>
                    <span class="hidden sm:inline">{{ tr('লেবেল স্ক্যান', 'Scan labels') }}</span>
                </button>
            </form>
            <a href="{{ route('admin.translations.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন অনুবাদ', 'New translation') }}</a>
        </div>
    </div>

    <div class="mb-4 rounded-xl border border-aqua-500/25 bg-aqua-500/5 px-4 py-3 text-[11px] text-ink2 flex items-start gap-2">
        <i class="fa-solid fa-circle-info text-aqua-400 mt-0.5"></i>
        <span>
            {{ tr('বাংলা লেবেলটিই কী (key)। ইংরেজি অনুবাদ না থাকলে কোডে দেওয়া ডিফল্ট ইংরেজি ব্যবহার হবে। ভাষা টগল অ্যাডমিনের উপরের বারে আছে।', 'The Bengali label is the key. When no English value exists, the built-in default is used. Use the language toggle in the admin top bar to switch.') }}
        </span>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[760px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('বাংলা লেবেল (key)', 'Bengali label (key)') }}</th>
                        <th>{{ tr('ইংরেজি অনুবাদ', 'English translation') }}</th>
                        <th>{{ tr('বিভাগ', 'Group') }}</th>
                        <th>{{ tr('আপডেট', 'Updated') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($translations as $translation)
                        <tr>
                            <td class="text-xs font-semibold text-ink max-w-[18rem]">{{ $translation->key }}</td>
                            <td class="text-xs text-ink2 max-w-[20rem]">{{ $translation->value_en ?: '—' }}</td>
                            <td><span class="badge border-line bg-card2 text-ink3">{{ $groups[$translation->group] ?? $translation->group }}</span></td>
                            <td class="text-[11px] text-ink3">{{ bn_num($translation->updated_at->format('d/m/Y')) }}</td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.translations.edit', $translation) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.translations.destroy', $translation) }}" class="inline-block" data-confirm="এই অনুবাদটি ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="5" class="text-center py-12 text-ink3 text-sm">
                                {{ tr('কোনো অনুবাদ পাওয়া যায়নি', 'No translations found') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($translations->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $translations->links() }}</div>
        @endif
    </div>
@endsection
