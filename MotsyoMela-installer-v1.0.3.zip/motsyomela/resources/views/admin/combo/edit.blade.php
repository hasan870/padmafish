@extends('admin.layouts.app')

@section('title', tr('কম্বো নিয়ন্ত্রণ', 'Combo control'))
@section('subtitle', tr('কম্বো ফিচার চালু/বন্ধ করুন', 'Turn the combo feature on or off'))

@section('content')
    <form method="POST" action="{{ route('admin.combo.update') }}" class="max-w-3xl">
        @csrf
        @method('PUT')

        <div class="glass rounded-2xl p-5 space-y-5">
            <div class="flex items-start gap-3 rounded-xl border border-gold-500/25 bg-gold-500/5 p-4">
                <span class="w-10 h-10 rounded-xl bg-gold-500/15 text-gold-400 flex items-center justify-center text-lg shrink-0"><i class="fa-solid fa-gift"></i></span>
                <div>
                    <p class="text-sm font-bold text-ink">{{ tr('চয়েস কম্বো প্যাকেজ', 'Choice combo package') }}</p>
                    <p class="text-[11px] text-ink3 mt-0.5">{{ tr('কাস্টমার নিজের পছন্দের মাছ বেছে নিয়ে কম্বো ছাড় পায়। প্যাক সাইজ, ছাড় ও নাম এখন আলাদা প্যাক হিসেবে নিয়ন্ত্রণ করা যায়।', 'Customers pick their own fish and get a combo discount. Pack size, discount and name are now managed as separate packs.') }}</p>
                </div>
            </div>

            <div class="rounded-xl border border-line bg-card2/40 p-4 flex items-center justify-between gap-3">
                <div>
                    <p class="text-xs font-bold text-ink">{{ bn_num($packCount) }}{{ tr('টি সক্রিয় কম্বো প্যাক', ' active combo packs') }}</p>
                    <a href="{{ route('admin.combo-packs.index') }}" class="text-[11px] text-aqua-400 hover:underline mt-1 inline-block"><i class="fa-solid fa-arrow-right mr-1"></i> {{ tr('কম্বো প্যাক ব্যবস্থাপনায় যান', 'Go to combo pack management') }}</a>
                </div>
                <a href="{{ route('admin.combo-packs.create') }}" class="btn-soft !py-2"><i class="fa-solid fa-plus"></i> {{ tr('নতুন প্যাক', 'New pack') }}</a>
            </div>

            <input type="hidden" name="combo_enabled" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('কম্বো ফিচার সক্রিয়', 'Combo feature enabled') }}</span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('বন্ধ থাকলে স্টোরফ্রন্টে কম্বো সেকশন ও চেকআউটে কম্বো গ্রহণ বন্ধ থাকবে', 'When off, the combo section and combo checkout are disabled on the storefront.') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="combo_enabled" value="1" @checked(old('combo_enabled', ($settings['combo_enabled'] ?? '1') === '1'))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="rounded-xl border border-line bg-card2/40 p-4">
                <p class="text-[11px] font-bold text-ink2 mb-2">{{ tr('স্বয়ংক্রিয় নিয়ম', 'Automatic rules') }}</p>
                <ul class="space-y-1.5 text-[11px] text-ink3">
                    <li><i class="fa-solid fa-check text-emerald-400 mr-1.5"></i> {{ tr('কম্বোতে একই মাছ একাধিকবার রাখা যাবে না।', 'The same fish cannot be added twice to a combo.') }}</li>
                    <li><i class="fa-solid fa-check text-emerald-400 mr-1.5"></i> {{ tr('স্টকে না থাকা মাছ কম্বোতে যোগ করা যাবে না।', 'Out-of-stock fish cannot be added to a combo.') }}</li>
                    <li><i class="fa-solid fa-check text-emerald-400 mr-1.5"></i> {{ tr('চেকআউটে সার্ভার DB থেকে প্যাক ও ছাড় পুনরায় যাচাই করে।', 'At checkout the server re-verifies the pack and discount from the DB.') }}</li>
                </ul>
            </div>

            <div class="flex items-center gap-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সেটিংস সংরক্ষণ করুন', 'Save settings') }}</button>
                <a href="{{ url('/') }}#combo-section" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরে দেখুন', 'View on store') }}</a>
            </div>
        </div>
    </form>
@endsection
