@extends('admin.layouts.app')

@section('title', tr('ডেলিভারি সময়', 'Delivery time slots'))
@section('subtitle', tr('চেকআউটে দেখানো সময় স্লটসমূহ', 'Time slots shown at checkout'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($slots->total()) }} {{ tr('টি সময় স্লট', 'time slots') }}</p>
        <a href="{{ route('admin.slots.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন সময়', 'New time slot') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[640px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('সময় স্লট', 'Time slot') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($slots as $slot)
                        <tr>
                            <td class="font-bold text-ink">
                                <i class="fa-solid fa-clock text-aqua-400 text-xs mr-2"></i>{{ localized($slot->label_bn, $slot->label_en) }}
                                @if ($slot->label_en)
                                    <p class="text-[11px] text-ink3 font-normal pl-5">{{ app()->getLocale() === 'en' ? $slot->label_bn : $slot->label_en }}</p>
                                @endif
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($slot->sort_order) }}</td>
                            <td>
                                @if ($slot->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.slots.edit', $slot) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.slots.destroy', $slot) }}" class="inline-block" data-confirm="ডেলিভারি সময় &quot;{{ $slot->label_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো সময় স্লট নেই', 'No time slots yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($slots->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $slots->links() }}</div>
        @endif
    </div>
@endsection
