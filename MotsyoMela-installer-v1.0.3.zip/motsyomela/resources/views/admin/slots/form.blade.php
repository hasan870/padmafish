@extends('admin.layouts.app')

@section('title', $slot->exists ? tr('ডেলিভারি সময় এডিট', 'Edit delivery time') : tr('নতুন ডেলিভারি সময়', 'New delivery time'))
@section('subtitle', tr('সময় স্লটের বিবরণ', 'Time slot details'))

@section('content')
    <form method="POST" action="{{ $slot->exists ? route('admin.slots.update', $slot) : route('admin.slots.store') }}" class="max-w-xl">
        @csrf
        @if ($slot->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div>
                <label class="form-label">{{ tr('সময়ের বিবরণ', 'Time description') }} <span class="text-rose-400">*</span></label>
                <input type="text" name="label_bn" value="{{ old('label_bn', $slot->label_bn) }}" class="form-input" placeholder="{{ tr('যেমন: সকাল ৮টা - ১১টা (আজকের মর্নিং ড্রাইভ)', 'e.g. 8am - 11am (today morning drive)') }}" required>
                <p class="text-[10px] text-ink3 mt-1">{{ tr('এই লেখাটি চেকআউট ড্রপডাউনে ও অর্ডারে সংরক্ষিত হবে।', 'This text appears in the checkout dropdown and is stored with the order.') }}</p>
                @error('label_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="form-label">{{ tr('ইংরেজি লেবেল', 'English label') }}</label>
                <input type="text" name="label_en" value="{{ old('label_en', $slot->label_en) }}" class="form-input" placeholder="e.g. 8am - 11am (today morning drive)">
                <p class="text-[10px] text-ink3 mt-1">{{ tr('ইংরেজি মোডে চেকআউটে এই লেখাটি দেখানো হবে। খালি রাখলে বাংলা লেখাই ব্যবহার হবে।', 'This label is shown at checkout in English mode. The Bengali label is used when left empty.') }}</p>
                @error('label_en') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                <input type="number" min="0" max="9999" name="sort_order" value="{{ old('sort_order', $slot->sort_order ?? 0) }}" class="form-input">
                @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় সময় চেকআউটে দেখাবে না', 'Inactive time slots are hidden at checkout') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $slot->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.slots.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
