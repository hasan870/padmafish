@extends('admin.layouts.app')

@section('title', $faq->exists ? tr('প্রশ্ন এডিট', 'Edit question') : tr('নতুন প্রশ্ন', 'New question'))
@section('subtitle', tr('প্রশ্ন-উত্তর', 'Question and answer'))

@section('content')
    <form method="POST" action="{{ $faq->exists ? route('admin.faqs.update', $faq) : route('admin.faqs.store') }}" class="max-w-2xl">
        @csrf
        @if ($faq->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div>
                <label class="form-label">{{ tr('প্রশ্ন', 'Question') }} <span class="text-rose-400">*</span></label>
                <input type="text" name="question_bn" value="{{ old('question_bn', $faq->question_bn) }}" class="form-input" placeholder="{{ tr('যেমন: ডেলিভারি চার্জ কত?', 'e.g. What is the delivery charge?') }}" required>
                @error('question_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="form-label">{{ tr('উত্তর', 'Answer') }} <span class="text-rose-400">*</span></label>
                <textarea name="answer_bn" rows="5" maxlength="2000" class="form-input" placeholder="{{ tr('বিস্তারিত উত্তর...', 'Detailed answer...') }}" required>{{ old('answer_bn', $faq->answer_bn) }}</textarea>
                @error('answer_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div class="max-w-[180px]">
                <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                <input type="number" min="0" max="9999" name="sort_order" value="{{ old('sort_order', $faq->sort_order ?? 0) }}" class="form-input">
                @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় প্রশ্ন স্টোরফ্রন্টে দেখাবে না', 'Inactive questions are hidden from the storefront') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $faq->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.faqs.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
