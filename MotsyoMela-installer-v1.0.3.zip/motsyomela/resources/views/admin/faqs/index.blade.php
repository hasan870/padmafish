@extends('admin.layouts.app')

@section('title', tr('সাধারণ প্রশ্ন (FAQ)', 'Frequently asked questions (FAQ)'))
@section('subtitle', tr('স্টোরফ্রন্টের প্রশ্ন-উত্তর সেকশন', 'Storefront question and answer section'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($faqs->total()) }} {{ tr('টি প্রশ্ন', 'questions') }}</p>
        <a href="{{ route('admin.faqs.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন প্রশ্ন', 'New question') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[720px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('প্রশ্ন ও উত্তর', 'Question & answer') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($faqs as $faq)
                        <tr>
                            <td class="max-w-xl">
                                <p class="font-bold text-ink"><i class="fa-solid fa-circle-question text-aqua-400 text-xs mr-2"></i>{{ $faq->question_bn }}</p>
                                <p class="text-[11px] text-ink3 mt-1 line-clamp-2">{{ $faq->answer_bn }}</p>
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($faq->sort_order) }}</td>
                            <td>
                                @if ($faq->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.faqs.edit', $faq) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.faqs.destroy', $faq) }}" class="inline-block" data-confirm="প্রশ্নটি ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="4" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো প্রশ্ন নেই', 'No questions yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($faqs->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $faqs->links() }}</div>
        @endif
    </div>
@endsection
