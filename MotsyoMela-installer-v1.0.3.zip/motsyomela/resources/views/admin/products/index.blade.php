@extends('admin.layouts.app')

@section('title', tr('পণ্য ব্যবস্থাপনা', 'Product management'))
@section('subtitle', tr('মাছের তালিকা, স্টক ও মূল্য নিয়ন্ত্রণ করুন', 'Manage the fish catalog, stock and prices'))

@section('content')
    <div class="flex flex-col lg:flex-row lg:items-center justify-between gap-3 mb-4">
        <form method="GET" action="{{ route('admin.products.index') }}" class="flex flex-wrap items-center gap-2">
            <div class="relative">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-xs"></i>
                <input type="search" name="q" value="{{ $search }}" placeholder="{{ tr('নাম বা উৎস দিয়ে খুঁজুন', 'Search by name or origin') }}"
                       class="form-input !py-2 !pl-8 !text-xs w-52">
            </div>
            <select name="category" class="form-input !py-2 !text-xs w-44">
                <option value="">{{ tr('সব ক্যাটাগরি', 'All categories') }}</option>
                @foreach ($categories as $category)
                    <option value="{{ $category->id }}" @selected($categoryId === $category->id)>{{ $category->name_bn }}</option>
                @endforeach
            </select>
            <button type="submit" class="btn-soft !py-2">{{ tr('ফিল্টার', 'Filter') }}</button>
            @if ($search !== '' || $categoryId > 0)
                <a href="{{ route('admin.products.index') }}" class="btn-soft !py-2" title="{{ tr('রিসেট', 'Reset') }}"><i class="fa-solid fa-rotate-left"></i></a>
            @endif
        </form>
        <a href="{{ route('admin.products.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন পণ্য যোগ করুন', 'Add new product') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[900px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('পণ্য', 'Product') }}</th>
                        <th>{{ tr('ক্যাটাগরি', 'Category') }}</th>
                        <th>{{ tr('সাইজ ও মূল্য', 'Size & price') }}</th>
                        <th class="text-center">{{ tr('স্টক', 'Stock') }}</th>
                        <th>{{ tr('ব্যাজ', 'Badge') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($products as $product)
                        <tr>
                            <td>
                                <div class="flex items-center gap-3">
                                    <img src="{{ $product->image_url }}" alt="{{ $product->name_bn }}" class="w-12 h-12 rounded-xl object-cover border border-line shrink-0">
                                    <div class="min-w-0">
                                        <p class="font-bold text-ink truncate">{{ localized($product->name_bn, $product->name_en) }}</p>
                                        <p class="text-[11px] text-ink3 truncate">{{ $product->name_en }} @if ($product->origin_bn) · {{ $product->origin_bn }} @endif</p>
                                        <p class="text-[10px] text-ink3">{{ tr('স্লাগ', 'Slug') }}: {{ $product->slug }}</p>
                                    </div>
                                </div>
                            </td>
                            <td class="text-[11px] font-semibold text-ink2">{{ $product->category ? localized($product->category->name_bn, $product->category->name_en) : '—' }}</td>
                            <td>
                                <div class="space-y-0.5">
                                    @foreach ($product->sizes as $size)
                                        <p class="text-[11px] text-ink2 flex items-center gap-1.5">
                                            <span class="w-1 h-1 rounded-full bg-aqua-400 shrink-0"></span>
                                            <span class="truncate max-w-[170px]">{{ $size->label_bn }}</span>
                                            <span class="font-bold text-ink shrink-0">{{ bn_money($size->price_per_kg) }}/কেজি</span>
                                        </p>
                                    @endforeach
                                    @if ($product->sizes_count === 0)
                                        <p class="text-[11px] text-rose-400">{{ tr('কোনো সাইজ নেই', 'No sizes') }}</p>
                                    @endif
                                </div>
                            </td>
                            <td class="text-center">
                                @if ($product->is_in_stock)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400"><i class="fa-solid fa-circle-check text-[9px]"></i> {{ tr('স্টকে', 'In stock') }}</span>
                                @else
                                    <span class="badge border-amber-500/30 bg-amber-500/10 text-amber-400"><i class="fa-solid fa-clock text-[9px]"></i> {{ tr('প্রি-অর্ডার', 'Pre-order') }}</span>
                                @endif
                            </td>
                            <td>
                                @if ($product->badge_bn)
                                    <span class="inline-flex text-[10px] font-bold text-white px-2 py-0.5 rounded-md {{ $product->badge_color ?: 'bg-aqua-600' }}">{{ $product->badge_bn }}</span>
                                @else
                                    <span class="text-[11px] text-ink3">—</span>
                                @endif
                                @if ($product->is_featured)
                                    <span class="badge border-gold-500/30 bg-gold-500/10 text-gold-400 ml-1"><i class="fa-solid fa-star text-[8px]"></i></span>
                                @endif
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($product->sort_order) }}</td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.products.edit', $product) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i> {{ tr('এডিট', 'Edit') }}</a>
                                <form method="POST" action="{{ route('admin.products.destroy', $product) }}" class="inline-block" data-confirm="পণ্য &quot;{{ $product->name_bn }}&quot; ডিলিট করা হবে। অর্ডারে ব্যবহৃত থাকলে ডিলিট হবে না। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center py-14 text-ink3 text-sm">
                                <i class="fa-solid fa-fish text-4xl block mb-3 opacity-60"></i>
                                {{ tr('কোনো পণ্য পাওয়া যায়নি', 'No products found') }}
                                <div class="mt-3">
                                    <a href="{{ route('admin.products.create') }}" class="btn-primary !py-2">{{ tr('প্রথম পণ্য যোগ করুন', 'Add your first product') }}</a>
                                </div>
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if ($products->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $products->links() }}</div>
        @endif
    </div>
@endsection
