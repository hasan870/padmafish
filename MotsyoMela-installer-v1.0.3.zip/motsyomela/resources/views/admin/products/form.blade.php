@extends('admin.layouts.app')

@section('title', $product->exists ? tr('পণ্য এডিট করুন', 'Edit product') : tr('নতুন পণ্য যোগ করুন', 'Add new product'))
@section('subtitle', $product->exists ? localized($product->name_bn, $product->name_en) : tr('মৎস্যমেলার ক্যাটালগে নতুন মাছ যোগ করুন', 'Add a new fish to the MotsyoMela catalog'))

@section('content')
    @php
        $oldSizes = old('sizes');
        if (is_array($oldSizes)) {
            $sizeRows = array_values($oldSizes);
        } elseif ($product->exists) {
            $sizeRows = $product->sizes->map(fn ($size) => ['label_bn' => $size->label_bn, 'price_per_kg' => (float) $size->price_per_kg])->all();
        } else {
            $sizeRows = [['label_bn' => '', 'price_per_kg' => '']];
        }
        if ($sizeRows === []) {
            $sizeRows = [['label_bn' => '', 'price_per_kg' => '']];
        }

        $badgeColors = [
            'bg-red-500' => 'লাল',
            'bg-rose-500' => 'রোজ',
            'bg-gold-500' => 'সোনালি',
            'bg-amber-500' => 'অ্যাম্বার',
            'bg-emerald-500' => 'সবুজ',
            'bg-sky-500' => 'আকাশি',
            'bg-aqua-600' => 'অ্যাকুয়া',
            'bg-violet-500' => 'ভায়োলেট',
            'bg-slate-600' => 'স্লেট',
        ];
    @endphp

    <form id="product-form" method="POST"
          action="{{ $product->exists ? route('admin.products.update', $product) : route('admin.products.store') }}"
          enctype="multipart/form-data" class="grid grid-cols-1 xl:grid-cols-3 gap-4">
        @csrf
        @if ($product->exists)
            @method('PUT')
        @endif

        <div class="xl:col-span-2 space-y-4">
            <div class="glass rounded-2xl p-5">
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2">
                    <i class="fa-solid fa-circle-info text-aqua-400"></i> {{ tr('মূল তথ্য', 'Basic information') }}
                </h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label">{{ tr('বাংলা নাম', 'Bengali name') }} <span class="text-rose-400">*</span> <span class="text-ink3 font-medium">(Name Bn)</span></label>
                        <input type="text" name="name_bn" value="{{ old('name_bn', $product->name_bn) }}" class="form-input" placeholder="{{ tr('যেমন: পদ্মার ইলিশ মাছ', 'e.g. Padma hilsa fish') }}" required>
                        @error('name_bn') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('ইংরেজি নাম', 'English name') }} <span class="text-ink3 font-medium">(Name En)</span></label>
                        <input type="text" name="name_en" value="{{ old('name_en', $product->name_en) }}" class="form-input" placeholder="Padma Hilsa Fish">
                        @error('name_en') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('ক্যাটাগরি', 'Category') }} <span class="text-rose-400">*</span></label>
                        <select name="category_id" class="form-input" required>
                            <option value="">{{ tr('নির্বাচন করুন', 'Select') }}</option>
                            @foreach ($categories as $category)
                                <option value="{{ $category->id }}" @selected((int) old('category_id', $product->category_id) === $category->id)>{{ localized($category->name_bn, $category->name_en) }} ({{ $category->slug }})</option>
                            @endforeach
                        </select>
                        @error('category_id') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('স্লাগ', 'Slug') }} <span class="text-ink3 font-medium">(URL Slug)</span></label>
                        <input type="text" name="slug" value="{{ old('slug', $product->slug) }}" class="form-input" placeholder="padma-hilsa-fish">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('খালি রাখলে স্বয়ংক্রিয়ভাবে তৈরি হবে।', 'Generated automatically when left empty.') }}</p>
                        @error('slug') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('উৎস', 'Origin') }} <span class="text-ink3 font-medium">(Origin)</span></label>
                        <input type="text" name="origin_bn" value="{{ old('origin_bn', $product->origin_bn) }}" class="form-input" placeholder="{{ tr('পদ্মা নদী, চাঁদপুর', 'Padma river, Chandpur') }}">
                        @error('origin_bn') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('ক্রম', 'Order') }} <span class="text-ink3 font-medium">(Sort order)</span></label>
                        <input type="number" name="sort_order" value="{{ old('sort_order', $product->sort_order ?? 0) }}" min="0" max="9999" class="form-input" placeholder="0">
                        @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('বিবরণ', 'Description') }} <span class="text-ink3 font-medium">(Description)</span></label>
                        <textarea name="description_bn" rows="3" maxlength="1000" class="form-input" placeholder="{{ tr('পণ্যের সংক্ষিপ্ত বিবরণ...', 'Short product description...') }}">{{ old('description_bn', $product->description_bn) }}</textarea>
                        @error('description_bn') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('ব্যাজ টেক্সট', 'Badge text') }} <span class="text-ink3 font-medium">(Badge)</span></label>
                        <input type="text" name="badge_bn" value="{{ old('badge_bn', $product->badge_bn) }}" class="form-input" placeholder="{{ tr('যেমন: বেস্ট সেলার', 'e.g. Best seller') }}">
                        @error('badge_bn') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('ব্যাজ রঙ', 'Badge colour') }} <span class="text-ink3 font-medium">(Badge color)</span></label>
                        @php $currentBadge = old('badge_color', $product->badge_color); @endphp
                        <select name="badge_color" class="form-input">
                            <option value="">{{ tr('ডিফল্ট (অ্যাকুয়া)', 'Default (aqua)') }}</option>
                            @foreach ($badgeColors as $value => $label)
                                <option value="{{ $value }}" @selected($currentBadge === $value)>{{ $label }} — {{ $value }}</option>
                            @endforeach
                            @if ($currentBadge && ! array_key_exists($currentBadge, $badgeColors))
                                <option value="{{ $currentBadge }}" selected>{{ tr('কাস্টম', 'Custom') }} — {{ $currentBadge }}</option>
                            @endif
                        </select>
                        @error('badge_color') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between mb-4">
                    <div>
                        <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-ruler-combined text-aqua-400"></i> {{ tr('সাইজ ও মূল্য', 'Sizes & prices') }}</h3>
                        <p class="text-[11px] text-ink3 mt-0.5">{{ tr('প্রতি কেজির মূল্যসহ একাধিক সাইজ যোগ করুন', 'Add multiple sizes with a price per kg') }}</p>
                    </div>
                    <button type="button" onclick="addSizeRow()" class="btn-soft !py-2"><i class="fa-solid fa-plus"></i> {{ tr('সাইজ যোগ', 'Add size') }}</button>
                </div>

                @error('sizes') <p class="form-error mb-2">{{ $message }}</p> @enderror

                <div id="sizes-container" class="space-y-2.5">
                    @foreach ($sizeRows as $i => $row)
                        <div class="size-row flex items-start gap-2">
                            <div class="flex-1">
                                <input type="text" name="sizes[{{ $i }}][label_bn]" value="{{ $row['label_bn'] ?? '' }}" class="form-input" placeholder="{{ tr('সাইজের নাম (যেমন: ৮০০ গ্রাম - ৯০০ গ্রাম)', 'Size label (e.g. 800g - 900g)') }}" required>
                                @error("sizes.$i.label_bn") <p class="form-error">{{ $message }}</p> @enderror
                            </div>
                            <div class="w-40">
                                <div class="relative">
                                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-sm font-bold">৳</span>
                                    <input type="number" step="0.01" min="0.01" name="sizes[{{ $i }}][price_per_kg]" value="{{ $row['price_per_kg'] ?? '' }}" class="form-input !pl-8" placeholder="{{ tr('প্রতি কেজি', 'Per kg') }}" required>
                                </div>
                                @error("sizes.$i.price_per_kg") <p class="form-error">{{ $message }}</p> @enderror
                            </div>
                            <button type="button" onclick="removeSizeRow(this)" class="btn-danger !px-3 !py-2.5 shrink-0" title="{{ tr('সাইজ মুছুন', 'Remove size') }}"><i class="fa-solid fa-xmark"></i></button>
                        </div>
                    @endforeach
                </div>
            </div>
        </div>

        <div class="space-y-4">
            <div class="glass rounded-2xl p-5">
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-image text-aqua-400"></i> {{ tr('পণ্যের ছবি', 'Product image') }}</h3>
                <div class="aspect-[4/3] rounded-xl overflow-hidden border border-line bg-card2 mb-3">
                    <img id="image-preview" src="{{ $product->image ? $product->image_url : 'https://placehold.co/600x450/0d192c/5eead4?text=Fish+Image' }}"
                         alt="{{ tr('পণ্যের ছবি', 'Product image') }}" class="w-full h-full object-cover">
                </div>
                <input type="file" id="image" name="image" accept="image/jpeg,image/png,image/webp"
                       class="block w-full text-xs text-ink3 file:mr-3 file:py-2 file:px-3 file:rounded-lg file:border-0 file:text-xs file:font-bold file:bg-aqua-500/15 file:text-aqua-400 hover:file:bg-aqua-500/25 cursor-pointer"
                       onchange="previewProductImage(this)">
                @error('image') <p class="form-error">{{ $message }}</p> @enderror
                <p class="text-[10px] text-ink3 mt-2">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ২ মেগাবাইট · নতুন ছবি দিলে পুরোনোটি প্রতিস্থাপিত হবে।', 'JPG, PNG or WebP · max 2MB · a new image replaces the old one.') }}</p>
            </div>

            <div class="glass rounded-2xl p-5 space-y-4">
                <h3 class="font-extrabold text-ink text-sm flex items-center gap-2"><i class="fa-solid fa-sliders text-aqua-400"></i> {{ tr('স্ট্যাটাস', 'Status') }}</h3>

                <input type="hidden" name="is_in_stock" value="0">
                <label class="flex items-center justify-between gap-3 cursor-pointer">
                    <span>
                        <span class="block text-xs font-bold text-ink">{{ tr('স্টকে আছে', 'In stock') }} <span class="text-ink3 font-medium">(In stock)</span></span>
                        <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('বন্ধ থাকলে প্রি-অর্ডার হিসেবে দেখাবে', 'Shows as pre-order when off') }}</span>
                    </span>
                    <span class="switch">
                        <input type="checkbox" name="is_in_stock" value="1" @checked(old('is_in_stock', $product->is_in_stock))>
                        <span class="track"></span>
                    </span>
                </label>

                <input type="hidden" name="is_featured" value="0">
                <label class="flex items-center justify-between gap-3 cursor-pointer">
                    <span>
                        <span class="block text-xs font-bold text-ink">{{ tr('ফিচার্ড পণ্য', 'Featured product') }} <span class="text-ink3 font-medium">(Featured)</span></span>
                        <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('হোমপেজে বিশেষভাবে হাইলাইট করুন', 'Highlight it on the homepage') }}</span>
                    </span>
                    <span class="switch">
                        <input type="checkbox" name="is_featured" value="1" @checked(old('is_featured', $product->is_featured))>
                        <span class="track"></span>
                    </span>
                </label>
            </div>

            <div class="glass rounded-2xl p-5">
                <button type="submit" class="btn-primary w-full">
                    <i class="fa-solid fa-floppy-disk"></i> {{ $product->exists ? tr('পরিবর্তন সংরক্ষণ করুন', 'Save changes') : tr('পণ্য যোগ করুন', 'Add product') }}
                </button>
                <a href="{{ route('admin.products.index') }}" class="btn-soft w-full justify-center mt-2">{{ tr('বাতিল করুন', 'Cancel') }}</a>
            </div>

            @if ($product->exists)
                <div class="glass rounded-2xl p-5 border border-rose-500/20">
                    <h3 class="font-extrabold text-rose-400 text-xs mb-2 flex items-center gap-2"><i class="fa-solid fa-triangle-exclamation"></i> {{ tr('ডেঞ্জার জোন', 'Danger zone') }}</h3>
                    <p class="text-[10px] text-ink3 mb-3">{{ tr('অর্ডারে ব্যবহৃত পণ্য ডিলিট করা যাবে না। প্রয়োজনে স্টক বন্ধ করুন।', 'Products used in orders cannot be deleted. Turn off stock instead.') }}</p>
                    {{-- The delete form lives outside this form (HTML forbids nested forms). --}}
                    <button type="submit" form="product-delete-form" class="btn-danger w-full justify-center"><i class="fa-solid fa-trash-can"></i> {{ tr('পণ্য ডিলিট করুন', 'Delete product') }}</button>
                </div>
            @endif
        </div>
    </form>

    @if ($product->exists)
        <form id="product-delete-form" method="POST" action="{{ route('admin.products.destroy', $product) }}" class="hidden"
              data-confirm="পণ্য &quot;{{ $product->name_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
            @csrf
            @method('DELETE')
        </form>
    @endif

    <template id="size-row-template">
        <div class="size-row flex items-start gap-2">
            <div class="flex-1">
                <input type="text" name="sizes[__INDEX__][label_bn]" class="form-input" placeholder="{{ tr('সাইজের নাম (যেমন: ৮০০ গ্রাম - ৯০০ গ্রাম)', 'Size label (e.g. 800g - 900g)') }}" required>
            </div>
            <div class="w-40">
                <div class="relative">
                    <span class="absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-sm font-bold">৳</span>
                    <input type="number" step="0.01" min="0.01" name="sizes[__INDEX__][price_per_kg]" class="form-input !pl-8" placeholder="{{ tr('প্রতি কেজি', 'Per kg') }}" required>
                </div>
            </div>
            <button type="button" onclick="removeSizeRow(this)" class="btn-danger !px-3 !py-2.5 shrink-0" title="সাইজ মুছুন"><i class="fa-solid fa-xmark"></i></button>
        </div>
    </template>
@endsection

@push('scripts')
    <script>
        function previewProductImage(input) {
            if (!input.files || !input.files[0]) return;
            const preview = document.getElementById('image-preview');
            preview.src = URL.createObjectURL(input.files[0]);
        }

        function reindexSizeRows() {
            document.querySelectorAll('#sizes-container .size-row').forEach(function (row, index) {
                row.querySelectorAll('input').forEach(function (input) {
                    input.name = input.name.replace(/sizes\[\d+\]/, 'sizes[' + index + ']');
                });
            });
        }

        function addSizeRow() {
            const template = document.getElementById('size-row-template');
            const container = document.getElementById('sizes-container');
            const html = template.innerHTML.replace(/__INDEX__/g, container.children.length);
            container.insertAdjacentHTML('beforeend', html);
            reindexSizeRows();
        }

        function removeSizeRow(button) {
            const container = document.getElementById('sizes-container');
            if (container.children.length <= 1) {
                return;
            }
            button.closest('.size-row').remove();
            reindexSizeRows();
        }
    </script>
@endpush
