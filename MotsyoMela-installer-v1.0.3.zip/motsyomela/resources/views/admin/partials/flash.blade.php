@if (session('status'))
    <div data-auto-dismiss class="mb-5 glass rounded-2xl border-emerald-500/30 px-4 py-3 flex items-start gap-3">
        <i class="fa-solid fa-circle-check text-emerald-400 mt-0.5"></i>
        <p class="text-sm text-ink font-semibold">{{ session('status') }}</p>
    </div>
@endif

@if (session('error'))
    <div data-auto-dismiss class="mb-5 glass rounded-2xl border-rose-500/30 px-4 py-3 flex items-start gap-3">
        <i class="fa-solid fa-circle-exclamation text-rose-400 mt-0.5"></i>
        <p class="text-sm text-ink font-semibold">{{ session('error') }}</p>
    </div>
@endif

@if ($errors->any())
    <div class="mb-5 glass rounded-2xl border-rose-500/30 px-4 py-3">
        <div class="flex items-start gap-3">
            <i class="fa-solid fa-triangle-exclamation text-rose-400 mt-0.5"></i>
            <div>
                <p class="text-sm text-ink font-bold">{{ tr('কিছু তথ্য সঠিক নয়। অনুগ্রহ করে আবার যাচাই করুন।', 'Some details are not valid. Please check again.') }}</p>
                <ul class="mt-1.5 space-y-1 list-disc list-inside">
                    @foreach ($errors->all() as $error)
                        <li class="text-xs text-rose-400/90">{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        </div>
    </div>
@endif
