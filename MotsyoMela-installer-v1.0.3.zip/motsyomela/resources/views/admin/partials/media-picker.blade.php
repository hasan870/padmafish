@php
    $modalId = $key.'-library';
@endphp

<div class="mt-2">
    <input type="hidden" name="{{ $key }}_pick" id="{{ $key }}-pick" value="{{ old($key.'_pick') }}">

    <div class="flex flex-wrap items-center gap-x-3 gap-y-2">
        <button type="button" data-library-open="{{ $modalId }}" class="btn-soft !py-1.5 !px-3 text-[11px]">
            <i class="fa-solid fa-folder-open text-gold-400"></i> {{ tr('স্টোরেজ থেকে বাছুন', 'Pick from storage') }}
        </button>
        <span id="{{ $key }}-pick-note" class="hidden items-center gap-1.5 text-[10px] text-aqua-400">
            <i class="fa-solid fa-check"></i>
            <span id="{{ $key }}-pick-name" class="font-mono"></span>
            <button type="button" data-library-clear="{{ $key }}" class="text-rose-400 hover:text-rose-300" title="{{ tr('বাছাই বাতিল', 'Clear selection') }}">
                <i class="fa-solid fa-xmark"></i>
            </button>
        </span>
        <span class="text-[10px] text-ink3">{{ tr('বা উপরে নতুন ফাইল আপলোড করুন', 'or upload a new file above') }}</span>
    </div>

    <div id="{{ $modalId }}" class="fixed inset-0 z-[75] hidden items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" data-library-close="{{ $modalId }}"></div>
        <div class="relative glass-strong rounded-3xl w-full max-w-4xl max-h-[85vh] flex flex-col overflow-hidden">
            <div class="flex items-start justify-between gap-3 px-5 py-4 border-b border-line/70">
                <div>
                    <h3 class="font-extrabold text-ink text-sm">{{ $label }}</h3>
                    <p class="text-[10px] text-ink3 mt-0.5">{{ tr('আগে আপলোড করা ফাইল বাছুন — আবার আপলোড করতে হবে না।', 'Pick a file you already uploaded — no need to upload it again.') }}</p>
                </div>
                <button type="button" data-library-close="{{ $modalId }}" class="btn-soft !px-2.5 !py-1.5">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div class="overflow-y-auto p-4">
                @if ($files === [])
                    <div class="text-center py-10">
                        <i class="fa-regular fa-folder-open text-3xl text-ink3"></i>
                        <p class="text-xs text-ink2 mt-3">{{ tr('স্টোরেজে এখনো কোনো ফাইল নেই। উপরে আপলোড করলে সেটিও এখানে দেখা যাবে।', 'No files in storage yet. Anything you upload above also shows up here.') }}</p>
                    </div>
                @else
                    <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-3">
                        @foreach ($files as $file)
                            <button type="button"
                                    data-library-file="{{ $file['path'] }}"
                                    data-library-url="{{ $file['url'] }}"
                                    data-library-name="{{ $file['name'] }}"
                                    data-library-target="{{ $key }}"
                                    class="group text-left rounded-xl border border-line/70 bg-card2/50 overflow-hidden hover:border-aqua-500/60 hover:-translate-y-0.5 transition-all">
                                <div class="aspect-[4/3] bg-card2 flex items-center justify-center overflow-hidden">
                                    @if ($kind === 'image')
                                        <img src="{{ $file['url'] }}" alt="{{ $file['name'] }}" loading="lazy" class="w-full h-full object-cover group-hover:scale-105 transition-transform">
                                    @else
                                        <i class="fa-solid fa-circle-play text-3xl text-aqua-400"></i>
                                    @endif
                                </div>
                                <div class="p-2">
                                    <p class="text-[10px] font-bold text-ink truncate" title="{{ $file['path'] }}">{{ $file['name'] }}</p>
                                    <p class="text-[9px] text-ink3 truncate">
                                        @if ($file['folder'] !== '')
                                            <i class="fa-regular fa-folder mr-0.5"></i>{{ $file['folder'] }} ·
                                        @endif
                                        {{ $file['size'] }}
                                    </p>
                                </div>
                            </button>
                        @endforeach
                    </div>
                @endif
            </div>
        </div>
    </div>
</div>
