@extends('admin.layouts.app')

@section('title', tr('কাস্টমার রিভিউ', 'Customer reviews'))
@section('subtitle', tr('স্টোরফ্রন্টের টেস্টিমোনিয়াল', 'Storefront testimonials'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($testimonials->total()) }} {{ tr('টি রিভিউ', 'reviews') }}</p>
        <a href="{{ route('admin.testimonials.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন রিভিউ', 'New review') }}</a>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
        @forelse ($testimonials as $testimonial)
            <div class="glass rounded-2xl p-5 flex flex-col">
                <div class="flex items-start justify-between gap-2">
                    <div class="flex items-center gap-3">
                        <span class="w-10 h-10 rounded-xl bg-gradient-to-br from-aqua-500 to-sky-600 text-white flex items-center justify-center font-bold text-sm">{{ $testimonial->initials }}</span>
                        <div>
                            <p class="font-bold text-ink text-sm">{{ $testimonial->customer_name_bn }}</p>
                            <p class="text-[11px] text-ink3">{{ $testimonial->location_bn }}</p>
                            @if ($testimonial->order_number)
                                <span class="badge border-sky-500/30 bg-sky-500/10 text-sky-400 mt-1">
                                    <i class="fa-solid fa-user-check text-[9px]"></i> কাস্টমার জমা · {{ $testimonial->order_number }}
                                </span>
                            @endif
                        </div>
                    </div>
                    @if ($testimonial->is_active)
                        <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                    @else
                        <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                    @endif
                </div>
                <div class="text-gold-400 text-xs mt-3">
                    @for ($i = 1; $i <= 5; $i++)
                        <i class="fa-{{ $i <= $testimonial->rating ? 'solid' : 'regular' }} fa-star"></i>
                    @endfor
                </div>
                <p class="text-xs text-ink2 mt-2 flex-1 leading-relaxed line-clamp-4">“{{ $testimonial->quote_bn }}”</p>
                <div class="flex items-center gap-2 mt-4 pt-3 border-t border-line/60">
                    <a href="{{ route('admin.testimonials.edit', $testimonial) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px] flex-1 justify-center"><i class="fa-solid fa-pen"></i> {{ tr('এডিট', 'Edit') }}</a>
                    <form method="POST" action="{{ route('admin.testimonials.destroy', $testimonial) }}" data-confirm="রিভিউটি ডিলিট করা হবে। নিশ্চিত?">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                    </form>
                </div>
            </div>
        @empty
            <div class="glass rounded-2xl p-10 text-center text-ink3 text-sm md:col-span-2 xl:col-span-3">{{ tr('কোনো রিভিউ নেই', 'No reviews yet') }}</div>
        @endforelse
    </div>

    @if ($testimonials->hasPages())
        <div class="mt-4 glass rounded-2xl px-4 py-3">{{ $testimonials->links() }}</div>
    @endif
@endsection
