@extends('admin.layouts.app')

@section('title', $testimonial->exists ? tr('রিভিউ এডিট', 'Edit review') : tr('নতুন রিভিউ', 'New review'))
@section('subtitle', tr('কাস্টমার টেস্টিমোনিয়াল', 'Customer testimonial'))

@section('content')
    <form method="POST" action="{{ $testimonial->exists ? route('admin.testimonials.update', $testimonial) : route('admin.testimonials.store') }}" class="max-w-2xl">
        @csrf
        @if ($testimonial->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('কাস্টমারের নাম', 'Customer name') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="customer_name_bn" value="{{ old('customer_name_bn', $testimonial->customer_name_bn) }}" class="form-input" placeholder="{{ tr('নাম', 'Name') }}" required>
                    @error('customer_name_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('এলাকা', 'Location') }}</label>
                    <input type="text" name="location_bn" value="{{ old('location_bn', $testimonial->location_bn) }}" class="form-input" placeholder="{{ tr('যেমন: ধানমন্ডি, ঢাকা', 'e.g. Dhanmondi, Dhaka') }}">
                    @error('location_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('রেটিং', 'Rating') }} <span class="text-rose-400">*</span></label>
                    <select name="rating" class="form-input" required>
                        @for ($i = 5; $i >= 1; $i--)
                            <option value="{{ $i }}" @selected((int) old('rating', $testimonial->rating) === $i)>{{ bn_num($i) }} {{ tr('স্টার', 'stars') }}</option>
                        @endfor
                    </select>
                    @error('rating') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('অ্যাভাটার ইনিশিয়াল', 'Avatar initials') }}</label>
                    <input type="text" name="initial_bn" value="{{ old('initial_bn', $testimonial->initial_bn) }}" class="form-input" placeholder="{{ tr('যেমন: নআ', 'e.g. NA') }}" maxlength="5">
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('খালি রাখলে নাম থেকে তৈরি হবে।', 'Generated from the name when left empty.') }}</p>
                    @error('initial_bn') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>
            <div>
                <label class="form-label">{{ tr('রিভিউ', 'Review') }} <span class="text-rose-400">*</span></label>
                <textarea name="quote_bn" rows="4" maxlength="1000" class="form-input" placeholder="{{ tr('কাস্টমারের মন্তব্য...', 'Customer comment...') }}" required>{{ old('quote_bn', $testimonial->quote_bn) }}</textarea>
                @error('quote_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় রিভিউ স্টোরফ্রন্টে দেখাবে না', 'Inactive reviews are hidden from the storefront') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $testimonial->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.testimonials.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
