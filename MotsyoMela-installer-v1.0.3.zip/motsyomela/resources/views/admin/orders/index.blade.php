@extends('admin.layouts.app')

@section('title', tr('অর্ডার ব্যবস্থাপনা', 'Order management'))
@section('subtitle', tr('সব অর্ডার দেখুন, ফিল্টার করুন ও স্ট্যাটাস পরিবর্তন করুন', 'View, filter and update all orders'))

@section('content')
    @php
        $statusTabs = [
            '' => tr('সব', 'All'),
            'pending' => tr('অপেক্ষমাণ', 'Pending'),
            'confirmed' => tr('নিশ্চিত', 'Confirmed'),
            'delivering' => tr('ডেলিভারিতে', 'Out for delivery'),
            'delivered' => tr('সম্পন্ন', 'Delivered'),
            'cancelled' => tr('বাতিল', 'Cancelled'),
        ];
        $totalAll = $statusCounts->sum();
    @endphp

    <div class="glass rounded-2xl p-4 mb-4">
        <div class="flex flex-col lg:flex-row lg:items-center gap-3 justify-between">
            <div class="flex items-center gap-1.5 overflow-x-auto pb-1 lg:pb-0">
                @foreach ($statusTabs as $key => $label)
                    <a href="{{ route('admin.orders.index', array_filter(['status' => $key, 'q' => $search])) }}"
                       class="badge border whitespace-nowrap !px-3 !py-2 {{ $status === $key ? 'bg-aqua-500/15 text-aqua-400 border-aqua-500/40' : 'bg-card2/60 text-ink2 border-line hover:text-ink' }}">
                        {{ $label }}
                        <span class="text-[10px] opacity-70">{{ bn_num($key === '' ? $totalAll : ($statusCounts[$key] ?? 0)) }}</span>
                    </a>
                @endforeach
            </div>

            <form method="GET" action="{{ route('admin.orders.index') }}" class="flex items-center gap-2">
                @if ($status !== '')
                    <input type="hidden" name="status" value="{{ $status }}">
                @endif
                <div class="relative">
                    <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-xs"></i>
                    <input type="search" name="q" value="{{ $search }}" placeholder="{{ tr('অর্ডার নং / ফোন / নাম', 'Order no. / phone / name') }}"
                           class="form-input !py-2 !pl-8 !text-xs w-56">
                </div>
                <button type="submit" class="btn-soft !py-2">{{ tr('খুঁজুন', 'Search') }}</button>
                @if ($search !== '' || $status !== '')
                    <a href="{{ route('admin.orders.index') }}" class="btn-soft !py-2" title="{{ tr('ফিল্টার রিসেট', 'Reset filters') }}"><i class="fa-solid fa-rotate-left"></i></a>
                @endif
            </form>
        </div>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[860px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('অর্ডার', 'Order') }}</th>
                        <th>{{ tr('কাস্টমার', 'Customer') }}</th>
                        <th>{{ tr('এলাকা', 'Zone') }}</th>
                        <th class="text-center">{{ tr('আইটেম', 'Items') }}</th>
                        <th class="text-right">{{ tr('মোট', 'Total') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th>{{ tr('সময়', 'Time') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($orders as $order)
                        <tr>
                            <td>
                                <a href="{{ route('admin.orders.show', $order) }}" class="font-bold text-aqua-400 hover:underline">{{ $order->order_number }}</a>
                                <p class="text-[10px] text-ink3">{{ $order->paymentLabelBn() }}</p>
                            </td>
                            <td>
                                <p class="font-bold text-ink">{{ $order->customer_name }}</p>
                                <p class="text-[11px] text-ink3">{{ $order->customer_phone }}</p>
                            </td>
                            <td class="text-[11px] text-ink2">{{ $order->zone ? localized($order->zone->name_bn, $order->zone->name_en) : '—' }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($order->items_count) }}</td>
                            <td class="text-right font-black text-ink">{{ bn_money($order->grand_total) }}</td>
                            <td><span class="badge {{ order_status_classes($order->status) }}">{{ $order->statusLabelBn() }}</span></td>
                            <td class="text-[11px] text-ink3">{{ bn_num($order->created_at->format('d/m/Y h:i A')) }}</td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.orders.show', $order) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-eye"></i> {{ tr('বিস্তারিত', 'Details') }}</a>
                                <form method="POST" action="{{ route('admin.orders.destroy', $order) }}" class="inline-block" data-confirm="অর্ডার {{ $order->order_number }} এবং এর সব আইটেম স্থায়ীভাবে ডিলিট হয়ে যাবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]" title="{{ tr('অর্ডার ডিলিট', 'Delete order') }}"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="8" class="text-center py-14 text-ink3 text-sm">
                                <i class="fa-solid fa-inbox text-4xl block mb-3 opacity-60"></i>
                                {{ tr('কোনো অর্ডার পাওয়া যায়নি', 'No orders found') }}
                                @if ($search !== '' || $status !== '')
                                    <p class="text-[11px] mt-1">{{ tr('অন্য কিছু দিয়ে খুঁজে দেখুন অথবা ফিল্টার রিসেট করুন।', 'Try a different search or reset the filters.') }}</p>
                                @endif
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>

        @if ($orders->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $orders->links() }}</div>
        @endif
    </div>
@endsection
