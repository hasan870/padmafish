@extends('admin.layouts.app')

@section('title', tr('অর্ডার', 'Order').' '.$order->order_number)
@section('subtitle', tr('অর্ডারের সম্পূর্ণ বিবরণ ও ব্যবস্থাপনা', 'Full order details and management'))

@section('content')
    @php
        $nextStatus = $order->nextStatus();
        $nextLabel = match ($nextStatus) {
            'confirmed' => tr('নিশ্চিত', 'Confirmed'),
            'delivering' => tr('ডেলিভারিতে', 'Out for delivery'),
            'delivered' => tr('সম্পন্ন', 'Delivered'),
            default => null,
        };
        $paymentStatuses = [
            'unpaid' => tr('অপরিশোধিত', 'Unpaid'),
            'pending' => tr('যাচাইয়ের অপেক্ষায়', 'Awaiting verification'),
            'paid' => tr('পরিশোধিত', 'Paid'),
            'refunded' => tr('ফেরত দেওয়া হয়েছে', 'Refunded'),
        ];
    @endphp
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5">
        <div class="flex items-center gap-3">
            <a href="{{ route('admin.orders.index') }}" class="btn-soft !px-3 !py-2"><i class="fa-solid fa-arrow-left"></i></a>
            <div>
                <div class="flex items-center gap-2 flex-wrap">
                    <h2 class="text-lg font-extrabold text-ink">{{ $order->order_number }}</h2>
                    <span class="badge {{ order_status_classes($order->status) }}">{{ $order->statusLabelBn() }}</span>
                    <span class="badge {{ payment_status_classes($order->payment_status) }}">{{ $order->paymentStatusLabelBn() }}</span>
                </div>
                <p class="text-[11px] text-ink3 mt-0.5">অর্ডার সময়: {{ bn_num($order->created_at->format('d/m/Y, h:i A')) }}</p>
            </div>
        </div>
        <div class="flex items-center gap-2 flex-wrap">
            @if ($customerWhatsappLink)
                <a href="{{ $customerWhatsappLink }}" target="_blank" rel="noopener" class="btn-soft !text-emerald-400" title="কাস্টমারের নম্বরে ইনভয়েস সারসংক্ষেপ ও রিভিউ লিংক সহ হোয়াটসঅ্যাপ বার্তা তৈরি হবে">
                    <i class="fa-brands fa-whatsapp"></i> {{ tr('ইনভয়েস + রিভিউ পাঠান', 'Send invoice + review') }}
                </a>
            @elseif ($whatsappLink)
                <a href="{{ $whatsappLink }}" target="_blank" rel="noopener" class="btn-soft !text-emerald-400">
                    <i class="fa-brands fa-whatsapp"></i> {{ tr('হোয়াটসঅ্যাপ চ্যাট', 'WhatsApp chat') }}
                </a>
            @endif
            <a href="{{ route('admin.orders.invoice', $order) }}" target="_blank" class="btn-soft"><i class="fa-solid fa-print"></i> {{ tr('ইনভয়েস প্রিন্ট', 'Print invoice') }}</a>
            <form method="POST" action="{{ route('admin.orders.destroy', $order) }}" data-confirm="অর্ডার {{ $order->order_number }} এবং এর সব আইটেম স্থায়ীভাবে ডিলিট হয়ে যাবে। নিশ্চিত?">
                @csrf
                @method('DELETE')
                <button type="submit" class="btn-danger"><i class="fa-solid fa-trash-can"></i> {{ tr('অর্ডার ডিলিট', 'Delete order') }}</button>
            </form>
            @if ($nextStatus)
                <form method="POST" action="{{ route('admin.orders.status', $order) }}" data-confirm="অর্ডারটি পরবর্তী ধাপে ({{ $nextLabel }}) নিয়ে যাওয়া হবে। নিশ্চিত?">
                    @csrf
                    @method('PATCH')
                    <button type="submit" class="btn-primary">
                        <i class="fa-solid fa-arrow-right"></i>
                        {{ tr('পরবর্তী ধাপ:', 'Next step:') }} {{ $nextLabel }}
                    </button>
                </form>
            @endif
        </div>
    </div>

    @if ($order->status === 'cancelled')
        <div class="mb-4 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 flex items-start gap-3">
            <i class="fa-solid fa-ban text-rose-400 mt-0.5"></i>
            <div>
                <p class="text-sm font-bold text-rose-400">{{ tr('অর্ডারটি বাতিল করা হয়েছে', 'This order has been cancelled') }}</p>
                @if ($order->cancel_reason)
                    <p class="text-xs text-ink2 mt-1">{{ tr('কারণ:', 'Reason:') }} {{ $order->cancel_reason }}</p>
                @endif
            </div>
        </div>
    @endif

    @if ($order->status !== 'cancelled')
        @php
            $steps = ['pending' => tr('অপেক্ষমাণ', 'Pending'), 'confirmed' => tr('নিশ্চিত', 'Confirmed'), 'delivering' => tr('ডেলিভারিতে', 'Out for delivery'), 'delivered' => tr('সম্পন্ন', 'Delivered')];
            $currentIndex = array_search($order->status, array_keys($steps), true);
        @endphp
        <div class="glass rounded-2xl p-4 mb-4">
            <div class="flex items-center">
                @foreach ($steps as $key => $label)
                    @php $idx = $loop->index; @endphp
                    <div class="flex-1 flex items-center {{ $loop->last ? '' : '' }}">
                        <div class="flex flex-col items-center gap-1.5 shrink-0">
                            <span class="w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold border-2 {{ $idx <= $currentIndex ? 'bg-gradient-to-br from-aqua-500 to-sky-600 text-white border-transparent' : 'bg-card2 text-ink3 border-line' }}">
                                @if ($idx < $currentIndex)
                                    <i class="fa-solid fa-check"></i>
                                @else
                                    {{ bn_num($idx + 1) }}
                                @endif
                            </span>
                            <span class="text-[10px] font-bold {{ $idx <= $currentIndex ? 'text-ink' : 'text-ink3' }}">{{ $label }}</span>
                        </div>
                        @if (! $loop->last)
                            <div class="flex-1 h-0.5 mx-2 mb-5 rounded-full {{ $idx < $currentIndex ? 'bg-aqua-500' : 'bg-line' }}"></div>
                        @endif
                    </div>
                @endforeach
            </div>
        </div>
    @endif

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div class="xl:col-span-2 space-y-4">
            <div class="glass rounded-2xl overflow-hidden">
                <div class="px-5 py-4 border-b border-line/70 flex items-center justify-between">
                    <h3 class="font-extrabold text-ink text-sm">{{ tr('অর্ডারকৃত পণ্য', 'Ordered items') }}</h3>
                    <span class="badge border-line bg-card2 text-ink2">{{ bn_num($order->items->count()) }} {{ tr('টি লাইন আইটেম', 'line items') }}</span>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full admin-table min-w-[620px]">
                        <thead class="bg-card2/40">
                            <tr>
                                <th>{{ tr('পণ্য', 'Product') }}</th>
                                <th>{{ tr('সাইজ / বিবরণ', 'Size / details') }}</th>
                                <th class="text-right">{{ tr('ওজন / প্যাক', 'Weight / pack') }}</th>
                                <th class="text-right">{{ tr('একক মূল্য', 'Unit price') }}</th>
                                <th class="text-right">{{ tr('মোট', 'Total') }}</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($order->items as $item)
                                <tr class="{{ $item->is_combo ? 'bg-gold-500/5' : '' }}">
                                    <td>
                                        <div class="flex items-start gap-2">
                                            @if ($item->is_combo)
                                                <span class="w-7 h-7 rounded-lg bg-gold-500/15 text-gold-400 flex items-center justify-center text-xs shrink-0"><i class="fa-solid fa-gift"></i></span>
                                            @else
                                                <span class="w-7 h-7 rounded-lg bg-aqua-500/10 text-aqua-400 flex items-center justify-center text-xs shrink-0"><i class="fa-solid fa-fish"></i></span>
                                            @endif
                                            <div>
                                                <p class="font-bold text-ink text-[13px]">{{ $item->name_snapshot_bn }}</p>
                                                @if ($item->product)
                                                    <a href="{{ route('admin.products.edit', $item->product) }}" class="text-[10px] text-aqua-400 hover:underline">{{ tr('পণ্য দেখুন', 'View product') }}</a>
                                                @endif
                                            </div>
                                        </div>
                                    </td>
                                    <td class="text-[11px] text-ink2">{{ $item->size_label_snapshot }}</td>
                                    <td class="text-right text-[11px] font-semibold text-ink2">
                                        @if ($item->is_combo)
                                            {{ bn_num($item->weight_kg) }} {{ tr('প্যাক', 'pack') }}
                                        @else
                                            {{ bn_kg($item->weight_kg) }}
                                        @endif
                                    </td>
                                    <td class="text-right text-ink2">{{ bn_money($item->unit_price) }}</td>
                                    <td class="text-right font-black text-ink">{{ bn_money($item->line_total) }}</td>
                                </tr>
                                @if ($item->is_combo && is_array($item->combo_meta))
                                    @php $comboMetaItems = $item->combo_meta['items'] ?? $item->combo_meta; @endphp
                                    @if (! empty($comboMetaItems))
                                        <tr>
                                            <td colspan="5" class="!pt-0 !pb-3">
                                                <div class="ml-9 rounded-xl border border-gold-500/20 bg-gold-500/5 p-3">
                                                    <p class="text-[10px] font-bold text-gold-400 mb-2"><i class="fa-solid fa-list-check mr-1"></i>{{ tr('কম্বো প্যাকেজের মাছসমূহ', 'Fish in this combo pack') }}</p>
                                                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                                        @foreach ($comboMetaItems as $meta)
                                                            <div class="flex items-center justify-between gap-2 text-[11px]">
                                                                <span class="text-ink2 truncate">{{ $meta['name_bn'] ?? '' }} <span class="text-ink3">({{ $meta['size_label'] ?? '' }})</span></span>
                                                                <span class="shrink-0 text-ink3">{{ bn_kg($meta['weight_kg'] ?? 0) }} · {{ bn_money($meta['line_total'] ?? 0) }}</span>
                                                            </div>
                                                        @endforeach
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    @endif
                                @endif
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <h3 class="font-extrabold text-ink text-sm mb-4">{{ tr('পেমেন্ট সারসংক্ষেপ', 'Payment summary') }}</h3>
                <div class="space-y-2.5 text-sm max-w-md ml-auto">
                    <div class="flex items-center justify-between">
                        <span class="text-ink2">{{ tr('সাবটোটাল', 'Subtotal') }}</span>
                        <span class="font-bold text-ink">{{ bn_money($order->subtotal) }}</span>
                    </div>
                    @if ((float) $order->discount_amount > 0)
                        <div class="flex items-center justify-between">
                            <span class="text-ink2">{{ tr('কুপন ছাড়', 'Coupon discount') }} @if ($order->coupon_code) <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400 !py-0">{{ $order->coupon_code }}</span> @endif</span>
                            <span class="font-bold text-emerald-400">− {{ bn_money($order->discount_amount) }}</span>
                        </div>
                    @endif
                    <div class="flex items-center justify-between">
                        <span class="text-ink2">{{ tr('ডেলিভারি চার্জ', 'Delivery charge') }} {{ $order->zone ? '('.localized($order->zone->name_bn, $order->zone->name_en).')' : '' }}</span>
                        <span class="font-bold text-ink">{{ bn_money($order->delivery_fee) }}</span>
                    </div>
                    <div class="flex items-center justify-between border-t border-line/70 pt-3">
                        <span class="font-extrabold text-ink">{{ tr('সর্বমোট', 'Grand total') }}</span>
                        <span class="font-black text-aqua-400 text-xl">{{ bn_money($order->grand_total) }}</span>
                    </div>
                    @if ((float) $order->combo_discount_amount > 0)
                        <p class="text-[10px] text-gold-400 text-right pt-1"><i class="fa-solid fa-gift mr-1"></i>{{ tr('কম্বো ছাড়', 'Combo discount') }} {{ bn_money($order->combo_discount_amount) }} {{ tr('সাবটোটালে ইতিমধ্যে প্রয়োগ করা আছে।', 'is already applied to the subtotal.') }}</p>
                    @endif
                </div>
            </div>
        </div>

        <div class="space-y-4">
            <div class="glass rounded-2xl p-5">
                <div class="flex items-center gap-2 mb-4">
                    <span class="w-8 h-8 rounded-lg bg-aqua-500/15 text-aqua-400 flex items-center justify-center text-sm"><i class="fa-solid fa-user"></i></span>
                    <h3 class="font-extrabold text-ink text-sm">{{ tr('কাস্টমার তথ্য', 'Customer details') }}</h3>
                </div>
                <div class="space-y-3 text-sm">
                    <div>
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('নাম', 'Name') }}</p>
                        <p class="font-bold text-ink">{{ $order->customer_name }}</p>
                    </div>
                    <div>
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('মোবাইল', 'Mobile') }}</p>
                        <a href="tel:{{ $order->customer_phone }}" class="font-bold text-aqua-400">{{ $order->customer_phone }}</a>
                    </div>
                    @if ($order->customer_email)
                        <div>
                            <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('ইমেইল', 'Email') }}</p>
                            <a href="mailto:{{ $order->customer_email }}" class="font-semibold text-aqua-400 break-all">{{ $order->customer_email }}</a>
                        </div>
                    @endif
                    <div>
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('ঠিকানা', 'Address') }}</p>
                        <p class="text-ink2 leading-relaxed">{{ $order->customer_address }}</p>
                    </div>
                    @if ($customerWhatsappLink)
                        <a href="{{ $customerWhatsappLink }}" target="_blank" rel="noopener" class="inline-flex items-center justify-center gap-2 w-full rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 px-3 py-2 text-xs font-bold hover:bg-emerald-500/25 transition-colors">
                            <i class="fa-brands fa-whatsapp text-sm"></i> {{ tr('কাস্টমারকে ইনভয়েস + রিভিউ লিংক পাঠান', 'Send invoice + review link to customer') }}
                        </a>
                    @endif

                    <div class="rounded-xl border border-line bg-card2/40 px-3 py-2.5">
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('রিভিউ', 'Review') }}</p>
                        @if ($review)
                            <p class="text-[11px] font-semibold text-ink2 mt-1">
                                <span class="text-gold-400">{{ str_repeat('★', (int) $review->rating) }}</span>
                                {{ $review->is_active ? tr('স্টোরফ্রন্টে প্রকাশিত', 'Published on the storefront') : tr('অনুমোদনের অপেক্ষায়', 'Awaiting approval') }}
                            </p>
                            <a href="{{ route('admin.testimonials.edit', $review) }}" class="text-[10px] font-bold text-aqua-400 hover:underline">{{ tr('রিভিউ দেখুন', 'View review') }}</a>
                        @elseif ($reviewUrl)
                            <p class="text-[11px] text-ink3 mt-1">{{ tr('এখনো জমা পড়েনি।', 'Not submitted yet.') }}</p>
                            <a href="{{ $reviewUrl }}" target="_blank" rel="noopener" class="text-[10px] font-bold text-aqua-400 hover:underline break-all">{{ tr('রিভিউ লিংক পরীক্ষা করুন', 'Test the review link') }}</a>
                        @else
                            <p class="text-[11px] text-ink3 mt-1">{{ tr('রিভিউ সংগ্রহ বন্ধ রয়েছে।', 'Review collection is turned off.') }}</p>
                        @endif
                    </div>
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center gap-2 mb-4">
                    <span class="w-8 h-8 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center text-sm"><i class="fa-solid fa-truck-fast"></i></span>
                    <h3 class="font-extrabold text-ink text-sm">{{ tr('ডেলিভারি তথ্য', 'Delivery details') }}</h3>
                </div>
                <div class="space-y-3 text-sm">
                    <div>
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('এলাকা', 'Zone') }}</p>
                        <p class="font-bold text-ink">{{ $order->zone ? localized($order->zone->name_bn, $order->zone->name_en) : '—' }}</p>
                    </div>
                    <div>
                        <p class="text-[10px] uppercase tracking-wide text-ink3 font-bold">{{ tr('ডেলিভারি সময়', 'Delivery time') }}</p>
                        <p class="font-semibold text-ink2">{{ $order->timeSlotLabel() }}</p>
                    </div>
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between gap-2 mb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-8 h-8 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center text-sm"><i class="fa-solid fa-wallet"></i></span>
                        <h3 class="font-extrabold text-ink text-sm">{{ tr('পেমেন্ট তথ্য', 'Payment details') }}</h3>
                    </div>
                    <span class="badge {{ payment_status_classes($order->payment_status) }}">{{ $order->paymentStatusLabelBn() }}</span>
                </div>
                <div class="space-y-3 text-sm">
                    <div class="flex items-center justify-between gap-2">
                        <span class="text-[11px] text-ink3 font-semibold">{{ tr('মেথড', 'Method') }}</span>
                        <span class="font-bold text-ink">{{ $order->paymentLabelBn() }}</span>
                    </div>
                    <div class="flex items-center justify-between gap-2">
                        <span class="text-[11px] text-ink3 font-semibold">{{ tr('পরিমাণ', 'Amount') }}</span>
                        <span class="font-black text-aqua-400">{{ bn_money($order->grand_total) }}</span>
                    </div>
                    @if ($order->payment_reference)
                        <div class="flex items-center justify-between gap-2">
                            <span class="text-[11px] text-ink3 font-semibold">{{ tr('রেফারেন্স', 'Reference') }}</span>
                            <span class="font-semibold text-ink2 break-all text-right">{{ $order->payment_reference }}</span>
                        </div>
                    @endif
                </div>
                <form method="POST" action="{{ route('admin.orders.payment', $order) }}" class="mt-4 pt-4 border-t border-line/70 space-y-2">
                    @csrf
                    @method('PATCH')
                    <label for="payment_status" class="form-label">{{ tr('পেমেন্ট স্ট্যাটাস', 'Payment status') }}</label>
                    <select id="payment_status" name="payment_status" class="form-input">
                        @foreach ($paymentStatuses as $value => $label)
                            <option value="{{ $value }}" @selected(old('payment_status', $order->payment_status) === $value)>{{ $label }}</option>
                        @endforeach
                    </select>
                    <label for="payment_reference" class="form-label">{{ tr('ট্রানজেকশন / রেফারেন্স', 'Transaction / reference') }}</label>
                    <input id="payment_reference" name="payment_reference" type="text" class="form-input" value="{{ old('payment_reference', $order->payment_reference) }}" placeholder="যেমন: TRX9F2K71" maxlength="100">
                    @error('payment_status') <p class="form-error">{{ $message }}</p> @enderror
                    @error('payment_reference') <p class="form-error">{{ $message }}</p> @enderror
                    <button type="submit" class="btn-primary w-full justify-center"><i class="fa-solid fa-check-double"></i> {{ tr('পেমেন্ট আপডেট করুন', 'Update payment') }}</button>
                </form>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center gap-2 mb-3">
                    <span class="w-8 h-8 rounded-lg bg-violet-500/15 text-violet-400 flex items-center justify-center text-sm"><i class="fa-solid fa-envelope"></i></span>
                    <h3 class="font-extrabold text-ink text-sm">{{ tr('ইনভয়েস ইমেইল', 'Invoice email') }}</h3>
                </div>
                <p class="text-[11px] text-ink3 mb-3">{{ tr('কাস্টমারকে অর্ডার ইনভয়েস ও পেমেন্ট নির্দেশনা ইমেইলে পাঠান।', 'Email the order invoice and payment instructions to the customer.') }}</p>
                <form method="POST" action="{{ route('admin.orders.email', $order) }}" class="space-y-2">
                    @csrf
                    <label for="invoice_email" class="form-label">{{ tr('ইমেইল ঠিকানা', 'Email address') }}</label>
                    <input id="invoice_email" name="email" type="email" class="form-input" value="{{ old('email', $order->customer_email) }}" placeholder="customer@example.com" maxlength="150" required>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                    <button type="submit" class="btn-soft w-full justify-center"><i class="fa-solid fa-paper-plane"></i> {{ tr('ইনভয়েস পাঠান', 'Send invoice') }}</button>
                </form>
            </div>

            @if (! in_array($order->status, ['delivered', 'cancelled'], true))
                <div class="glass rounded-2xl p-5 border border-rose-500/20">
                    <details>
                        <summary class="cursor-pointer text-sm font-bold text-rose-400 flex items-center gap-2 select-none">
                            <i class="fa-solid fa-ban"></i> {{ tr('অর্ডার বাতিল করুন', 'Cancel order') }}
                        </summary>
                        <form method="POST" action="{{ route('admin.orders.cancel', $order) }}" class="mt-3 space-y-2" data-confirm="অর্ডারটি স্থায়ীভাবে বাতিল করা হবে। আপনি কি নিশ্চিত?">
                            @csrf
                            @method('PATCH')
                            <label for="cancel_reason" class="form-label">{{ tr('বাতিলের কারণ', 'Cancellation reason') }} <span class="text-rose-400">*</span></label>
                            <textarea id="cancel_reason" name="cancel_reason" rows="3" class="form-input" placeholder="{{ tr('যেমন: কাস্টমার ফোনে অর্ডার বাতিল করেছেন', 'e.g. customer cancelled the order by phone') }}" required>{{ old('cancel_reason') }}</textarea>
                            @error('cancel_reason') <p class="form-error">{{ $message }}</p> @enderror
                            <button type="submit" class="btn-danger w-full justify-center"><i class="fa-solid fa-ban"></i> {{ tr('অর্ডার বাতিল নিশ্চিত করুন', 'Confirm order cancellation') }}</button>
                        </form>
                    </details>
                </div>
            @endif
        </div>
    </div>
@endsection
