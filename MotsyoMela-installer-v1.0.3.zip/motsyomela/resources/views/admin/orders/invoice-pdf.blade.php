<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title>ইনভয়েস {{ $order->order_number }}</title>
    <style>
        @font-face {
            font-family: 'HindSiliguri';
            font-style: normal;
            font-weight: normal;
            src: url("{{ $fontRegular }}") format("truetype");
        }
        @font-face {
            font-family: 'HindSiliguri';
            font-style: normal;
            font-weight: bold;
            src: url("{{ $fontBold }}") format("truetype");
        }
        @page { margin: 24px 26px; }
        * { box-sizing: border-box; }
        body { font-family: 'HindSiliguri', sans-serif; font-size: 11px; color: #0b1c2a; margin: 0; }
        .head { width: 100%; border-bottom: 2px solid #0d9488; padding-bottom: 12px; margin-bottom: 16px; }
        .head td { vertical-align: top; }
        .brand { font-size: 20px; font-weight: bold; color: #075e63; }
        .brand-sub { font-size: 10px; color: #5a7d8a; margin-top: 2px; }
        .inv-label { text-align: right; font-size: 15px; font-weight: bold; letter-spacing: 1px; color: #0f766e; }
        .inv-meta { text-align: right; font-size: 10px; color: #47616f; margin-top: 3px; }
        .logo { width: 42px; height: 42px; margin-right: 8px; }
        table.panels { width: 100%; margin-bottom: 14px; }
        table.panels td { width: 50%; vertical-align: top; }
        .panel { border: 1px solid #d9e8ee; border-radius: 6px; padding: 9px 11px; background: #f8fcfd; margin-right: 8px; }
        .panel.right { margin-right: 0; margin-left: 8px; }
        .panel h3 { font-size: 9px; letter-spacing: .6px; color: #5a7d8a; margin: 0 0 5px; text-transform: uppercase; font-weight: bold; }
        .panel .name { font-size: 12px; font-weight: bold; color: #08222e; }
        .panel p { margin: 2px 0; font-size: 10px; color: #33525f; line-height: 1.55; }
        .row-line { font-size: 10px; color: #33525f; margin: 2px 0; }
        .row-line .k { color: #5a7d8a; }
        table.items { width: 100%; border-collapse: collapse; margin-bottom: 12px; }
        table.items th { background: #eef7f9; color: #4d7080; font-size: 9px; text-transform: uppercase; letter-spacing: .4px; padding: 6px 7px; text-align: left; border-bottom: 1px solid #cfe1e8; }
        table.items td { padding: 7px; border-bottom: 1px solid #e5eff3; font-size: 10px; vertical-align: top; color: #12333f; }
        table.items td.num, table.items th.num { text-align: right; }
        .pname { font-weight: bold; color: #0a2531; font-size: 10.5px; }
        .pmeta { font-size: 9px; color: #6b8893; }
        .combo { margin-top: 4px; border-left: 2px solid #d5a017; background: #fffaf0; padding: 4px 6px; }
        .combo .t { font-size: 8px; font-weight: bold; color: #a17308; text-transform: uppercase; letter-spacing: .4px; }
        .combo .l { font-size: 9px; color: #5c5334; padding: 1px 0; }
        table.totals { width: 260px; margin-left: auto; border-collapse: collapse; }
        table.totals td { padding: 4px 0; font-size: 10px; color: #33525f; }
        table.totals td.amt { text-align: right; white-space: nowrap; }
        table.totals tr.grand td { border-top: 1px solid #0d9488; padding-top: 7px; font-size: 13px; font-weight: bold; color: #08222e; }
        table.totals tr.grand td.amt { color: #0d9488; }
        .note { font-size: 9px; color: #9a7b1f; text-align: right; margin-top: 5px; }
        .foot { border-top: 1px dashed #cfe1e8; margin-top: 18px; padding-top: 10px; }
        .foot td { vertical-align: bottom; font-size: 9.5px; color: #5a7d8a; line-height: 1.6; }
        .thanks { font-size: 10.5px; color: #33525f; }
        .thanks strong { color: #0d9488; }
        .stamp { display: inline-block; margin-top: 4px; font-size: 8px; font-weight: bold; letter-spacing: .4px; padding: 2px 6px; border: 1px solid #b9d6d3; color: #0f766e; background: #effbf9; }
        table.qr-pay { width: 100%; margin-top: 14px; border: 1px dashed #b9d6d3; background: #effbf9; padding: 9px 11px; }
        table.qr-pay td { vertical-align: middle; }
        .qr-pay img { width: 86px; height: 86px; background: #fff; border: 1px solid #cfe1e8; padding: 3px; }
        .qr-pay .t { font-size: 11px; font-weight: bold; color: #0f766e; }
        .qr-pay .d { font-size: 9.5px; color: #33525f; line-height: 1.6; margin-top: 2px; }
    </style>
</head>
<body>
    @php
        $siteName = $settings['site_name'] ?? 'মৎস্যমেলা';
        $siteTagline = $settings['site_tagline'] ?? '১০০% কেমিশ্যাল ও ফরমালিন মুক্ত তাজা মাছ';
    @endphp

    <table class="head">
        <tr>
            <td>
                <table>
                    <tr>
                        @if ($logoData)
                            <td><img src="{{ $logoData }}" class="logo" alt="{{ $siteName }}"></td>
                        @endif
                        <td>
                            <div class="brand">{{ $siteName }}</div>
                            <div class="brand-sub">{{ $siteTagline }}</div>
                        </td>
                    </tr>
                </table>
            </td>
            <td>
                <div class="inv-label">ইনভয়েস</div>
                <div class="inv-meta">{{ $order->order_number }}</div>
                <div class="inv-meta">{{ bn_num($order->created_at->format('d/m/Y, h:i A')) }}</div>
            </td>
        </tr>
    </table>

    <table class="panels">
        <tr>
            <td>
                <div class="panel">
                    <h3>কাস্টমার তথ্য</h3>
                    <div class="name">{{ $order->customer_name }}</div>
                    <p>{{ $order->customer_address }}</p>
                    <p>মোবাইল: {{ bn_num($order->customer_phone) }}</p>
                    @if ($order->customer_email)
                        <p>ইমেইল: {{ $order->customer_email }}</p>
                    @endif
                </div>
            </td>
            <td>
                <div class="panel right">
                    <h3>ডেলিভারি ও পেমেন্ট</h3>
                    <div class="row-line"><span class="k">এলাকা:</span> {{ $order->zone?->name_bn ?? '—' }}</div>
                    <div class="row-line"><span class="k">ডেলিভারি সময়:</span> {{ $order->time_slot_label }}</div>
                    <div class="row-line"><span class="k">পেমেন্ট:</span> {{ $order->paymentLabelBn() }}</div>
                    <div class="row-line"><span class="k">পেমেন্ট স্ট্যাটাস:</span> {{ $order->paymentStatusLabelBn() }}</div>
                    @if ($order->payment_reference)
                        <div class="row-line"><span class="k">রেফারেন্স:</span> {{ $order->payment_reference }}</div>
                    @endif
                    <div class="row-line"><span class="k">অর্ডার স্ট্যাটাস:</span> {{ $order->statusLabelBn() }}</div>
                </div>
            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
            <tr>
                <th style="width: 42%;">পণ্য</th>
                <th>সাইজ / বিবরণ</th>
                <th class="num">পরিমাণ</th>
                <th class="num">একক মূল্য</th>
                <th class="num">মোট</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($order->items as $item)
                <tr>
                    <td>
                        <div class="pname">{{ $item->name_snapshot_bn }}</div>
                        @if ($item->is_combo && is_array($item->combo_meta))
                            @php $comboMetaItems = $item->combo_meta['items'] ?? $item->combo_meta; @endphp
                            @if (! empty($comboMetaItems))
                                <div class="combo">
                                    <div class="t">কম্বো প্যাকেজের মাছসমূহ</div>
                                    @foreach ($comboMetaItems as $meta)
                                        <div class="l">{{ $meta['name_bn'] ?? '' }} ({{ $meta['size_label'] ?? '' }}) — {{ bn_kg($meta['weight_kg'] ?? 0) }}</div>
                                    @endforeach
                                </div>
                            @endif
                        @endif
                    </td>
                    <td class="pmeta">{{ $item->size_label_snapshot }}</td>
                    <td class="num">{{ $item->is_combo ? bn_num($item->weight_kg).' প্যাক' : bn_kg($item->weight_kg) }}</td>
                    <td class="num">{{ bn_money($item->unit_price) }}</td>
                    <td class="num">{{ bn_money($item->line_total) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <table class="totals">
        <tr>
            <td>সাবটোটাল</td>
            <td class="amt">{{ bn_money($order->subtotal) }}</td>
        </tr>
        @if ((float) $order->discount_amount > 0)
            <tr>
                <td>কুপন ছাড়{{ $order->coupon_code ? ' ('.$order->coupon_code.')' : '' }}</td>
                <td class="amt">− {{ bn_money($order->discount_amount) }}</td>
            </tr>
        @endif
        <tr>
            <td>ডেলিভারি চার্জ</td>
            <td class="amt">{{ bn_money($order->delivery_fee) }}</td>
        </tr>
        <tr class="grand">
            <td>সর্বমোট</td>
            <td class="amt">{{ bn_money($order->grand_total) }}</td>
        </tr>
    </table>

    @if ((float) $order->combo_discount_amount > 0)
        <div class="note">* কম্বো প্যাকেজে {{ bn_money($order->combo_discount_amount) }} ছাড় সাবটোটালের মধ্যে অন্তর্ভুক্ত।</div>
    @endif

    @if (! empty($qrData))
        <table class="qr-pay">
            <tr>
                <td style="width: 96px;"><img src="{{ $qrData }}" alt="bKash QR কোড"></td>
                <td>
                    <div class="t">bKash QR স্ক্যান করে পেমেন্ট করুন</div>
                    <div class="d">ডেলিভারির সময় ক্যাশ অন ডেলিভারি অর্ডারের পেমেন্ট এই QR কোড স্ক্যান করে bKash-এ করতে পারেন।</div>
                    @if (! empty($settings['payment_bkash_number']))
                        <div class="d">বিকাশ নম্বর: {{ $settings['payment_bkash_number'] }}</div>
                    @endif
                </td>
            </tr>
        </table>
    @endif

    <table class="foot" width="100%">
        <tr>
            <td>
                <div class="thanks">{{ $siteName }}-এর সাথে থাকার জন্য ধন্যবাদ! <strong>তাজা মাছ, সুস্থ জীবন।</strong></div>
                <span class="stamp">{{ $order->statusLabelBn() }} · {{ $order->paymentLabelBn() }} · {{ $order->paymentStatusLabelBn() }}</span>
            </td>
            <td style="text-align: right;">
                হটলাইন: {{ bn_num($settings['site_phone'] ?? '16234') }}<br>
                ডেলিভারি সময়: {{ $settings['delivery_hours'] ?? '' }}<br>
                @if (! empty($settings['whatsapp_number']))
                    হোয়াটসঅ্যাপ: {{ bn_num($settings['whatsapp_number']) }}<br>
                @endif
                {{ $settings['site_name'] ?? 'MotsyoMela' }}
            </td>
        </tr>
    </table>
</body>
</html>
