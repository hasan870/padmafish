<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    @php
        $siteName = $settings['site_name'] ?? 'মৎস্যমেলা';
        $siteTagline = $settings['site_tagline'] ?? '১০০% কেমিক্যাল ও ফরমালিন মুক্ত তাজা মাছ';
        $logoUrl = ! empty($settings['theme_logo']) ? \Illuminate\Support\Facades\Storage::url($settings['theme_logo']) : null;
    @endphp
    <title>ইনভয়েস {{ $order->order_number }} | {{ $siteName }}</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Hind Siliguri', sans-serif; background: #eef4f7; color: #0b1c2a; padding: 24px; font-size: 13px; }
        .toolbar { max-width: 800px; margin: 0 auto 14px; display: flex; align-items: center; justify-content: space-between; gap: 10px; }
        .toolbar a, .toolbar button { font-family: inherit; font-size: 13px; font-weight: 700; padding: 9px 16px; border-radius: 10px; border: 1px solid #cbdde5; background: #fff; color: #0b5e63; cursor: pointer; text-decoration: none; }
        .toolbar button { background: #0d9488; color: #fff; border-color: #0d9488; }
        .invoice { max-width: 800px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 12px 34px -18px rgba(9, 60, 73, .35); }
        .inv-head { display: flex; justify-content: space-between; gap: 20px; padding: 28px 32px; background: linear-gradient(120deg, #053b3c, #075e63 55%, #0b7c86); color: #eafffd; }
        .brand { display: flex; align-items: center; gap: 12px; }
        .brand-mark { width: 46px; height: 46px; border-radius: 13px; background: rgba(255,255,255,.14); border: 1px solid rgba(255,255,255,.28); display: flex; align-items: center; justify-content: center; font-size: 22px; overflow: hidden; }
        .brand-mark img { width: 100%; height: 100%; object-fit: contain; padding: 4px; }
        .brand h1 { font-size: 22px; letter-spacing: .5px; }
        .brand p { font-size: 11px; opacity: .82; margin-top: 1px; }
        .inv-title { text-align: right; }
        .inv-title h2 { font-size: 20px; letter-spacing: 1px; text-transform: uppercase; opacity: .92; }
        .inv-title .no { font-size: 15px; font-weight: 700; margin-top: 4px; }
        .inv-title .date { font-size: 11px; opacity: .8; margin-top: 2px; }
        .inv-body { padding: 26px 32px 30px; }
        .meta-grid { display: grid; grid-template-columns: 1.15fr 1fr; gap: 16px; margin-bottom: 20px; }
        .panel { border: 1px solid #d9e8ee; border-radius: 12px; padding: 14px 16px; background: #f8fcfd; }
        .panel h3 { font-size: 10px; text-transform: uppercase; letter-spacing: .8px; color: #5a7d8a; margin-bottom: 8px; }
        .panel .name { font-size: 15px; font-weight: 700; color: #08222e; }
        .panel p { font-size: 12px; color: #33525f; line-height: 1.65; }
        .panel .row { display: flex; justify-content: space-between; gap: 10px; font-size: 12px; padding: 2.5px 0; }
        .panel .row span:first-child { color: #5a7d8a; }
        .panel .row span:last-child { font-weight: 600; color: #12333f; text-align: right; }
        table.items { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
        table.items th { background: #f1f8fa; color: #4d7080; font-size: 10px; text-transform: uppercase; letter-spacing: .5px; padding: 9px 10px; text-align: left; border-bottom: 2px solid #d7e6ec; }
        table.items td { padding: 10px; border-bottom: 1px solid #e5eff3; font-size: 12px; vertical-align: top; }
        table.items th.num, table.items td.num { text-align: right; white-space: nowrap; }
        .product-name { font-weight: 700; color: #0a2531; }
        .product-meta { font-size: 10px; color: #6b8893; margin-top: 2px; }
        .combo-box { margin-top: 7px; border-left: 3px solid #d5a017; background: #fffaf0; padding: 6px 9px; border-radius: 0 7px 7px 0; }
        .combo-box .combo-title { font-size: 9px; font-weight: 700; color: #a17308; text-transform: uppercase; letter-spacing: .5px; margin-bottom: 3px; }
        .combo-box .combo-line { display: flex; justify-content: space-between; gap: 10px; font-size: 10px; color: #5c5334; padding: 1px 0; }
        .totals { margin-left: auto; width: 300px; }
        .totals .row { display: flex; justify-content: space-between; padding: 6px 0; font-size: 12px; color: #33525f; }
        .totals .row.discount { color: #0f766e; font-weight: 600; }
        .totals .row.grand { border-top: 2px solid #0d9488; margin-top: 5px; padding-top: 10px; font-size: 17px; font-weight: 700; color: #08222e; }
        .totals .row.grand span:last-child { color: #0d9488; }
        .note { margin-top: 12px; font-size: 10px; color: #9a7b1f; text-align: right; }
        .inv-foot { border-top: 1px dashed #cfe1e8; margin-top: 26px; padding-top: 14px; display: flex; justify-content: space-between; align-items: flex-end; gap: 20px; }
        .inv-foot .thanks { font-size: 12px; color: #33525f; }
        .inv-foot .thanks strong { color: #0d9488; }
        .inv-foot .contact { text-align: right; font-size: 10.5px; color: #5a7d8a; line-height: 1.7; }
        .stamp { display: inline-block; margin-top: 6px; font-size: 9px; font-weight: 700; text-transform: uppercase; letter-spacing: .6px; padding: 3px 8px; border-radius: 5px; border: 1px solid #b9d6d3; color: #0f766e; background: #effbf9; }
        .qr-pay { margin-top: 18px; display: flex; align-items: center; gap: 16px; border: 1px dashed #b9d6d3; background: #effbf9; border-radius: 12px; padding: 12px 16px; }
        .qr-pay img { width: 100px; height: 100px; object-fit: contain; background: #fff; border: 1px solid #cfe1e8; border-radius: 8px; padding: 4px; }
        .qr-pay h4 { font-size: 13px; color: #0f766e; margin-bottom: 4px; }
        .qr-pay p { font-size: 11px; color: #33525f; line-height: 1.6; }
        @page { size: A4; margin: 10mm; }
        @media print {
            body { background: #fff; padding: 0; font-size: 11.5px; }
            .no-print { display: none !important; }
            .invoice { box-shadow: none; border-radius: 0; max-width: 100%; }
            .inv-head { padding: 20px 24px; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
            .inv-body { padding: 18px 24px 20px; }
            .panel, table.items th, .combo-box, .stamp, .qr-pay { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
        }
    </style>
</head>
<body>
    <div class="toolbar no-print">
        <a href="{{ route('admin.orders.show', $order) }}">← অর্ডারে ফিরুন</a>
        <button type="button" onclick="window.print()">প্রিন্ট করুন</button>
    </div>

    <div class="invoice">
        <div class="inv-head">
            <div class="brand">
                <div class="brand-mark">
                    @if ($logoUrl)
                        <img src="{{ $logoUrl }}" alt="{{ $siteName }}">
                    @else
                        🐟
                    @endif
                </div>
                <div>
                    <h1>{{ $siteName }}</h1>
                    <p>{{ $siteTagline }}</p>
                </div>
            </div>
            <div class="inv-title">
                <h2>ইনভয়েস</h2>
                <div class="no">{{ $order->order_number }}</div>
                <div class="date">{{ bn_num($order->created_at->format('d/m/Y, h:i A')) }}</div>
            </div>
        </div>

        <div class="inv-body">
            <div class="meta-grid">
                <div class="panel">
                    <h3>কাস্টমার তথ্য / Billed To</h3>
                    <div class="name">{{ $order->customer_name }}</div>
                    <p>{{ $order->customer_address }}</p>
                    <p>মোবাইল: {{ $order->customer_phone }}</p>
                    @if ($order->customer_email)
                        <p>ইমেইল: {{ $order->customer_email }}</p>
                    @endif
                </div>
                <div class="panel">
                    <h3>ডেলিভারি ও পেমেন্ট</h3>
                    <div class="row"><span>ডেলিভারি এলাকা</span><span>{{ $order->zone?->name_bn ?? '—' }}</span></div>
                    <div class="row"><span>ডেলিভারি সময়</span><span>{{ $order->time_slot_label }}</span></div>
                    <div class="row"><span>পেমেন্ট মেথড</span><span>{{ $order->paymentLabelBn() }}</span></div>
                    <div class="row"><span>পেমেন্ট স্ট্যাটাস</span><span>{{ $order->paymentStatusLabelBn() }}</span></div>
                    @if ($order->payment_reference)
                        <div class="row"><span>পেমেন্ট রেফারেন্স</span><span>{{ $order->payment_reference }}</span></div>
                    @endif
                    <div class="row"><span>অর্ডার স্ট্যাটাস</span><span>{{ $order->statusLabelBn() }}</span></div>
                </div>
            </div>

            <table class="items">
                <thead>
                    <tr>
                        <th style="width: 44%;">পণ্য</th>
                        <th>সাইজ / বিবরণ</th>
                        <th class="num">ওজন</th>
                        <th class="num">একক মূল্য</th>
                        <th class="num">মোট</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($order->items as $item)
                        <tr>
                            <td>
                                <div class="product-name">{{ $item->name_snapshot_bn }}</div>
                                @if ($item->is_combo && is_array($item->combo_meta))
                                    @php $comboMetaItems = $item->combo_meta['items'] ?? $item->combo_meta; @endphp
                                    @if (! empty($comboMetaItems))
                                        <div class="combo-box">
                                            <div class="combo-title">কম্বো প্যাকেজের মাছসমূহ</div>
                                            @foreach ($comboMetaItems as $meta)
                                                <div class="combo-line">
                                                    <span>{{ $meta['name_bn'] ?? '' }} ({{ $meta['size_label'] ?? '' }}) — {{ bn_kg($meta['weight_kg'] ?? 0) }}</span>
                                                    <span>{{ bn_money($meta['line_total'] ?? 0) }}</span>
                                                </div>
                                            @endforeach
                                        </div>
                                    @endif
                                @endif
                            </td>
                            <td>{{ $item->size_label_snapshot }}</td>
                            <td class="num">{{ $item->is_combo ? bn_num($item->weight_kg).' প্যাক' : bn_kg($item->weight_kg) }}</td>
                            <td class="num">{{ bn_money($item->unit_price) }}</td>
                            <td class="num">{{ bn_money($item->line_total) }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>

            <div class="totals">
                <div class="row"><span>সাবটোটাল</span><span>{{ bn_money($order->subtotal) }}</span></div>
                @if ((float) $order->discount_amount > 0)
                    <div class="row discount">
                        <span>কুপন ছাড়{{ $order->coupon_code ? ' ('.$order->coupon_code.')' : '' }}</span>
                        <span>− {{ bn_money($order->discount_amount) }}</span>
                    </div>
                @endif
                <div class="row"><span>ডেলিভারি চার্জ</span><span>{{ bn_money($order->delivery_fee) }}</span></div>
                <div class="row grand"><span>সর্বমোট</span><span>{{ bn_money($order->grand_total) }}</span></div>
            </div>

            @if ((float) $order->combo_discount_amount > 0)
                <p class="note">* কম্বো প্যাকেজে {{ bn_money($order->combo_discount_amount) }} ছাড় সাবটোটালের মধ্যে অন্তর্ভুক্ত।</p>
            @endif

            @php $bkashQrPath = (string) ($settings['payment_bkash_qr'] ?? ''); @endphp
            @if ($bkashQrPath !== '')
                <div class="qr-pay">
                    <img src="{{ \Illuminate\Support\Facades\Storage::url($bkashQrPath) }}" alt="bKash QR কোড">
                    <div>
                        <h4>bKash QR স্ক্যান করে পেমেন্ট করুন</h4>
                        <p>ডেলিভারির সময় ক্যাশ অন ডেলিভারি অর্ডারের পেমেন্ট এই QR কোড স্ক্যান করে bKash-এ করতে পারেন।</p>
                        @if (! empty($settings['payment_bkash_number']))
                            <p>বিকাশ নম্বর: {{ $settings['payment_bkash_number'] }}</p>
                        @endif
                    </div>
                </div>
            @endif

            <div class="inv-foot">
                <div class="thanks">
                    <p>{{ $siteName }}-এর সাথে থাকার জন্য ধন্যবাদ! <strong>তাজা মাছ, সুস্থ জীবন।</strong></p>
                    <span class="stamp">{{ $order->statusLabelBn() }} · {{ $order->paymentLabelBn() }} · {{ $order->paymentStatusLabelBn() }}</span>
                </div>
                <div class="contact">
                    হটলাইন: {{ $settings['site_phone'] ?? '16234' }}<br>
                    ডেলিভারি সময়: {{ $settings['delivery_hours'] ?? 'সকাল ৮টা - রাত ৮টা' }}<br>
                    @if (! empty($settings['whatsapp_number']))
                        হোয়াটসঅ্যাপ: {{ bn_num($settings['whatsapp_number']) }}<br>
                    @endif
                    {{ request()->getHost() }}
                </div>
            </div>
        </div>
    </div>

</body>
</html>
