@extends('admin.layouts.app')

@section('title', tr('ব্যানার বিজ্ঞাপন', 'Banner ads'))
@section('subtitle', tr('কম্বো সেকশনের উপরে দুটি ছবি বা HTML ব্যানার স্লট', 'Two image or HTML banner slots above the combo section'))

@section('content')
    <form method="POST" action="{{ route('admin.banners.update') }}" enctype="multipart/form-data" class="max-w-4xl">
        @csrf
        @method('PUT')

        <div class="mb-4 rounded-2xl border border-sky-500/25 bg-sky-500/5 p-4 flex items-start gap-3">
            <span class="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center text-sm shrink-0"><i class="fa-solid fa-circle-info"></i></span>
            <p class="text-[11px] text-ink2 leading-relaxed">
                {{ tr('এই ব্যানারগুলো হোম পেজে কম্বো প্যাকেজ সেকশনের ঠিক উপরে দেখাবে। সহজ উপায় হলো ছবি আপলোড করা (ঐচ্ছিকভাবে ক্লিক লিংক দিন)।', 'These banners appear on the homepage just above the combo section. Uploading an image (with an optional click link) is the easiest option.') }}
                {{ tr('ছবি না দিয়ে চাইলে নিচের HTML ঘরে নিজের ডিজাইন করা মার্কআপও বসাতে পারেন — ছবি থাকলে সেটিই দেখাবে।', 'You can also put custom markup in the HTML box below; the image takes priority when one is uploaded.') }}
            </p>
        </div>

        <div class="grid grid-cols-1 xl:grid-cols-2 gap-4">
            @foreach ([1, 2] as $slot)
                @php
                    $imageKey = 'banner_slot_'.$slot.'_image';
                    $htmlKey = 'banner_slot_'.$slot.'_html';
                    $linkKey = 'banner_slot_'.$slot.'_link';
                    $activeKey = 'banner_slot_'.$slot.'_active';
                    $imagePath = (string) ($settings[$imageKey] ?? '');
                @endphp
                <div class="glass rounded-2xl p-5 space-y-4">
                    <div class="flex items-start justify-between gap-3">
                        <div class="flex items-center gap-2">
                            <span class="w-9 h-9 rounded-lg bg-aqua-500/15 text-aqua-400 flex items-center justify-center"><i class="fa-solid fa-rectangle-ad"></i></span>
                            <div>
                                <h3 class="font-extrabold text-ink text-sm">{{ tr('ব্যানার স্লট', 'Banner slot') }} {{ bn_num($slot) }}</h3>
                                <p class="text-[10px] text-ink3">{{ tr('কম্বো সেকশনের উপরে দেখাবে', 'Shown above the combo section') }}</p>
                            </div>
                        </div>
                        <label class="switch" aria-label="স্লট {{ bn_num($slot) }} সক্রিয় করুন">
                            <input type="hidden" name="{{ $activeKey }}" value="0">
                            <input type="checkbox" name="{{ $activeKey }}" value="1" @checked(($settings[$activeKey] ?? '0') === '1')>
                            <span class="track"></span>
                        </label>
                    </div>

                    <div>
                        <label class="form-label">{{ tr('ব্যানার ছবি', 'Banner image') }}</label>
                        <div class="rounded-xl border border-line bg-card2/40 overflow-hidden mb-2 aspect-[16/5] flex items-center justify-center">
                            @if ($imagePath !== '')
                                <img src="{{ asset('storage/'.$imagePath) }}" alt="ব্যানার {{ bn_num($slot) }}" class="w-full h-full object-cover">
                            @else                                    <span class="text-[11px] text-ink3"><i class="fa-solid fa-image mr-1"></i> {{ tr('এখনো ছবি আপলোড করা হয়নি', 'No image uploaded yet') }}</span>
                            @endif
                        </div>
                        <input type="file" name="{{ $imageKey }}" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('JPG, PNG বা WebP · সর্বোচ্চ ৩MB · চওড়া ব্যানার (যেমন ১৬০০×৫০০) সবচেয়ে ভালো দেখায়।', 'JPG, PNG or WebP · max 3MB · a wide banner (e.g. 1600×500) looks best.') }}</p>
                        @if ($imagePath !== '')
                            <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                <input type="checkbox" name="{{ $imageKey }}_remove" value="1" class="rounded border-line"> {{ tr('বর্তমান ছবি মুছে ফেলুন', 'Remove current image') }}
                            </label>
                        @endif
                        @error($imageKey) <p class="form-error">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="form-label">{{ tr('ক্লিক লিংক (ঐচ্ছিক)', 'Click link (optional)') }}</label>
                        <input type="url" name="{{ $linkKey }}" value="{{ old($linkKey, $settings[$linkKey] ?? '') }}" class="form-input text-xs font-mono" placeholder="https://example.com/offer">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('ছবিতে ক্লিক করলে এই লিংকটি নতুন ট্যাবে খুলবে।', 'Clicking the image opens this link in a new tab.') }}</p>
                        @error($linkKey) <p class="form-error">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <label class="form-label">{{ tr('অথবা HTML কোড', 'Or HTML code') }}</label>
                        <textarea name="{{ $htmlKey }}" rows="4" class="form-input font-mono !text-[11px] leading-relaxed banner-html-input" data-slot="{{ $slot }}" placeholder="<a href=&quot;https://example.com&quot;><img src=&quot;https://example.com/banner.jpg&quot; alt=&quot;বিশেষ অফার&quot;></a>">{{ old($htmlKey, $settings[$htmlKey] ?? '') }}</textarea>
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('ছবি আপলোড না করলে এই HTML দেখানো হবে। সর্বোচ্চ ৫০০০ অক্ষর।', 'This HTML is shown when no image is uploaded. Max 5000 characters.') }}</p>
                        @error($htmlKey) <p class="form-error">{{ $message }}</p> @enderror
                    </div>

                    <div>
                        <p class="form-label">{{ tr('HTML প্রিভিউ', 'HTML preview') }}</p>
                        <div id="banner-preview-{{ $slot }}" class="rounded-xl border border-dashed border-line bg-card2/40 p-3 min-h-[4.5rem] overflow-hidden text-[11px] text-ink3 banner-preview">
                            @if (trim((string) ($settings[$htmlKey] ?? '')) !== '')
                                {!! $settings[$htmlKey] !!}
                            @else
                                {{ tr('HTML লিখলে এখানে প্রিভিউ দেখাবে।', 'The preview appears here when you write HTML.') }}
                            @endif
                        </div>
                    </div>
                </div>
            @endforeach
        </div>

        <div class="flex items-center gap-2 mt-5">
            <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('ব্যানার সংরক্ষণ করুন', 'Save banners') }}</button>
            <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
        </div>
    </form>
@endsection

@push('head')
    <style>
        .banner-preview img { max-width: 100%; height: auto; border-radius: .75rem; }
        .banner-preview a { display: block; }
    </style>
@endpush

@push('scripts')
    <script>
        document.querySelectorAll('.banner-html-input').forEach(function (input) {
            input.addEventListener('input', function () {
                const preview = document.getElementById('banner-preview-' + input.dataset.slot);
                if (!preview) return;
                const html = input.value.trim();
                preview.innerHTML = html !== '' ? html : @json(tr('HTML লিখলে এখানে প্রিভিউ দেখাবে।', 'The preview appears here when you write HTML.'));
            });
        });
    </script>
@endpush
