    @php $iconPath = (string) ($settings['payment_'.$method.'_icon'] ?? ''); @endphp
    <div class="pt-3 mt-1 border-t border-line/60">
        <label class="form-label">গেটওয়ের আইকন / লোগো (ঐচ্ছিক)</label>
        <div class="flex items-center gap-3">
            <div class="w-14 h-10 rounded-lg bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                @if ($iconPath !== '')
                    <img src="{{ asset('storage/'.$iconPath) }}" alt="আইকন" class="h-full w-full object-contain p-1">
                @else
                    <i class="fa-solid fa-image text-ink3"></i>
                @endif
            </div>
            <div class="flex-1">
                <input type="file" name="payment_{{ $method }}_icon" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                <p class="text-[10px] text-ink3 mt-1">PNG, JPG বা WebP · সর্বোচ্চ ১MB। চেকআউট ও ফুটারে আইকন হিসেবে দেখাবে।</p>
                @if ($iconPath !== '')
                    <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                        <input type="checkbox" name="payment_{{ $method }}_icon_remove" value="1" class="rounded border-line"> বর্তমান আইকন মুছে ফেলুন
                    </label>
                @endif
                @error('payment_'.$method.'_icon') <p class="form-error">{{ $message }}</p> @enderror
            </div>
        </div>
    </div>
