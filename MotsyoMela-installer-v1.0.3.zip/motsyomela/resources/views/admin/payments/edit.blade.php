@extends('admin.layouts.app')

@section('title', tr('পেমেন্ট গেটওয়ে', 'Payment gateway'))
@section('subtitle', tr('বিকাশ, নগদ, কার্ড ও ক্যাশ অন ডেলিভারি কনফিগার করুন', 'Configure bKash, Nagad, card and cash on delivery'))

@section('content')
    <form method="POST" action="{{ route('admin.payments.update') }}" enctype="multipart/form-data" class="max-w-5xl">
        @csrf
        @method('PUT')

        @if ($errors->has('payment_methods'))
            <div class="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-sm text-rose-400">
                <i class="fa-solid fa-triangle-exclamation mr-1"></i> {{ $errors->first('payment_methods') }}
            </div>
        @endif

        <div class="mb-4 rounded-2xl border border-sky-500/25 bg-sky-500/5 p-4 flex items-start gap-3">
            <span class="w-9 h-9 rounded-lg bg-sky-500/15 text-sky-400 flex items-center justify-center text-sm shrink-0"><i class="fa-solid fa-circle-info"></i></span>
            <p class="text-[11px] text-ink2 leading-relaxed">
                {{ tr('পেমেন্ট নম্বর ও নির্দেশনা চেকআউটের পর সফল অর্ডার পপআপে কাস্টমার দেখতে পাবে। পেমেন্ট লিংক দিলে কাস্টমার সরাসরি সেখানে যেতে পারবে। গেটওয়ে API সংযুক্ত না থাকায় পেমেন্ট অ্যাডমিন প্যানেল থেকে যাচাই করে "পরিশোধিত" চিহ্নিত করতে হবে।', 'Customers see the payment number and instructions in the order-success popup after checkout. A payment link takes them straight to the gateway. Since no gateway API is connected, mark payments as paid manually from the admin panel after verification.') }}
            </p>
        </div>

        <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-9 h-9 rounded-lg bg-emerald-500/15 text-emerald-400 flex items-center justify-center"><i class="fa-solid fa-money-bill-wave"></i></span>
                        <div>
                            <h3 class="font-extrabold text-ink text-sm">{{ tr('ক্যাশ অন ডেলিভারি', 'Cash on delivery') }}</h3>
                            <p class="text-[10px] text-ink3">{{ tr('ডেলিভারির সময় নগদ পেমেন্ট', 'Pay cash on delivery') }}</p>
                        </div>
                    </div>
                    <span class="switch">
                        <input type="hidden" name="payment_cod_enabled" value="0">
                        <input type="checkbox" name="payment_cod_enabled" value="1" @checked(($settings['payment_cod_enabled'] ?? '1') === '1')>
                        <span class="track"></span>
                    </span>
                </div>
                <p class="text-[11px] text-ink3 leading-relaxed">{{ tr('সক্রিয় থাকলে কাস্টমার অর্ডার ডেলিভারির সময় নগদ টাকা পরিশোধ করতে পারবে।', 'When enabled, customers can pay cash when the order is delivered.') }}</p>
                @include('admin.payments.partials.icon', ['method' => 'cod'])
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-9 h-9 rounded-lg bg-pink-500/15 text-pink-400 flex items-center justify-center"><i class="fa-solid fa-mobile-screen"></i></span>
                        <div>
                            <h3 class="font-extrabold text-ink text-sm">{{ tr('বিকাশ (bKash)', 'bKash') }}</h3>
                            <p class="text-[10px] text-ink3">{{ tr('মোবাইল ব্যাংকিং', 'Mobile banking') }}</p>
                        </div>
                    </div>
                    <span class="switch">
                        <input type="hidden" name="payment_bkash_enabled" value="0">
                        <input type="checkbox" name="payment_bkash_enabled" value="1" @checked(($settings['payment_bkash_enabled'] ?? '1') === '1')>
                        <span class="track"></span>
                    </span>
                </div>
                <div class="space-y-3">
                    <div>
                        <label class="form-label">{{ tr('বিকাশ নম্বর', 'bKash number') }}</label>
                        <input type="text" name="payment_bkash_number" value="{{ old('payment_bkash_number', $settings['payment_bkash_number'] ?? '') }}" class="form-input" placeholder="01XXXXXXXXX">
                        @error('payment_bkash_number') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('অ্যাকাউন্টের ধরন', 'Account type') }}</label>
                        <select name="payment_bkash_type" class="form-input">
                            <option value="personal" @selected(($settings['payment_bkash_type'] ?? 'personal') === 'personal')>{{ tr('পার্সোনাল', 'Personal') }}</option>
                            <option value="merchant" @selected(($settings['payment_bkash_type'] ?? 'personal') === 'merchant')>{{ tr('মার্চেন্ট', 'Merchant') }}</option>
                        </select>
                        @error('payment_bkash_type') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('পেমেন্ট লিংক (ঐচ্ছিক)', 'Payment link (optional)') }}</label>
                        <input type="url" name="payment_bkash_link" value="{{ old('payment_bkash_link', $settings['payment_bkash_link'] ?? '') }}" class="form-input text-xs" placeholder="https://...">
                        @error('payment_bkash_link') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('কাস্টমারের জন্য নির্দেশনা', 'Instructions for the customer') }}</label>
                        <textarea name="payment_bkash_instructions" rows="3" class="form-input" placeholder="Send Money করার নিয়ম লিখুন">{{ old('payment_bkash_instructions', $settings['payment_bkash_instructions'] ?? '') }}</textarea>
                        @error('payment_bkash_instructions') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    @include('admin.payments.partials.icon', ['method' => 'bkash'])

                    @php $bkashQrPath = (string) ($settings['payment_bkash_qr'] ?? ''); @endphp
                    <div class="pt-3 mt-1 border-t border-line/60">
                        <label class="form-label">bKash QR কোড (ঐচ্ছিক)</label>
                        <div class="flex items-center gap-3">
                            <div class="w-16 h-16 rounded-lg bg-card2 border border-line overflow-hidden flex items-center justify-center shrink-0">
                                @if ($bkashQrPath !== '')
                                    <img src="{{ asset('storage/'.$bkashQrPath) }}" alt="bKash QR" class="w-full h-full object-contain p-1">
                                @else
                                    <i class="fa-solid fa-qrcode text-ink3 text-xl"></i>
                                @endif
                            </div>
                            <div class="flex-1">
                                <input type="file" name="payment_bkash_qr" accept="image/jpeg,image/png,image/webp" class="form-input !py-1.5 text-xs">
                                <p class="text-[10px] text-ink3 mt-1">QR ছবি আপলোড করুন। কাস্টমার ইনভয়েস থেকে স্ক্যান করে ডেলিভারির সময় পেমেন্ট করতে পারবে · সর্বোচ্চ ২MB।</p>
                                @if ($bkashQrPath !== '')
                                    <label class="inline-flex items-center gap-1.5 mt-2 text-[11px] text-ink2 cursor-pointer">
                                        <input type="checkbox" name="payment_bkash_qr_remove" value="1" class="rounded border-line"> বর্তমান QR কোড মুছে ফেলুন
                                    </label>
                                @endif
                                @error('payment_bkash_qr') <p class="form-error">{{ $message }}</p> @enderror
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-9 h-9 rounded-lg bg-orange-500/15 text-orange-400 flex items-center justify-center"><i class="fa-solid fa-mobile-screen-button"></i></span>
                        <div>
                            <h3 class="font-extrabold text-ink text-sm">{{ tr('নগদ (Nagad)', 'Nagad') }}</h3>
                            <p class="text-[10px] text-ink3">{{ tr('মোবাইল ব্যাংকিং', 'Mobile banking') }}</p>
                        </div>
                    </div>
                    <span class="switch">
                        <input type="hidden" name="payment_nagad_enabled" value="0">
                        <input type="checkbox" name="payment_nagad_enabled" value="1" @checked(($settings['payment_nagad_enabled'] ?? '1') === '1')>
                        <span class="track"></span>
                    </span>
                </div>
                <div class="space-y-3">
                    <div>
                        <label class="form-label">{{ tr('নগদ নম্বর', 'Nagad number') }}</label>
                        <input type="text" name="payment_nagad_number" value="{{ old('payment_nagad_number', $settings['payment_nagad_number'] ?? '') }}" class="form-input" placeholder="01XXXXXXXXX">
                        @error('payment_nagad_number') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('অ্যাকাউন্টের ধরন', 'Account type') }}</label>
                        <select name="payment_nagad_type" class="form-input">
                            <option value="personal" @selected(($settings['payment_nagad_type'] ?? 'personal') === 'personal')>{{ tr('পার্সোনাল', 'Personal') }}</option>
                            <option value="merchant" @selected(($settings['payment_nagad_type'] ?? 'personal') === 'merchant')>{{ tr('মার্চেন্ট', 'Merchant') }}</option>
                        </select>
                        @error('payment_nagad_type') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('পেমেন্ট লিংক (ঐচ্ছিক)', 'Payment link (optional)') }}</label>
                        <input type="url" name="payment_nagad_link" value="{{ old('payment_nagad_link', $settings['payment_nagad_link'] ?? '') }}" class="form-input text-xs" placeholder="https://...">
                        @error('payment_nagad_link') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('কাস্টমারের জন্য নির্দেশনা', 'Instructions for the customer') }}</label>
                        <textarea name="payment_nagad_instructions" rows="3" class="form-input" placeholder="Send Money করার নিয়ম লিখুন">{{ old('payment_nagad_instructions', $settings['payment_nagad_instructions'] ?? '') }}</textarea>
                        @error('payment_nagad_instructions') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    @include('admin.payments.partials.icon', ['method' => 'nagad'])
                </div>
            </div>

            <div class="glass rounded-2xl p-5">
                <div class="flex items-center justify-between mb-4">
                    <div class="flex items-center gap-2">
                        <span class="w-9 h-9 rounded-lg bg-violet-500/15 text-violet-400 flex items-center justify-center"><i class="fa-regular fa-credit-card"></i></span>
                        <div>
                            <h3 class="font-extrabold text-ink text-sm">{{ tr('কার্ড পেমেন্ট', 'Card payment') }}</h3>
                            <p class="text-[10px] text-ink3">{{ tr('ডেবিট / ক্রেডিট কার্ড', 'Debit / credit card') }}</p>
                        </div>
                    </div>
                    <span class="switch">
                        <input type="hidden" name="payment_card_enabled" value="0">
                        <input type="checkbox" name="payment_card_enabled" value="1" @checked(($settings['payment_card_enabled'] ?? '0') === '1')>
                        <span class="track"></span>
                    </span>
                </div>
                <div class="space-y-3">
                    <div>
                        <label class="form-label">{{ tr('গেটওয়ের নাম', 'Gateway name') }}</label>
                        <input type="text" name="payment_card_gateway" value="{{ old('payment_card_gateway', $settings['payment_card_gateway'] ?? '') }}" class="form-input" placeholder="SSLCommerz / Stripe / Banglalink">
                        @error('payment_card_gateway') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('চেকআউট লিংক (ঐচ্ছিক)', 'Checkout link (optional)') }}</label>
                        <input type="url" name="payment_card_link" value="{{ old('payment_card_link', $settings['payment_card_link'] ?? '') }}" class="form-input text-xs" placeholder="https://...">
                        @error('payment_card_link') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('কাস্টমারের জন্য নির্দেশনা', 'Instructions for the customer') }}</label>
                        <textarea name="payment_card_instructions" rows="3" class="form-input" placeholder="কার্ড পেমেন্টের নিয়ম লিখুন">{{ old('payment_card_instructions', $settings['payment_card_instructions'] ?? '') }}</textarea>
                        @error('payment_card_instructions') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    @include('admin.payments.partials.icon', ['method' => 'card'])
                </div>
            </div>
        </div>

        <div class="flex items-center gap-2 mt-5">
            <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('পেমেন্ট সেটিংস সংরক্ষণ করুন', 'Save payment settings') }}</button>
            <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
        </div>
    </form>
@endsection
