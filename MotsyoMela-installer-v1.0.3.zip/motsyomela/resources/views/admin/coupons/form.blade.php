@extends('admin.layouts.app')

@section('title', $coupon->exists ? tr('কুপন এডিট', 'Edit coupon') : tr('নতুন কুপন', 'New coupon'))
@section('subtitle', tr('চেকআউটে ব্যবহারযোগ্য ডিসকাউন্ট কোড', 'Discount code usable at checkout'))

@section('content')
    <form method="POST" action="{{ $coupon->exists ? route('admin.coupons.update', $coupon) : route('admin.coupons.store') }}" class="max-w-2xl">
        @csrf
        @if ($coupon->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('কুপন কোড', 'Coupon code') }} <span class="text-rose-400">*</span></label>
                    <input type="text" name="code" value="{{ old('code', $coupon->code) }}" class="form-input uppercase font-mono font-bold" placeholder="FRESH50" required>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('স্বয়ংক্রিয়ভাবে বড় হাতের অক্ষরে পরিণত হবে।', 'Automatically converted to uppercase.') }}</p>
                    @error('code') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ধরন', 'Type') }} <span class="text-rose-400">*</span></label>
                    <select name="type" class="form-input" required>
                        <option value="fixed" @selected(old('type', $coupon->type) === 'fixed')>{{ tr('নির্দিষ্ট টাকা (Fixed ৳)', 'Fixed amount (৳)') }}</option>
                        <option value="percent" @selected(old('type', $coupon->type) === 'percent')>{{ tr('শতকরা (Percent %)', 'Percentage (%)') }}</option>
                    </select>
                    @error('type') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('মান', 'Value') }} <span class="text-rose-400">*</span></label>
                    <input type="number" step="0.01" min="0.01" name="value" value="{{ old('value', $coupon->value) }}" class="form-input" placeholder="50" required>
                    <p class="text-[10px] text-ink3 mt-1">{{ tr('Fixed হলে টাকা, Percent হলে শতাংশ (সর্বোচ্চ ১০০)।', 'Amount for fixed, percentage for percent (max 100).') }}</p>
                    @error('value') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('সর্বনিম্ন অর্ডার মূল্য', 'Minimum order value') }}</label>
                    <input type="number" step="0.01" min="0" name="min_order_total" value="{{ old('min_order_total', $coupon->min_order_total) }}" class="form-input" placeholder="{{ tr('খালি রাখলে শর্ত নেই', 'Leave empty for no minimum') }}">
                    @error('min_order_total') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer pt-1">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় কুপন চেকআউটে কাজ করবে না', 'Inactive coupons do not work at checkout') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $coupon->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.coupons.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
