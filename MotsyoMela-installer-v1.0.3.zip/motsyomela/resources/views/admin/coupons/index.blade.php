@extends('admin.layouts.app')

@section('title', tr('কুপন ব্যবস্থাপনা', 'Coupon management'))
@section('subtitle', tr('ডিসকাউন্ট কুপন তৈরি ও নিয়ন্ত্রণ করুন', 'Create and manage discount coupons'))

@section('content')
    <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <form method="GET" action="{{ route('admin.coupons.index') }}" class="flex items-center gap-2">
            <div class="relative">
                <i class="fa-solid fa-magnifying-glass absolute left-3 top-1/2 -translate-y-1/2 text-ink3 text-xs"></i>
                <input type="search" name="q" value="{{ $search }}" placeholder="{{ tr('কুপন কোড খুঁজুন', 'Search coupon code') }}" class="form-input !py-2 !pl-8 !text-xs w-52">
            </div>
            <button type="submit" class="btn-soft !py-2">{{ tr('খুঁজুন', 'Search') }}</button>
            @if ($search !== '')
                <a href="{{ route('admin.coupons.index') }}" class="btn-soft !py-2"><i class="fa-solid fa-rotate-left"></i></a>
            @endif
        </form>
        <a href="{{ route('admin.coupons.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন কুপন', 'New coupon') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[760px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('কোড', 'Code') }}</th>
                        <th>{{ tr('ধরন', 'Type') }}</th>
                        <th class="text-right">{{ tr('মান', 'Value') }}</th>
                        <th class="text-right">{{ tr('সর্বনিম্ন অর্ডার', 'Min. order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th>{{ tr('তৈরি', 'Created') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($coupons as $coupon)
                        <tr>
                            <td>
                                <span class="inline-flex items-center gap-1.5 font-mono font-black text-aqua-400 text-sm">
                                    <i class="fa-solid fa-ticket text-[11px]"></i>{{ $coupon->code }}
                                </span>
                            </td>
                            <td class="text-[11px] font-semibold text-ink2">{{ $coupon->type === 'fixed' ? tr('নির্দিষ্ট টাকা (Fixed)', 'Fixed amount') : tr('শতকরা (Percent)', 'Percentage') }}</td>
                            <td class="text-right font-black text-ink">{{ $coupon->type === 'fixed' ? bn_money($coupon->value) : bn_num((float) $coupon->value).'%' }}</td>
                            <td class="text-right text-ink2">{{ $coupon->min_order_total !== null ? bn_money($coupon->min_order_total) : tr('নেই', 'None') }}</td>
                            <td>
                                @if ($coupon->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-[11px] text-ink3">{{ bn_num($coupon->created_at->format('d/m/Y')) }}</td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.coupons.edit', $coupon) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.coupons.destroy', $coupon) }}" class="inline-block" data-confirm="কুপন {{ $coupon->code }} ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="7" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো কুপন নেই', 'No coupons yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($coupons->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $coupons->links() }}</div>
        @endif
    </div>
@endsection
