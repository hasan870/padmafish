@extends('admin.layouts.app')

@section('title', $zone->exists ? tr('ডেলিভারি এলাকা এডিট', 'Edit delivery zone') : tr('নতুন ডেলিভারি এলাকা', 'New delivery zone'))
@section('subtitle', tr('এলাকার নাম ও চার্জ', 'Zone name and charge'))

@section('content')
    <form method="POST" action="{{ $zone->exists ? route('admin.zones.update', $zone) : route('admin.zones.store') }}" class="max-w-xl">
        @csrf
        @if ($zone->exists) @method('PUT') @endif

        <div class="glass rounded-2xl p-5 space-y-4">
            <div>
                <label class="form-label">{{ tr('এলাকার নাম', 'Zone name') }} <span class="text-rose-400">*</span></label>
                <input type="text" name="name_bn" value="{{ old('name_bn', $zone->name_bn) }}" class="form-input" placeholder="{{ tr('যেমন: ঢাকা শহর (ভিতরে)', 'e.g. Dhaka city (inside)') }}" required>
                @error('name_bn') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div>
                <label class="form-label">{{ tr('ইংরেজি নাম', 'English name') }}</label>
                <input type="text" name="name_en" value="{{ old('name_en', $zone->name_en) }}" class="form-input" placeholder="e.g. Dhaka city (inside)">
                <p class="text-[10px] text-ink3 mt-1">{{ tr('ইংরেজি মোডে চেকআউটে এই নামটি দেখানো হবে। খালি রাখলে বাংলা নামই ব্যবহার হবে।', 'This name is shown at checkout in English mode. The Bengali name is used when left empty.') }}</p>
                @error('name_en') <p class="form-error">{{ $message }}</p> @enderror
            </div>
            <div class="grid grid-cols-2 gap-4">
                <div>
                    <label class="form-label">{{ tr('ডেলিভারি চার্জ (৳)', 'Delivery charge (৳)') }} <span class="text-rose-400">*</span></label>
                    <input type="number" step="0.01" min="0" name="charge" value="{{ old('charge', $zone->charge) }}" class="form-input" placeholder="80" required>
                    @error('charge') <p class="form-error">{{ $message }}</p> @enderror
                </div>
                <div>
                    <label class="form-label">{{ tr('ক্রম', 'Order') }}</label>
                    <input type="number" min="0" max="9999" name="sort_order" value="{{ old('sort_order', $zone->sort_order ?? 0) }}" class="form-input">
                    @error('sort_order') <p class="form-error">{{ $message }}</p> @enderror
                </div>
            </div>

            <input type="hidden" name="is_active" value="0">
            <label class="flex items-center justify-between gap-3 cursor-pointer">
                <span>
                    <span class="block text-xs font-bold text-ink">{{ tr('সক্রিয়', 'Active') }} <span class="text-ink3 font-medium">(Active)</span></span>
                    <span class="block text-[10px] text-ink3 mt-0.5">{{ tr('নিষ্ক্রিয় এলাকা চেকআউটে দেখাবে না', 'Inactive zones are hidden at checkout') }}</span>
                </span>
                <span class="switch">
                    <input type="checkbox" name="is_active" value="1" @checked(old('is_active', $zone->is_active))>
                    <span class="track"></span>
                </span>
            </label>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('সংরক্ষণ করুন', 'Save') }}</button>
                <a href="{{ route('admin.zones.index') }}" class="btn-soft">{{ tr('বাতিল', 'Cancel') }}</a>
            </div>
        </div>
    </form>
@endsection
