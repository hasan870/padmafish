@extends('admin.layouts.app')

@section('title', tr('ডেলিভারি এলাকা', 'Delivery zones'))
@section('subtitle', tr('এলাকা অনুযায়ী ডেলিভারি চার্জ নির্ধারণ করুন', 'Set delivery charges for each zone'))

@section('content')
    <div class="flex items-center justify-between mb-4">
        <p class="text-xs text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($zones->total()) }} {{ tr('টি এলাকা', 'zones') }}</p>
        <a href="{{ route('admin.zones.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('নতুন এলাকা', 'New zone') }}</a>
    </div>

    <div class="glass rounded-2xl overflow-hidden">
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[700px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('এলাকা', 'Zone') }}</th>
                        <th class="text-right">{{ tr('ডেলিভারি চার্জ', 'Delivery charge') }}</th>
                        <th class="text-center">{{ tr('অর্ডার', 'Orders') }}</th>
                        <th class="text-center">{{ tr('ক্রম', 'Order') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($zones as $zone)
                        <tr>
                            <td class="font-bold text-ink">
                                {{ localized($zone->name_bn, $zone->name_en) }}
                                @if ($zone->name_en)
                                    <p class="text-[11px] text-ink3 font-normal">{{ app()->getLocale() === 'en' ? $zone->name_bn : $zone->name_en }}</p>
                                @endif
                            </td>
                            <td class="text-right font-black text-ink">{{ bn_money($zone->charge) }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($zone->orders_count) }}</td>
                            <td class="text-center font-bold text-ink2">{{ bn_num($zone->sort_order) }}</td>
                            <td>
                                @if ($zone->is_active)
                                    <span class="badge border-emerald-500/30 bg-emerald-500/10 text-emerald-400">{{ tr('সক্রিয়', 'Active') }}</span>
                                @else
                                    <span class="badge border-line bg-card2 text-ink3">{{ tr('নিষ্ক্রিয়', 'Inactive') }}</span>
                                @endif
                            </td>
                            <td class="text-right whitespace-nowrap">
                                <a href="{{ route('admin.zones.edit', $zone) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-pen"></i></a>
                                <form method="POST" action="{{ route('admin.zones.destroy', $zone) }}" class="inline-block" data-confirm="ডেলিভারি এলাকা &quot;{{ $zone->name_bn }}&quot; ডিলিট করা হবে। নিশ্চিত?">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="btn-danger !px-2.5 !py-1.5 !text-[11px]"><i class="fa-solid fa-trash-can"></i></button>
                                </form>
                            </td>
                        </tr>
                    @empty
                        <tr><td colspan="6" class="text-center py-12 text-ink3 text-sm">{{ tr('কোনো এলাকা নেই', 'No zones yet') }}</td></tr>
                    @endforelse
                </tbody>
            </table>
        </div>
        @if ($zones->hasPages())
            <div class="px-4 py-3 border-t border-line/70">{{ $zones->links() }}</div>
        @endif
    </div>
@endsection
