@extends('admin.layouts.app')

@section('title', tr('ফুটার সেটিংস', 'Footer settings'))
@section('subtitle', tr('ফুটারের লেখা, ঠিকানা ও সোশ্যাল মিডিয়া লিংক', 'Footer text, address and social media links'))

@section('content')
    <form method="POST" action="{{ route('admin.footer.update') }}" class="max-w-3xl">
        @csrf
        @method('PUT')

        <div class="glass rounded-2xl p-5 space-y-5">
            <div>
                <h3 class="font-extrabold text-ink text-sm mb-1 flex items-center gap-2"><i class="fa-solid fa-align-left text-aqua-400"></i> {{ tr('ফুটারের লেখা', 'Footer text') }}</h3>
                <p class="text-[10px] text-ink3 mb-4">{{ tr('খালি রাখলে সাইটের ডিফল্ট লেখা দেখাবে।', 'The built-in default is used when a field is left empty.') }}</p>
                <div class="space-y-4">
                    <div>
                        <label class="form-label">{{ tr('সাইটের পরিচিতি', 'Site description') }}</label>
                        <textarea name="footer_about_text" rows="3" maxlength="500" class="form-input" placeholder="{{ tr('বাংলাদেশের প্রিমিয়াম অনলাইন মাছের বাজার। কেমিক্যালমুক্ত তাজা মাছ নিয়ে আমরা আছি আপনার পাশে।', "Bangladesh's premium online fish market. We are here for you with chemical-free fresh fish.") }}">{{ old('footer_about_text', $settings['footer_about_text'] ?? '') }}</textarea>
                        @error('footer_about_text') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('কপিরাইট লেখা', 'Copyright text') }}</label>
                        <input type="text" name="footer_copyright" value="{{ old('footer_copyright', $settings['footer_copyright'] ?? '') }}" maxlength="300" class="form-input" placeholder="{{ tr('সর্বস্বত্ব সংরক্ষিত। কেমিক্যালমুক্ত তাজা মাছের নির্ভরযোগ্য বিশ্বস্ত প্রতিষ্ঠান।', 'All rights reserved. Your trusted source for chemical-free fresh fish.') }}">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('শুরুর © বছর ও সাইটের নাম স্বয়ংক্রিয়ভাবে যুক্ত হবে।', 'The © year and site name are added automatically.') }}</p>
                        @error('footer_copyright') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label">{{ tr('পেমেন্ট সেকশনের নোট', 'Payment section note') }}</label>
                        <input type="text" name="footer_payment_note" value="{{ old('footer_payment_note', $settings['footer_payment_note'] ?? '') }}" maxlength="300" class="form-input" placeholder="{{ tr('ক্যাশ অন ডেলিভারি ও মোবাইল ব্যাংকিং/কার্ডে নিরাপদ পেমেন্ট করুন', 'Pay securely with cash on delivery, mobile banking or card') }}">
                        @error('footer_payment_note') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-4 flex items-center gap-2"><i class="fa-solid fa-location-dot text-aqua-400"></i> {{ tr('ঠিকানা ও যোগাযোগ', 'Address & contact') }}</h3>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('ঠিকানা', 'Address') }}</label>
                        <textarea name="footer_address" rows="2" maxlength="300" class="form-input" placeholder="{{ tr('কারওয়ান বাজার, গাবতলী, গুলশান ও চট্টগ্রাম পোর্ট', 'Karwan Bazar, Gabtoli, Gulshan & Chattogram Port') }}">{{ old('footer_address', $settings['footer_address'] ?? '') }}</textarea>
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('ফুটারের গ্রাহক সেবা তালিকায় দেখানো হবে। হটলাইন নম্বর সাইট সেটিংস থেকে আসে।', 'Shown in the footer customer care list. The hotline number comes from Site settings.') }}</p>
                        @error('footer_address') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div class="sm:col-span-2">
                        <label class="form-label">{{ tr('হটলাইনের সময়', 'Hotline hours') }}</label>
                        <input type="text" name="footer_hotline_note" value="{{ old('footer_hotline_note', $settings['footer_hotline_note'] ?? '') }}" maxlength="100" class="form-input" placeholder="{{ tr('(সকাল ৭টা - রাত ৯টা)', '(7am - 9pm)') }}">
                        @error('footer_hotline_note') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="pt-4 border-t border-line/70">
                <h3 class="font-extrabold text-ink text-sm mb-1 flex items-center gap-2"><i class="fa-brands fa-facebook text-aqua-400"></i> {{ tr('সোশ্যাল মিডিয়া', 'Social media') }}</h3>
                <p class="text-[10px] text-ink3 mb-4">{{ tr('লিংক খালি রাখলে সেই আইকনটি ফুটারে দেখাবে না।', 'An empty link hides that icon in the footer.') }}</p>
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="form-label"><i class="fa-brands fa-facebook-f text-[11px] mr-1"></i> Facebook</label>
                        <input type="url" name="footer_facebook_url" value="{{ old('footer_facebook_url', $settings['footer_facebook_url'] ?? '') }}" class="form-input" placeholder="https://facebook.com/yourpage">
                        @error('footer_facebook_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label"><i class="fa-brands fa-youtube text-[11px] mr-1"></i> YouTube</label>
                        <input type="url" name="footer_youtube_url" value="{{ old('footer_youtube_url', $settings['footer_youtube_url'] ?? '') }}" class="form-input" placeholder="https://youtube.com/@yourchannel">
                        @error('footer_youtube_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label"><i class="fa-brands fa-instagram text-[11px] mr-1"></i> Instagram</label>
                        <input type="url" name="footer_instagram_url" value="{{ old('footer_instagram_url', $settings['footer_instagram_url'] ?? '') }}" class="form-input" placeholder="https://instagram.com/yourpage">
                        @error('footer_instagram_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                    <div>
                        <label class="form-label"><i class="fa-brands fa-whatsapp text-[11px] mr-1"></i> {{ tr('WhatsApp লিংক', 'WhatsApp link') }}</label>
                        <input type="url" name="footer_whatsapp_url" value="{{ old('footer_whatsapp_url', $settings['footer_whatsapp_url'] ?? '') }}" class="form-input" placeholder="https://wa.me/8801700000000">
                        <p class="text-[10px] text-ink3 mt-1">{{ tr('খালি রাখলে সাইট সেটিংসের হোয়াটসঅ্যাপ নম্বর ব্যবহার হবে।', 'The WhatsApp number from Site settings is used when empty.') }}</p>
                        @error('footer_whatsapp_url') <p class="form-error">{{ $message }}</p> @enderror
                    </div>
                </div>
            </div>

            <div class="rounded-xl border border-aqua-500/25 bg-aqua-500/5 px-4 py-3 text-[11px] text-ink2 flex items-start gap-2">
                <i class="fa-solid fa-circle-info text-aqua-400 mt-0.5"></i>
                <span>{{ tr('ফুটারের ডেলিভারি পলিসি, রিফান্ড ও রিটার্ন নীতির মতো লিংক', 'Links such as delivery policy and refund & return policy in the footer come') }} <a href="{{ route('admin.pages.index') }}" class="font-bold text-aqua-400 underline">HTML পেজ</a> {{ tr('থেকে নিয়ন্ত্রণ করুন — “ফুটারে দেখান” চালু রাখুন।', 'from HTML pages — keep “Show in footer” enabled there.') }}</span>
            </div>

            <div class="flex items-center gap-2 pt-2">
                <button type="submit" class="btn-primary"><i class="fa-solid fa-floppy-disk"></i> {{ tr('ফুটার সংরক্ষণ করুন', 'Save footer') }}</button>
                <a href="{{ url('/') }}" target="_blank" class="btn-soft"><i class="fa-solid fa-eye"></i> {{ tr('স্টোরফ্রন্ট', 'Storefront') }}</a>
            </div>
        </div>
    </form>
@endsection
