<!DOCTYPE html>
<html lang="bn" data-theme="dark">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'অ্যাডমিন প্যানেল') | মৎস্যমেলা</title>

    <script>
        (function () {
            try {
                var saved = localStorage.getItem('mm-admin-theme');
                var theme = saved || 'dark';
                document.documentElement.setAttribute('data-theme', theme);
                if (theme === 'dark') document.documentElement.classList.add('dark');
            } catch (e) { /* noop */ }
        })();
    </script>

    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Hind+Siliguri:wght@300;400;500;600;700&family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        navy: { 800: '#0f172a', 900: '#0b1324', 950: '#050b14' },
                        aqua: { 50: '#f0fdfa', 100: '#ccfbf1', 200: '#99f6e4', 300: '#5eead4', 400: '#2dd4bf', 500: '#14b8a6', 600: '#0d9488', 700: '#0f766e' },
                        sky: { 500: '#0ea5e9', 600: '#0284c7' },
                        gold: { 400: '#fbbf24', 500: '#f59e0b', 600: '#d97706' },
                        app: 'rgb(var(--app) / <alpha-value>)',
                        card: 'rgb(var(--card) / <alpha-value>)',
                        card2: 'rgb(var(--card2) / <alpha-value>)',
                        ink: 'rgb(var(--ink) / <alpha-value>)',
                        ink2: 'rgb(var(--ink2) / <alpha-value>)',
                        ink3: 'rgb(var(--ink3) / <alpha-value>)',
                        line: 'rgb(var(--line) / <alpha-value>)'
                    },
                    fontFamily: {
                        bangla: ['Hind Siliguri', 'Inter', 'sans-serif'],
                        sans: ['Inter', 'Hind Siliguri', 'sans-serif']
                    }
                }
            }
        }
    </script>

    <style>
        :root, html[data-theme='dark'] {
            color-scheme: dark;
            --app: 4 10 20;
            --card: 13 25 44;
            --card2: 21 36 58;
            --ink: 226 240 249;
            --ink2: 152 175 194;
            --ink3: 106 130 151;
            --line: 40 60 86;
            --glass: rgba(14, 28, 50, 0.55);
            --glass-strong: rgba(9, 19, 36, 0.9);
            --glass-border: rgba(126, 190, 238, 0.14);
            --glass-hi: rgba(255, 255, 255, 0.08);
            --header-bg: rgba(6, 13, 27, 0.78);
            --glow-a: rgba(20, 184, 166, 0.16);
            --glow-b: rgba(14, 165, 233, 0.14);
            --shadow-card: 0 10px 40px -14px rgba(2, 8, 20, 0.6);
        }

        html[data-theme='light'] {
            color-scheme: light;
            --app: 234 245 248;
            --card: 255 255 255;
            --card2: 240 247 250;
            --ink: 9 33 46;
            --ink2: 71 97 111;
            --ink3: 116 141 154;
            --line: 213 229 235;
            --glass: rgba(255, 255, 255, 0.65);
            --glass-strong: rgba(255, 255, 255, 0.94);
            --glass-border: rgba(2, 116, 110, 0.14);
            --glass-hi: rgba(255, 255, 255, 0.95);
            --header-bg: rgba(255, 255, 255, 0.78);
            --glow-a: rgba(20, 184, 166, 0.2);
            --glow-b: rgba(14, 165, 233, 0.16);
            --shadow-card: 0 12px 36px -16px rgba(9, 60, 73, 0.22);
        }

        html { background: rgb(var(--app)); }
        body {
            font-family: 'Hind Siliguri', 'Inter', sans-serif;
            background: transparent;
            color: rgb(var(--ink));
        }
        ::-webkit-scrollbar { width: 8px; height: 8px; }
        ::-webkit-scrollbar-track { background: rgb(var(--card2)); }
        ::-webkit-scrollbar-thumb { background: linear-gradient(180deg, #14b8a6, #0284c7); border-radius: 8px; }
        .glass {
            background: var(--glass);
            backdrop-filter: blur(18px) saturate(170%);
            -webkit-backdrop-filter: blur(18px) saturate(170%);
            border: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi), var(--shadow-card);
        }
        .glass-strong {
            background: var(--glass-strong);
            backdrop-filter: blur(28px) saturate(190%);
            -webkit-backdrop-filter: blur(28px) saturate(190%);
            border: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi);
        }
        .glass-header {
            background: var(--header-bg);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border-bottom: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi);
        }
        @supports not ((backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px))) {
            .glass, .glass-strong, .glass-header { background: rgb(var(--card)); }
        }
        .admin-aurora { position: fixed; inset: 0; z-index: -1; overflow: hidden; pointer-events: none; }
        .admin-aurora span { position: absolute; border-radius: 9999px; filter: blur(100px); }
        .admin-aurora .a1 { width: 520px; height: 520px; background: var(--glow-a); top: -180px; right: 0; }
        .admin-aurora .a2 { width: 440px; height: 440px; background: var(--glow-b); bottom: -160px; left: 8%; }
        .nav-link { display: flex; align-items: center; gap: .75rem; padding: .65rem .9rem; border-radius: .9rem; font-size: .875rem; font-weight: 600; color: rgb(var(--ink2)); border: 1px solid transparent; transition: all .18s ease; }
        .nav-link:hover { background: rgb(var(--card2) / .7); color: rgb(var(--ink)); }
        .nav-link.active { background: linear-gradient(90deg, rgba(20,184,166,.18), rgba(14,165,233,.12)); color: rgb(var(--ink)); border-color: rgba(20,184,166,.35); }
        .nav-link i { width: 1.15rem; text-align: center; color: rgb(var(--ink3)); }
        .nav-link.active i { color: #2dd4bf; }
        .form-input {
            width: 100%; background: rgb(var(--card2) / .7); border: 1px solid rgb(var(--line));
            border-radius: .8rem; padding: .6rem .85rem; font-size: .875rem; color: rgb(var(--ink));
            outline: none; transition: border-color .18s ease, box-shadow .18s ease;
        }
        .form-input:focus { border-color: #14b8a6; box-shadow: 0 0 0 3px rgba(20,184,166,.14); }
        .form-input::placeholder { color: rgb(var(--ink3)); }
        .form-label { display: block; font-size: .75rem; font-weight: 700; color: rgb(var(--ink2)); margin-bottom: .35rem; }
        .form-error { color: #fb7185; font-size: .72rem; margin-top: .3rem; font-weight: 600; }
        .btn-primary {
            display: inline-flex; align-items: center; justify-content: center; gap: .5rem;
            background: linear-gradient(90deg, #0d9488, #0284c7); color: #fff; font-weight: 700;
            padding: .62rem 1.15rem; border-radius: .8rem; font-size: .85rem;
            box-shadow: 0 10px 24px -12px rgba(13,148,136,.8); transition: all .18s ease;
        }
        .btn-primary:hover { filter: brightness(1.08); transform: translateY(-1px); }
        .btn-soft {
            display: inline-flex; align-items: center; justify-content: center; gap: .45rem;
            background: rgb(var(--card2) / .8); border: 1px solid rgb(var(--line)); color: rgb(var(--ink2));
            font-weight: 600; padding: .55rem .95rem; border-radius: .75rem; font-size: .8rem; transition: all .18s ease;
        }
        .btn-soft:hover { color: rgb(var(--ink)); border-color: rgba(20,184,166,.4); }
        .btn-danger {
            display: inline-flex; align-items: center; justify-content: center; gap: .4rem;
            background: rgba(244,63,94,.12); border: 1px solid rgba(244,63,94,.35); color: #fb7185;
            font-weight: 600; padding: .5rem .85rem; border-radius: .7rem; font-size: .78rem; transition: all .18s ease;
        }
        .btn-danger:hover { background: rgba(244,63,94,.2); }
        .admin-table th { text-align: left; font-size: .68rem; text-transform: uppercase; letter-spacing: .04em; color: rgb(var(--ink3)); font-weight: 700; padding: .7rem .8rem; border-bottom: 1px solid rgb(var(--line)); white-space: nowrap; }
        .admin-table td { padding: .75rem .8rem; font-size: .82rem; border-bottom: 1px solid rgb(var(--line) / .6); vertical-align: middle; }
        .admin-table tr:last-child td { border-bottom: none; }
        .admin-table tbody tr:hover { background: rgb(var(--card2) / .45); }
        .badge { display: inline-flex; align-items: center; gap: .3rem; font-size: .68rem; font-weight: 700; padding: .22rem .55rem; border-radius: .5rem; border: 1px solid transparent; white-space: nowrap; }
        .switch { position: relative; display: inline-flex; align-items: center; cursor: pointer; }
        .switch input { position: absolute; inset: 0; opacity: 0; width: 100%; height: 100%; margin: 0; cursor: pointer; }
        .switch input[type="checkbox"] { z-index: 2; }
        .switch .track { pointer-events: none; }
        .switch .track { width: 2.6rem; height: 1.4rem; background: rgb(var(--line)); border-radius: 9999px; transition: background .2s; position: relative; }
        .switch .track::after { content: ''; position: absolute; top: 3px; left: 3px; width: 1.02rem; height: 1.02rem; border-radius: 9999px; background: #fff; transition: transform .2s; box-shadow: 0 1px 3px rgba(0,0,0,.35); }
        .switch input:checked + .track { background: #0d9488; }
        .switch input:checked + .track::after { transform: translateX(1.2rem); }
        .sidebar-scroll { scrollbar-width: thin; }
        @media print { .no-print { display: none !important; } }
    </style>
    @stack('head')
</head>
<body class="min-h-screen font-bangla antialiased">
    <div class="admin-aurora"><span class="a1"></span><span class="a2"></span></div>

    <div id="admin-sidebar-overlay" class="fixed inset-0 bg-black/50 z-40 hidden lg:hidden" onclick="toggleAdminSidebar(false)"></div>

    <aside id="admin-sidebar" class="fixed inset-y-0 left-0 z-50 w-72 glass-strong border-r border-line flex flex-col -translate-x-full lg:translate-x-0 transition-transform duration-300">
        <div class="px-5 py-5 border-b border-line/70 flex items-center justify-between">
            <a href="{{ route('admin.dashboard') }}" class="flex items-center gap-3">
                <span class="w-11 h-11 rounded-2xl bg-gradient-to-br from-aqua-500 to-sky-600 flex items-center justify-center text-white text-xl shadow-lg shadow-aqua-600/30">
                    <i class="fa-solid fa-fish"></i>
                </span>
                <span>
                    <span class="block font-extrabold text-ink text-lg leading-tight">মৎস্যমেলা</span>
                    <span class="block text-[10px] uppercase tracking-widest text-ink3 font-bold">Admin Panel</span>
                </span>
            </a>
            <button type="button" class="lg:hidden text-ink3 hover:text-ink p-2" onclick="toggleAdminSidebar(false)">
                <i class="fa-solid fa-xmark text-lg"></i>
            </button>
        </div>

        @php
            $admin = auth('admin')->user();
            $navSections = [
                ['heading' => 'ওভারভিউ', 'en' => 'Overview'],
                ['label' => 'ড্যাশবোর্ড', 'en' => 'Dashboard', 'icon' => 'fa-gauge-high', 'route' => 'admin.dashboard', 'active' => 'admin.dashboard'],
                ['heading' => 'অর্ডার', 'en' => 'Orders'],
                ['label' => 'সব অর্ডার', 'en' => 'Orders', 'icon' => 'fa-bag-shopping', 'route' => 'admin.orders.index', 'active' => 'admin.orders.*'],
                ['heading' => 'ক্যাটালগ', 'en' => 'Catalog'],
                ['label' => 'পণ্যসমূহ', 'en' => 'Products', 'icon' => 'fa-fish', 'route' => 'admin.products.index', 'active' => 'admin.products.*'],
                ['label' => 'ক্যাটাগরি', 'en' => 'Categories', 'icon' => 'fa-layer-group', 'route' => 'admin.categories.index', 'active' => 'admin.categories.*'],
                ['heading' => 'মার্কেটিং', 'en' => 'Marketing'],
                ['label' => 'কুপন', 'en' => 'Coupons', 'icon' => 'fa-ticket', 'route' => 'admin.coupons.index', 'active' => 'admin.coupons.*'],
                ['label' => 'কম্বো প্যাক', 'en' => 'Combo packs', 'icon' => 'fa-boxes-stacked', 'route' => 'admin.combo-packs.index', 'active' => 'admin.combo-packs.*'],
                ['label' => 'ঘোষণা', 'en' => 'Announcements', 'icon' => 'fa-bullhorn', 'route' => 'admin.announcements.index', 'active' => 'admin.announcements.*'],
                ['label' => 'হিরো প্রোমো', 'en' => 'Hero promo', 'icon' => 'fa-bullseye', 'route' => 'admin.hero-promo.edit', 'active' => 'admin.hero-promo.*'],
                ['label' => 'রিভিউ', 'en' => 'Testimonials', 'icon' => 'fa-star', 'route' => 'admin.testimonials.index', 'active' => 'admin.testimonials.*'],
                ['heading' => 'কনটেন্ট ও ডেলিভারি', 'en' => 'Content & Delivery'],
                ['label' => 'সাধারণ প্রশ্ন', 'en' => 'FAQs', 'icon' => 'fa-circle-question', 'route' => 'admin.faqs.index', 'active' => 'admin.faqs.*'],
                ['label' => 'হেডার মেনু', 'en' => 'Header menu', 'icon' => 'fa-bars-staggered', 'route' => 'admin.menu-items.index', 'active' => 'admin.menu-items.*'],
                ['label' => 'HTML পেজ', 'en' => 'HTML pages', 'icon' => 'fa-file-lines', 'route' => 'admin.pages.index', 'active' => 'admin.pages.*'],
                ['label' => 'ডেলিভারি এলাকা', 'en' => 'Zones', 'icon' => 'fa-truck-fast', 'route' => 'admin.zones.index', 'active' => 'admin.zones.*'],
                ['label' => 'ডেলিভারি সময়', 'en' => 'Time slots', 'icon' => 'fa-clock', 'route' => 'admin.slots.index', 'active' => 'admin.slots.*'],
                ['heading' => 'সেটিংস', 'en' => 'Settings'],
                ['label' => 'কম্বো সেটিংস', 'en' => 'Combo', 'icon' => 'fa-gift', 'route' => 'admin.combo.edit', 'active' => 'admin.combo.*'],
                ['label' => 'পেমেন্ট গেটওয়ে', 'en' => 'Payments', 'icon' => 'fa-credit-card', 'route' => 'admin.payments.edit', 'active' => 'admin.payments.*'],
                ['label' => 'থিম ও ব্র্যান্ডিং', 'en' => 'Theme', 'icon' => 'fa-palette', 'route' => 'admin.theme.edit', 'active' => 'admin.theme.*'],
                ['label' => 'ব্যানার বিজ্ঞাপন', 'en' => 'Banners', 'icon' => 'fa-rectangle-ad', 'route' => 'admin.banners.edit', 'active' => 'admin.banners.*'],
                ['label' => 'SEO ও অ্যানালিটিক্স', 'en' => 'SEO', 'icon' => 'fa-magnifying-glass-chart', 'route' => 'admin.seo.edit', 'active' => 'admin.seo.*'],
                ['label' => 'ভাষা ও অনুবাদ', 'en' => 'Translations', 'icon' => 'fa-language', 'route' => 'admin.translations.index', 'active' => 'admin.translations.*'],
                ['label' => 'ইমেইল সেটিংস', 'en' => 'Email', 'icon' => 'fa-envelope', 'route' => 'admin.mail.edit', 'active' => 'admin.mail.*'],
                ['label' => 'সাইট সেটিংস', 'en' => 'Site settings', 'icon' => 'fa-gear', 'route' => 'admin.settings.edit', 'active' => 'admin.settings.*'],
                ['label' => 'ফুটার সেটিংস', 'en' => 'Footer settings', 'icon' => 'fa-shoe-prints', 'route' => 'admin.footer.edit', 'active' => 'admin.footer.*'],
            ];
            if ($admin && $admin->isSuper()) {
                $navSections[] = ['heading' => 'অ্যাডমিন', 'en' => 'Admin'];
                $navSections[] = ['label' => 'অ্যাডমিন ইউজার', 'en' => 'Admin users', 'icon' => 'fa-user-shield', 'route' => 'admin.admins.index', 'active' => 'admin.admins.*'];
            }
        @endphp

        <nav class="flex-1 overflow-y-auto sidebar-scroll px-3 py-4 space-y-1">
            @foreach ($navSections as $item)
                @if (isset($item['heading']))
                    <p class="px-3 pt-4 pb-1 text-[10px] uppercase tracking-widest text-ink3 font-extrabold flex items-center justify-between">
                        <span>{{ app()->getLocale() === 'en' ? $item['en'] : $item['heading'] }}</span>
                        <span class="normal-case tracking-normal text-[9px] opacity-60">{{ app()->getLocale() === 'en' ? $item['heading'] : $item['en'] }}</span>
                    </p>
                @else
                    <a href="{{ route($item['route']) }}" class="nav-link {{ request()->routeIs($item['active']) ? 'active' : '' }}">
                        <i class="fa-solid {{ $item['icon'] }}"></i>
                        <span class="flex-1">{{ app()->getLocale() === 'en' ? $item['en'] : $item['label'] }}</span>
                        <span class="text-[9px] uppercase tracking-wide opacity-50">{{ app()->getLocale() === 'en' ? $item['label'] : $item['en'] }}</span>
                    </a>
                @endif
            @endforeach
        </nav>

        <div class="px-4 py-4 border-t border-line/70 space-y-2">
            <a href="{{ url('/') }}" target="_blank" class="btn-soft w-full justify-center">
                <i class="fa-solid fa-arrow-up-right-from-square"></i> {{ tr('স্টোরফ্রন্ট দেখুন', 'View storefront') }}
            </a>
            <form method="POST" action="{{ route('admin.logout') }}">
                @csrf
                <button type="submit" class="btn-danger w-full justify-center">
                    <i class="fa-solid fa-right-from-bracket"></i> {{ tr('লগআউট', 'Log out') }}
                </button>
            </form>
        </div>
    </aside>

    <div class="lg:pl-72 min-h-screen flex flex-col">
        <header class="glass-header sticky top-0 z-30">
            <div class="flex items-center gap-3 px-4 sm:px-6 py-3">
                <button type="button" class="lg:hidden text-ink2 hover:text-ink p-2 rounded-lg hover:bg-card2" onclick="toggleAdminSidebar(true)">
                    <i class="fa-solid fa-bars text-lg"></i>
                </button>
                <div class="min-w-0 flex-1">
                    <h1 class="font-extrabold text-ink text-base sm:text-lg leading-tight truncate">@yield('title', 'অ্যাডমিন প্যানেল')</h1>
                    <p class="text-[11px] text-ink3 truncate">@yield('subtitle', 'মৎস্যমেলা অ্যাডমিনিস্ট্রেশন')</p>
                </div>
                <form method="POST" action="{{ route('admin.language.switch', app()->getLocale() === 'en' ? 'bn' : 'en') }}">
                    @csrf
                    <button type="submit" class="btn-soft !px-3 !py-2" title="{{ app()->getLocale() === 'en' ? 'বাংলায় দেখুন' : 'Switch to English' }}">
                        <i class="fa-solid fa-language"></i>
                        <span class="hidden sm:inline">{{ app()->getLocale() === 'en' ? 'বাংলা' : 'English' }}</span>
                    </button>
                </form>
                <button type="button" onclick="toggleAdminTheme()" class="btn-soft !px-3 !py-2" title="থিম পরিবর্তন">
                    <i id="admin-theme-icon" class="fa-solid fa-sun text-amber-400"></i>
                </button>
                <div class="hidden sm:flex items-center gap-2 pl-3 border-l border-line/70">
                    <span class="w-9 h-9 rounded-xl bg-gradient-to-br from-aqua-500 to-sky-600 text-white flex items-center justify-center font-bold text-sm">
                        {{ mb_substr($admin->name ?? 'A', 0, 1) }}
                    </span>
                    <div class="leading-tight">
                        <p class="text-xs font-bold text-ink">{{ $admin->name ?? '' }}</p>
                        <p class="text-[10px] text-ink3">{{ $admin && $admin->isSuper() ? 'সুপার অ্যাডমিন' : 'স্টাফ' }}</p>
                    </div>
                </div>
            </div>
        </header>

        <main class="flex-1 px-4 sm:px-6 py-6">
            <div class="max-w-7xl mx-auto">
                @include('admin.partials.flash')
                @yield('content')
            </div>
        </main>

        <footer class="px-6 py-4 text-center text-[11px] text-ink3">
            মৎস্যমেলা অ্যাডমিন প্যানেল · {{ bn_num(date('Y')) }}
        </footer>
    </div>

    <!-- Confirmation modal -->
    <div id="admin-confirm" class="fixed inset-0 z-[80] hidden items-center justify-center p-4">
        <div class="absolute inset-0 bg-black/60 backdrop-blur-sm" onclick="closeAdminConfirm()"></div>
        <div class="relative glass-strong rounded-3xl w-full max-w-sm p-6 text-center">
            <div class="w-14 h-14 mx-auto rounded-2xl bg-rose-500/15 text-rose-400 flex items-center justify-center text-2xl mb-4">
                <i class="fa-solid fa-triangle-exclamation"></i>
            </div>
            <h3 class="font-extrabold text-ink text-lg">আপনি কি নিশ্চিত?</h3>
            <p id="admin-confirm-message" class="text-sm text-ink2 mt-2">এই কাজটি ফিরিয়ে আনা যাবে না।</p>
            <div class="flex items-center gap-2 mt-6">
                <button type="button" class="btn-soft flex-1 justify-center" onclick="closeAdminConfirm()">বাতিল করুন</button>
                <button type="button" id="admin-confirm-yes" class="btn-primary flex-1 justify-center !bg-gradient-to-r !from-rose-600 !to-rose-500">হ্যাঁ, নিশ্চিত</button>
            </div>
        </div>
    </div>

    <script>
        function toggleAdminSidebar(show) {
            const sidebar = document.getElementById('admin-sidebar');
            const overlay = document.getElementById('admin-sidebar-overlay');
            if (show) {
                sidebar.classList.remove('-translate-x-full');
                overlay.classList.remove('hidden');
            } else {
                sidebar.classList.add('-translate-x-full');
                overlay.classList.add('hidden');
            }
        }

        function toggleAdminTheme() {
            const html = document.documentElement;
            const next = html.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            html.setAttribute('data-theme', next);
            html.classList.toggle('dark', next === 'dark');
            localStorage.setItem('mm-admin-theme', next);
            updateAdminThemeIcon(next);
        }

        function updateAdminThemeIcon(theme) {
            const icon = document.getElementById('admin-theme-icon');
            if (!icon) return;
            icon.className = theme === 'dark'
                ? 'fa-solid fa-sun text-amber-400'
                : 'fa-solid fa-moon text-sky-500';
        }
        updateAdminThemeIcon(document.documentElement.getAttribute('data-theme') || 'dark');

        let pendingAdminForm = null;
        function confirmSubmit(form, message) {
            pendingAdminForm = form;
            document.getElementById('admin-confirm-message').textContent = message || 'এই কাজটি ফিরিয়ে আনা যাবে না।';
            const modal = document.getElementById('admin-confirm');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }
        function closeAdminConfirm() {
            pendingAdminForm = null;
            const modal = document.getElementById('admin-confirm');
            modal.classList.add('hidden');
            modal.classList.remove('flex');
        }
        document.getElementById('admin-confirm-yes').addEventListener('click', function () {
            if (pendingAdminForm) {
                pendingAdminForm.dataset.confirmed = '1';
                pendingAdminForm.submit();
            }
            closeAdminConfirm();
        });
        document.querySelectorAll('form[data-confirm]').forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (form.dataset.confirmed === '1') return;
                event.preventDefault();
                confirmSubmit(form, form.dataset.confirm);
            });
        });

        setTimeout(function () {
            document.querySelectorAll('[data-auto-dismiss]').forEach(function (el) {
                el.style.transition = 'opacity .4s ease, transform .4s ease';
                el.style.opacity = '0';
                el.style.transform = 'translateY(-6px)';
                setTimeout(function () { el.remove(); }, 450);
            });
        }, 4500);
    </script>
    @stack('scripts')
</body>
</html>
