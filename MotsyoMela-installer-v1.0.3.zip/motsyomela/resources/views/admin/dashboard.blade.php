@extends('admin.layouts.app')

@section('title', tr('ড্যাশবোর্ড', 'Dashboard'))
@section('subtitle', tr('আজকের ব্যবসার সারসংক্ষেপ', "Today's business snapshot"))

@section('content')
    @php
        $statusMeta = [
            'pending' => ['label' => tr('অপেক্ষমাণ', 'Pending'), 'icon' => 'fa-hourglass-half'],
            'confirmed' => ['label' => tr('নিশ্চিত', 'Confirmed'), 'icon' => 'fa-circle-check'],
            'delivering' => ['label' => tr('ডেলিভারিতে', 'Delivering'), 'icon' => 'fa-truck-fast'],
            'delivered' => ['label' => tr('সম্পন্ন', 'Delivered'), 'icon' => 'fa-box-open'],
            'cancelled' => ['label' => tr('বাতিল', 'Cancelled'), 'icon' => 'fa-ban'],
        ];
        $totalStatus = max(1, $statusCounts->sum());
    @endphp

    <div class="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 mb-5">
        <div>
            <h2 class="text-xl font-extrabold text-ink">{{ tr('স্বাগতম', 'Welcome back') }}, {{ auth('admin')->user()->name }}!</h2>
            <p class="text-xs text-ink3 mt-1">{{ now()->format('l, d M Y') }} · {{ tr('বাংলাদেশ সময়', 'Bangladesh time') }}</p>
        </div>
        <div class="flex gap-2">
            <a href="{{ route('admin.orders.index') }}" class="btn-soft"><i class="fa-solid fa-bag-shopping"></i> {{ tr('অর্ডার দেখুন', 'View orders') }}</a>
            <a href="{{ route('admin.products.create') }}" class="btn-primary"><i class="fa-solid fa-plus"></i> {{ tr('পণ্য যোগ করুন', 'Add product') }}</a>
        </div>
    </div>

    <div class="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <div class="glass rounded-2xl p-5 relative overflow-hidden">
            <div class="absolute -right-5 -top-5 w-24 h-24 rounded-full bg-aqua-500/10"></div>
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-[11px] font-bold text-ink3">{{ tr('আজকের অর্ডার', "Today's orders") }}</p>
                    <p class="text-3xl font-black text-ink mt-1">{{ bn_num(number_format($todayOrders)) }}</p>
                </div>
                <span class="w-11 h-11 rounded-xl bg-aqua-500/15 text-aqua-400 flex items-center justify-center text-lg"><i class="fa-solid fa-bag-shopping"></i></span>
            </div>
            <p class="text-[11px] text-ink3 mt-3">{{ tr('সর্বমোট', 'In total') }} {{ bn_num(number_format($statusCounts->sum())) }} {{ tr('টি অর্ডার রেকর্ড হয়েছে', 'orders recorded') }}</p>
        </div>

        <div class="glass rounded-2xl p-5 relative overflow-hidden">
            <div class="absolute -right-5 -top-5 w-24 h-24 rounded-full bg-emerald-500/10"></div>
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-[11px] font-bold text-ink3">{{ tr('আজকের আয়', "Today's revenue") }}</p>
                    <p class="text-3xl font-black text-ink mt-1">{{ bn_money($todayRevenue) }}</p>
                </div>
                <span class="w-11 h-11 rounded-xl bg-emerald-500/15 text-emerald-400 flex items-center justify-center text-lg"><i class="fa-solid fa-bangladeshi-taka-sign"></i></span>
            </div>
            <p class="text-[11px] text-ink3 mt-3">{{ tr('গত ৭ দিনে', 'In the last 7 days') }} {{ bn_money($weekRevenue) }}</p>
        </div>

        <div class="glass rounded-2xl p-5 relative overflow-hidden">
            <div class="absolute -right-5 -top-5 w-24 h-24 rounded-full bg-amber-500/10"></div>
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-[11px] font-bold text-ink3">{{ tr('অপেক্ষমাণ অর্ডার', 'Pending orders') }}</p>
                    <p class="text-3xl font-black text-ink mt-1">{{ bn_num(number_format($pendingOrders)) }}</p>
                </div>
                <span class="w-11 h-11 rounded-xl bg-amber-500/15 text-amber-400 flex items-center justify-center text-lg"><i class="fa-solid fa-hourglass-half"></i></span>
            </div>
            <p class="text-[11px] text-ink3 mt-3">{{ tr('শীঘ্রই নিশ্চিত করা প্রয়োজন', 'Needs confirmation soon') }}</p>
        </div>

        <div class="glass rounded-2xl p-5 relative overflow-hidden">
            <div class="absolute -right-5 -top-5 w-24 h-24 rounded-full bg-rose-500/10"></div>
            <div class="flex items-start justify-between">
                <div>
                    <p class="text-[11px] font-bold text-ink3">{{ tr('স্টক শেষ', 'Out of stock') }}</p>
                    <p class="text-3xl font-black text-ink mt-1">{{ bn_num(number_format($outOfStock)) }}</p>
                </div>
                <span class="w-11 h-11 rounded-xl bg-rose-500/15 text-rose-400 flex items-center justify-center text-lg"><i class="fa-solid fa-triangle-exclamation"></i></span>
            </div>
            <a href="{{ route('admin.products.index') }}" class="text-[11px] text-rose-400 font-bold mt-3 inline-flex items-center gap-1 hover:underline">{{ tr('স্টক আপডেট করুন', 'Update stock') }} <i class="fa-solid fa-arrow-right text-[9px]"></i></a>
        </div>
    </div>

    <div class="grid grid-cols-1 xl:grid-cols-3 gap-4 mt-4">
        <div class="glass rounded-2xl p-5 xl:col-span-2">
            <div class="flex items-center justify-between mb-4">
                <div>
                    <h3 class="font-extrabold text-ink text-sm">{{ tr('সাপ্তাহিক অর্ডার প্রবণতা', 'Weekly order trend') }}</h3>
                    <p class="text-[11px] text-ink3">{{ tr('গত ৭ দিনের অর্ডার', 'Orders over the last 7 days') }}</p>
                </div>
                <span class="badge border-line bg-card2 text-ink2"><i class="fa-solid fa-chart-simple text-aqua-400"></i> {{ tr('৭ দিন', '7 days') }}</span>
            </div>
            <div class="h-64">
                <canvas id="weeklyOrdersChart"></canvas>
            </div>
        </div>

        <div class="glass rounded-2xl p-5">
            <h3 class="font-extrabold text-ink text-sm">{{ tr('অর্ডার স্ট্যাটাস', 'Order status') }}</h3>
            <p class="text-[11px] text-ink3 mb-4">{{ tr('বর্তমান পাইপলাইনের বিভাজন', 'Current pipeline breakdown') }}</p>
            <div class="space-y-3">
                @foreach ($statusMeta as $key => $meta)
                    @php $count = (int) ($statusCounts[$key] ?? 0); @endphp
                    <div>
                        <div class="flex items-center justify-between text-xs mb-1.5">
                            <span class="font-bold text-ink2 flex items-center gap-1.5"><i class="fa-solid {{ $meta['icon'] }} text-[10px] text-ink3"></i>{{ $meta['label'] }}</span>
                            <span class="font-black text-ink">{{ bn_num(number_format($count)) }}</span>
                        </div>
                        <div class="h-1.5 rounded-full bg-card2 overflow-hidden">
                            <div class="h-full rounded-full {{ $key === 'cancelled' ? 'bg-rose-500' : 'bg-gradient-to-r from-aqua-500 to-sky-500' }}" style="width: {{ round($count / $totalStatus * 100) }}%"></div>
                        </div>
                    </div>
                @endforeach
            </div>
            <a href="{{ route('admin.orders.index') }}" class="btn-soft w-full justify-center mt-5">{{ tr('সব অর্ডার দেখুন', 'View all orders') }}</a>
        </div>
    </div>

    <div class="glass rounded-2xl mt-4 overflow-hidden">
        <div class="px-5 py-4 flex items-center justify-between border-b border-line/70">
            <div>
                <h3 class="font-extrabold text-ink text-sm">{{ tr('সর্বশেষ অর্ডার', 'Latest orders') }}</h3>
                <p class="text-[11px] text-ink3">{{ tr('সাম্প্রতিক ১০টি অর্ডার', 'Most recent 10 orders') }}</p>
            </div>
            <a href="{{ route('admin.orders.index') }}" class="text-[11px] font-bold text-aqua-400 hover:underline">{{ tr('সব দেখুন', 'View all') }} <i class="fa-solid fa-arrow-right text-[9px]"></i></a>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full admin-table min-w-[720px]">
                <thead class="bg-card2/40">
                    <tr>
                        <th>{{ tr('অর্ডার নং', 'Order no.') }}</th>
                        <th>{{ tr('কাস্টমার', 'Customer') }}</th>
                        <th class="text-center">{{ tr('আইটেম', 'Items') }}</th>
                        <th class="text-right">{{ tr('মোট', 'Total') }}</th>
                        <th>{{ tr('স্ট্যাটাস', 'Status') }}</th>
                        <th>{{ tr('সময়', 'Time') }}</th>
                        <th class="text-right">{{ tr('অ্যাকশন', 'Action') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @forelse ($latestOrders as $order)
                        <tr>
                            <td class="font-bold text-aqua-400">{{ $order->order_number }}</td>
                            <td>
                                <p class="font-bold text-ink">{{ $order->customer_name }}</p>
                                <p class="text-[11px] text-ink3">{{ $order->customer_phone }}</p>
                            </td>
                            <td class="text-center font-bold text-ink2">{{ bn_num(number_format($order->items_count)) }}</td>
                            <td class="text-right font-black text-ink">{{ bn_money($order->grand_total) }}</td>
                            <td><span class="badge {{ order_status_classes($order->status) }}">{{ $statusMeta[$order->status]['label'] ?? ucfirst($order->status) }}</span></td>
                            <td class="text-[11px] text-ink3">{{ bn_num($order->created_at->format('d M, h:i A')) }}</td>
                            <td class="text-right">
                                <a href="{{ route('admin.orders.show', $order) }}" class="btn-soft !px-2.5 !py-1.5 !text-[11px]">{{ tr('বিস্তারিত', 'Details') }}</a>
                            </td>
                        </tr>
                    @empty
                        <tr>
                            <td colspan="7" class="text-center py-10 text-ink3 text-sm">
                                <i class="fa-solid fa-inbox text-3xl block mb-2"></i>
                                {{ tr('এখনো কোনো অর্ডার নেই', 'No orders yet') }}
                            </td>
                        </tr>
                    @endforelse
                </tbody>
            </table>
        </div>
    </div>
@endsection

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <script>
        (function () {
            const ctx = document.getElementById('weeklyOrdersChart');
            if (!ctx) return;
            const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
            const textColor = isDark ? '#98afc2' : '#47616f';
            const gridColor = isDark ? 'rgba(40,60,86,0.6)' : 'rgba(213,229,235,0.9)';

            new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: @json($weekLabels),
                    datasets: [{
                        label: @json(tr('অর্ডার', 'Orders')),
                        data: @json($weekValues),
                        backgroundColor: 'rgba(20,184,166,0.65)',
                        hoverBackgroundColor: 'rgba(45,212,191,0.95)',
                        borderRadius: 8,
                        maxBarThickness: 38
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: { display: false },
                        tooltip: {
                            backgroundColor: 'rgba(9,19,36,0.92)',
                            titleFont: { family: 'Inter' },
                            bodyFont: { family: 'Inter' }
                        }
                    },
                    scales: {
                        x: { ticks: { color: textColor, font: { family: 'Inter' } }, grid: { display: false } },
                        y: { beginAtZero: true, ticks: { color: textColor, precision: 0, font: { family: 'Inter' } }, grid: { color: gridColor } }
                    }
                }
            });
        })();
    </script>
@endpush
