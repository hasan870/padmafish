    <!-- SCROLL TO TOP FLOATING BUTTON (glass) -->
    <button id="scroll-top" onclick="scrollToTop()" aria-label="উপরে যান"
            class="fixed bottom-[calc(5.2rem+env(safe-area-inset-bottom))] md:bottom-5 left-4 md:left-5 z-40 glass-chip w-11 h-11 rounded-2xl text-aqua-500 hover:text-aqua-400 hover:-translate-y-1 flex items-center justify-center text-lg shadow-xl">
        <i class="fa-solid fa-arrow-up"></i>
    </button>
