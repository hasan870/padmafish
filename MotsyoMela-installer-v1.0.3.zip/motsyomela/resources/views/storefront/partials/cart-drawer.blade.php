    <!-- SLIDE-OVER SHOPPING CART DRAWER (frosted glass) -->
    <div id="cart-drawer-overlay" class="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 opacity-0 pointer-events-none transition-opacity duration-300"
         onclick="if (event.target === this) closeCartDrawer()">
        <div id="cart-drawer" class="fixed top-0 right-0 h-full w-full max-w-md glass-strong flex flex-col transform translate-x-full transition-transform duration-300 ease-out z-50 rounded-l-3xl">

            <!-- Drawer Header -->
            <div class="p-4 flex items-center justify-between border-b border-line/70">
                <div class="flex items-center gap-2 text-ink">
                    <i class="fa-solid fa-basket-shopping text-aqua-500 text-lg"></i>
                    <h3 class="font-bold text-base">{{ tr('আপনার শপিং কার্ট', 'Your shopping cart') }}</h3>
                </div>
                <button onclick="closeCartDrawer()" class="text-ink3 hover:text-ink p-2.5 -mr-1 rounded-lg text-lg transition-colors" aria-label="{{ tr('বন্ধ করুন', 'Close') }}">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <!-- Cart Items List -->
            <div id="cart-drawer-items" class="flex-1 overflow-y-auto p-4 divide-y divide-line/60">
                <!-- Dynamic Cart Items injected via JS -->
            </div>

            <!-- Drawer Footer / Summary -->
            <div class="p-4 bg-card2/60 border-t border-line/70 space-y-3 backdrop-blur-md rounded-b-3xl">

                <!-- Coupon Code Section -->
                <div class="flex gap-2">
                    <input type="text" id="coupon-input" placeholder="{{ tr('কুপন কোড (FRESH50)', 'Coupon code (FRESH50)') }}" class="flex-1 bg-card border border-line rounded-xl px-3 py-2.5 text-xs text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 uppercase transition-colors">
                    <button onclick="applyCoupon()" class="btn-glow bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-all active:scale-95">
                        {{ tr('প্রয়োগ', 'Apply') }}
                    </button>
                </div>
                <div id="coupon-message" class="text-[11px] font-semibold hidden"></div>

                <!-- Price Breakdown -->
                <div class="space-y-1.5 text-xs text-ink2 pt-1">
                    <div class="flex justify-between">
                        <span>{{ tr('মাছের মোট মূল্য:', 'Fish subtotal:') }}</span>
                        <span id="cart-subtotal" class="font-bold text-ink">৳০</span>
                    </div>
                    <div class="flex justify-between">
                        <span>{{ tr('ছাড়/ডিসকাউন্ট:', 'Discount:') }}</span>
                        <span id="cart-discount" class="font-bold text-emerald-500">-৳০</span>
                    </div>
                    <div class="flex justify-between">
                        <span>{{ tr('কাটাই ও প্রসেসিং সার্ভিস:', 'Cutting & processing:') }}</span>
                        <span class="font-bold text-emerald-500">{{ tr('ফ্রি', 'Free') }}</span>
                    </div>
                    <div class="flex justify-between text-sm font-black text-ink pt-2 border-t border-line/70">
                        <span>{{ tr('সাবটোটাল:', 'Subtotal:') }}</span>
                        <span id="cart-grandtotal" class="text-aqua-500 dark:text-aqua-400">৳০</span>
                    </div>
                </div>

                <!-- Checkout Button -->
                <button onclick="openCheckoutModal()" class="btn-glow w-full bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white font-bold py-3 rounded-xl text-center shadow-lg shadow-emerald-500/25 text-sm flex items-center justify-center gap-2 transition-all active:scale-95">
                    <i class="fa-solid fa-circle-check"></i> {{ tr('অর্ডার সম্পন্ন করুন (অর্ডার পেজ)', 'Complete order (checkout)') }}
                </button>
            </div>

        </div>
    </div>
