    @if (($settings['theme_bg_style'] ?? 'aurora') === 'aurora')
    <!-- AMBIENT AURORA BACKGROUND (animated, theme-aware) -->
    <div class="aurora" aria-hidden="true">
        <span class="a1"></span>
        <span class="a2"></span>
        <span class="a3"></span>
    </div>
    @endif
