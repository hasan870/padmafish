    <!-- MAIN HEADER NAVIGATION (glassmorphic + theme toggle) -->
    @php
        $logoMode = $settings['theme_logo_mode'] ?? 'image';
        $logoUrl = in_array($logoMode, ['image', 'image_only'], true) && ! empty($settings['theme_logo'])
            ? \Illuminate\Support\Facades\Storage::url($settings['theme_logo'])
            : null;
        // "Image only" hides the site name, badge and tagline. It falls back to
        // the text brand when no image has been uploaded yet.
        $imageOnly = $logoMode === 'image_only' && $logoUrl;
        $showLogoMark = $logoMode === 'image';
        $siteName = $settings['site_name'] ?? 'মৎস্যমেলা';
        $siteTagline = $settings['site_tagline'] ?? '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট';
        $siteBadge = $settings['site_badge'] ?? 'BD';
        $waLink = whatsapp_url($settings['whatsapp_number'] ?? '', 'হ্যালো, আমি মৎস্যমেলা থেকে তাজা মাছ অর্ডার করতে চাই।');
        $sitePhone = $settings['site_phone'] ?? '';
    @endphp
    <header class="sticky top-0 z-40 glass-header text-ink shadow-lg">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex items-center justify-between h-16 sm:h-20 gap-3 sm:gap-4">

                <!-- Brand Logo -->
                <a href="{{ url('/') }}" onclick="return handleHomeNav(event)" class="flex items-center gap-2.5 sm:gap-3 min-w-0 group">
                    @if ($logoUrl)
                        {{-- Uploaded logo image: no gradient box, shadow or padding — just the image, a little larger. --}}
                        <img src="{{ $logoUrl }}" alt="{{ $siteName }}"
                             class="h-11 sm:h-14 w-auto max-w-[7rem] sm:max-w-[12rem] object-contain shrink-0 group-hover:scale-105 transition-transform">
                    @elseif ($showLogoMark)
                        <div class="logo-badge w-10 h-10 sm:w-12 sm:h-12 shrink-0 rounded-2xl bg-gradient-to-tr from-aqua-600 via-sky-500 to-emerald-400 flex items-center justify-center text-white text-xl sm:text-2xl shadow-lg shadow-aqua-500/30 group-hover:scale-110 transition-transform overflow-hidden">
                            <i class="fa-solid fa-fish-fins"></i>
                        </div>
                    @endif
                    @unless ($imageOnly)
                        <div class="min-w-0">
                            <div class="flex items-center gap-1.5">
                                <span class="{{ ($showLogoMark || $logoUrl) ? 'text-lg max-[360px]:text-base sm:text-2xl' : 'text-2xl max-[360px]:text-lg sm:text-3xl' }} font-black tracking-tight text-ink truncate max-w-[11rem] sm:max-w-none group-hover:text-aqua-500 dark:group-hover:text-aqua-300 transition-colors">{{ $siteName }}</span>
                                @if ($siteBadge !== '')
                                    <span class="max-[360px]:hidden bg-aqua-500/15 text-aqua-600 dark:text-aqua-300 text-[10px] font-bold px-1.5 py-0.5 rounded border border-aqua-500/30">{{ $siteBadge }}</span>
                                @endif
                            </div>
                            <p class="hidden sm:block text-[10px] sm:text-[11px] text-aqua-600 dark:text-aqua-400 font-medium tracking-wide truncate max-w-[10rem] sm:max-w-xs">{{ $siteTagline }}</p>
                        </div>
                    @endunless
                </a>

                <!-- Bangla Live Search Bar -->
                <div class="hidden md:flex flex-1 max-w-lg mx-6 relative">
                    <div class="relative w-full">
                        <input type="text" id="desktop-search" oninput="handleSearchInput(this.value)"
                               placeholder="{{ tr('মাছ খুঁজুন (যেমন: ইলিশ, রুই, গলদা চিংড়ি, রূপচাঁদা)...', 'Search fish (e.g. Hilsa, Rohu, Prawn, Pomfret)...') }}"
                               class="w-full bg-card2/70 focus:bg-card2 border border-line focus:border-aqua-500 rounded-xl py-2.5 pl-10 pr-10 text-sm text-ink placeholder:text-ink3 focus:outline-none focus:ring-2 focus:ring-aqua-500/30 transition-all">
                        <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-3.5 text-ink3"></i>
                        <button id="clear-search-btn" onclick="clearSearch()" class="hidden absolute right-3 top-3 text-ink3 hover:text-ink transition-colors">
                            <i class="fa-solid fa-xmark"></i>
                        </button>
                    </div>
                </div>

                <!-- Navigation Action Controls -->
                <div class="flex items-center gap-1.5 sm:gap-3.5 shrink-0">

                    <!-- Mobile menu lives in the bottom navigation bar, so no hamburger here -->

                    <!-- Mobile search trigger -->
                    <button type="button" onclick="openMobileSearch()" aria-label="মাছ খুঁজুন"
                            class="md:hidden glass-chip w-10 h-10 rounded-xl text-ink2 hover:text-ink transition-colors flex items-center justify-center">
                        <i class="fa-solid fa-magnifying-glass text-base"></i>
                    </button>

                    <!-- LANGUAGE TOGGLE (Bangla / English) — hidden on phones, the mobile drawer has it -->
                    <form method="POST" action="{{ route('language.switch', app()->getLocale() === 'en' ? 'bn' : 'en') }}" class="hidden sm:flex">
                        @csrf
                        <button type="submit" aria-label="{{ app()->getLocale() === 'en' ? 'বাংলায় দেখুন' : 'Switch to English' }}" title="{{ app()->getLocale() === 'en' ? 'বাংলায় দেখুন' : 'Switch to English' }}"
                                class="glass-chip h-10 px-2.5 rounded-xl text-ink2 hover:text-ink transition-colors flex items-center justify-center gap-1.5">
                            <i class="fa-solid fa-language text-base"></i>
                            <span class="text-[11px] font-bold">{{ app()->getLocale() === 'en' ? 'বাংলা' : 'EN' }}</span>
                        </button>
                    </form>

                    <!-- THEME TOGGLE (Dark / Light) -->
                    <button id="theme-toggle" onclick="toggleTheme()" aria-label="থিম পরিবর্তন করুন" title="লাইট / ডার্ক মোড"
                            class="theme-toggle glass-chip w-10 h-10 rounded-xl text-ink2 hover:text-ink transition-colors hidden sm:flex items-center justify-center">
                        <i class="fa-solid fa-sun icon-sun text-base"></i>
                        <i class="fa-solid fa-moon icon-moon text-base"></i>
                    </button>

                    <!-- Account / Login Button -->
                    @auth('web')
                        <a href="{{ route('account.index') }}" class="glass-chip p-2.5 rounded-xl text-ink2 hover:text-ink transition-colors hidden sm:flex items-center gap-2" title="আমার অর্ডার">
                            <i class="fa-regular fa-user text-lg"></i>
                            <span class="hidden lg:inline text-xs font-semibold">আমার অর্ডার</span>
                        </a>
                    @else
                        <a href="{{ route('account.login') }}" class="glass-chip p-2.5 rounded-xl text-ink2 hover:text-ink transition-colors hidden sm:flex items-center gap-2" title="লগইন">
                            <i class="fa-regular fa-user text-lg"></i>
                            <span class="hidden lg:inline text-xs font-semibold">লগইন</span>
                        </a>
                    @endauth

                    <!-- Cart Drawer Trigger Button -->
                    <button onclick="openCartDrawer()" class="relative bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white px-3 sm:px-4 py-2.5 rounded-xl flex items-center gap-2.5 shadow-lg shadow-aqua-600/30 transition-all transform active:scale-95">
                        <div class="relative">
                            <i class="fa-solid fa-bag-shopping text-lg"></i>
                            <span id="cart-badge-count" class="absolute -top-2 -right-2.5 bg-gold-500 text-slate-950 text-[10px] font-black w-4 h-4 rounded-full flex items-center justify-center border-2 border-app">0</span>
                        </div>
                        <div class="hidden sm:flex flex-col text-left leading-none">
                            <span class="text-[10px] text-aqua-100 font-medium">{{ tr('কার্ট আইটেম', 'Cart items') }}</span>
                            <span id="cart-badge-total" class="text-xs font-bold">৳০</span>
                        </div>
                    </button>
                </div>
            </div>

        </div>

        <!-- QUICK MENU + CATEGORY NAVIGATION BAR (glass strip) -->
        <div class="bg-card2/40 border-t border-line/60 backdrop-blur-md overflow-x-auto scrollbar-none">
            <div class="max-w-7xl mx-auto px-4 flex items-center gap-1.5 py-2 text-xs font-medium whitespace-nowrap">
                @if ($menuItems->isNotEmpty())
                    <nav class="hidden md:flex items-center gap-0.5 pr-2 mr-1 border-r border-line/60" aria-label="হেডার মেনু">
                        @foreach ($menuItems as $menuItem)
                            <a href="{{ $menuItem->url }}" target="{{ $menuItem->target }}" @if ($menuItem->target === '_blank') rel="noopener" @endif
                               @if ($menuItem->target === '_self') onclick="return handleHeaderNav(event)" @endif
                               class="px-2.5 py-1.5 rounded-lg text-ink2 hover:text-ink hover:bg-card2 transition-colors flex items-center gap-1.5">
                                @if ($menuItem->icon)<i class="fa-solid {{ $menuItem->icon }} text-[10px]"></i>@endif
                                {{ localized($menuItem->label_bn, $menuItem->label_en) }}
                            </a>
                        @endforeach
                    </nav>
                @endif
                <button onclick="filterByCategory('all')" id="cat-tab-all" class="category-tab tab-active px-3.5 py-2.5 rounded-lg flex items-center gap-1.5">
                    <i class="fa-solid fa-border-all"></i> {{ tr('সকল মাছ', 'All fish') }}
                </button>
                @foreach ($categories as $category)
                <button onclick="filterByCategory('{{ $category->slug }}')" id="cat-tab-{{ $category->slug }}" class="category-tab {{ $category->slug === 'offer' ? 'bg-gold-500/15 text-gold-500 dark:text-gold-400 border border-gold-500/30 hover:bg-gold-500/25' : 'bg-card2/70 text-ink2 hover:bg-card2 hover:text-ink' }} px-3.5 py-2.5 rounded-lg flex items-center gap-1.5">
                    <i class="fa-solid {{ $category->icon }}"></i> {{ localized($category->name_bn, $category->name_en) }}
                </button>
                @endforeach
                @if ($combo['enabled'])
                <a href="#combo-section" class="bg-gradient-to-r from-gold-500/20 to-amber-500/20 text-gold-500 dark:text-gold-400 border border-gold-500/40 hover:from-gold-500/35 hover:to-amber-500/35 px-3.5 py-2.5 rounded-lg flex items-center gap-1.5 transition-all">
                    <i class="fa-solid fa-gift"></i> {{ tr('কম্বো প্যাকেজ', 'Combo packages') }}
                </a>
                @endif
            </div>
        </div>
    </header>

    <!-- MOBILE MENU DRAWER -->
    <div id="mobile-menu-overlay" class="fixed inset-0 z-[60] bg-slate-950/60 backdrop-blur-sm opacity-0 pointer-events-none transition-opacity duration-200 md:hidden" onclick="closeMobileMenu()"></div>
    <aside id="mobile-menu-drawer" aria-hidden="true" aria-label="মোবাইল মেনু"
           class="fixed inset-y-0 left-0 z-[70] w-[86%] max-w-sm glass-strong border-r border-line md:hidden -translate-x-full transition-transform duration-300 ease-out flex flex-col"
           style="padding-top: env(safe-area-inset-top);">
        <div class="px-4 py-4 border-b border-line/70 flex items-center justify-between shrink-0">
            <a href="{{ url('/') }}" class="flex items-center gap-2.5 min-w-0">
                @if ($logoUrl)
                    <img src="{{ $logoUrl }}" alt="{{ $siteName }}" class="h-10 w-auto max-w-[8rem] object-contain shrink-0">
                @elseif ($showLogoMark)
                    <span class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-aqua-600 via-sky-500 to-emerald-400 flex items-center justify-center text-white text-lg shadow-lg shadow-aqua-500/30 overflow-hidden shrink-0">
                        <i class="fa-solid fa-fish-fins"></i>
                    </span>
                @endif
                @unless ($imageOnly)
                    <span class="min-w-0">
                        <span class="block font-black text-ink text-base leading-tight truncate">{{ $siteName }}</span>
                        <span class="block text-[10px] text-ink3 truncate">{{ $siteTagline }}</span>
                    </span>
                @endunless
            </a>                        <button type="button" onclick="closeMobileMenu()" aria-label="মেনু বন্ধ করুন" class="text-ink3 hover:text-ink p-2.5 -mr-1 rounded-lg">
                <i class="fa-solid fa-xmark text-lg"></i>
            </button>
        </div>

        <div class="px-4 pt-3 shrink-0">
            <button type="button" onclick="openMobileSearch()" class="w-full flex items-center gap-2.5 bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-left text-sm text-ink3 active:scale-[.99] transition-transform">
                <i class="fa-solid fa-magnifying-glass text-aqua-500"></i>
                <span>{{ tr('মাছ খুঁজুন...', 'Search fish...') }}</span>
            </button>
        </div>

        <div class="flex-1 overflow-y-auto sidebar-scroll px-4 py-4 space-y-5">
            @if ($menuItems->isNotEmpty())
                <div>
                    <p class="px-1 pb-2 text-[10px] uppercase tracking-widest text-ink3 font-extrabold">{{ tr('মেনু', 'Menu') }}</p>
                    <div class="space-y-1">
                        @foreach ($menuItems as $menuItem)
                            <a href="{{ $menuItem->url }}" target="{{ $menuItem->target }}" @if ($menuItem->target === '_blank') rel="noopener" @endif
                               onclick="closeMobileMenu()"
                               class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                                <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-aqua-500 flex items-center justify-center text-xs shrink-0">
                                    <i class="fa-solid {{ $menuItem->icon ?: 'fa-angle-right' }}"></i>
                                </span>
                                <span class="flex-1 min-w-0 truncate">{{ localized($menuItem->label_bn, $menuItem->label_en) }}</span>
                                <i class="fa-solid fa-chevron-right text-[10px] text-ink3"></i>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endif

            <div>
                <p class="px-1 pb-2 text-[10px] uppercase tracking-widest text-ink3 font-extrabold">{{ tr('ক্যাটাগরি', 'Categories') }}</p>
                <div class="grid grid-cols-2 gap-2">
                    <button type="button" onclick="mobilePickCategory('all')" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-card2/70 border border-line text-xs font-bold text-ink2 hover:text-ink transition-colors">
                        <i class="fa-solid fa-border-all text-aqua-500"></i> {{ tr('সকল মাছ', 'All fish') }}
                    </button>
                    @foreach ($categories as $category)
                        <button type="button" onclick="mobilePickCategory('{{ $category->slug }}')" class="flex items-center gap-2 px-3 py-2.5 rounded-xl bg-card2/70 border border-line text-xs font-bold text-ink2 hover:text-ink transition-colors">
                            <i class="fa-solid {{ $category->icon }} text-aqua-500"></i> {{ localized($category->name_bn, $category->name_en) }}
                        </button>
                    @endforeach
                </div>
            </div>

            <div>
                <p class="px-1 pb-2 text-[10px] uppercase tracking-widest text-ink3 font-extrabold">{{ tr('দ্রুত অ্যাকশন', 'Quick actions') }}</p>
                <div class="space-y-1">
                    <button type="button" onclick="toggleTheme()" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                        <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-gold-500 flex items-center justify-center text-xs"><i class="fa-solid fa-moon"></i></span>
                        <span class="flex-1 text-left">{{ tr('ডার্ক / লাইট মোড', 'Dark / light mode') }}</span>
                    </button>
                    <form method="POST" action="{{ route('language.switch', app()->getLocale() === 'en' ? 'bn' : 'en') }}" class="w-full">
                        @csrf
                        <button type="submit" onclick="closeMobileMenu()" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                            <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-sky-500 flex items-center justify-center text-xs"><i class="fa-solid fa-language"></i></span>
                            <span class="flex-1 text-left">{{ app()->getLocale() === 'en' ? 'বাংলা ভাষায় দেখুন' : 'Switch to English' }}</span>
                        </button>
                    </form>
                    <button type="button" onclick="closeMobileMenu(); openCartDrawer();" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                        <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-aqua-500 flex items-center justify-center text-xs"><i class="fa-solid fa-bag-shopping"></i></span>
                        <span class="flex-1 text-left">{{ tr('কার্ট দেখুন', 'View cart') }}</span>
                    </button>
                    @auth('web')
                        <a href="{{ route('account.index') }}" onclick="closeMobileMenu()" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                            <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-sky-500 flex items-center justify-center text-xs"><i class="fa-regular fa-user"></i></span>
                            <span class="flex-1">{{ tr('আমার অর্ডার ও প্রোফাইল', 'My orders & profile') }}</span>
                        </a>
                        <form method="POST" action="{{ route('account.logout') }}" class="w-full">
                            @csrf
                            <button type="submit" class="w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-rose-500 hover:text-rose-400 hover:bg-rose-500/10 transition-colors">
                                <span class="w-8 h-8 rounded-lg bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-xs"><i class="fa-solid fa-right-from-bracket"></i></span>
                                <span class="flex-1 text-left">{{ tr('লগআউট', 'Log out') }}</span>
                            </button>
                        </form>
                    @else
                        <a href="{{ route('account.login') }}" onclick="closeMobileMenu()" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                            <span class="w-8 h-8 rounded-lg bg-card2 border border-line text-sky-500 flex items-center justify-center text-xs"><i class="fa-regular fa-user"></i></span>
                            <span class="flex-1">{{ tr('লগইন / অ্যাকাউন্ট', 'Login / account') }}</span>
                        </a>
                    @endauth
                    @if ($waLink)
                        <a href="{{ $waLink }}" target="_blank" rel="noopener" onclick="closeMobileMenu()" class="flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm font-bold text-ink2 hover:text-ink hover:bg-card2/70 transition-colors">
                            <span class="w-8 h-8 rounded-lg bg-[#25D366]/15 text-[#25D366] flex items-center justify-center text-xs"><i class="fa-brands fa-whatsapp"></i></span>
                            <span class="flex-1">{{ tr('WhatsApp-এ কথা বলুন', 'Chat on WhatsApp') }}</span>
                            <i class="fa-solid fa-chevron-right text-[10px] text-ink3"></i>
                        </a>
                    @endif
                </div>
            </div>
        </div>

        <div class="px-4 py-3 border-t border-line/70 shrink-0" style="padding-bottom: calc(0.75rem + env(safe-area-inset-bottom));">
            @if ($sitePhone !== '')
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $sitePhone) }}" class="flex items-center justify-center gap-2 text-xs font-bold text-ink2 hover:text-ink py-2">
                    <i class="fa-solid fa-phone-volume text-aqua-500"></i>
                    {{ tr('হটলাইন', 'Hotline') }}: {{ $sitePhone }}
                </a>
            @endif
        </div>
    </aside>

    <!-- MOBILE SEARCH OVERLAY -->
    <div id="mobile-search-overlay" class="fixed inset-0 z-[80] md:hidden opacity-0 pointer-events-none transition-opacity duration-200" onclick="closeMobileSearch()">
        <div class="absolute inset-0 bg-slate-950/70 backdrop-blur-sm"></div>
        <div id="mobile-search-panel" class="absolute inset-x-0 top-0 glass-strong border-b border-line p-4 -translate-y-3 transition-transform duration-200"
             style="padding-top: calc(1rem + env(safe-area-inset-top));" onclick="event.stopPropagation()">
            <div class="flex items-center gap-2">
                <div class="relative flex-1">
                    <input type="search" id="mobile-search" oninput="handleSearchInput(this.value)"
                           onkeydown="if (event.key === 'Enter') { event.preventDefault(); closeMobileSearch(); scrollToProducts(); }"
                           placeholder="{{ tr('মাছ খুঁজুন (ইলিশ, রুই, পাবদা)...', 'Search fish (Hilsa, Rohu, Pabda)...') }}"
                           autocomplete="off"
                           class="w-full bg-card2/80 border border-line rounded-xl py-2.5 pl-10 pr-10 text-base text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                    <i class="fa-solid fa-magnifying-glass absolute left-3.5 top-3.5 text-ink3"></i>
                    <button id="mobile-clear-search-btn" type="button" onclick="handleSearchInput('')" class="hidden absolute right-3 top-3 text-ink3 hover:text-ink transition-colors" aria-label="সার্চ মুছুন">
                        <i class="fa-solid fa-xmark"></i>
                    </button>
                </div>
                <button type="button" onclick="closeMobileSearch()" aria-label="সার্চ বন্ধ করুন" class="w-10 h-10 rounded-xl bg-card2/80 border border-line text-ink2 flex items-center justify-center">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <div class="flex items-center gap-2 mt-3 overflow-x-auto scrollbar-none">
                <span class="text-[10px] font-bold text-ink3 shrink-0">{{ tr('জনপ্রিয়', 'Popular') }}:</span>
                @foreach (['ইলিশ' => 'Hilsa', 'রুই' => 'Rohu', 'চিংড়ি' => 'Prawn', 'পাবদা' => 'Pabda'] as $term => $termEn)
                    <button type="button" onclick="mobileSearchChip('{{ $term }}')" class="shrink-0 px-3 py-2 rounded-full bg-card2/80 border border-line text-xs font-bold text-ink2 hover:text-ink transition-colors">{{ tr($term, $termEn) }}</button>
                @endforeach
            </div>

            <button type="button" onclick="closeMobileSearch(); scrollToProducts();" class="mt-3 w-full bg-gradient-to-r from-aqua-600 to-sky-600 text-white font-bold py-2.5 rounded-xl text-sm active:scale-[.99] transition-transform">
                {{ tr('ফলাফল দেখুন', 'View results') }}
            </button>
        </div>
    </div>
