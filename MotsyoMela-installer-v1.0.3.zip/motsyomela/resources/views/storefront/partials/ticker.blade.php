    <!-- TOP URGENT ANNOUNCEMENT BAR (live marquee ticker) -->
    @php
        $tickerWhatsApp = whatsapp_url($settings['whatsapp_number'] ?? '', 'হ্যালো, আমি মৎস্যমেলা থেকে অর্ডার করতে চাই।');
        $tickerPhone = (string) ($settings['site_phone'] ?? '');
        $tickerHours = (string) ($settings['delivery_hours'] ?? '');
    @endphp
    <div class="topbar text-xs sm:text-sm py-2 px-4 relative z-40">
        <div class="max-w-7xl mx-auto flex flex-col sm:flex-row justify-between items-center gap-2">
            <div class="flex items-center gap-2 min-w-0 flex-1 w-full sm:w-auto">
                <span class="bg-gold-500 text-slate-950 text-[11px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1 shrink-0 animate-pulse">
                    <i class="fa-solid fa-bolt text-xs"></i> {{ tr('তাজা স্টক আপডেট', 'Fresh stock update') }}
                </span>
                <div class="ticker-wrap min-w-0 flex-1 overflow-hidden">
                    <div class="ticker">
                        <span class="px-10 font-medium">{{ $tickerMessage }} &nbsp;🐟&nbsp; {{ $tickerMessage }}</span>
                        <span class="px-10 font-medium">{{ $tickerMessage }} &nbsp;🐟&nbsp; {{ $tickerMessage }}</span>
                    </div>
                </div>
            </div>
            <div class="flex items-center gap-4 sm:gap-5 text-xs font-medium shrink-0">
                @if ($tickerPhone !== '')
                    <a href="tel:{{ preg_replace('/[^0-9+]/', '', $tickerPhone) }}" class="py-1.5 hover:text-aqua-300 transition-colors flex items-center gap-1.5">
                        <i class="fa-solid fa-headset text-aqua-300"></i> {{ tr('হটলাইন:', 'Hotline:') }} {{ bn_num($tickerPhone) }}
                    </a>
                @endif
                @if ($tickerWhatsApp)
                    <a href="{{ $tickerWhatsApp }}" target="_blank" rel="noopener" class="py-1.5 hover:text-emerald-300 transition-colors flex items-center gap-1.5">
                        <i class="fa-brands fa-whatsapp text-emerald-300"></i> {{ tr('হোয়াটসঅ্যাপ অর্ডার', 'Order on WhatsApp') }}
                    </a>
                @endif
                <span class="hidden md:inline-block opacity-40">|</span>
                <span class="hidden md:inline-flex items-center gap-1 text-gold-300">
                    <i class="fa-solid fa-truck-ramp-box"></i> {{ tr('ডেলিভারি:', 'Delivery:') }} {{ $tickerHours }}
                </span>
            </div>
        </div>
    </div>
