    <!-- MULTI-STEP CHECKOUT MODAL (frosted glass) -->
    <div id="checkout-modal" class="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-50 flex items-center justify-center p-3 sm:p-4 opacity-0 pointer-events-none transition-opacity duration-300"
         onclick="if (event.target === this) closeCheckoutModal()">
        <div id="checkout-panel" class="modal-panel glass-strong w-full max-w-2xl rounded-3xl overflow-hidden max-h-[92vh] flex flex-col">
            <div class="mobile-sheet-grabber"></div>

            <!-- Checkout Header -->
            <div class="bg-card2/60 border-b border-line/70 text-ink p-4 sm:p-5 flex justify-between items-center shrink-0 backdrop-blur-md">
                <div>
                    <h3 class="text-lg font-bold flex items-center gap-2">
                        <i class="fa-solid fa-truck-fast text-aqua-500"></i> {{ tr('ডেলিভারি ও অর্ডার তথ্য', 'Delivery & order details') }}
                    </h3>
                    <p class="text-xs text-ink3 mt-0.5">{{ tr('অর্ডার নিশ্চিতে আপনার সঠিক ঠিকানা প্রদান করুন', 'Provide your correct address to confirm the order') }}</p>
                </div>
                <button onclick="closeCheckoutModal()" class="text-ink3 hover:text-ink text-xl p-2 -mr-1 rounded-lg transition-colors" aria-label="{{ tr('বন্ধ করুন', 'Close') }}">
                    <i class="fa-solid fa-xmark"></i>
                </button>
            </div>

            <!-- Checkout Form Content -->
            <div class="p-5 sm:p-6 overflow-y-auto space-y-5">

                <!-- Personal Info Inputs -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('আপনার পূর্ণ নাম *', 'Your full name *') }}</label>
                        <input type="text" id="cust-name" value="{{ auth('web')->user()?->name }}" placeholder="{{ tr('যেমন: মো: আব্দুর রহিম', 'e.g. Md. Abdur Rahim') }}" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-xs text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('মোবাইল নম্বর *', 'Mobile number *') }}</label>
                        <input type="tel" id="cust-phone" placeholder="{{ tr('০১৭০০-০০০০০০', '01700-000000') }}" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-xs text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                    </div>
                    <div class="sm:col-span-2">
                        <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('ইমেইল (ঐচ্ছিক)', 'Email (optional)') }}</label>
                        <input type="email" id="cust-email" value="{{ auth('web')->user()?->email }}" placeholder="you@example.com" autocomplete="email" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-xs text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                        <p class="text-[10px] text-ink3 mt-1"><i class="fa-regular fa-envelope mr-1"></i>{{ tr('অর্ডার কনফার্মেশন ও ইনভয়েস ইমেইলে পাঠানো হবে।', 'Order confirmation and invoice will be emailed to you.') }}</p>
                    </div>
                </div>

                <!-- Delivery Zone & Time Slot -->
                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('ডেলিভারি এলাকা *', 'Delivery area *') }}</label>
                        <select id="cust-zone" onchange="calculateFinalTotal()" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-xs font-medium text-ink focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                            @foreach ($zones as $zone)
                            <option value="{{ $zone->id }}" data-charge="{{ (int) $zone->charge }}">{{ localized($zone->name_bn, $zone->name_en) }} - ৳{{ bn_num((int) $zone->charge) }} {{ tr('ডেলিভারি', 'delivery') }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('ডেলিভারি সময় বেছে নিন *', 'Choose a delivery time *') }}</label>
                        <select id="cust-timeslot" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2.5 text-xs font-medium text-ink focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                            @foreach ($slots as $slot)
                            <option value="{{ $slot->label_bn }}">{{ localized($slot->label_bn, $slot->label_en) }}</option>
                            @endforeach
                        </select>
                    </div>
                </div>

                <!-- Detailed Address -->
                <div>
                    <label class="block text-xs font-bold text-ink2 mb-1">{{ tr('পূর্ণাঙ্গ ঠিকানা (বাসা নম্বর, রোড, এলাকা) *', 'Full address (house, road, area) *') }}</label>
                    <textarea id="cust-address" rows="2" placeholder="{{ tr('যেমন: বাসা-২৪, রোড-৫, ব্লক-বি, মিরপুর-১২, ঢাকা', 'e.g. House 24, Road 5, Block B, Mirpur-12, Dhaka') }}" class="w-full bg-card2/70 border border-line rounded-xl p-3 text-xs text-ink placeholder:text-ink3 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all"></textarea>
                </div>

                <!-- Payment Method Selector -->
                @php
                    $paymentOptions = [
                        'cod' => ['label' => tr('ক্যাশ অন ডেলিভারি', 'Cash on delivery'), 'sub' => tr('হাতে পেয়ে দিন', 'Pay on delivery'), 'icon' => 'fa-hand-holding-dollar', 'color' => 'text-ink'],
                        'bkash' => ['label' => 'bKash', 'sub' => tr('বিকাশ', 'bKash'), 'icon' => 'fa-mobile-screen-button', 'color' => 'text-pink-500'],
                        'nagad' => ['label' => 'Nagad', 'sub' => tr('নগদ', 'Nagad'), 'icon' => 'fa-mobile-screen-button', 'color' => 'text-orange-500'],
                        'card' => ['label' => tr('কার্ড', 'Card'), 'sub' => tr('অনলাইন গেটওয়ে', 'Online gateway'), 'icon' => 'fa-credit-card', 'color' => 'text-sky-500'],
                    ];
                    $enabledPayments = array_filter(
                        $paymentOptions,
                        fn ($key) => ($settings['payment_'.$key.'_enabled'] ?? '1') === '1',
                        ARRAY_FILTER_USE_KEY
                    );
                @endphp
                <div>
                    <label class="block text-xs font-bold text-ink2 mb-2">{{ tr('পেমেন্ট মেথড সিলেক্ট করুন', 'Select a payment method') }}</label>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-2.5 sm:gap-3">
                        @foreach ($enabledPayments as $key => $payment)
                        <label class="payment-radio cursor-pointer border border-line bg-card2/40 p-3 rounded-xl flex flex-col items-center text-center gap-1 transition-all hover:border-aqua-500/60">
                            <input type="radio" name="payment" value="{{ $key }}" @checked($loop->first) class="sr-only">
                            @php $gatewayIcon = payment_icon_url($settings, $key); @endphp
                            @if ($gatewayIcon)
                                <img src="{{ $gatewayIcon }}" alt="{{ $payment['label'] }}" class="h-6 w-auto max-w-[4.5rem] object-contain bg-white rounded px-1 py-0.5">
                            @else
                                <i class="fa-solid {{ $payment['icon'] }} {{ $payment['color'] }} text-lg"></i>
                            @endif
                            <span class="text-xs font-bold text-ink">{{ $payment['label'] }}</span>
                            <span class="text-[10px] text-ink3">{{ $payment['sub'] }}</span>
                        </label>
                        @endforeach
                    </div>
                    <p class="text-[10px] text-ink3 mt-2"><i class="fa-solid fa-shield-halved mr-1 text-emerald-500"></i>{{ tr('পেমেন্ট নম্বর, লিংক ও ধাপে ধাপে নির্দেশনা অর্ডার সম্পন্নের পর দেখানো হবে।', 'The payment number, link and step-by-step instructions will be shown after you place the order.') }}</p>
                </div>

                <!-- Order Final Breakdown Table -->
                <div class="bg-card2/60 border border-line p-4 rounded-2xl text-xs space-y-1.5 backdrop-blur-sm">
                    <div class="flex justify-between text-ink2">
                        <span>{{ tr('মাছের দাম মোট:', 'Fish subtotal:') }}</span>
                        <span id="final-subtotal" class="font-semibold text-ink">৳০</span>
                    </div>
                    <div class="flex justify-between text-ink2">
                        <span>{{ tr('কুপন ডিসকাউন্ট:', 'Coupon discount:') }}</span>
                        <span id="final-discount" class="text-emerald-500 font-semibold">-৳০</span>
                    </div>
                    <div class="flex justify-between text-ink2">
                        <span>{{ tr('ডেলিভারি চার্জ:', 'Delivery charge:') }}</span>
                        <span id="final-delivery" class="font-semibold text-ink">৳৮০</span>
                    </div>
                    <div class="flex justify-between text-sm font-black text-ink pt-2 border-t border-line/70">
                        <span>{{ tr('সর্বমোট দেয় টাকা:', 'Total payable:') }}</span>
                        <span id="final-total" class="text-aqua-500 dark:text-aqua-400 text-base">৳০</span>
                    </div>
                </div>

            </div>

            <!-- Checkout Action Footer -->
            <div class="p-4 bg-card2/60 border-t border-line/70 shrink-0 backdrop-blur-md">
                <button id="checkout-submit-btn" onclick="submitOrder()" class="btn-glow w-full bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white font-bold py-3.5 rounded-xl text-center text-sm shadow-xl shadow-emerald-600/25 transition-all flex items-center justify-center gap-2 active:scale-95">
                    <i class="fa-solid fa-circle-check"></i> {{ tr('কনফার্ম অর্ডার করুন', 'Confirm order') }}
                </button>
            </div>

        </div>
    </div>
