    <!-- FOOTER SECTION (theme-aware, admin-editable) -->
    @php
        $footerLogoMode = $settings['theme_logo_mode'] ?? 'image';
        $footerLogo = $footerLogoMode !== 'text' && ! empty($settings['theme_logo']) ? \Illuminate\Support\Facades\Storage::url($settings['theme_logo']) : null;
        $footerImageOnly = $footerLogoMode === 'image_only' && $footerLogo;
        $footerSiteName = $settings['site_name'] ?? 'মৎস্যমেলা';
        $footerTagline = $settings['site_tagline'] ?? '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট';
        $footerAbout = trim((string) ($settings['footer_about_text'] ?? ''))
            ?: tr('বাংলাদেশের প্রিমিয়াম অনলাইন মাছের বাজার। কেমিক্যালমুক্ত তাজা মাছ নিয়ে আমরা আছি আপনার পাশে।', "Bangladesh's premium online fish market. We are here for you with chemical-free fresh fish.");
        $footerAddress = trim((string) ($settings['footer_address'] ?? ''))
            ?: tr('কারওয়ান বাজার, গাবতলী, গুলশান ও চট্টগ্রাম পোর্ট', 'Karwan Bazar, Gabtoli, Gulshan & Chattogram Port');
        $footerHotlineNote = trim((string) ($settings['footer_hotline_note'] ?? ''));
        $footerPaymentNote = trim((string) ($settings['footer_payment_note'] ?? ''))
            ?: tr('ক্যাশ অন ডেলিভারি ও মোবাইল ব্যাংকিং/কার্ডে নিরাপদ পেমেন্ট করুন', 'Pay securely with cash on delivery, mobile banking or card');
        $footerCopyright = trim((string) ($settings['footer_copyright'] ?? ''))
            ?: tr('সর্বস্বত্ব সংরক্ষিত। কেমিক্যালমুক্ত তাজা মাছের নির্ভরযোগ্য বিশ্বস্ত প্রতিষ্ঠান।', 'All rights reserved. Your trusted source for chemical-free fresh fish.');

        $footerWhatsAppLink = trim((string) ($settings['footer_whatsapp_url'] ?? ''))
            ?: whatsapp_url($settings['whatsapp_number'] ?? '', 'হ্যালো, আমি মৎস্যমেলা সম্পর্কে জানতে চাই।');

        $footerSocials = array_values(array_filter([
            ['url' => trim((string) ($settings['footer_facebook_url'] ?? '')), 'icon' => 'fa-facebook-f', 'label' => 'Facebook', 'hover' => 'hover:bg-[#1877F2] hover:border-[#1877F2]'],
            ['url' => trim((string) ($settings['footer_youtube_url'] ?? '')), 'icon' => 'fa-youtube', 'label' => 'YouTube', 'hover' => 'hover:bg-[#FF0000] hover:border-[#FF0000]'],
            ['url' => trim((string) ($settings['footer_instagram_url'] ?? '')), 'icon' => 'fa-instagram', 'label' => 'Instagram', 'hover' => 'hover:bg-[#E1306C] hover:border-[#E1306C]'],
            ['url' => (string) $footerWhatsAppLink, 'icon' => 'fa-whatsapp', 'label' => 'WhatsApp', 'hover' => 'hover:bg-emerald-600 hover:border-emerald-600'],
        ], fn ($social) => $social['url'] !== ''));

        $footerPages = \App\Models\Page::query()
            ->where('is_active', true)
            ->where('show_in_footer', true)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get();
    @endphp
    <footer class="site-footer text-xs py-12 border-t border-line/70 mt-12">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-10">

                <div class="space-y-3">
                    @if ($footerImageOnly)
                        <a href="{{ url('/') }}" class="inline-flex items-center gap-2 group">
                            <img src="{{ $footerLogo }}" alt="{{ $footerSiteName }}" class="h-10 w-auto max-w-[10rem] object-contain transition-transform group-hover:scale-105">
                        </a>
                    @else
                        <div class="flex items-center gap-2 text-ink font-bold text-lg">
                            @if ($footerLogo)
                                <img src="{{ $footerLogo }}" alt="{{ $footerSiteName }}" class="h-8 w-auto max-w-[4rem] object-contain">
                            @elseif ($footerLogoMode !== 'text')
                                <i class="fa-solid fa-fish-fins text-aqua-500"></i>
                            @endif
                            {{ $footerSiteName }}
                        </div>
                    @endif
                    <p class="text-xs font-semibold">{{ $footerTagline }}</p>
                    <p class="text-xs leading-relaxed">{{ $footerAbout }}</p>
                    @if (count($footerSocials))
                        <div class="flex items-center gap-3 pt-2">
                            @foreach ($footerSocials as $social)
                                <a href="{{ $social['url'] }}" target="_blank" rel="noopener" aria-label="{{ $social['label'] }}"
                                   class="w-9 h-9 rounded-full bg-card2 border border-line text-ink2 hover:text-white flex items-center justify-center transition-all hover:-translate-y-1 {{ $social['hover'] }}">
                                    <i class="fa-brands {{ $social['icon'] }}"></i>
                                </a>
                            @endforeach
                        </div>
                    @endif
                </div>

                <div>
                    <h5 class="text-ink font-bold mb-3 uppercase tracking-wider text-[11px]">{{ tr('জনপ্রিয় ক্যাটাগরি', 'Popular categories') }}</h5>
                    <ul class="space-y-2 text-xs">
                        <li><a href="#product-section" onclick="filterByCategory('river')" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('চাঁদপুরের পদ্মার ইলিশ', "Hilsa from the Padma, Chandpur") }}</a></li>
                        <li><a href="#product-section" onclick="filterByCategory('river')" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('দেশি নদীর রুই ও কাতলা', 'Rohu & katla from native rivers') }}</a></li>
                        <li><a href="#product-section" onclick="filterByCategory('live')" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('জ্যান্ত জিয়ল মাছ (শিং/মাগুর/কৈ)', 'Live fish (shing/magur/koi)') }}</a></li>
                        <li><a href="#product-section" onclick="filterByCategory('marine')" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('কক্সবাজারের সাদা রূপচাঁদা', "Cox's Bazar white pomfret") }}</a></li>
                        <li><a href="#product-section" onclick="filterByCategory('dried')" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('অর্গানিক লইট্যা ও চ্যাপা শুঁটকি', 'Organic loitta & chapa dried fish') }}</a></li>
                        <li><a href="#combo-section" class="inline-block py-1 hover:text-aqua-500 transition-colors">{{ tr('নিজের পছন্দের কম্বো প্যাকেজ', 'Build your own combo') }}</a></li>
                    </ul>
                </div>

                <div>
                    <h5 class="text-ink font-bold mb-3 uppercase tracking-wider text-[11px]">{{ tr('গ্রাহক সেবা & হাব', 'Customer care & hubs') }}</h5>
                    <ul class="space-y-2 text-xs">
                        <li>
                            <span class="text-ink2">{{ tr('হটলাইন', 'Hotline') }}:</span>
                            {{ bn_num($settings['site_phone'] ?? '') }}
                            {{ $footerHotlineNote !== '' ? $footerHotlineNote : tr('(সকাল ৭টা - রাত ৯টা)', '(7am - 9pm)') }}
                        </li>
                        @if (trim(strip_tags($footerAddress)) !== '')
                            <li>
                                <span class="text-ink2">{{ tr('ঠিকানা', 'Address') }}:</span>
                                {!! nl2br(e($footerAddress)) !!}
                            </li>
                        @endif
                        @foreach ($footerPages as $footerPage)
                            <li>
                                <a href="{{ route('page.show', $footerPage->slug) }}" target="_blank" rel="noopener" class="inline-block py-1 hover:text-aqua-500 transition-colors">
                                    {{ localized($footerPage->title_bn, $footerPage->title_en) }}
                                    <i class="fa-solid fa-arrow-up-right-from-square text-[8px] opacity-60"></i>
                                </a>
                            </li>
                        @endforeach
                    </ul>
                </div>

                <div>
                    <h5 class="text-ink font-bold mb-3 uppercase tracking-wider text-[11px]">{{ tr('নিরাপদ পেমেন্ট মাধ্যম', 'Secure payment methods') }}</h5>
                    <p class="text-xs mb-3">{{ $footerPaymentNote }}</p>
                    <div class="flex flex-wrap items-center gap-2">
                        @foreach (['bkash' => ['bKash', 'text-pink-500'], 'nagad' => ['Nagad', 'text-orange-500'], 'card' => ['Card', 'text-sky-500'], 'cod' => ['COD', 'text-emerald-500']] as $method => [$label, $color])
                            @if (($settings['payment_'.$method.'_enabled'] ?? '1') === '1')
                                @php $paymentIcon = payment_icon_url($settings, $method); @endphp
                                <span class="bg-card2 border border-line {{ $color }} font-bold px-2.5 py-1 rounded text-[11px] flex items-center gap-1.5">
                                    @if ($paymentIcon)
                                        <img src="{{ $paymentIcon }}" alt="{{ $label }}" class="h-5 w-auto max-w-[3.5rem] object-contain bg-white rounded px-0.5">
                                    @endif
                                    {{ $label }}
                                </span>
                            @endif
                        @endforeach
                    </div>
                </div>

            </div>

            <div class="pt-6 border-t border-line/70 text-center text-[11px]">
                &copy; {{ bn_num(2026) }} {{ $footerSiteName }}. {{ $footerCopyright }}
            </div>
        </div>
    </footer>
