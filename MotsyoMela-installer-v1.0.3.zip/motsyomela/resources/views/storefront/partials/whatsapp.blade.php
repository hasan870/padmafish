    @php $waLink = whatsapp_url($settings['whatsapp_number'] ?? '', 'হ্যালো, আমি মৎস্যমেলা থেকে তাজা মাছ অর্ডার করতে চাই।'); @endphp
    @if ($waLink)
    <!-- WHATSAPP BUSINESS CHAT -->
    <a href="{{ $waLink }}" target="_blank" rel="noopener" aria-label="WhatsApp-এ যোগাযোগ করুন"
       class="fixed right-4 md:right-6 bottom-[calc(5.2rem+env(safe-area-inset-bottom))] md:bottom-24 z-40 w-12 h-12 rounded-full bg-[#25D366] hover:bg-[#1ebe5b] text-white flex items-center justify-center text-2xl shadow-xl shadow-emerald-900/30 transition-all hover:-translate-y-1 active:scale-95">
        <i class="fa-brands fa-whatsapp"></i>
    </a>
    @endif
