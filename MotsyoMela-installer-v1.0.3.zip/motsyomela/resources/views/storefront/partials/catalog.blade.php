        <!-- CONTROLS, FILTERS & VIEW SWITCHER (frosted glass panel) -->
        <div data-reveal class="glass rounded-2xl p-4 sm:p-5 mb-8 space-y-4">

            <div class="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-line/70">
                <div>
                    <h2 id="daily-price-table" class="text-xl sm:text-2xl font-black text-ink flex items-center gap-2 scroll-mt-32">
                        <span>{{ tr('দৈনিক মাছের বাজার দর', 'Daily fish market price') }}</span>
                        <span id="filtered-count" class="bg-aqua-500/15 text-aqua-600 dark:text-aqua-300 text-xs font-bold px-2.5 py-0.5 rounded-full">{{ bn_num($products->count()) }} {{ tr('টি পাওয়া গেছে', 'found') }}</span>
                    </h2>
                    <p class="text-xs text-ink3 mt-0.5">{{ tr('সবগুলো মাছ শতভাগ কেমিক্যালমুক্ত ও সরাসরি ঘাট থেকে সংগৃহীত', 'Every fish is 100% chemical free and sourced directly from the ghat') }}</p>
                </div>

                <!-- View Switcher (Grid vs Table) -->
                <div class="flex items-center bg-card2/70 border border-line p-1 rounded-xl shrink-0 self-start md:self-auto">
                    <button id="grid-view-btn" onclick="switchView('grid')" class="px-3.5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all bg-card text-ink shadow-sm">
                        <i class="fa-solid fa-border-all"></i> {{ tr('গ্রিড ভিউ', 'Grid view') }}
                    </button>
                    <button id="table-view-btn" onclick="switchView('table')" class="px-3.5 py-2.5 rounded-lg text-xs font-bold flex items-center gap-2 transition-all text-ink3 hover:text-ink">
                        <i class="fa-solid fa-table-list"></i> {{ tr('তালিকা ভিউ', 'List view') }}
                    </button>
                </div>
            </div>

            <!-- Secondary Filters Row -->
            <div class="flex flex-wrap items-center justify-between gap-3 text-xs sm:text-sm">

                <div class="flex flex-wrap items-center gap-2 sm:gap-3">
                    <!-- Stock Filter -->
                    <select id="stock-select" onchange="applyAllFilters()" class="bg-card2/70 border border-line text-ink2 font-medium rounded-xl px-3 py-2.5 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                        <option value="all">{{ tr('স্টক স্ট্যাটাস: সকল', 'Stock status: All') }}</option>
                        <option value="in-stock">{{ tr('স্টকে আছে', 'In stock') }}</option>
                        <option value="pre-order">{{ tr('প্রি-অর্ডার', 'Pre-order') }}</option>
                    </select>

                    <!-- Price Sorting Filter -->
                    <select id="sort-select" onchange="applyAllFilters()" class="bg-card2/70 border border-line text-ink2 font-medium rounded-xl px-3 py-2.5 focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25 transition-all">
                        <option value="default">{{ tr('সাজান: জনপ্রিয়', 'Sort: Popular') }}</option>
                        <option value="price-low">{{ tr('দাম: কম থেকে বেশি', 'Price: Low to high') }}</option>
                        <option value="price-high">{{ tr('দাম: বেশি থেকে কম', 'Price: High to low') }}</option>
                    </select>

                    <!-- Reset Filters Button -->
                    <button onclick="resetAllFilters()" class="text-ink3 hover:text-aqua-500 font-semibold underline px-2 py-2 inline-flex items-center transition-colors">
                        {{ tr('ফিল্টার রিসেট', 'Reset filters') }}
                    </button>
                </div>

                <div class="text-ink3 text-xs flex items-center gap-1.5">
                    <i class="fa-solid fa-rotate-right text-aqua-500 animate-spin" style="animation-duration: 8s;"></i>
                    <span>{{ tr('সর্বশেষ আপডেট: আজ সকাল ৬:৩০', 'Last updated: today at 6:30 AM') }}</span>
                </div>
            </div>

        </div>

        <!-- PRODUCT GRID VIEW CONTAINER -->
        <div id="grid-container" class="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            <!-- Dynamic Grid Product Cards via JS -->
        </div>

        <!-- PRODUCT TABLE LIST VIEW CONTAINER -->
        <div id="table-container" class="hidden glass rounded-2xl overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-left border-collapse">
                    <thead>
                        <tr class="bg-card2/70 border-b border-line text-xs font-bold text-ink3 uppercase tracking-wider">
                            <th class="py-4 px-4">{{ tr('মাছের বিবরণ', 'Fish details') }}</th>
                            <th class="py-4 px-4">{{ tr('উৎস/ঘাট', 'Source / ghat') }}</th>
                            <th class="py-4 px-4">{{ tr('সাইজ সিলেক্ট', 'Select size') }}</th>
                            <th class="py-4 px-4">{{ tr('আজকের মূল্য (প্রতি কেজি)', 'Today\'s price (per kg)') }}</th>
                            <th class="py-4 px-4">{{ tr('অবস্থা', 'Status') }}</th>
                            <th class="py-4 px-4 text-center">{{ tr('অ্যাকশন', 'Action') }}</th>
                        </tr>
                    </thead>
                    <tbody id="table-body" class="divide-y divide-line/70 text-sm">
                        <!-- Dynamic Table Rows via JS -->
                    </tbody>
                </table>
            </div>
        </div>

        <!-- EMPTY RESULTS STATE -->
        <div id="empty-state" class="hidden glass rounded-3xl p-12 text-center my-6">
            <div class="w-20 h-20 bg-card2 text-ink3 rounded-full flex items-center justify-center mx-auto mb-4 text-3xl">
                <i class="fa-solid fa-fish"></i>
            </div>
            <h3 class="text-xl font-bold text-ink mb-2">{{ tr('কোনো মাছ পাওয়া যায়নি!', 'No fish found!') }}</h3>
            <p class="text-ink3 text-sm mb-5 max-w-md mx-auto">{{ tr('আপনার সার্চ বা ফিল্টারের সাথে মিলে এমন কোনো পণ্য এই মুহূর্তে স্টকে নেই। অনুগ্রহ করে অন্য কি-ওয়ার্ড বা ফিল্টার ট্রাই করুন।', 'No product matching your search or filters is in stock right now. Please try another keyword or filter.') }}</p>
            <button onclick="resetAllFilters()" class="btn-glow bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-700 hover:to-sky-700 text-white font-bold text-sm px-6 py-2.5 rounded-xl shadow-md transition-all active:scale-95">
                {{ tr('সকল মাছ দেখুন', 'View all fish') }}
            </button>
        </div>
