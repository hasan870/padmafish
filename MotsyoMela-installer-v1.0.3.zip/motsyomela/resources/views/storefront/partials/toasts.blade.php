    <!-- TOAST NOTIFICATION CONTAINER -->
    <div id="toast-container" class="fixed bottom-[5.8rem] md:bottom-5 right-4 md:right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none"></div>
