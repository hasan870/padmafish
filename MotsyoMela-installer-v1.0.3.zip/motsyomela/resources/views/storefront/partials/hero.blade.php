    <!-- HERO SECTION (themed backdrop + swimming fish + rising bubbles) -->
    <section class="hero relative overflow-hidden py-12 sm:py-16 px-4 border-b border-line/60">
        <!-- Decorative Glows -->
        <div class="absolute top-0 right-1/4 w-96 h-96 bg-aqua-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="absolute bottom-0 left-10 w-80 h-80 bg-sky-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <!-- Floating Fish Silhouettes -->
        <i class="fa-solid fa-fish-fins float-fish text-5xl" style="top: 18%; left: 6%; animation-duration: 17s;" aria-hidden="true"></i>
        <i class="fa-solid fa-fish float-fish text-3xl" style="top: 62%; left: 44%; animation-duration: 13s; animation-delay: -4s;" aria-hidden="true"></i>
        <i class="fa-solid fa-fish-fins float-fish text-4xl" style="top: 30%; right: 8%; animation-duration: 19s; animation-delay: -8s; transform: scaleX(-1);" aria-hidden="true"></i>

        <!-- Rising Bubbles -->
        <span class="bubble w-3 h-3" style="left: 12%; animation-duration: 11s;" aria-hidden="true"></span>
        <span class="bubble w-2 h-2" style="left: 30%; animation-duration: 14s; animation-delay: 2s;" aria-hidden="true"></span>
        <span class="bubble w-4 h-4" style="left: 55%; animation-duration: 12s; animation-delay: 5s;" aria-hidden="true"></span>
        <span class="bubble w-2.5 h-2.5" style="left: 72%; animation-duration: 16s; animation-delay: 1s;" aria-hidden="true"></span>
        <span class="bubble w-3.5 h-3.5" style="left: 88%; animation-duration: 13s; animation-delay: 7s;" aria-hidden="true"></span>

        <div class="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-10 items-center relative z-10">

            <!-- Left Hero Content -->
            <div class="lg:col-span-7 space-y-5 text-center lg:text-left">
                <div class="inline-flex items-center gap-2 glass-chip px-3.5 py-1.5 rounded-full text-xs text-aqua-600 dark:text-aqua-300 font-semibold card-enter">
                    <i class="fa-solid fa-circle-check text-emerald-400"></i> {{ tr('ফরমালিন ও কেমিক্যাল মুক্ত ১০০% নিশ্চয়তা', '100% formalin & chemical free guarantee') }}
                </div>

                <h1 class="text-3xl sm:text-5xl lg:text-6xl font-black leading-tight tracking-tight text-ink card-enter" style="animation-delay: .1s;">
                    {{ tr('পদ্মা ও মেঘনার তাজা স্বাদ', 'The fresh taste of Padma & Meghna') }} <br>
                    <span class="text-gradient">{{ tr('সরাসরি আপনার রান্নাঘরে', 'Straight to your kitchen') }}</span>
                </h1>

                <p class="text-ink2 text-sm sm:text-base leading-relaxed max-w-2xl mx-auto lg:mx-0 card-enter" style="animation-delay: .2s;">
                    {{ tr('প্রতিদিন সূর্য ওঠার আগেই চাঁদপুরের পদ্মা ঘাট ও কক্সবাজার থেকে তাজা মাছ সংগ্রহ করা হয়। আপনার পছন্দের কাট ও মাপে ফ্রি ক্লিনিং সুবিধাসহ দ্রুত পৌঁছে দিচ্ছি বাড়ি বাড়ি।', 'Every day before sunrise we collect fresh fish from the Padma ghats of Chandpur and from Cox\'s Bazar. We deliver it quickly to your door, cleaned and cut exactly the way you like.') }}
                </p>

                <!-- Hero Action Buttons -->
                <div class="flex flex-wrap items-center justify-center lg:justify-start gap-4 pt-2 card-enter" style="animation-delay: .3s;">
                    <a href="#product-section" class="btn-glow bg-gradient-to-r from-aqua-500 to-sky-600 hover:from-aqua-600 hover:to-sky-700 text-white px-6 py-3.5 rounded-xl font-bold text-sm sm:text-base shadow-xl shadow-aqua-500/25 flex items-center gap-2 transition-all transform hover:-translate-y-0.5 active:scale-95">
                        <i class="fa-solid fa-basket-shopping"></i> {{ tr('এখনই বাজার করুন', 'Shop now') }}
                    </a>
                    <a href="#daily-price-table" class="glass px-5 py-3.5 rounded-xl font-semibold text-sm sm:text-base text-ink flex items-center gap-2 transition-all hover:-translate-y-0.5 active:scale-95">
                        <i class="fa-solid fa-table-list text-gold-500"></i> {{ tr('আজকের বাজার দর', 'Today\'s market price') }}
                    </a>
                </div>

                <!-- Feature Badges (glass) -->
                <div class="pt-4 grid grid-cols-2 sm:grid-cols-4 gap-3 text-left card-enter" style="animation-delay: .4s;">
                    <div class="glass rounded-xl p-2.5 flex items-center gap-2.5 hover:-translate-y-1 transition-transform duration-300">
                        <i class="fa-solid fa-shield-halved text-emerald-400 text-lg"></i>
                        <div>
                            <p class="text-xs font-bold text-ink">{{ tr('ফরমালিন মুক্ত', 'Formalin free') }}</p>
                            <p class="text-[10px] text-ink3">{{ tr('প্রতিটি ব্যাচ টেস্টেড', 'Every batch tested') }}</p>
                        </div>
                    </div>
                    <div class="glass rounded-xl p-2.5 flex items-center gap-2.5 hover:-translate-y-1 transition-transform duration-300">
                        <i class="fa-solid fa-scissors text-amber-400 text-lg"></i>
                        <div>
                            <p class="text-xs font-bold text-ink">{{ tr('ফ্রি কাট ও ক্লিন', 'Free cut & clean') }}</p>
                            <p class="text-[10px] text-ink3">{{ tr('ইচ্ছামত পিস সুবিধা', 'Cut to your preference') }}</p>
                        </div>
                    </div>
                    <div class="glass rounded-xl p-2.5 flex items-center gap-2.5 hover:-translate-y-1 transition-transform duration-300">
                        <i class="fa-solid fa-truck-fast text-sky-400 text-lg"></i>
                        <div>
                            <p class="text-xs font-bold text-ink">{{ tr('২-৩ ঘন্টায় ডেলিভারি', 'Delivery in 2-3 hours') }}</p>
                            <p class="text-[10px] text-ink3">{{ tr('এক্সপ্রেস হোম সার্ভিস', 'Express home service') }}</p>
                        </div>
                    </div>
                    <div class="glass rounded-xl p-2.5 flex items-center gap-2.5 hover:-translate-y-1 transition-transform duration-300">
                        <i class="fa-solid fa-box-tissue text-gold-400 text-lg"></i>
                        <div>
                            <p class="text-xs font-bold text-ink">{{ tr('আইস বক্স প্যাক', 'Ice box packed') }}</p>
                            <p class="text-[10px] text-ink3">{{ tr('তাজা থাকার গ্যারান্টি', 'Freshness guaranteed') }}</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Promotional Highlight Banner (admin editable: text, image or video) -->
            @php
                $promoEnabled = ($settings['hero_promo_enabled'] ?? '1') === '1';
                $promoHasKey = fn (string $key) => array_key_exists($key, $settings);
                $promoBadge = $promoHasKey('hero_promo_badge') ? trim((string) $settings['hero_promo_badge']) : tr('হট ডিল', 'Hot deal');
                $promoEyebrow = $promoHasKey('hero_promo_eyebrow') ? trim((string) $settings['hero_promo_eyebrow']) : tr('আজকের সেরা অফার', 'Best offer of the day');
                $promoTitle = $promoHasKey('hero_promo_title') ? trim((string) $settings['hero_promo_title']) : tr('চাঁদপুরের তাজা পদ্মার ইলিশ', 'Fresh Padma hilsa from Chandpur');
                $promoDescription = $promoHasKey('hero_promo_description') ? trim((string) $settings['hero_promo_description']) : tr('স্বাদে ও গন্ধে অতুলনীয়, বড় সাইজ (১.২ কেজি - ১.৫ কেজি)। আজই স্পেশাল কম্বো অফারে সংগ্রহ করুন!', 'Unmatched in taste and aroma, large size (1.2 kg - 1.5 kg). Get it today with the special combo offer!');
                $promoRegular = $promoHasKey('hero_promo_regular_price') ? trim((string) $settings['hero_promo_regular_price']) : tr('৳২,১০০/কেজি', '৳2,100/kg');
                $promoOffer = $promoHasKey('hero_promo_offer_price') ? trim((string) $settings['hero_promo_offer_price']) : tr('৳১,৮৫০ / কেজি', '৳1,850 / kg');
                $promoCtaLabel = trim((string) ($settings['hero_promo_cta_label'] ?? '')) ?: tr('অফারটি নিন', 'Grab the offer');
                $promoCtaUrl = trim((string) ($settings['hero_promo_cta_url'] ?? ''));

                $promoMediaType = $settings['hero_promo_media_type'] ?? 'none';
                $promoImagePath = (string) ($settings['hero_promo_image'] ?? '');
                $promoImageUrl = $promoImagePath !== '' ? \Illuminate\Support\Facades\Storage::url($promoImagePath) : null;
                $promoVideoPath = (string) ($settings['hero_promo_video'] ?? '');
                $promoVideoUrl = $promoVideoPath !== ''
                    ? \Illuminate\Support\Facades\Storage::url($promoVideoPath)
                    : trim((string) ($settings['hero_promo_video_url'] ?? ''));
                $promoVideoEmbed = video_embed_url($promoVideoUrl);
                $promoShowImage = $promoMediaType === 'image' && $promoImageUrl;
                $promoShowVideo = $promoMediaType === 'video' && $promoVideoUrl !== '';
                $promoHasMedia = $promoShowImage || $promoShowVideo;
                $promoMediaOnly = ($settings['hero_promo_media_only'] ?? '0') === '1' && $promoHasMedia;
                // Embedded players (YouTube/Vimeo) are 16:9, so avoid pillarboxing
                // them inside the card's 16:10 frame.
                $promoMediaAspect = $promoShowVideo && $promoVideoEmbed
                    ? 'aspect-video'
                    : ($promoMediaOnly ? 'aspect-[4/3]' : 'aspect-[16/10] mb-4');
            @endphp
            @if ($promoEnabled)
                <div class="lg:col-span-5 card-enter" style="animation-delay: .25s;">
                    <div class="promo-card glass-strong p-6 rounded-3xl relative overflow-hidden float-soft">
                        @if ($promoBadge !== '')
                            <span class="absolute top-4 right-4 z-10 bg-red-500 text-white text-xs font-black px-3 py-1 rounded-full uppercase tracking-wider animate-bounce shadow-lg shadow-red-500/40">
                                {{ $promoBadge }}
                            </span>
                        @endif

                        @if ($promoHasMedia)
                            <div class="rounded-2xl overflow-hidden border border-line/70 bg-card2/60 relative {{ $promoMediaAspect }}">
                                @if ($promoShowVideo)
                                    @if ($promoVideoEmbed)
                                        <iframe class="w-full h-full" src="{{ $promoVideoEmbed }}"
                                                title="{{ $promoTitle !== '' ? $promoTitle : tr('প্রোমো ভিডিও', 'Promo video') }}"
                                                loading="lazy" allowfullscreen
                                                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                                                referrerpolicy="strict-origin-when-cross-origin"></iframe>
                                    @else
                                        <video class="w-full h-full object-cover" controls playsinline preload="metadata"
                                               @if ($promoImageUrl) poster="{{ $promoImageUrl }}" @endif>
                                            <source src="{{ $promoVideoUrl }}">
                                            {{ tr('আপনার ব্রাউজার ভিডিও চালাতে পারছে না।', 'Your browser cannot play this video.') }}
                                        </video>
                                    @endif
                                @else
                                    <img src="{{ $promoImageUrl }}" alt="{{ ($settings['site_name'] ?? 'মৎস্যমেলা').' — '.tr('অফার', 'offer') }}" loading="lazy" class="w-full h-full object-cover">
                                @endif
                            </div>
                        @endif

                        @unless ($promoMediaOnly)
                            @if ($promoEyebrow !== '')
                                <div class="flex items-center gap-2 text-gold-500 font-bold text-xs uppercase tracking-widest mb-2">
                                    <i class="fa-solid fa-crown"></i> {{ $promoEyebrow }}
                                </div>
                            @endif
                            @if ($promoTitle !== '')
                                <h3 class="text-2xl font-bold text-ink mb-2">{{ $promoTitle }}</h3>
                            @endif
                            @if ($promoDescription !== '')
                                <p class="text-xs text-ink2 mb-4">{{ $promoDescription }}</p>
                            @endif

                            @if ($promoRegular !== '' || $promoOffer !== '' || $promoCtaLabel !== '')
                                <div class="bg-card2/70 border border-line/70 p-4 rounded-2xl flex items-center justify-between gap-3 mb-5 backdrop-blur-sm">
                                    <div>
                                        @if ($promoRegular !== '')
                                            <span class="text-xs text-ink3 line-through">{{ tr('নিয়মিত মূল্য:', 'Regular price:') }} {{ $promoRegular }}</span>
                                        @endif
                                        @if ($promoOffer !== '')
                                            <div class="text-2xl font-extrabold text-emerald-500 dark:text-emerald-400">{{ tr('অফার মূল্য:', 'Offer price:') }} {{ $promoOffer }}</div>
                                        @endif
                                    </div>
                                    @if ($promoCtaUrl !== '')
                                        <a href="{{ $promoCtaUrl }}" target="_blank" rel="noopener" class="btn-glow bg-gold-500 hover:bg-gold-600 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-gold-500/30 active:scale-95 shrink-0">
                                            {{ $promoCtaLabel }}
                                        </a>
                                    @else
                                        <button onclick="quickBuyFeaturedItem()" class="btn-glow bg-gold-500 hover:bg-gold-600 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-xl transition-all shadow-md shadow-gold-500/30 active:scale-95 shrink-0">
                                            {{ $promoCtaLabel }}
                                        </button>
                                    @endif
                                </div>
                            @endif

                            <div class="flex items-center justify-between text-[11px] text-ink3">
                                <span><i class="fa-solid fa-clock text-aqua-500 mr-1"></i> {{ tr('স্টক সীমিত', 'Limited stock') }}</span>
                                <span><i class="fa-solid fa-thumbs-up text-emerald-400 mr-1"></i> {{ tr('৯৮% পজিটিভ রিভিউ', '98% positive reviews') }}</span>
                            </div>
                        @endunless
                    </div>
                </div>
            @endif

        </div>
    </section>
