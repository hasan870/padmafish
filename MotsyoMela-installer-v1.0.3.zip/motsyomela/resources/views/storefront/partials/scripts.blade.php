    <script>
        // ============================================================
        // THEME ENGINE — Dark / Light mode with persistence
        // ============================================================
        const THEME_KEY = 'mm-theme';

        function currentTheme() {
            return document.documentElement.getAttribute('data-theme') || 'dark';
        }

        function applyTheme(theme) {
            document.documentElement.setAttribute('data-theme', theme);
            document.documentElement.classList.toggle('dark', theme === 'dark');
            try { localStorage.setItem(THEME_KEY, theme); } catch (e) { /* noop */ }
        }

        function toggleTheme() {
            const next = currentTheme() === 'dark' ? 'light' : 'dark';
            const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

            if (document.startViewTransition && !reduceMotion) {
                // Modern browsers: smooth cross-morph between themes
                document.startViewTransition(() => applyTheme(next));
            } else {
                // Fallback: temporary global color transition
                document.documentElement.classList.add('theme-anim');
                applyTheme(next);
                setTimeout(() => document.documentElement.classList.remove('theme-anim'), 550);
            }
        }

        // ============================================================
        // SCROLL REVEAL — sections glide in as you scroll
        // ============================================================
        const revealObserver = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.classList.add('in-view');
                    revealObserver.unobserve(entry.target);
                }
            });
        }, { threshold: 0.12, rootMargin: '0px 0px -40px 0px' });

        function initReveals() {
            document.querySelectorAll('[data-reveal]').forEach(el => {
                el.classList.add('reveal');
                if (el.dataset.revealDelay) el.style.transitionDelay = el.dataset.revealDelay;
                revealObserver.observe(el);
            });
        }

        // ============================================================
        // SCROLL TO TOP
        // ============================================================
        function scrollToTop() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        }

        // ============================================================
        // PAYMENT METHOD VISUAL SELECTOR
        // ============================================================
        function updatePaymentStyles() {
            document.querySelectorAll('.payment-radio').forEach(label => {
                const input = label.querySelector('input');
                label.classList.toggle('payment-active', input.checked);
            });
        }

        // CART BADGE POP ANIMATION
        function popCartBadge() {
            const badge = document.getElementById('cart-badge-count');
            badge.classList.remove('badge-pop');
            void badge.offsetWidth; // reflow to restart animation
            badge.classList.add('badge-pop');
        }

        // CATALOG DATA — injected from MySQL via window.__MM_DATA__
        const productsData = (window.__MM_DATA__ && window.__MM_DATA__.products) || [];
        const mmCoupons = (window.__MM_DATA__ && window.__MM_DATA__.coupons) || [];
        const mmSettings = (window.__MM_DATA__ && window.__MM_DATA__.settings) || {};
        const mmComboPacks = (window.__MM_DATA__ && window.__MM_DATA__.comboPacks) || [];

        // LANGUAGE HELPERS — storefront locale is injected by the layout
        const MM_EN = ((window.__MM_DATA__ && window.__MM_DATA__.locale) === 'en');
        function L(bn, en) { return MM_EN ? en : bn; }
        function pName(product) {
            return MM_EN && product && product.nameEng ? product.nameEng : (product ? product.nameBng : '');
        }

        // Storefront display options managed from Admin → Theme & branding
        const showCuttingPreference = String(mmSettings.show_cutting_preference ?? '1') !== '0';
        const comboThumbShape = String(mmSettings.combo_thumb_shape ?? 'square') === 'circle' ? 'circle' : 'square';

        function toBn(value) {
            const digits = { '0': '০', '1': '১', '2': '২', '3': '৩', '4': '৪', '5': '৫', '6': '৬', '7': '৭', '8': '৮', '9': '৯' };
            return String(value).replace(/[0-9]/g, d => digits[d]);
        }

        // CUTTING PREFERENCES OPTIONS
        const cuttingOptions = [
            { id: "steak", label: L("গাদা-পেটি রিং পিস (Steak Cut)", "Ring pieces (steak cut)") },
            { id: "curry", label: L("ঝোল কাট (Curry Cut)", "Curry cut") },
            { id: "whole", label: L("আস্ত মাছ (Clean Whole)", "Whole fish (clean)") },
            { id: "skinless", label: L("চামড়া ছাড়ানো (Skinless)", "Skinless") }
        ];

        // GLOBAL APP STATE
        let activeCategory = 'all';
        let currentSearchQuery = '';
        let currentStockFilter = 'all';
        let currentSort = 'default';
        let currentView = 'grid'; // 'grid' or 'table'

        let selectedSizesMap = {}; // productId -> size index
        let selectedWeightsMap = {}; // productId -> weight (kg)
        let selectedCutsMap = {}; // productId -> cut preference string

        const CART_KEY = 'mm-cart';
        let cartItems = [];
        let appliedCoupon = null;
        let appliedCouponCode = "";

        // COMBO PACKAGE STATE — packs are managed from the admin panel
        let comboTarget = mmComboPacks.length ? Number(mmComboPacks[0].itemCount) : 4;
        let comboSelections = []; // [{ id, sizeIdx, weight }]

        // INITIALIZATION
        window.addEventListener('DOMContentLoaded', () => {
            productsData.forEach(prod => {
                selectedSizesMap[prod.id] = 0;
                selectedWeightsMap[prod.id] = 1.0;
                selectedCutsMap[prod.id] = cuttingOptions[0].label;
            });
            restoreCart();
            applyAllFilters();
            initReveals();
            updatePaymentStyles();
            renderComboBuilder();
            renderCartItemsUI();

            document.querySelectorAll('input[name="payment"]').forEach(radio => {
                radio.addEventListener('change', updatePaymentStyles);
            });

            window.addEventListener('scroll', () => {
                document.getElementById('scroll-top').classList.toggle('show', window.scrollY > 480);
            }, { passive: true });
        });

        // FILTER & SEARCH LOGIC
        function filterByCategory(cat) {
            activeCategory = cat;
            document.querySelectorAll('.category-tab').forEach(btn => {
                btn.classList.remove('tab-active');
                if (btn.id !== 'cat-tab-offer') btn.classList.add('bg-card2/70', 'text-ink2');
            });

            const activeTab = document.getElementById(`cat-tab-${cat}`);
            if (activeTab) {
                activeTab.classList.remove('bg-card2/70', 'text-ink2');
                activeTab.classList.add('tab-active');
            }
            applyAllFilters();
        }

        function handleSearchInput(val) {
            currentSearchQuery = val.toLowerCase().trim();
            const desktopInput = document.getElementById('desktop-search');
            const mobileInput = document.getElementById('mobile-search');
            if (desktopInput) desktopInput.value = val;
            if (mobileInput && mobileInput.value !== val) mobileInput.value = val;

            const clearBtn = document.getElementById('clear-search-btn');
            if (clearBtn) {
                if (val.length > 0) clearBtn.classList.remove('hidden');
                else clearBtn.classList.add('hidden');
            }

            const mobileClearBtn = document.getElementById('mobile-clear-search-btn');
            if (mobileClearBtn) {
                if (val.length > 0) mobileClearBtn.classList.remove('hidden');
                else mobileClearBtn.classList.add('hidden');
            }

            applyAllFilters();
        }

        function clearSearch() {
            handleSearchInput('');
        }

        function syncBodyScrollLock() {
            const drawer = document.getElementById('mobile-menu-drawer');
            const search = document.getElementById('mobile-search-overlay');
            const cart = document.getElementById('cart-drawer');
            const checkout = document.getElementById('checkout-modal');
            const menuOpen = drawer && !drawer.classList.contains('-translate-x-full');
            const searchOpen = search && !search.classList.contains('pointer-events-none');
            const cartOpen = cart && !cart.classList.contains('translate-x-full');
            const checkoutOpen = checkout && !checkout.classList.contains('pointer-events-none');
            document.body.style.overflow = (menuOpen || searchOpen || cartOpen || checkoutOpen) ? 'hidden' : '';
        }

        function openMobileMenu() {
            closeMobileSearch();
            const drawer = document.getElementById('mobile-menu-drawer');
            const overlay = document.getElementById('mobile-menu-overlay');
            if (!drawer || !overlay) return;
            drawer.classList.remove('-translate-x-full');
            drawer.setAttribute('aria-hidden', 'false');
            overlay.classList.remove('opacity-0', 'pointer-events-none');
            document.getElementById('mobile-menu-btn')?.setAttribute('aria-expanded', 'true');
            syncBodyScrollLock();
        }

        function closeMobileMenu() {
            const drawer = document.getElementById('mobile-menu-drawer');
            const overlay = document.getElementById('mobile-menu-overlay');
            if (!drawer || !overlay) return;
            drawer.classList.add('-translate-x-full');
            drawer.setAttribute('aria-hidden', 'true');
            overlay.classList.add('opacity-0', 'pointer-events-none');
            document.getElementById('mobile-menu-btn')?.setAttribute('aria-expanded', 'false');
            syncBodyScrollLock();
        }

        function openMobileSearch() {
            closeMobileMenu();
            const overlay = document.getElementById('mobile-search-overlay');
            const panel = document.getElementById('mobile-search-panel');
            if (!overlay) return;
            overlay.classList.remove('opacity-0', 'pointer-events-none');
            panel?.classList.remove('-translate-y-3');

            const input = document.getElementById('mobile-search');
            if (input) {
                const desktopInput = document.getElementById('desktop-search');
                input.value = desktopInput ? desktopInput.value : '';
                setTimeout(() => { input.focus(); input.select(); }, 90);
            }
            syncBodyScrollLock();
        }

        function closeMobileSearch() {
            const overlay = document.getElementById('mobile-search-overlay');
            const panel = document.getElementById('mobile-search-panel');
            if (!overlay) return;
            overlay.classList.add('opacity-0', 'pointer-events-none');
            panel?.classList.add('-translate-y-3');
            syncBodyScrollLock();
        }

        function mobileSearchChip(term) {
            handleSearchInput(term);
            closeMobileSearch();
            setTimeout(scrollToProducts, 80);
        }

        function mobilePickCategory(slug) {
            closeMobileMenu();
            filterByCategory(slug);
            setTimeout(scrollToProducts, 80);
        }

        function scrollToProducts() {
            document.getElementById('daily-price-table')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }

        document.addEventListener('keydown', (event) => {
            if (event.key === 'Escape') {
                closeMobileSearch();
                closeMobileMenu();
            }
        });

        function applyAllFilters() {
            // Content pages (delivery policy, refund policy, ...) have no catalog.
            const stockSelect = document.getElementById('stock-select');
            const sortSelect = document.getElementById('sort-select');
            if (!stockSelect || !sortSelect || !document.getElementById('grid-container')) return;

            currentStockFilter = stockSelect.value;
            currentSort = sortSelect.value;

            let filtered = productsData.filter(item => {
                // Category Filter
                if (activeCategory === 'offer' && item.badge !== 'হট ডিল') return false;
                if (activeCategory !== 'all' && activeCategory !== 'offer' && item.category !== activeCategory) {
                    return false;
                }

                // Search Filter (Bangla & English)
                if (currentSearchQuery !== '') {
                    const matchBng = item.nameBng.toLowerCase().includes(currentSearchQuery);
                    const matchEng = item.nameEng.toLowerCase().includes(currentSearchQuery);
                    const matchOrigin = item.origin.toLowerCase().includes(currentSearchQuery);
                    if (!matchBng && !matchEng && !matchOrigin) return false;
                }

                // Stock Filter
                if (currentStockFilter === 'in-stock' && !item.inStock) return false;
                if (currentStockFilter === 'pre-order' && item.inStock) return false;

                return true;
            });

            // Sorting
            if (currentSort === 'price-low') {
                filtered.sort((a, b) => a.sizes[0].pricePerKg - b.sizes[0].pricePerKg);
            } else if (currentSort === 'price-high') {
                filtered.sort((a, b) => b.sizes[0].pricePerKg - a.sizes[0].pricePerKg);
            }

            // Update Counter Text
            document.getElementById('filtered-count').textContent = `${MM_EN ? filtered.length : toBn(filtered.length)} ${L('টি পাওয়া গেছে', 'results found')}`;

            if (filtered.length === 0) {
                document.getElementById('grid-container').classList.add('hidden');
                document.getElementById('table-container').classList.add('hidden');
                document.getElementById('empty-state').classList.remove('hidden');
            } else {
                document.getElementById('empty-state').classList.add('hidden');
                if (currentView === 'grid') {
                    document.getElementById('grid-container').classList.remove('hidden');
                    document.getElementById('table-container').classList.add('hidden');
                    renderGridView(filtered);
                } else {
                    document.getElementById('grid-container').classList.add('hidden');
                    document.getElementById('table-container').classList.remove('hidden');
                    renderTableView(filtered);
                }
            }
        }

        // Header navigation: on the home page, re-clicking a home/anchor link should
        // reset the catalog filters and scroll instead of doing nothing.
        function handleHomeNav(event) {
            const link = event.currentTarget;
            try {
                const target = new URL(link.href, window.location.href);
                if (target.pathname === window.location.pathname && (target.hash === '' || target.hash === '#')) {
                    event.preventDefault();
                    resetAllFilters();
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                    return false;
                }
            } catch (e) { /* invalid URL — let the browser handle it */ }
            return true;
        }

        function handleHeaderNav(event) {
            return handleHomeNav(event);
        }

        function resetAllFilters() {
            currentSearchQuery = '';
            activeCategory = 'all';
            document.getElementById('desktop-search').value = '';
            document.getElementById('mobile-search').value = '';
            document.getElementById('stock-select').value = 'all';
            document.getElementById('sort-select').value = 'default';
            filterByCategory('all');
        }

        function switchView(view) {
            currentView = view;
            const gridBtn = document.getElementById('grid-view-btn');
            const tableBtn = document.getElementById('table-view-btn');

            if (view === 'grid') {
                gridBtn.classList.add('bg-card', 'text-ink', 'shadow-sm');
                gridBtn.classList.remove('text-ink3');
                tableBtn.classList.remove('bg-card', 'text-ink', 'shadow-sm');
                tableBtn.classList.add('text-ink3');
            } else {
                tableBtn.classList.add('bg-card', 'text-ink', 'shadow-sm');
                tableBtn.classList.remove('text-ink3');
                gridBtn.classList.remove('bg-card', 'text-ink', 'shadow-sm');
                gridBtn.classList.add('text-ink3');
            }
            applyAllFilters();
        }

        // CARDS DYNAMIC SELECTION
        function updateSizeSelection(prodId, sizeIdx) {
            selectedSizesMap[prodId] = parseInt(sizeIdx);
            applyAllFilters();
        }

        function updateWeightQty(prodId, delta) {
            let curr = selectedWeightsMap[prodId] || 1.0;
            let next = curr + delta;
            if (next < 0.5) next = 0.5;
            selectedWeightsMap[prodId] = parseFloat(next.toFixed(1));
            applyAllFilters();
        }

        function updateCutPreference(prodId, cutVal) {
            selectedCutsMap[prodId] = cutVal;
        }

        // RENDER GRID VIEW CARDS (glassmorphic, staggered entrance)
        function renderGridView(items) {
            const container = document.getElementById('grid-container');
            container.innerHTML = items.map((item, idx) => {
                const sIdx = selectedSizesMap[item.id] || 0;
                const activeSize = item.sizes[sIdx];
                const weight = selectedWeightsMap[item.id] || 1.0;
                const calcTotal = Math.round(activeSize.pricePerKg * weight);
                const delay = Math.min(idx * 60, 480);

                return `
                    <div class="product-card glass rounded-3xl flex flex-col overflow-hidden group card-enter" style="animation-delay: ${delay}ms;">

                        <!-- Image Top -->
                        <div class="relative h-52 overflow-hidden bg-card2">
                            <img src="${item.image}" alt="${pName(item)}" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" loading="lazy">
                            <div class="absolute inset-0 bg-gradient-to-t from-black/45 via-transparent to-transparent pointer-events-none"></div>
                            <span class="absolute top-3 left-3 ${item.badgeColor} text-white text-[11px] font-bold px-3 py-1 rounded-full shadow-lg font-bangla">
                                ${item.badge}
                            </span>
                            <span class="absolute bottom-3 right-3 bg-slate-950/55 backdrop-blur-md border border-white/10 text-white text-[11px] px-2.5 py-1 rounded-lg font-medium">
                                <i class="fa-solid fa-location-dot text-aqua-400 mr-1"></i>${item.origin}
                            </span>
                        </div>

                        <!-- Card Body -->
                        <div class="p-5 flex-1 flex flex-col justify-between space-y-4">
                            <div>
                                <div class="flex justify-between items-start gap-2">
                                    <div class="min-w-0">
                                        <h3 class="font-extrabold text-ink text-lg group-hover:text-aqua-500 dark:group-hover:text-aqua-300 transition-colors">${pName(item)}</h3>
                                        <p class="text-xs text-ink3 font-medium">${item.nameEng}</p>
                                    </div>
                                    ${item.inStock
                                        ? '<span class="shrink-0 bg-emerald-500/15 text-emerald-600 dark:text-emerald-300 text-[10px] font-bold px-2 py-0.5 rounded-md">' + L('স্টকে আছে', 'In stock') + '</span>'
                                        : '<span class="shrink-0 bg-amber-500/15 text-amber-600 dark:text-amber-300 text-[10px] font-bold px-2 py-0.5 rounded-md">' + L('প্রি-অর্ডার', 'Pre-order') + '</span>'}
                                </div>

                                <p class="text-xs text-ink2 mt-2 line-clamp-2">${item.desc}</p>

                                <!-- Size Selector -->
                                <div class="mt-3">
                                    <label class="block text-[11px] font-bold text-ink2 mb-1">${L('সাইজ নির্বাচন করুন:', 'Choose a size:')}</label>
                                    <select onchange="updateSizeSelection(${item.id}, this.value)" class="w-full bg-card2/70 border border-line rounded-xl px-3 py-2.5 text-xs font-semibold text-ink focus:outline-none focus:border-aqua-500 transition-colors">
                                        ${item.sizes.map((s, idx) => `
                                            <option value="${idx}" ${idx === sIdx ? 'selected' : ''}>
                                                ${s.label} — ৳${s.pricePerKg}${L('/কেজি', '/kg')}
                                            </option>
                                        `).join('')}
                                    </select>
                                </div>

                                <!-- Cut Preference Selector (toggleable from the admin panel) -->
                                ${showCuttingPreference ? `
                                <div class="mt-2.5">
                                    <label class="block text-[11px] font-bold text-ink2 mb-1">${L('কাটিং পছন্দ (ফ্রি):', 'Cutting preference (free):')}</label>
                                    <select onchange="updateCutPreference(${item.id}, this.value)" class="w-full bg-card2/70 border border-line rounded-xl px-3 py-2.5 text-xs text-ink2 focus:outline-none focus:border-aqua-500 transition-colors">
                                        ${cuttingOptions.map(c => `
                                            <option value="${c.label}" ${selectedCutsMap[item.id] === c.label ? 'selected' : ''}>
                                                ${c.label}
                                            </option>
                                        `).join('')}
                                    </select>
                                </div>` : ''}

                                <!-- Weight Multiplier -->
                                <div class="mt-3 flex items-center justify-between bg-card2/60 border border-line/70 p-2.5 rounded-xl">
                                    <span class="text-xs font-bold text-ink2">${L('পরিমাণ (কেজি):', 'Quantity (kg):')}</span>
                                    <div class="flex items-center gap-2">
                                        <button onclick="updateWeightQty(${item.id}, -0.5)" class="w-9 h-9 rounded-lg bg-card border border-line text-ink font-bold hover:bg-aqua-500/15 hover:border-aqua-500/50 flex items-center justify-center text-sm transition-all active:scale-90">-</button>
                                        <span class="text-xs font-bold text-ink w-10 text-center">${weight} ${L('কেজি', 'kg')}</span>
                                        <button onclick="updateWeightQty(${item.id}, 0.5)" class="w-9 h-9 rounded-lg bg-card border border-line text-ink font-bold hover:bg-aqua-500/15 hover:border-aqua-500/50 flex items-center justify-center text-sm transition-all active:scale-90">+</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Bottom Price & Action -->
                            <div class="pt-3 border-t border-line/70 flex items-center justify-between">
                                <div>
                                    <span class="text-[10px] text-ink3 block uppercase font-bold">${L('মোট টাকা', 'Total')}</span>
                                    <span class="text-xl font-black text-ink">৳${calcTotal}</span>
                                </div>

                                <button onclick="addItemToCart(${item.id})" class="btn-glow bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-700 hover:to-sky-700 text-white px-4 py-3 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-md shadow-aqua-600/25 transition-all transform active:scale-95">
                                    <i class="fa-solid fa-cart-plus"></i> ${L('ঝুড়িতে নিন', 'Add to cart')}
                                </button>
                            </div>

                        </div>
                    </div>
                `;
            }).join('');
        }

        // RENDER TABLE VIEW
        function renderTableView(items) {
            const tbody = document.getElementById('table-body');
            tbody.innerHTML = items.map((item, idx) => {
                const sIdx = selectedSizesMap[item.id] || 0;
                const activeSize = item.sizes[sIdx];
                const delay = Math.min(idx * 45, 360);

                return `
                    <tr class="hover:bg-card2/50 transition-colors card-enter" style="animation-delay: ${delay}ms;">
                        <td class="py-3.5 px-4">
                            <div class="flex items-center gap-3">
                                <img src="${item.image}" class="w-12 h-12 rounded-xl object-cover border border-line" alt="${pName(item)}">
                                <div>
                                    <div class="font-bold text-ink">${pName(item)}</div>
                                    <div class="text-xs text-ink3">${item.nameEng}</div>
                                </div>
                            </div>
                        </td>
                        <td class="py-3.5 px-4 text-xs text-ink2 font-medium">
                            <i class="fa-solid fa-location-dot text-aqua-500 mr-1"></i>${item.origin}
                        </td>
                        <td class="py-3.5 px-4">
                            <select onchange="updateSizeSelection(${item.id}, this.value)" class="bg-card2/70 border border-line rounded-lg px-2 py-1 text-xs font-medium text-ink focus:outline-none focus:border-aqua-500 transition-colors">
                                ${item.sizes.map((s, idx) => `
                                    <option value="${idx}" ${idx === sIdx ? 'selected' : ''}>${s.label}</option>
                                `).join('')}
                            </select>
                        </td>
                        <td class="py-3.5 px-4">
                            <span class="font-bold text-ink text-base">৳${activeSize.pricePerKg}</span>
                            <span class="text-[10px] text-ink3">${L('/কেজি', '/kg')}</span>
                        </td>
                        <td class="py-3.5 px-4">
                            ${item.inStock
                                ? '<span class="text-emerald-600 dark:text-emerald-300 bg-emerald-500/15 px-2 py-0.5 rounded text-[11px] font-bold">' + L('স্টকে আছে', 'In stock') + '</span>'
                                : '<span class="text-amber-600 dark:text-amber-300 bg-amber-500/15 px-2 py-0.5 rounded text-[11px] font-bold">' + L('প্রি-অর্ডার', 'Pre-order') + '</span>'}
                        </td>
                        <td class="py-3.5 px-4 text-center">
                            <button onclick="addItemToCart(${item.id})" class="bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-700 hover:to-sky-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition-all inline-flex items-center gap-1 active:scale-95">
                                <i class="fa-solid fa-cart-plus"></i> ${L('কিনুন', 'Buy')}
                            </button>
                        </td>
                    </tr>
                `;
            }).join('');
        }

        // CART MANAGEMENT LOGIC
        function openCartDrawer() {
            document.getElementById('cart-drawer-overlay').classList.remove('opacity-0', 'pointer-events-none');
            document.getElementById('cart-drawer').classList.remove('translate-x-full');
            syncBodyScrollLock();
        }

        function closeCartDrawer() {
            document.getElementById('cart-drawer-overlay').classList.add('opacity-0', 'pointer-events-none');
            document.getElementById('cart-drawer').classList.add('translate-x-full');
            syncBodyScrollLock();
        }

        function addItemToCart(prodId) {
            const item = productsData.find(p => p.id === prodId);
            const sIdx = selectedSizesMap[prodId] || 0;
            const activeSize = item.sizes[sIdx];
            const weight = selectedWeightsMap[prodId] || 1.0;
            const cutPref = selectedCutsMap[prodId] || cuttingOptions[0].label;

            // Check duplicate
            const existingIdx = cartItems.findIndex(c => c.id === prodId && c.sizeLabel === activeSize.label && c.cutPref === cutPref);

            if (existingIdx > -1) {
                cartItems[existingIdx].weight += weight;
            } else {
                cartItems.push({
                    id: item.id,
                    productId: item.id,
                    sizeId: activeSize.id,
                    nameBng: item.nameBng,
                    nameEng: item.nameEng,
                    image: item.image,
                    sizeLabel: activeSize.label,
                    pricePerKg: activeSize.pricePerKg,
                    weight: weight,
                    cutPref: cutPref
                });
            }

            renderCartItemsUI();
            popCartBadge();
            showToast(`${pName(item)} ${L('কার্টে যোগ করা হয়েছে!', 'added to cart!')}`);
            openCartDrawer();
        }

        function removeCartItem(idx) {
            cartItems.splice(idx, 1);
            renderCartItemsUI();
        }

        function updateCartItemQty(idx, delta) {
            const item = cartItems[idx];
            if (item.isCombo) {
                // কম্বো লাইন = প্যাক সংখ্যা (১ ধাপ করে), কেজি নয়
                item.weight = Math.max(1, Math.min(9, item.weight + delta));
            } else {
                item.weight += delta;
                if (item.weight < 0.5) item.weight = 0.5;
                item.weight = parseFloat(item.weight.toFixed(1));
            }
            renderCartItemsUI();
        }

        function renderCartItemsUI() {
            const container = document.getElementById('cart-drawer-items');

            // Update Badges
            document.getElementById('cart-badge-count').textContent = cartItems.length;
            const mobileCount = document.getElementById('mobile-cart-count');
            if (mobileCount) mobileCount.textContent = cartItems.length;

            if (cartItems.length === 0) {
                container.innerHTML = `
                    <div class="text-center py-16">
                        <i class="fa-solid fa-basket-shopping text-ink3 text-5xl mb-3"></i>
                        <p class="text-ink2 font-bold text-sm">${L('আপনার কার্ট খালি রয়েছে!', 'Your cart is empty!')}</p>
                        <p class="text-ink3 text-xs mt-1">${L('বাজার ঘুরে তাজা মাছ যোগ করুন', 'Browse the market and add fresh fish')}</p>
                    </div>
                `;
            } else {
                container.innerHTML = cartItems.map((item, idx) => {
                    // COMBO PACKAGE cart line — shows contents, discount chip & pack quantity
                    if (item.isCombo) {
                        return `
                        <div class="py-3.5 flex flex-wrap items-start gap-2 sm:gap-3">
                            <div class="relative shrink-0">
                                <img src="${item.image}" class="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover shrink-0 border border-gold-500/40" alt="${pName(item)}">
                                <span class="absolute -bottom-1.5 -right-1.5 bg-gold-500 text-slate-950 text-[8px] font-black px-1.5 py-0.5 rounded-full border-2 border-app">${L('কম্বো', 'Combo')}</span>
                            </div>
                            <div class="flex-1 min-w-0">
                                <h4 class="font-bold text-xs text-ink flex items-center gap-1.5">
                                    <i class="fa-solid fa-gift text-gold-500"></i> ${pName(item)}
                                </h4>
                                <div class="mt-1 space-y-0.5 border-l-2 border-gold-500/30 pl-2">
                                    ${item.comboDetails.map(d => `
                                        <p class="text-[10px] text-ink3 flex justify-between gap-2">
                                            <span class="truncate">${pName(d)} (${d.sizeLabel})</span>
                                            <span class="shrink-0 font-semibold text-ink2">${d.weight} ${L('কেজি', 'kg')}</span>
                                        </p>`).join('')}
                                </div>
                                <p class="text-[10px] text-emerald-500 font-bold mt-1"><i class="fa-solid fa-tags mr-0.5"></i>${L('কম্বো ছাড়', 'Combo discount')} ${item.comboDiscountLabel || (item.comboDiscountPct ? item.comboDiscountPct + '%' : '')} ${L('প্রয়োগ হয়েছে', 'applied')}</p>
                                <div class="text-xs font-black text-ink mt-1">৳${Math.round(item.pricePerKg * item.weight)}</div>
                            </div>
                            <div class="order-last w-full sm:order-none sm:w-auto flex justify-end sm:justify-start shrink-0">
                                <div class="flex items-center gap-0.5 bg-card2/80 border border-line/70 p-0.5 rounded-lg">
                                    <button onclick="updateCartItemQty(${idx}, -1)" class="w-9 h-9 bg-card border border-line rounded-lg font-bold text-base flex items-center justify-center text-ink transition-all active:scale-90">-</button>
                                    <span class="text-xs font-bold w-8 text-center text-ink">×${item.weight}</span>
                                    <button onclick="updateCartItemQty(${idx}, 1)" class="w-9 h-9 bg-card border border-line rounded-lg font-bold text-base flex items-center justify-center text-ink transition-all active:scale-90">+</button>
                                </div>
                            </div>
                            <button onclick="removeCartItem(${idx})" aria-label="${L('মুছে ফেলুন', 'Remove item')}" class="w-9 h-9 shrink-0 flex items-center justify-center rounded-lg text-ink3 hover:text-red-500 hover:bg-rose-500/10 text-sm transition-colors">
                                <i class="fa-solid fa-trash-can"></i>
                            </button>
                        </div>`;
                    }
                    return `
                    <div class="py-3.5 flex flex-wrap items-start gap-2 sm:gap-3">
                        <img src="${item.image}" class="w-12 h-12 sm:w-14 sm:h-14 rounded-xl object-cover shrink-0 border border-line" alt="${pName(item)}">
                        <div class="flex-1 min-w-0">
                            <h4 class="font-bold text-xs text-ink truncate">${pName(item)}</h4>
                            <p class="text-[11px] text-ink3">${L('সাইজ:', 'Size:')} ${item.sizeLabel}</p>
                            <p class="text-[10px] text-aqua-600 dark:text-aqua-300 bg-aqua-500/12 px-1.5 py-0.5 rounded inline-block mt-0.5">${item.cutPref}</p>
                            <div class="text-xs font-black text-ink mt-1">৳${Math.round(item.pricePerKg * item.weight)}</div>
                        </div>
                        <div class="order-last w-full sm:order-none sm:w-auto flex justify-end sm:justify-start shrink-0">
                            <div class="flex items-center gap-0.5 bg-card2/80 border border-line/70 p-0.5 rounded-lg">
                                <button onclick="updateCartItemQty(${idx}, -0.5)" class="w-9 h-9 bg-card border border-line rounded-lg font-bold text-base flex items-center justify-center text-ink transition-all active:scale-90">-</button>
                                <span class="text-xs font-bold w-9 text-center text-ink">${item.weight}kg</span>
                                <button onclick="updateCartItemQty(${idx}, 0.5)" class="w-9 h-9 bg-card border border-line rounded-lg font-bold text-base flex items-center justify-center text-ink transition-all active:scale-90">+</button>
                            </div>
                        </div>
                        <button onclick="removeCartItem(${idx})" aria-label="${L('মুছে ফেলুন', 'Remove item')}" class="w-9 h-9 shrink-0 flex items-center justify-center rounded-lg text-ink3 hover:text-red-500 hover:bg-rose-500/10 text-sm transition-colors">
                            <i class="fa-solid fa-trash-can"></i>
                        </button>
                    </div>
                `;
                }).join('');
            }

            calculateCartTotals();
        }

        function cartSubtotal() {
            return cartItems.reduce((sum, item) => sum + (item.pricePerKg * item.weight), 0);
        }

        function couponDiscountAmount(subtotal) {
            if (!appliedCoupon) return 0;
            const minTotal = Number(appliedCoupon.min_order_total || 0);
            if (minTotal > 0 && subtotal < minTotal) return 0;
            const raw = appliedCoupon.type === 'percent'
                ? subtotal * (Number(appliedCoupon.value) / 100)
                : Number(appliedCoupon.value);
            return Math.min(Math.round(raw), Math.round(subtotal));
        }

        function persistCart() {
            try {
                localStorage.setItem(CART_KEY, JSON.stringify({ items: cartItems, coupon: appliedCouponCode }));
            } catch (e) { /* noop */ }
        }

        function restoreCart() {
            try {
                const saved = JSON.parse(localStorage.getItem(CART_KEY) || 'null');
                if (!saved || !Array.isArray(saved.items)) return;
                cartItems = saved.items.filter(item => item && (item.isCombo ? Array.isArray(item.comboDetails) : item.sizeId));
                appliedCouponCode = saved.coupon || '';
                appliedCoupon = mmCoupons.find(c => c.code === appliedCouponCode) || null;
                if (!appliedCoupon) appliedCouponCode = '';
            } catch (e) { /* noop */ }
        }

        function calculateCartTotals() {
            const subtotal = cartSubtotal();
            const discount = couponDiscountAmount(subtotal);
            const grandTotal = Math.max(0, subtotal - discount);

            document.getElementById('cart-subtotal').textContent = `৳${Math.round(subtotal)}`;
            document.getElementById('cart-discount').textContent = `-৳${Math.round(discount)}`;
            document.getElementById('cart-grandtotal').textContent = `৳${Math.round(grandTotal)}`;
            document.getElementById('cart-badge-total').textContent = `৳${Math.round(grandTotal)}`;
            persistCart();
        }

        function applyCoupon() {
            const code = document.getElementById('coupon-input').value.trim().toUpperCase();
            const msgEl = document.getElementById('coupon-message');
            const subtotal = cartSubtotal();
            const coupon = mmCoupons.find(c => c.code === code);

            msgEl.classList.remove('hidden', 'text-red-500', 'text-emerald-500');

            if (!coupon) {
                appliedCoupon = null;
                appliedCouponCode = '';
                msgEl.classList.add('text-red-500');
                msgEl.textContent = L("অবৈধ কুপন কোড! (ট্রাই করুন FRESH50)", "Invalid coupon code! (try FRESH50)");
                calculateCartTotals();
                return;
            }

            const minTotal = Number(coupon.min_order_total || 0);
            if (minTotal > 0 && subtotal < minTotal) {
                appliedCoupon = null;
                appliedCouponCode = '';
                msgEl.classList.add('text-red-500');
                msgEl.textContent = `${L('এই কুপনটি সর্বনিম্ন', 'This coupon needs a minimum order of')} ৳${toBn(Math.round(minTotal))}${L(' অর্ডারে প্রযোজ্য।', '')}`;
                calculateCartTotals();
                return;
            }

            appliedCoupon = coupon;
            appliedCouponCode = coupon.code;
            const discount = couponDiscountAmount(subtotal);
            msgEl.classList.add('text-emerald-500');
            msgEl.textContent = coupon.type === 'percent'
                ? `${toBn(coupon.value)}% ${L('কুপন ছাড়', 'coupon discount')} (৳${toBn(discount)}) ${L('প্রয়োগ করা হয়েছে!', 'applied!')}`
                : `৳${toBn(Math.round(discount))} ${L('কুপন ছাড় প্রয়োগ করা হয়েছে!', 'coupon discount applied!')}`;
            calculateCartTotals();
        }

        // CHECKOUT MODAL WORKFLOW
        function openCheckoutModal() {
            if (cartItems.length === 0) {
                showToast(L("আপনার কার্ট খালি! প্রথমে মাছ যোগ করুন।", "Your cart is empty! Add some fish first."), "fa-basket-shopping", "text-amber-400");
                return;
            }
            closeCartDrawer();
            calculateFinalTotal();
            document.getElementById('checkout-modal').classList.remove('opacity-0', 'pointer-events-none');
            document.getElementById('checkout-panel').classList.add('show');
            syncBodyScrollLock();
        }

        function closeCheckoutModal() {
            document.getElementById('checkout-modal').classList.add('opacity-0', 'pointer-events-none');
            document.getElementById('checkout-panel').classList.remove('show');
            syncBodyScrollLock();
        }

        function selectedZoneCharge() {
            const sel = document.getElementById('cust-zone');
            if (!sel) return 0;
            const opt = sel.options[sel.selectedIndex];
            return parseInt((opt && opt.dataset.charge) || '0', 10) || 0;
        }

        function selectedZoneId() {
            const sel = document.getElementById('cust-zone');
            return sel ? parseInt(sel.value, 10) || null : null;
        }

        function calculateFinalTotal() {
            const subtotal = cartSubtotal();
            const discount = couponDiscountAmount(subtotal);
            const deliveryCharge = selectedZoneCharge();
            const grand = subtotal - discount + deliveryCharge;

            document.getElementById('final-subtotal').textContent = `৳${Math.round(subtotal)}`;
            document.getElementById('final-discount').textContent = `-৳${Math.round(discount)}`;
            document.getElementById('final-delivery').textContent = `৳${deliveryCharge}`;
            document.getElementById('final-total').textContent = `৳${Math.round(grand)}`;
        }

        function checkoutUrl() {
            return (window.__MM_ROUTES__ && window.__MM_ROUTES__.checkout) || '/checkout';
        }

        function csrfTokenUrl() {
            return (window.__MM_ROUTES__ && window.__MM_ROUTES__.csrf) || '/csrf-token';
        }

        function requestCheckout(payload, token) {
            return fetch(checkoutUrl(), {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json',
                    'X-CSRF-TOKEN': token
                },
                body: JSON.stringify(payload)
            });
        }

        async function refreshCsrfToken() {
            try {
                const response = await fetch(csrfTokenUrl(), {
                    headers: { 'Accept': 'application/json' },
                    credentials: 'same-origin',
                    cache: 'no-store'
                });
                const data = await response.json();
                if (data.token) {
                    const meta = document.querySelector('meta[name="csrf-token"]');
                    if (meta) meta.content = data.token;
                    return data.token;
                }
            } catch (e) { /* noop */ }
            return null;
        }

        function checkoutErrorMessage(status) {
            if (status === 419) return L('সেশনের মেয়াদ শেষ হয়েছে। আবার চেষ্টা করুন।', 'Your session expired. Please try again.');
            if (status === 429) return L('অনেকবার চেষ্টা করা হয়েছে। এক মিনিট পর আবার চেষ্টা করুন।', 'Too many attempts. Please try again in a minute.');
            if (status >= 500) return L('সার্ভারে সাময়িক সমস্যা হয়েছে। কিছুক্ষণ পর আবার চেষ্টা করুন।', 'A temporary server error occurred. Please try again shortly.');
            return '';
        }

        async function submitOrder() {
            const name = document.getElementById('cust-name').value.trim();
            const phone = document.getElementById('cust-phone').value.trim();
            const email = document.getElementById('cust-email') ? document.getElementById('cust-email').value.trim() : '';
            const address = document.getElementById('cust-address').value.trim();
            const timeSlot = document.getElementById('cust-timeslot').value;

            if (!name || !phone || !address) {
                showToast(L("অনুগ্রহ করে নাম, মোবাইল নম্বর এবং ঠিকানা পূরণ করুন।", "Please fill in your name, mobile number and address."), "fa-triangle-exclamation", "text-amber-400");
                return;
            }

            if (cartItems.length === 0) {
                showToast(L("আপনার কার্ট খালি! প্রথমে মাছ যোগ করুন।", "Your cart is empty! Add some fish first."), "fa-basket-shopping", "text-amber-400");
                return;
            }

            const paymentInput = document.querySelector('input[name="payment"]:checked');
            const paymentMethod = paymentInput ? paymentInput.value : 'cod';

            const items = cartItems.filter(item => !item.isCombo).map(item => ({
                product_id: item.productId || item.id,
                size_id: item.sizeId,
                weight_kg: item.weight
            }));

            const combos = cartItems.filter(item => item.isCombo).map(item => ({
                combo_pack_id: item.comboPackId || null,
                target: item.comboTarget || item.comboDetails.length,
                quantity: Math.max(1, parseInt(item.weight, 10) || 1),
                items: item.comboDetails.map(d => ({
                    product_id: d.product_id,
                    size_id: d.size_id,
                    weight_kg: d.weight
                }))
            }));

            const payload = {
                customer_name: name,
                customer_phone: phone,
                customer_email: email || null,
                customer_address: address,
                zone_id: selectedZoneId(),
                time_slot: timeSlot,
                payment_method: paymentMethod,
                coupon_code: appliedCouponCode || null,
                items: items,
                combos: combos
            };

            if (combos.length === 1) payload.combo = combos[0];

            const submitBtn = document.getElementById('checkout-submit-btn');
            if (submitBtn) {
                submitBtn.disabled = true;
                submitBtn.classList.add('opacity-70', 'cursor-wait');
            }

            try {
                const meta = document.querySelector('meta[name="csrf-token"]');
                let response = await requestCheckout(payload, meta ? meta.content : '');

                if (response.status === 419) {
                    const freshToken = await refreshCsrfToken();
                    if (freshToken) response = await requestCheckout(payload, freshToken);
                }

                const raw = await response.text();
                let data = {};
                try { data = raw ? JSON.parse(raw) : {}; } catch (e) { data = {}; }

                if (!response.ok) {
                    let message = '';
                    if (data.errors) {
                        const first = Object.values(data.errors)[0];
                        if (Array.isArray(first) && first.length) message = first[0];
                    }
                    if (!message) message = checkoutErrorMessage(response.status) || data.message || L('অর্ডার সম্পন্ন করা যায়নি। আবার চেষ্টা করুন।', 'Could not place the order. Please try again.');
                    console.error('Checkout failed', response.status, raw.slice(0, 500));
                    showToast(message, "fa-triangle-exclamation", "text-amber-400");
                    return;
                }

                document.getElementById('order-id-display').textContent = data.order_number;
                document.getElementById('order-cust-name').textContent = data.customer_name;
                document.getElementById('order-time-display').textContent = data.time_slot_label;
                document.getElementById('order-payment-label').textContent = `${L('মোট টাকা', 'Total')} (${data.payment_label}):`;
                document.getElementById('order-total-display').textContent = `৳${data.grand_total}`;
                renderPaymentInfo(data);

                closeCheckoutModal();
                openSuccessModal();

                // Clear cart state
                cartItems = [];
                appliedCoupon = null;
                appliedCouponCode = '';
                document.getElementById('coupon-input').value = '';
                document.getElementById('coupon-message').classList.add('hidden');
                renderCartItemsUI();
            } catch (e) {
                showToast(L("নেটওয়ার্ক সমস্যা! ইন্টারনেট সংযোগ চেক করে আবার চেষ্টা করুন।", "Network problem! Check your internet connection and try again."), "fa-triangle-exclamation", "text-amber-400");
            } finally {
                if (submitBtn) {
                    submitBtn.disabled = false;
                    submitBtn.classList.remove('opacity-70', 'cursor-wait');
                }
            }
        }

        function openSuccessModal() {
            document.getElementById('success-modal').classList.remove('opacity-0', 'pointer-events-none');
            document.getElementById('success-panel').classList.add('show');
        }

        function renderPaymentInfo(data) {
            const box = document.getElementById('payment-info-box');
            const numberRow = document.getElementById('order-payment-number-row');
            const payLink = document.getElementById('order-payment-link');
            const waLink = document.getElementById('order-whatsapp-link');
            const emailNote = document.getElementById('order-email-note');

            emailNote.classList.toggle('hidden', !data.email_sent);

            // Review CTA — only rendered when the signed review link is available
            const reviewLink = document.getElementById('order-review-link');
            if (reviewLink) {
                if (data.review_url) {
                    reviewLink.href = data.review_url;
                    reviewLink.classList.remove('hidden');
                    reviewLink.classList.add('flex');
                } else {
                    reviewLink.classList.add('hidden');
                    reviewLink.classList.remove('flex');
                }
            }

            const online = ['bkash', 'nagad', 'card'].includes(data.payment_method);
            if (!online) {
                box.classList.add('hidden');
                return;
            }

            box.classList.remove('hidden');
            document.getElementById('payment-info-title').textContent = `${data.payment_label} ${L('পেমেন্ট', 'payment')}`;

            const paymentIcon = document.getElementById('order-payment-icon');
            if (paymentIcon) {
                if (data.payment_icon) {
                    paymentIcon.src = data.payment_icon;
                    paymentIcon.classList.remove('hidden');
                } else {
                    paymentIcon.removeAttribute('src');
                    paymentIcon.classList.add('hidden');
                }
            }

            if (data.payment_number) {
                numberRow.classList.remove('hidden');
                numberRow.classList.add('flex');
                document.getElementById('order-payment-number').textContent = data.payment_number;
            } else {
                numberRow.classList.add('hidden');
                numberRow.classList.remove('flex');
            }

            document.getElementById('order-payment-instructions').textContent = data.payment_instructions
                || L('পেমেন্ট সম্পন্ন করে WhatsApp-এ ট্রানজেকশন আইডি পাঠিয়ে অর্ডার কনফার্ম করুন।', 'Complete the payment, then send the transaction ID on WhatsApp to confirm your order.');

            if (data.payment_link) {
                payLink.href = data.payment_link;
                payLink.classList.remove('hidden');
                payLink.classList.add('flex');
            } else {
                payLink.classList.add('hidden');
                payLink.classList.remove('flex');
            }

            if (data.whatsapp_link) {
                waLink.href = data.whatsapp_link;
                waLink.classList.remove('hidden');
            } else {
                waLink.classList.add('hidden');
            }
        }

        function closeSuccessModal() {
            document.getElementById('success-modal').classList.add('opacity-0', 'pointer-events-none');
            document.getElementById('success-panel').classList.remove('show');
        }

        // QUICK BUY PROMOTIONAL ITEM — resolve the featured product from the injected data
        function quickBuyFeaturedItem() {
            const item = productsData.find(p => p.featured && p.inStock) || productsData.find(p => p.inStock);
            if (!item) {
                showToast(L("এই মুহূর্তে কোনো পণ্য স্টকে নেই।", "No products are in stock right now."), "fa-triangle-exclamation", "text-amber-400");
                return;
            }
            addItemToCart(item.id);
        }

        // ============================================================
        // COMBO PACKAGE BUILDER — packs/discounts come from the admin panel
        // ============================================================
        function currentComboPack() {
            return mmComboPacks.find(p => Number(p.itemCount) === Number(comboTarget)) || mmComboPacks[0] || null;
        }

        function comboDiscountPct() {
            const pack = currentComboPack();
            return pack && pack.discountType === 'percent' ? Number(pack.discountValue) : 0;
        }

        function comboDiscountLabel() {
            const pack = currentComboPack();
            if (!pack) return '';
            return pack.discountLabel || (pack.discountType === 'percent' ? toBn(pack.discountValue) + '%' : '৳' + toBn(pack.discountValue));
        }

        function comboDiscountAmount(subtotal) {
            const pack = currentComboPack();
            if (!pack) return 0;
            const value = Number(pack.discountValue) || 0;
            const discount = pack.discountType === 'percent' ? subtotal * (value / 100) : value;
            return Math.max(0, Math.min(Math.round(discount), Math.round(subtotal)));
        }

        function comboBnDigit() {
            return toBn(comboTarget);
        }

        function setComboTarget(n) {
            n = Number(n);
            if (!mmComboPacks.some(p => Number(p.itemCount) === n)) return;
            if (comboTarget === n) return;
            comboTarget = n;
            if (comboSelections.length > n) {
                comboSelections = comboSelections.slice(0, n);
                showToast(L("কম্বো সাইজ পরিবর্তনের কারণে অতিরিক্ত মাছ বাদ দেওয়া হয়েছে।", "Extra fish were removed because the combo size changed."), "fa-circle-info", "text-sky-400");
            }
            renderComboBuilder();
        }

        function toggleComboItem(prodId) {
            const idx = comboSelections.findIndex(s => s.id === prodId);
            if (idx > -1) {
                comboSelections.splice(idx, 1);
                renderComboBuilder();
                return;
            }
            if (comboSelections.length >= comboTarget) {
                showToast(`${L('সর্বোচ্চ', 'You can pick up to')} ${toBn(comboTarget)} ${L('টি মাছ নেওয়া যাবে! নতুন মাছ যোগ করতে আগে একটি বাদ দিন।', 'fish! Remove one before adding another.')}`, "fa-triangle-exclamation", "text-amber-400");
                return;
            }
            comboSelections.push({ id: prodId, sizeIdx: 0, weight: 1.0 });
            renderComboBuilder(true);
        }

        function removeComboItem(prodId) {
            comboSelections = comboSelections.filter(s => s.id !== prodId);
            renderComboBuilder();
        }

        function updateComboSize(prodId, sizeIdx) {
            const sel = comboSelections.find(s => s.id === prodId);
            if (sel) {
                sel.sizeIdx = parseInt(sizeIdx);
                renderComboBuilder();
            }
        }

        function updateComboWeight(prodId, delta) {
            const sel = comboSelections.find(s => s.id === prodId);
            if (!sel) return;
            let next = sel.weight + delta;
            if (next < 0.5) next = 0.5;
            if (next > 5) next = 5;
            sel.weight = parseFloat(next.toFixed(1));
            renderComboBuilder();
        }

        function resetCombo(silent = true) {
            comboSelections = [];
            renderComboBuilder();
            if (!silent) showToast(L("কম্বো নির্বাচন রিসেট করা হয়েছে।", "Combo selection has been reset."), "fa-rotate-left", "text-sky-400");
        }

        function renderComboBuilder(animate = false) {
            if (!document.getElementById('combo-items-grid')) return;
            const count = comboSelections.length;
            const complete = count === comboTarget;

            // Package size toggle styles (gold = active)
            document.querySelectorAll('.combo-target-btn').forEach(btn => {
                const active = Number(btn.dataset.itemCount) === comboTarget;
                btn.className = active
                    ? "combo-target-btn px-4 sm:px-5 py-2 rounded-xl text-center transition-all duration-300 bg-gradient-to-r from-gold-400 to-amber-500 text-slate-950 shadow-md shadow-gold-500/25 scale-[1.03]"
                    : "combo-target-btn px-4 sm:px-5 py-2 rounded-xl text-center transition-all duration-300 text-ink2 hover:text-ink";
            });

            // Progress label + fill + slots
            document.getElementById('combo-progress-label').textContent = complete
                ? L("কম্বো রেডি হয়ে গেছে!", "Your combo is ready!")
                : `${toBn(count)}/${toBn(comboTarget)} ${L('আইটেম নির্বাচিত — আরও', 'items selected —')} ${toBn(comboTarget - count)} ${L('টি বাকি', 'more to go')}`;
            document.getElementById('combo-progress-hint').textContent = complete
                ? L("এখন ঝুড়িতে কম্বোটি যোগ করুন", "Now add the combo to your cart")
                : L("প্রতিটি আইটেম ভিন্ন হতে হবে", "Each item must be different");

            const fill = document.getElementById('combo-progress-fill');
            fill.style.width = (count / comboTarget * 100) + '%';
            fill.classList.toggle('done', complete);

            document.getElementById('combo-slots').innerHTML = Array.from({ length: comboTarget }, (_, i) => {
                const filled = i < count;
                return `<div class="combo-slot w-9 h-9 rounded-xl border flex items-center justify-center text-sm ${filled
                    ? 'border-emerald-500/60 bg-emerald-500/15 text-emerald-500 scale-110'
                    : 'border-dashed border-line text-ink3 bg-card2/50'}">
                    <i class="fa-solid ${filled ? 'fa-fish' : 'fa-plus'}"></i>
                </div>`;
            }).join('');

            // Fish picker grid (in-stock items only; tap toggles selection)
            document.getElementById('combo-items-grid').innerHTML = productsData.filter(p => p.inStock).map(p => {
                const sel = comboSelections.find(s => s.id === p.id);
                return `
                <button type="button" onclick="toggleComboItem(${p.id})" aria-pressed="${!!sel}"
                        class="combo-mini group text-left rounded-2xl border p-2.5 flex flex-col gap-2 ${sel
                            ? 'selected border-aqua-500 bg-aqua-500/10' + (animate ? ' combo-pop' : '')
                            : 'border-line bg-card2/50'}">
                    <span class="relative block ${comboThumbShape === 'circle' ? 'w-20 h-20 mx-auto rounded-full' : 'h-20 rounded-xl'} overflow-hidden">
                        <img src="${p.image}" alt="${pName(p)}" loading="lazy" class="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500">
                        <span class="combo-check absolute top-1.5 right-1.5 w-6 h-6 rounded-full bg-emerald-500 text-white text-[11px] shadow-lg">
                            <i class="fa-solid fa-check"></i>
                        </span>
                    </span>
                    <span class="block">
                        <span class="block text-xs font-bold text-ink leading-tight truncate">${pName(p)}</span>
                        <span class="block text-[10px] text-ink3 mt-0.5">৳${p.sizes[0].pricePerKg}${L('/কেজি থেকে শুরু', '/kg onwards')}</span>
                    </span>
                </button>`;
            }).join('');

            // Summary rows (per-item size + weight config)
            const body = document.getElementById('combo-summary-body');
            const empty = document.getElementById('combo-summary-empty');
            document.getElementById('combo-count-chip').textContent = `${toBn(count)}/${toBn(comboTarget)}`;

            if (count === 0) {
                body.classList.add('hidden');
                empty.classList.remove('hidden');
                body.innerHTML = '';
            } else {
                empty.classList.add('hidden');
                body.classList.remove('hidden');
                body.innerHTML = comboSelections.map(sel => {
                    const p = productsData.find(x => x.id === sel.id);
                    const size = p.sizes[sel.sizeIdx];
                    const lineTotal = Math.round(size.pricePerKg * sel.weight);
                    return `
                    <div class="rounded-xl border border-line bg-card2/60 p-2.5 space-y-2 ${animate ? 'combo-row-in' : ''}">
                        <div class="flex items-center gap-2">
                            <img src="${p.image}" alt="${pName(p)}" class="w-9 h-9 ${comboThumbShape === 'circle' ? 'rounded-full' : 'rounded-lg'} object-cover border border-line">
                            <div class="flex-1 min-w-0">
                                <p class="text-xs font-bold text-ink truncate">${pName(p)}</p>
                                <p class="text-[10px] text-ink3">৳${size.pricePerKg}${L('/কেজি', '/kg')}</p>
                            </div>
                            <button onclick="removeComboItem(${p.id})" aria-label="${L('বাদ দিন', 'Remove')}" class="text-ink3 hover:text-red-500 text-sm p-1.5 transition-colors">
                                <i class="fa-solid fa-xmark"></i>
                            </button>
                        </div>
                        <div class="flex items-center gap-1.5">
                            <select onchange="updateComboSize(${p.id}, this.value)" class="flex-1 min-w-0 bg-card border border-line rounded-lg px-2 py-2 text-[11px] font-semibold text-ink focus:outline-none focus:border-aqua-500">
                                ${p.sizes.map((s, i) => `<option value="${i}" ${i === sel.sizeIdx ? 'selected' : ''}>${s.label}</option>`).join('')}
                            </select>
                            <div class="flex items-center gap-1 bg-card border border-line rounded-lg p-0.5 shrink-0">
                                <button onclick="updateComboWeight(${p.id}, -0.5)" class="w-8 h-8 rounded-lg bg-card2 border border-line font-bold text-sm text-ink flex items-center justify-center active:scale-90 transition-all">-</button>
                                <span class="text-[10px] font-bold text-ink w-11 text-center">${sel.weight} ${L('কেজি', 'kg')}</span>
                                <button onclick="updateComboWeight(${p.id}, 0.5)" class="w-8 h-8 rounded-lg bg-card2 border border-line font-bold text-sm text-ink flex items-center justify-center active:scale-90 transition-all">+</button>
                            </div>
                        </div>
                        <div class="text-right text-xs font-black text-ink">৳${lineTotal}</div>
                    </div>`;
                }).join('');
            }

            // Live totals
            const subtotal = comboSelections.reduce((sum, sel) => {
                const p = productsData.find(x => x.id === sel.id);
                return sum + p.sizes[sel.sizeIdx].pricePerKg * sel.weight;
            }, 0);
            const discount = comboDiscountAmount(subtotal);
            const total = Math.round(subtotal - discount);
            const discountLabel = comboDiscountLabel();

            document.getElementById('combo-subtotal').textContent = `৳${Math.round(subtotal)}`;
            document.getElementById('combo-discount-label').textContent = `${L('কম্বো ছাড়', 'Combo discount')} (${discountLabel}):`;
            document.getElementById('combo-discount').textContent = `-৳${discount}`;
            document.getElementById('combo-total').textContent = `৳${total}`;

            const saveBadge = document.getElementById('combo-save-badge');
            saveBadge.classList.toggle('hidden', subtotal === 0);
            saveBadge.classList.toggle('flex', subtotal > 0);
            document.getElementById('combo-save-amount').textContent = `৳${discount} (${discountLabel})`;

            // CTA state — enabled & pulsing only when combo is complete
            const btn = document.getElementById('combo-add-btn');
            const remaining = comboTarget - count;
            if (complete) {
                btn.disabled = false;
                btn.className = "btn-glow w-full font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 transition-all transform active:scale-95 combo-ready bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white shadow-lg shadow-emerald-500/25";
                btn.innerHTML = `<i class="fa-solid fa-gift"></i> ${L('কম্বো ঝুড়িতে যোগ করুন', 'Add combo to cart')} (৳${total})`;
            } else {
                btn.disabled = true;
                btn.className = "w-full font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2 cursor-not-allowed bg-card2/80 border border-line text-ink3";
                btn.innerHTML = `<i class="fa-solid fa-basket-shopping"></i> ${L('আরও', 'Select')} ${toBn(remaining)} ${L('টি মাছ নির্বাচন করুন', 'more fish')}`;
            }
        }

        function addComboToCart() {
            const pack = currentComboPack();
            if (!pack) {
                showToast(L("কম্বো প্যাকেজটি পাওয়া যায়নি। পেজ রিফ্রেশ করুন।", "Combo package not found. Please refresh the page."), "fa-triangle-exclamation", "text-amber-400");
                return;
            }
            if (comboSelections.length !== comboTarget) {
                showToast(`${L('কম্বো সম্পূর্ণ করতে আরও', 'Select')} ${toBn(comboTarget - comboSelections.length)} ${L('টি ভিন্ন মাছ নির্বাচন করুন।', 'more different fish to complete the combo.')}`, "fa-triangle-exclamation", "text-amber-400");
                return;
            }

            const discountLabel = comboDiscountLabel();
            const details = comboSelections.map(sel => {
                const p = productsData.find(x => x.id === sel.id);
                const size = p.sizes[sel.sizeIdx];
                return {
                    product_id: p.id,
                    size_id: size.id,
                    nameBng: p.nameBng,
                    nameEng: p.nameEng,
                    sizeLabel: size.label,
                    pricePerKg: size.pricePerKg,
                    weight: sel.weight
                };
            });

            const subtotal = Math.round(details.reduce((s, d) => s + d.pricePerKg * d.weight, 0));
            const discount = comboDiscountAmount(subtotal);
            const total = Math.round(subtotal - discount);

            cartItems.push({
                id: 'combo-' + Date.now(),
                isCombo: true,
                comboPackId: pack.id,
                comboTarget: comboTarget,
                comboDiscountType: pack.discountType,
                comboDiscountValue: Number(pack.discountValue),
                comboDiscountLabel: discountLabel,
                comboDiscountPct: comboDiscountPct(),
                nameBng: pack.nameBn || L(`চয়েস কম্বো প্যাকেজ (${comboBnDigit()}টি মাছ)`, `Custom combo pack (${comboBnDigit()} fish)`),
                nameEng: pack.nameEn || '',
                image: productsData.find(x => x.id === comboSelections[0].id).image,
                sizeLabel: `${comboBnDigit()} ${L('টি ভিন্ন মাছ একসাথে', 'different fish together')} • ${discountLabel}`,
                pricePerKg: total, // কম্বো প্যাকের মূল্য
                weight: 1,         // প্যাক সংখ্যা
                comboDetails: details
            });

            renderCartItemsUI();
            popCartBadge();
            showToast(`${L('কম্বো প্যাকেজ কার্টে যোগ হয়েছে! আপনি সাশ্রয় করলেন', 'Combo package added to cart! You saved')} ৳${subtotal - total} (${discountLabel})${L('।', '.')}`, "fa-gift", "text-gold-400");
            resetCombo();
            openCartDrawer();
        }

        // TOAST NOTIFICATIONS (frosted glass, icon-aware)
        function showToast(msg, icon = "fa-circle-check", iconColor = "text-emerald-400") {
            const container = document.getElementById('toast-container');
            const toast = document.createElement('div');
            toast.className = "toast-glass border border-line text-ink text-xs px-4 py-3 rounded-2xl flex items-center gap-2 toast-enter pointer-events-auto";

            const iconEl = document.createElement('i');
            iconEl.className = `fa-solid ${icon} ${iconColor} text-base`;
            const textEl = document.createElement('span');
            textEl.textContent = msg;
            toast.append(iconEl, textEl);

            container.appendChild(toast);

            setTimeout(() => {
                toast.classList.remove('toast-enter');
                toast.classList.add('toast-exit');
                setTimeout(() => toast.remove(), 350);
            }, 3000);
        }

        // FAQ ACCORDION TOGGLE (smooth height animation)
        function toggleFaq(btn) {
            btn.closest('.faq-item').classList.toggle('open');
        }
    </script>
