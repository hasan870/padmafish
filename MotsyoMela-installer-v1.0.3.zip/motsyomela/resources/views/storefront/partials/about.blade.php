    <!-- ABOUT US SECTION (admin-editable, above the footer) -->
    @php
        $aboutTitle = trim((string) ($settings['about_title'] ?? '')) ?: tr('আমাদের সম্পর্কে', 'About us');
        $aboutSubtitle = trim((string) ($settings['about_subtitle'] ?? '')) ?: tr('মৎস্যমেলা — তাজা মাছের বিশ্বস্ত ঠিকানা', 'MotsyoMela — your trusted source for fresh fish');
        $aboutText = trim((string) ($settings['about_text'] ?? ''))
            ?: 'মৎস্যমেলা শুরু হয়েছিল একটি সহজ লক্ষ্য নিয়ে — শহরের মানুষের কাছে সরাসরি ঘাট থেকে তাজা, ফরমালিনমুক্ত মাছ পৌঁছে দেওয়া। আমাদের নিজস্ব কোয়ালিটি টিম প্রতিদিন মাছ যাচাই করে, পরিষ্কার করে এবং ফুড-গ্রেড আইস বক্সে প্যাক করে আপনার দরজায় পৌঁছে দেয়।';
        $aboutPoints = collect(preg_split('/\r\n|\r|\n/', (string) ($settings['about_points'] ?? '')))
            ->map(fn ($line) => trim($line))
            ->filter()
            ->values();
        if ($aboutPoints->isEmpty()) {
            $aboutPoints = collect([
                'সরাসরি ঘাট ও নিবন্ধিত খামার থেকে সংগ্রহ',
                'প্রতিটি ব্যাচে ফরমালিন টেস্ট ও মান যাচাই',
                'বিনামূল্যে কাটাই, পরিষ্কার ও ফুড-গ্রেড প্যাকিং',
                'ঢাকায় ২–৩ ঘণ্টায় এক্সপ্রেস ডেলিভারি',
            ]);
        }
        $aboutImagePath = (string) ($settings['about_image'] ?? '');
        $aboutImageUrl = $aboutImagePath !== '' ? \Illuminate\Support\Facades\Storage::url($aboutImagePath) : null;
        $aboutWhatsApp = whatsapp_url($settings['whatsapp_number'] ?? '', 'হ্যালো, আমি মৎস্যমেলা সম্পর্কে জানতে চাই।');
    @endphp
    <section id="about-section" data-reveal class="mt-16 glass rounded-3xl p-6 sm:p-10 overflow-hidden relative">
        <div class="absolute -top-20 -right-20 w-64 h-64 bg-aqua-500/10 rounded-full blur-3xl pointer-events-none"></div>
        <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center relative z-10">
            <div class="order-2 lg:order-1">
                <span class="inline-flex items-center gap-1.5 text-[11px] font-bold text-aqua-600 dark:text-aqua-300 bg-aqua-500/10 border border-aqua-500/25 px-3 py-1 rounded-full">
                    <i class="fa-solid fa-fish-fins"></i> {{ tr('আমাদের সম্পর্কে', 'About us') }}
                </span>
                <h2 class="text-2xl sm:text-3xl font-black text-ink mt-3">{{ $aboutTitle }}</h2>
                <p class="text-xs font-semibold text-aqua-600 dark:text-aqua-400 mt-1">{{ $aboutSubtitle }}</p>
                <p class="text-sm text-ink2 leading-relaxed mt-4">{!! nl2br(e($aboutText)) !!}</p>

                <ul class="mt-5 grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                    @foreach ($aboutPoints as $point)
                        <li class="flex items-start gap-2 text-xs text-ink2">
                            <i class="fa-solid fa-circle-check text-aqua-500 mt-0.5 shrink-0"></i>
                            <span>{{ $point }}</span>
                        </li>
                    @endforeach
                </ul>

                <div class="flex flex-wrap items-center gap-2 mt-6">
                    <a href="#product-section" class="bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold px-4 py-2.5 rounded-xl text-xs shadow-lg shadow-aqua-600/25 transition-all active:scale-95">
                        <i class="fa-solid fa-fish mr-1.5"></i> {{ tr('মাছ দেখুন', 'Browse fish') }}
                    </a>
                    @if ($aboutWhatsApp)
                        <a href="{{ $aboutWhatsApp }}" target="_blank" rel="noopener" class="glass-chip text-ink2 hover:text-ink font-bold px-4 py-2.5 rounded-xl text-xs transition-colors">
                            <i class="fa-brands fa-whatsapp text-[#25D366] mr-1.5"></i> {{ tr('আমাদের সাথে কথা বলুন', 'Talk to us') }}
                        </a>
                    @endif
                </div>
            </div>

            <div class="order-1 lg:order-2">
                <div class="relative rounded-2xl overflow-hidden border border-line bg-card2 aspect-[4/3]">
                    @if ($aboutImageUrl)
                        <img src="{{ $aboutImageUrl }}" alt="{{ $aboutTitle }}" loading="lazy" class="w-full h-full object-cover">
                    @else
                        <div class="w-full h-full bg-gradient-to-br from-aqua-600/25 via-sky-600/15 to-emerald-500/20 flex flex-col items-center justify-center gap-3 text-center p-6">
                            <span class="w-16 h-16 rounded-2xl bg-white/10 border border-white/20 flex items-center justify-center text-aqua-500 dark:text-aqua-300 text-3xl">
                                <i class="fa-solid fa-fish-fins"></i>
                            </span>
                            <p class="text-sm font-bold text-ink">{{ $settings['site_name'] ?? 'মৎস্যমেলা' }}</p>
                            <p class="text-[11px] text-ink3 max-w-[16rem]">{{ $settings['site_tagline'] ?? '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট' }}</p>
                        </div>
                    @endif
                    <span class="absolute bottom-3 left-3 bg-slate-950/70 backdrop-blur-md text-white text-[10px] font-bold px-3 py-1.5 rounded-full border border-white/15">
                        <i class="fa-solid fa-shield-halved text-emerald-400 mr-1"></i> {{ tr('১০০% ফরমালিনমুক্ত গ্যারান্টি', '100% formalin-free guarantee') }}
                    </span>
                </div>
            </div>
        </div>
    </section>
