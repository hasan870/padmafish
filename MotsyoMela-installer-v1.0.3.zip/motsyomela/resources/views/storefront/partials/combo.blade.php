        <!-- ============================================================
             COMBO PACKAGE BUILDER — packs and discounts are managed in admin
             ============================================================ -->
        @php
            $firstPack = $comboPacks->first();
            $packCountsBn = $comboPacks->pluck('item_count')->map(fn ($count) => bn_num($count))->implode(' বা ');
        @endphp
        <section id="combo-section" data-reveal class="mt-16 scroll-mt-32">
            <div class="promo-card glass-strong rounded-3xl p-5 sm:p-8 relative overflow-hidden">

                <!-- Decorative glows -->
                <div class="absolute -top-20 -left-20 w-64 h-64 bg-gold-500/10 rounded-full blur-3xl pointer-events-none"></div>
                <div class="absolute -bottom-24 -right-16 w-72 h-72 bg-aqua-500/10 rounded-full blur-3xl pointer-events-none"></div>

                <!-- Header row -->
                <div class="relative z-10 flex flex-col lg:flex-row lg:items-end justify-between gap-5">
                    <div>
                        <span class="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-gold-600 dark:text-gold-400 bg-gold-500/12 border border-gold-500/30 px-3 py-1 rounded-full">
                            <i class="fa-solid fa-gift"></i> {{ tr('কম্বো সেভিংস ডিল', 'Combo savings deal') }}
                        </span>
                        <h2 class="text-2xl sm:text-3xl font-black text-ink mt-3">{{ tr('নিজের পছন্দমতো কম্বো প্যাকেজ বানান', 'Build a combo package your way') }}</h2>
                        <p class="text-xs sm:text-sm text-ink2 mt-1.5 max-w-2xl leading-relaxed">
                            {{ $packCountsBn }} {{ tr('টি ভিন্ন মাছ বেছে নিন — সাথে সাথেই পাচ্ছেন এক্সক্লুসিভ কম্বো ছাড়, ফ্রি কাটাই-ক্লিনিং এবং ফ্রি আইস-বক্স প্যাকিং।', 'different fish and instantly get an exclusive combo discount, free cutting & cleaning, and free ice-box packing.') }}
                        </p>
                    </div>

                    <!-- Package size switch (managed packs) -->
                    <div class="flex items-center gap-1.5 bg-card2/70 border border-line p-1.5 rounded-2xl shrink-0 self-start max-w-full overflow-x-auto scrollbar-none">
                        @foreach ($comboPacks as $pack)
                            <button id="combo-target-{{ $pack->item_count }}" type="button"
                                    data-pack-id="{{ $pack->id }}"
                                    data-item-count="{{ $pack->item_count }}"
                                    data-discount-type="{{ $pack->discount_type }}"
                                    data-discount-value="{{ (float) $pack->discount_value }}"
                                    data-discount-label="{{ $pack->discountLabelBn() }}"
                                    onclick="setComboTarget({{ $pack->item_count }})"
                                    class="combo-target-btn px-4 sm:px-5 py-2 rounded-xl text-center transition-all duration-300 whitespace-nowrap">
                                <span class="block text-sm font-black leading-tight">{{ bn_num($pack->item_count) }} {{ tr('টি মাছ', 'fish') }}</span>
                                <span class="block text-[10px] font-semibold opacity-80">{{ $pack->discountLabelBn() }}</span>
                                @if ($pack->badge_bn)
                                    <span class="inline-block mt-0.5 text-[9px] font-bold text-gold-600 dark:text-gold-400">{{ $pack->badge_bn }}</span>
                                @endif
                            </button>
                        @endforeach
                    </div>
                </div>

                <!-- Progress strip -->
                <div class="relative z-10 mt-6">
                    <div class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between text-xs font-bold mb-2 sm:gap-3">
                        <span id="combo-progress-label" class="text-ink2">0/{{ bn_num($firstPack->item_count) }} {{ tr('আইটেম নির্বাচিত', 'items selected') }}</span>
                        <span id="combo-progress-hint" class="text-ink3 font-medium sm:text-right">{{ tr('প্রতিটি আইটেম ভিন্ন হতে হবে', 'Every item must be different') }}</span>
                    </div>
                    <div class="h-2.5 bg-card2/80 border border-line/70 rounded-full overflow-hidden">
                        <div id="combo-progress-fill" class="h-full rounded-full combo-progress-fill" style="width:0%;"></div>
                    </div>
                    <div id="combo-slots" class="flex items-center gap-2 mt-3 flex-wrap"></div>
                </div>

                <!-- Picker + Live summary -->
                <div class="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-6 mt-7">

                    <!-- Fish picker grid -->
                    <div class="lg:col-span-2">
                        <h4 class="text-sm font-bold text-ink flex items-center gap-2 mb-3 flex-wrap">
                            <i class="fa-solid fa-fish-fins text-aqua-500"></i> {{ tr('মাছ বেছে নিন', 'Choose fish') }}
                            <span class="text-[10px] font-semibold text-ink3">{{ tr('(ট্যাপ করলে যোগ হবে, আবার ট্যাপ করলে বাদ যাবে)', '(tap to add, tap again to remove)') }}</span>
                        </h4>
                        <div id="combo-items-grid" class="grid grid-cols-2 sm:grid-cols-3 gap-3"></div>
                        <p class="text-[11px] text-ink3 mt-3 flex items-start gap-1.5">
                            <i class="fa-solid fa-circle-info text-aqua-500 mt-0.5"></i>
                            <span>{{ tr('প্রি-অর্ডার (স্টকে নেই) মাছ কম্বো প্যাকেজে প্রযোজ্য নয়। একই মাছ একাধিকবার যোগ করা যাবে না — প্রতিটি আইটেম অবশ্যই আলাদা হতে হবে।', 'Pre-order (out of stock) fish are not available in combo packages. The same fish cannot be added twice — every item must be different.') }}</span>
                        </p>
                    </div>

                    <!-- Live summary panel -->
                    <div class="glass rounded-2xl p-4 sm:p-5 flex flex-col self-start w-full">
                        <div class="flex items-center justify-between mb-3">
                            <h4 class="text-sm font-bold text-ink flex items-center gap-2"><i class="fa-solid fa-receipt text-gold-500"></i> {{ tr('কম্বো সারসংক্ষেপ', 'Combo summary') }}</h4>
                            <span id="combo-count-chip" class="text-[10px] font-black px-2 py-0.5 rounded-full bg-aqua-500/15 text-aqua-600 dark:text-aqua-300">0/{{ bn_num($firstPack->item_count) }}</span>
                        </div>

                        <div id="combo-summary-body" class="space-y-2.5 flex-1 overflow-y-auto max-h-80 lg:max-h-[430px] pr-0.5"></div>

                        <div id="combo-summary-empty" class="text-center py-9">
                            <i class="fa-solid fa-hand-pointer text-ink3 text-3xl mb-2 block"></i>
                            <p class="text-xs text-ink2 font-semibold">{{ tr('এখনো কোনো মাছ নির্বাচন করা হয়নি', 'No fish selected yet') }}</p>
                            <p class="text-[11px] text-ink3 mt-1">{{ tr('ট্যাপ করুন', 'Tap') }} {{ $packCountsBn }} {{ tr('টি ভিন্ন মাছে', 'different fish above') }}</p>
                        </div>

                        <!-- Totals + CTA -->
                        <div class="mt-auto pt-4 space-y-2 text-xs">
                            <div class="border-t border-line/70 pt-3 flex justify-between text-ink2">
                                <span>{{ tr('আসল মূল্য:', 'Subtotal:') }}</span>
                                <span id="combo-subtotal" class="font-bold text-ink">৳0</span>
                            </div>
                            <div class="flex justify-between text-ink2">
                                <span id="combo-discount-label">{{ tr('কম্বো ছাড়:', 'Combo discount:') }}</span>
                                <span id="combo-discount" class="font-bold text-emerald-500">-৳0</span>
                            </div>
                            <div id="combo-save-badge" class="hidden justify-between items-center bg-emerald-500/12 border border-emerald-500/30 text-emerald-600 dark:text-emerald-300 rounded-lg px-2.5 py-1.5 font-bold">
                                <span><i class="fa-solid fa-piggy-bank mr-1"></i> {{ tr('আপনার সাশ্রয়', 'You save') }}</span>
                                <span id="combo-save-amount">৳0</span>
                            </div>
                            <div class="flex justify-between text-sm font-black text-ink pt-2 border-t border-line/70">
                                <span>{{ tr('কম্বো মূল্য:', 'Combo total:') }}</span>
                                <span id="combo-total" class="text-aqua-500 dark:text-aqua-400 text-base total-pulse inline-block">৳0</span>
                            </div>

                            <button id="combo-add-btn" onclick="addComboToCart()" disabled
                                    class="w-full font-bold py-3 rounded-xl text-sm flex items-center justify-center gap-2">
                                <i class="fa-solid fa-basket-shopping"></i> {{ tr('কম্বো ঝুড়িতে যোগ করুন', 'Add combo to cart') }}
                            </button>
                            <button onclick="resetCombo(false)" class="w-full text-ink3 hover:text-red-400 font-semibold text-[11px] py-2 transition-colors">
                                <i class="fa-solid fa-rotate-left mr-1"></i> {{ tr('নির্বাচন রিসেট করুন', 'Reset selection') }}
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </section>
