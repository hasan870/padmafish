        <!-- WHY CHOOSE US & TRUST SECTION (premium dark glass band — intentional contrast in both themes) -->
        <section id="trust-section" data-reveal class="mt-16 bg-gradient-to-br from-navy-900 via-[#0c1a30] to-navy-950 rounded-3xl p-8 sm:p-12 text-white relative overflow-hidden shadow-2xl border border-slate-800">
            <div class="absolute -top-24 -right-24 w-80 h-80 bg-aqua-500/15 rounded-full blur-3xl pointer-events-none"></div>
            <div class="absolute -bottom-24 -left-24 w-72 h-72 bg-sky-600/10 rounded-full blur-3xl pointer-events-none"></div>

            <div class="max-w-3xl relative z-10">
                <span class="text-xs font-bold text-aqua-300 uppercase tracking-widest bg-aqua-500/10 px-3 py-1 rounded-full border border-aqua-400/25">{{ tr('মৎস্যমেলা কোয়ালিটি ওয়াদা', 'MotsyoMela quality promise') }}</span>
                <h2 class="text-2xl sm:text-4xl font-extrabold mt-3 mb-4">{{ tr('কেন আমরাই আপনার সেরা পছন্দ?', 'Why are we your best choice?') }}</h2>
                <p class="text-slate-300 text-sm leading-relaxed mb-8">
                    {{ tr('মাছ কেনাকাটায় সততা ও তাজাভাবই আমাদের মূল শক্তি। আমরা কোনো রাসায়নিক বা ক্ষতিকর কেমিক্যাল ব্যবহার করি না।', 'Honesty and freshness are at the heart of how we sell fish. We never use any harmful chemicals.') }}
                </p>

                <div class="grid grid-cols-1 sm:grid-cols-2 gap-6">
                    <div class="flex gap-4 group">
                        <div class="w-12 h-12 rounded-2xl bg-aqua-500/20 border border-aqua-400/30 flex items-center justify-center text-aqua-300 text-xl shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                            <i class="fa-solid fa-flask-vial"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-base text-white">{{ tr('ফরমালিন টেস্টেড', 'Formalin tested') }}</h4>
                            <p class="text-xs text-slate-400 mt-1">{{ tr('প্রতিদিন ল্যাব টেস্ট করে ফরমালিন মুক্ত সার্টিফাইড মাছই আমরা ডেলিভারি করি।', 'We lab-test every day and deliver only certified formalin-free fish.') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 group">
                        <div class="w-12 h-12 rounded-2xl bg-aqua-500/20 border border-aqua-400/30 flex items-center justify-center text-aqua-300 text-xl shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                            <i class="fa-solid fa-utensils"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-base text-white">{{ tr('ফ্রি ক্লিনিং ও কাটা সেবা', 'Free cleaning & cutting') }}</h4>
                            <p class="text-xs text-slate-400 mt-1">{{ tr('আপনার পছন্দমতো রিং কাট, পেটি কাট বা চামড়া ছাড়িয়ে পরিষ্কার করে পাঠানো হয়।', 'Cleaned and cut your way — ring cut, cube cut, or skin removed.') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 group">
                        <div class="w-12 h-12 rounded-2xl bg-aqua-500/20 border border-aqua-400/30 flex items-center justify-center text-aqua-300 text-xl shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                            <i class="fa-solid fa-snowflake"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-base text-white">{{ tr('ফুড-গ্রেড আইস বক্স', 'Food-grade ice box') }}</h4>
                            <p class="text-xs text-slate-400 mt-1">{{ tr('বিশেষ থার্মাল আইস বক্সে প্যাকেট করা হয় যাতে প্রাকৃতিকভাবে তাজা থাকে।', 'Packed in a special thermal ice box so it stays naturally fresh.') }}</p>
                        </div>
                    </div>

                    <div class="flex gap-4 group">
                        <div class="w-12 h-12 rounded-2xl bg-aqua-500/20 border border-aqua-400/30 flex items-center justify-center text-aqua-300 text-xl shrink-0 group-hover:scale-110 group-hover:rotate-6 transition-transform duration-300">
                            <i class="fa-solid fa-rotate-left"></i>
                        </div>
                        <div>
                            <h4 class="font-bold text-base text-white">{{ tr('তাত্ক্ষণিক রিফান্ড', 'Instant refund') }}</h4>
                            <p class="text-xs text-slate-400 mt-1">{{ tr('পছন্দ না হলে বা মানসম্মত না মনে হলে ডেলিভারির সময়েই ১০০% রিফান্ড সুবিধা।', 'If you are not satisfied with the quality at delivery, get a 100% refund on the spot.') }}</p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
