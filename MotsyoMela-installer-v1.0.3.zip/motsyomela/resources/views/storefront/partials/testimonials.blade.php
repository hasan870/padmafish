        <!-- CUSTOMER REVIEWS SECTION -->
        <section class="mt-16">
            <div data-reveal class="text-center max-w-xl mx-auto mb-10">
                <h2 class="text-2xl sm:text-3xl font-black text-ink">{{ tr('সম্মানিত গ্রাহকদের মতামত', 'What our customers say') }}</h2>
                <p class="text-xs sm:text-sm text-ink3 mt-1">{{ tr('দেশজুড়ে আমাদের ৫০০০+ সন্তুষ্ট গ্রাহকের অভিজ্ঞতা', 'Experiences from 5000+ happy customers across the country') }}</p>
            </div>

            <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                @foreach ($testimonials as $testimonial)
                <div data-reveal @if ($loop->index > 0) data-reveal-delay="{{ $loop->index * 120 }}ms" @endif class="review-card glass p-6 rounded-2xl relative">
                    <div class="flex items-center gap-1 text-gold-500 text-xs mb-3">
                        @for ($star = 1; $star <= 5; $star++)
                            <i class="fa-{{ $star <= $testimonial->rating ? 'solid' : 'regular' }} fa-star"></i>
                        @endfor
                    </div>
                    <p class="text-xs text-ink2 leading-relaxed italic mb-4">{{ $testimonial->quote_bn }}</p>
                    <div class="flex items-center gap-3">
                        <div class="w-9 h-9 rounded-full bg-card2 border border-line text-ink font-bold flex items-center justify-center text-xs">{{ $testimonial->initials }}</div>
                        <div>
                            <h5 class="text-xs font-bold text-ink">{{ $testimonial->customer_name_bn }}</h5>
                            <p class="text-[10px] text-ink3">{{ $testimonial->location_bn }}</p>
                        </div>
                    </div>
                </div>
                @endforeach
            </div>
        </section>
