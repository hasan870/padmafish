<!DOCTYPE html>
<html lang="bn" data-theme="dark">
<head>
    @php
        $fontOptions = storefront_fonts();
        $englishFontOptions = storefront_english_fonts();
        $fontKey = $settings['theme_font_bangla'] ?? ($settings['theme_font'] ?? 'hind-siliguri');
        if (! isset($fontOptions[$fontKey])) {
            $fontKey = 'hind-siliguri';
        }
        $fontFamily = $fontOptions[$fontKey]['family'] ?? 'Hind Siliguri';
        $englishFontKey = $settings['theme_font_english'] ?? 'inter';
        if (! isset($englishFontOptions[$englishFontKey])) {
            $englishFontKey = 'inter';
        }
        $englishFontFamily = $englishFontOptions[$englishFontKey]['family'] ?? 'Inter';
        $googleFontsUrl = google_fonts_url($fontFamily, $englishFontFamily, $fontOptions, $englishFontOptions);

        // Typography & icon scale from admin (percentages, 100 = theme default).
        $baseFontSize = min(22, max(13, (int) ($settings['theme_font_size'] ?? 16)));
        $scaleOf = static function (string $key, int $min = 70, int $max = 150) use ($settings): float {
            return min($max, max($min, (int) ($settings[$key] ?? 100))) / 100;
        };
        $h1Scale = number_format($scaleOf('theme_h1_scale'), 2, '.', '');
        $h2Scale = number_format($scaleOf('theme_h2_scale'), 2, '.', '');
        $h3Scale = number_format($scaleOf('theme_h3_scale'), 2, '.', '');
        $textScale = number_format($scaleOf('theme_text_scale', 80, 130), 2, '.', '');
        $iconScale = number_format($scaleOf('theme_icon_scale'), 2, '.', '');
        $textColor = trim((string) ($settings['theme_text_color'] ?? ''));
        $textColorShades = preg_match('/^#[0-9a-fA-F]{6}$/', $textColor) === 1 ? theme_palette($textColor) : null;
        $bgStyle = $settings['theme_bg_style'] ?? 'aurora';
        $bgImagePath = (string) ($settings['theme_bg_image'] ?? '');
        $bgImageUrl = $bgImagePath !== '' ? \Illuminate\Support\Facades\Storage::url($bgImagePath) : null;
        if ($bgStyle === 'image' && ! $bgImageUrl) {
            $bgStyle = 'aurora';
        }
        $bgOverlay = min(90, max(0, (int) ($settings['theme_bg_overlay'] ?? 60)));
        $themePrimary = $settings['theme_primary'] ?? '#14b8a6';
        $themeSecondary = $settings['theme_secondary'] ?? '#0284c7';
        $themeAccent = $settings['theme_accent'] ?? '#f59e0b';
        $primaryShades = theme_palette($themePrimary);
        $secondaryShades = theme_palette($themeSecondary);
        $accentShades = theme_palette($themeAccent);
        $themeRadius = min(32, max(0, (int) ($settings['theme_radius'] ?? 16)));
        $themeBorderWidth = min(3, max(0, (int) ($settings['theme_border_width'] ?? 1)));
        $siteName = $settings['site_name'] ?? 'মৎস্যমেলা';
        $siteTagline = $settings['site_tagline'] ?? '১০০% বিশুদ্ধ ও তাজা মাছের ঘাট';

        $seoMetaTitle = trim((string) ($settings['seo_meta_title'] ?? ''));
        $seoMetaDescription = trim((string) ($settings['seo_meta_description'] ?? ''));
        $seoMetaKeywords = trim((string) ($settings['seo_meta_keywords'] ?? ''));
        $seoRobots = $settings['seo_robots'] ?? 'index,follow';
        $seoOgPath = (string) ($settings['seo_og_image'] ?? '');
        $seoOgUrl = $seoOgPath !== '' ? \Illuminate\Support\Facades\Storage::url($seoOgPath) : null;
        $seoVerification = trim((string) ($settings['seo_google_verification'] ?? ''));
        $gaMeasurementId = trim((string) ($settings['seo_ga4_id'] ?? ''));
        $gaEnabled = ($settings['seo_ga_enabled'] ?? '0') === '1' && $gaMeasurementId !== '';
        $seoTitle = $seoMetaTitle !== '' ? $seoMetaTitle : $siteName.' | '.$siteTagline;
        $seoDescription = $seoMetaDescription !== '' ? $seoMetaDescription : $siteTagline;

        // Admin HTML pages use their own title/description in the browser tab.
        if (isset($page) && $page instanceof \App\Models\Page) {
            $pageHeading = trim(localized($page->title_bn, $page->title_en));
            $seoTitle = $pageHeading.' | '.$siteName;
            $pageSummary = trim(strip_tags(app()->getLocale() === 'en' && trim((string) $page->content_en) !== '' ? $page->content_en : (string) $page->content_bn));
            if ($pageSummary !== '') {
                $seoDescription = \Illuminate\Support\Str::limit(preg_replace('/\s+/u', ' ', $pageSummary), 155);
            }
        }
    @endphp
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">
    <meta name="theme-color" content="{{ $themePrimary }}">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $seoTitle }}</title>
    <meta name="description" content="{{ $seoDescription }}">
    @if ($seoMetaKeywords !== '')
        <meta name="keywords" content="{{ $seoMetaKeywords }}">
    @endif
    <meta name="robots" content="{{ $seoRobots }}">
    <link rel="canonical" href="{{ url()->current() }}">

    <!-- Open Graph / Social sharing -->
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="{{ $siteName }}">
    <meta property="og:title" content="{{ $seoTitle }}">
    <meta property="og:description" content="{{ $seoDescription }}">
    <meta property="og:url" content="{{ url()->current() }}">
    @if ($seoOgUrl)
        <meta property="og:image" content="{{ $seoOgUrl }}">
    @endif
    <meta name="twitter:card" content="{{ $seoOgUrl ? 'summary_large_image' : 'summary' }}">
    <meta name="twitter:title" content="{{ $seoTitle }}">
    <meta name="twitter:description" content="{{ $seoDescription }}">
    @if ($seoOgUrl)
        <meta name="twitter:image" content="{{ $seoOgUrl }}">
    @endif
    @if ($seoVerification !== '')
        <meta name="google-site-verification" content="{{ $seoVerification }}">
    @endif

    <!-- Theme Bootstrap (runs before paint — prevents flash of wrong theme) -->
    <script>
        (function () {
            try {
                var saved = localStorage.getItem('mm-theme');
                var theme = saved || (window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches ? 'light' : 'dark');
                document.documentElement.setAttribute('data-theme', theme);
                if (theme === 'dark') document.documentElement.classList.add('dark');
            } catch (e) { /* noop */ }
        })();
    </script>

    <!-- Tailwind CSS CDN -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- Google Fonts: theme-selected Bengali font & Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="{{ $googleFontsUrl }}" rel="stylesheet">

    <!-- FontAwesome Icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    colors: {
                        navy: {
                            800: '#0f172a',
                            900: '#0b1324',
                            950: '#050b14'
                        },
                        aqua: {
                            50: 'rgb(var(--brand-50) / <alpha-value>)',
                            100: 'rgb(var(--brand-100) / <alpha-value>)',
                            200: 'rgb(var(--brand-200) / <alpha-value>)',
                            300: 'rgb(var(--brand-300) / <alpha-value>)',
                            400: 'rgb(var(--brand-400) / <alpha-value>)',
                            500: 'rgb(var(--brand-500) / <alpha-value>)',
                            600: 'rgb(var(--brand-600) / <alpha-value>)',
                            700: 'rgb(var(--brand-700) / <alpha-value>)',
                            800: 'rgb(var(--brand-800) / <alpha-value>)',
                            900: 'rgb(var(--brand-900) / <alpha-value>)'
                        },
                        sky: {
                            300: 'rgb(var(--sky-300) / <alpha-value>)',
                            400: 'rgb(var(--sky-400) / <alpha-value>)',
                            500: 'rgb(var(--sky-500) / <alpha-value>)',
                            600: 'rgb(var(--sky-600) / <alpha-value>)',
                            700: 'rgb(var(--sky-700) / <alpha-value>)'
                        },
                        gold: {
                            300: 'rgb(var(--accent-300) / <alpha-value>)',
                            400: 'rgb(var(--accent-400) / <alpha-value>)',
                            500: 'rgb(var(--accent-500) / <alpha-value>)',
                            600: 'rgb(var(--accent-600) / <alpha-value>)'
                        },
                        /* Theme-aware semantic tokens — driven by CSS variables */
                        app: 'rgb(var(--app) / <alpha-value>)',
                        card: 'rgb(var(--card) / <alpha-value>)',
                        card2: 'rgb(var(--card2) / <alpha-value>)',
                        ink: 'rgb(var(--ink) / <alpha-value>)',
                        ink2: 'rgb(var(--ink2) / <alpha-value>)',
                        ink3: 'rgb(var(--ink3) / <alpha-value>)',
                        line: 'rgb(var(--line) / <alpha-value>)'
                    },
                    fontFamily: {
                        /* English font first: it has no Bengali glyphs, so Bengali
                           text falls through to the Bangla font automatically. */
                        bangla: ['{{ $englishFontFamily }}', '{{ $fontFamily }}', 'sans-serif'],
                        sans: ['{{ $englishFontFamily }}', '{{ $fontFamily }}', 'sans-serif']
                    }
                }
            }
        }
    </script>

    <style>
        /* ============================================================
           CUSTOMER THEME — palette, font, radius & border from admin
           ============================================================ */
        :root {
            @foreach ([50, 100, 200, 300, 400, 500, 600, 700, 800, 900] as $shade)
            --brand-{{ $shade }}: {{ $primaryShades[$shade] }};
            --sky-{{ $shade }}: {{ $secondaryShades[$shade] }};
            --accent-{{ $shade }}: {{ $accentShades[$shade] }};
            @endforeach
            --radius-app: {{ $themeRadius }}px;
            --theme-border-width: {{ $themeBorderWidth }}px;
        }

        /* ============================================================
           THEME TOKENS — "Deep Ocean Night" (dark) / "Morning Aqua" (light)
           ============================================================ */
        :root, html[data-theme='dark'] {
            color-scheme: dark;
            --app: 4 10 20;            /* page background   #040a14 */
            --card: 13 25 44;          /* main surface      #0d192c */
            --card2: 21 36 58;         /* secondary surface #15243a */
            --ink: 226 240 249;        /* primary text */
            --ink2: 152 175 194;       /* secondary text */
            --ink3: 106 130 151;       /* muted text */
            --line: 40 60 86;          /* borders */

            --glass: rgba(14, 28, 50, 0.55);
            --glass-strong: rgba(9, 19, 36, 0.82);
            --glass-border: rgba(126, 190, 238, 0.14);
            --glass-hi: rgba(255, 255, 255, 0.08);
            --header-bg: rgba(6, 13, 27, 0.74);
            --bar-bg: linear-gradient(90deg, #040a14, #0b1728 50%, #040a14);
            --bar-text: #c9d8e6;
            --hero-bg: radial-gradient(1100px 480px at 85% -10%, rgba(14,165,233,.16), transparent 60%),
                       radial-gradient(900px 420px at 8% 108%, rgba(20,184,166,.14), transparent 60%),
                       linear-gradient(180deg, #071022 0%, #0a1526 45%, #0b1528 100%);
            --grad-text: linear-gradient(90deg, #2dd4bf, #38bdf8, #34d399, #2dd4bf);
            --fish-ink: rgba(94, 234, 212, 0.15);
            --bubble-ink: rgba(125, 211, 252, 0.18);
            --glow-a: rgba(20, 184, 166, 0.17);
            --glow-b: rgba(14, 165, 233, 0.15);
            --glow-c: rgba(52, 211, 153, 0.12);
            --footer-bg: linear-gradient(180deg, #050c17, #040a14);
            --footer-ink: #92a6b9;
            --shadow-card: 0 10px 40px -14px rgba(2, 8, 20, 0.6);
            --shadow-pop: 0 26px 70px -20px rgba(2, 8, 20, 0.75);
        }

        html[data-theme='light'] {
            color-scheme: light;
            --app: 234 245 248;        /* page background   #eaf5f8 */
            --card: 255 255 255;       /* main surface */
            --card2: 240 247 250;      /* secondary surface */
            --ink: 9 33 46;            /* primary text      #09212e */
            --ink2: 71 97 111;         /* secondary text */
            --ink3: 116 141 154;       /* muted text */
            --line: 213 229 235;       /* borders */

            --glass: rgba(255, 255, 255, 0.62);
            --glass-strong: rgba(255, 255, 255, 0.88);
            --glass-border: rgba(2, 116, 110, 0.14);
            --glass-hi: rgba(255, 255, 255, 0.95);
            --header-bg: rgba(255, 255, 255, 0.7);
            --bar-bg: linear-gradient(90deg, #0d9488, #0891b2 50%, #0d9488);
            --bar-text: #e9fdf8;
            --hero-bg: radial-gradient(1100px 480px at 85% -10%, rgba(45,212,191,.18), transparent 60%),
                       radial-gradient(900px 420px at 8% 108%, rgba(14,165,233,.14), transparent 60%),
                       linear-gradient(180deg, #f4fbfd 0%, #e9f6f9 50%, #f7fcfe 100%);
            --grad-text: linear-gradient(90deg, #0d9488, #0284c7, #059669, #0d9488);
            --fish-ink: rgba(13, 148, 136, 0.13);
            --bubble-ink: rgba(14, 165, 233, 0.16);
            --glow-a: rgba(20, 184, 166, 0.22);
            --glow-b: rgba(14, 165, 233, 0.18);
            --glow-c: rgba(251, 191, 36, 0.14);
            --footer-bg: linear-gradient(180deg, #ffffff, #eaf5f8);
            --footer-ink: #5a7684;
            --shadow-card: 0 12px 36px -16px rgba(9, 60, 73, 0.22);
            --shadow-pop: 0 26px 64px -22px rgba(9, 60, 73, 0.3);
        }

        html { background: rgb(var(--app)); scroll-behavior: smooth; }

        /* Theme-derived gradients & glows */
        :root, html[data-theme='dark'] {
            --grad-text: linear-gradient(90deg, rgb(var(--brand-300)), rgb(var(--sky-500)), rgb(var(--brand-400)), rgb(var(--brand-300)));
            --glow-a: rgb(var(--brand-500) / 0.17);
            --glow-b: rgb(var(--sky-500) / 0.15);
            --glow-c: rgb(var(--brand-400) / 0.12);
            --bar-bg: linear-gradient(90deg, rgb(var(--app)), rgb(var(--brand-800)) 50%, rgb(var(--app)));
        }
        html[data-theme='light'] {
            --grad-text: linear-gradient(90deg, rgb(var(--brand-600)), rgb(var(--sky-600)), rgb(var(--brand-500)), rgb(var(--brand-600)));
            --glow-a: rgb(var(--brand-500) / 0.2);
            --glow-b: rgb(var(--sky-500) / 0.16);
            --glow-c: rgb(var(--brand-400) / 0.14);
            --bar-bg: linear-gradient(90deg, rgb(var(--brand-700)), rgb(var(--sky-600)) 50%, rgb(var(--brand-700)));
        }

        body {
            /* English font first (no Bengali glyphs), so Bengali text falls back
               to the Bangla font selected in admin. */
            font-family: '{{ $englishFontFamily }}', '{{ $fontFamily }}', sans-serif;
            background: transparent;
            color: rgb(var(--ink));
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }

        /* Background style selected in admin */
        body.bg-style-gradient {
            background:
                radial-gradient(1000px 520px at 88% -8%, rgb(var(--brand-500) / 0.16), transparent 60%),
                radial-gradient(900px 460px at 4% 104%, rgb(var(--sky-500) / 0.14), transparent 62%),
                linear-gradient(160deg, rgb(var(--app)), rgb(var(--card)) 55%, rgb(var(--app)));
            background-attachment: fixed;
        }
        body.bg-style-solid { background: rgb(var(--app)); }
        body.bg-style-image { background: rgb(var(--app)); }
        body.bg-style-image::before {
            content: '';
            position: fixed;
            inset: 0;
            z-index: -3;
            background-image: url('{{ $bgImageUrl }}');
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }
        body.bg-style-image::after {
            content: '';
            position: fixed;
            inset: 0;
            z-index: -2;
            background: rgb(var(--app) / {{ number_format($bgOverlay / 100, 2) }});
        }

        /* Radius & border controls */
        .glass, .glass-strong, .glass-chip, .product-card, .promo-card, .review-card, .modal-panel {
            border-radius: var(--radius-app) !important;
        }
        .glass, .glass-strong, .glass-chip, .product-card { border-width: var(--theme-border-width); }
        .glass-header { border-bottom-width: var(--theme-border-width); }

        /* ============================================================
           TYPOGRAPHY & ICONS — base size, per-level scale, icon scale
           ============================================================ */
        html { font-size: {{ $baseFontSize }}px; }

        /* zoom keeps each element's own responsive Tailwind size and scales it,
           so headings stay fluid on mobile instead of freezing to one value. */
        h1 { zoom: {{ $h1Scale }}; }
        h2 { zoom: {{ $h2Scale }}; }
        h3 { zoom: {{ $h3Scale }}; }
        p  { zoom: {{ $textScale }}; }

        i[class*="fa-"], .fa-solid, .fa-regular, .fa-brands, .fa-light, .fa-thin, .fa-duotone {
            zoom: {{ $iconScale }};
        }

        @if ($textColorShades)
        html[data-theme] { --ink: {{ $textColorShades[500] }}; }
        @endif

        /* Anchor offset for sticky header + app-like touch defaults */
        section[id], main[id] { scroll-margin-top: 8.5rem; }
        button, a { -webkit-tap-highlight-color: transparent; }
        .mobile-nav-item {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            gap: .15rem;
            font-size: .625rem;
            font-weight: 700;
            color: rgb(var(--ink3));
            transition: color .2s ease, transform .15s ease;
            min-height: 3rem;
        }
        .mobile-nav-item:active { transform: scale(.92); }
        .mobile-nav-item i { font-size: 1.05rem; }
        .mobile-nav-item:hover { color: rgb(var(--ink)); }

        .mobile-sheet-grabber { display: none; width: 42px; height: 4px; border-radius: 9999px; background: rgb(var(--ink3) / .45); margin: 8px auto 0; }

        @media (max-width: 767px) {
            body { padding-bottom: calc(4.9rem + env(safe-area-inset-bottom)); }
            #checkout-modal, #success-modal { align-items: flex-end !important; padding: 0 !important; }
            #checkout-panel, #success-panel {
                width: 100%;
                max-width: 100%;
                max-height: 93dvh;
                border-radius: 1.5rem 1.5rem 0 0 !important;
            }
            .mobile-sheet-grabber { display: block; }
            /* Full-screen sheets: square edges so they sit flush with the screen. */
            #cart-drawer, #cart-drawer > div:last-child { border-radius: 0 !important; }
            /* 16px stops iOS Safari from zooming into a focused field. */
            select, input[type='text'], input[type='tel'], input[type='email'], input[type='password'],
            input[type='search'], input[type='number'], input[type='url'], textarea { font-size: 16px !important; }
        }

        /* Public form controls (customer login, registration, profile).
           The admin panel defines these classes in its own layout. */
        .form-input {
            width: 100%;
            background: rgb(var(--card2) / .7);
            border: 1px solid rgb(var(--line));
            border-radius: .75rem;
            padding: .7rem .85rem;
            color: rgb(var(--ink));
            font-size: .875rem;
            transition: border-color .2s ease, box-shadow .2s ease, background-color .2s ease;
        }
        .form-input:focus {
            outline: none;
            border-color: rgb(var(--brand-500));
            box-shadow: 0 0 0 3px rgb(var(--brand-500) / .18);
            background: rgb(var(--card2));
        }
        .form-input::placeholder { color: rgb(var(--ink3)); }
        .form-label { display: block; font-size: .75rem; font-weight: 700; color: rgb(var(--ink2)); margin-bottom: .35rem; }
        .form-error { color: #fb7185; font-size: .72rem; margin-top: .3rem; font-weight: 600; }

        /* Smooth cross-theme transition (applied temporarily while switching) */
        html.theme-anim, html.theme-anim *, html.theme-anim *::before, html.theme-anim *::after {
            transition: background-color .45s ease, color .45s ease, border-color .45s ease,
                        box-shadow .45s ease, fill .45s ease, stroke .45s ease, opacity .45s ease !important;
        }

        /* View Transitions API — smooth theme morph on modern browsers */
        ::view-transition-old(root), ::view-transition-new(root) {
            animation-duration: .55s;
            animation-timing-function: ease;
        }

        /* Custom Scrollbar (theme-aware) */
        ::-webkit-scrollbar { width: 9px; height: 9px; }
        ::-webkit-scrollbar-track { background: rgb(var(--card2)); }
        ::-webkit-scrollbar-thumb {
            background: linear-gradient(180deg, rgb(var(--brand-500)), rgb(var(--sky-600)));
            border-radius: 8px;
            border: 2px solid rgb(var(--card2));
        }
        ::-webkit-scrollbar-thumb:hover { background: linear-gradient(180deg, rgb(var(--brand-600)), rgb(var(--sky-700))); }
        .scrollbar-none::-webkit-scrollbar { display: none; }
        .scrollbar-none { scrollbar-width: none; }

        /* ============================================================
           GLASSMORPHISM SYSTEM
           ============================================================ */
        .glass {
            background: var(--glass);
            backdrop-filter: blur(18px) saturate(170%);
            -webkit-backdrop-filter: blur(18px) saturate(170%);
            border: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi), var(--shadow-card);
        }
        .glass-strong {
            background: var(--glass-strong);
            backdrop-filter: blur(28px) saturate(190%);
            -webkit-backdrop-filter: blur(28px) saturate(190%);
            border: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi), var(--shadow-pop);
        }
        .glass-header {
            background: var(--header-bg);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            border-bottom: 1px solid var(--glass-border);
            box-shadow: inset 0 1px 0 var(--glass-hi);
        }
        .glass-chip {
            background: var(--glass);
            backdrop-filter: blur(12px) saturate(160%);
            -webkit-backdrop-filter: blur(12px) saturate(160%);
            border: 1px solid var(--glass-border);
        }
        /* Fallback when backdrop-filter is unsupported */
        @supports not ((backdrop-filter: blur(1px)) or (-webkit-backdrop-filter: blur(1px))) {
            .glass, .glass-strong, .glass-header, .glass-chip { background: rgb(var(--card)); }
        }

        /* ============================================================
           AURORA BACKGROUND — floating ambient glows
           ============================================================ */
        .aurora {
            position: fixed;
            inset: 0;
            z-index: -1;
            overflow: hidden;
            pointer-events: none;
        }
        .aurora span {
            position: absolute;
            border-radius: 9999px;
            filter: blur(95px);
            will-change: transform;
        }
        .aurora .a1 { width: 540px; height: 540px; background: var(--glow-a); top: -160px; right: 6%; animation: drift1 26s ease-in-out infinite alternate; }
        .aurora .a2 { width: 460px; height: 460px; background: var(--glow-b); bottom: -120px; left: -80px; animation: drift2 32s ease-in-out infinite alternate; }
        .aurora .a3 { width: 380px; height: 380px; background: var(--glow-c); top: 38%; left: 42%; animation: drift3 38s ease-in-out infinite alternate; }
        @keyframes drift1 { from { transform: translate3d(0,0,0) scale(1); } to { transform: translate3d(-70px, 70px, 0) scale(1.18); } }
        @keyframes drift2 { from { transform: translate3d(0,0,0) scale(1); } to { transform: translate3d(80px, -60px, 0) scale(1.22); } }
        @keyframes drift3 { from { transform: translate3d(0,0,0) scale(1); } to { transform: translate3d(-60px, -80px, 0) scale(1.1); } }

        /* ============================================================
           TOP ANNOUNCEMENT BAR — live marquee ticker
           ============================================================ */
        .topbar { background: var(--bar-bg); color: var(--bar-text); }
        .ticker-wrap {
            overflow: hidden;
            -webkit-mask-image: linear-gradient(90deg, transparent, #000 5%, #000 95%, transparent);
            mask-image: linear-gradient(90deg, transparent, #000 5%, #000 95%, transparent);
        }
        .ticker { display: inline-flex; white-space: nowrap; animation: tickerScroll 30s linear infinite; will-change: transform; }
        .ticker:hover { animation-play-state: paused; }
        @keyframes tickerScroll { from { transform: translateX(0); } to { transform: translateX(-50%); } }

        /* ============================================================
           HERO — themed backdrop, swimming fish, rising bubbles
           ============================================================ */
        .hero { background: var(--hero-bg); }
        .float-fish {
            position: absolute;
            color: var(--fish-ink);
            pointer-events: none;
            animation: swim 15s ease-in-out infinite;
            will-change: transform;
        }
        @keyframes swim {
            0%, 100% { transform: translate(0, 0) rotate(0deg); }
            25%      { transform: translate(26px, -18px) rotate(5deg); }
            50%      { transform: translate(52px, 8px) rotate(-4deg); }
            75%      { transform: translate(18px, 22px) rotate(3deg); }
        }
        .bubble {
            position: absolute;
            bottom: -30px;
            border-radius: 50%;
            background: radial-gradient(circle at 32% 30%, rgba(255,255,255,.55), var(--bubble-ink));
            animation: bubbleRise linear infinite;
            pointer-events: none;
            will-change: transform, opacity;
        }
        @keyframes bubbleRise {
            0%   { transform: translateY(0) translateX(0); opacity: 0; }
            12%  { opacity: 1; }
            85%  { opacity: .8; }
            100% { transform: translateY(-105vh) translateX(30px); opacity: 0; }
        }
        .logo-badge { animation: logoFloat 5s ease-in-out infinite; }
        @keyframes logoFloat {
            0%, 100% { transform: translateY(0) rotate(0deg); }
            50%      { transform: translateY(-4px) rotate(-5deg); }
        }
        .float-soft { animation: floatSoft 7s ease-in-out infinite; }
        @keyframes floatSoft {
            0%, 100% { transform: translateY(0); }
            50%      { transform: translateY(-10px); }
        }
        .text-gradient {
            background-image: var(--grad-text);
            background-size: 250% 100%;
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            animation: gradientFlow 7s ease infinite;
        }
        @keyframes gradientFlow {
            0%, 100% { background-position: 0% 50%; }
            50%      { background-position: 100% 50%; }
        }

        /* ============================================================
           CARDS — glass products, shine sweep, entrance stagger
           ============================================================ */
        .product-card {
            transition: transform .5s cubic-bezier(.16,1,.3,1), box-shadow .5s ease, border-color .35s ease;
            position: relative;
        }
        .product-card:hover {
            transform: translateY(-8px);
            border-color: rgb(var(--brand-500) / 0.45);
            box-shadow: var(--shadow-pop), 0 18px 55px -20px rgb(var(--brand-500) / 0.4);
        }
        .product-card::after {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            background: linear-gradient(115deg, transparent 32%, rgba(255,255,255,.10) 45%, rgba(255,255,255,.22) 50%, rgba(255,255,255,.10) 55%, transparent 68%);
            transform: translateX(-130%) skewX(-6deg);
            transition: transform 1s ease;
            pointer-events: none;
            z-index: 5;
        }
        .product-card:hover::after { transform: translateX(130%) skewX(-6deg); }

        .card-enter { animation: cardIn .6s cubic-bezier(.16,1,.3,1) both; }
        @keyframes cardIn {
            from { opacity: 0; transform: translateY(24px) scale(.97); }
            to   { opacity: 1; transform: none; }
        }

        /* Scroll reveal (applied via JS to [data-reveal] elements) */
        .reveal {
            opacity: 0;
            transform: translateY(30px);
            transition: opacity .8s ease, transform .8s cubic-bezier(.16,1,.3,1);
        }
        .reveal.in-view { opacity: 1; transform: none; }

        .review-card { transition: transform .45s cubic-bezier(.16,1,.3,1), box-shadow .45s ease, border-color .35s ease; }
        .review-card:hover {
            transform: translateY(-6px);
            border-color: rgb(var(--brand-500) / 0.4);
            box-shadow: var(--shadow-pop);
        }

        /* Promo card — animated gradient border */
        .promo-card { position: relative; }
        .promo-card::before {
            content: "";
            position: absolute;
            inset: 0;
            border-radius: inherit;
            padding: 1.5px;
            background: linear-gradient(135deg, rgb(var(--accent-400) / .65), rgb(var(--brand-400) / .45), rgb(var(--sky-500) / .55), rgb(var(--accent-400) / .65));
            background-size: 300% 300%;
            animation: borderFlow 8s ease infinite;
            -webkit-mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
            -webkit-mask-composite: xor;
            mask: linear-gradient(#000 0 0) content-box, linear-gradient(#000 0 0);
            mask-composite: exclude;
            pointer-events: none;
        }
        @keyframes borderFlow {
            0%, 100% { background-position: 0% 50%; }
            50%      { background-position: 100% 50%; }
        }

        /* ============================================================
           COMBO PACKAGE BUILDER — 4/5 item picker, progress & animations
           ============================================================ */
        .combo-mini {
            cursor: pointer;
            transition: transform .4s cubic-bezier(.16,1,.3,1), border-color .3s ease, box-shadow .3s ease, background-color .3s ease;
        }
        .combo-mini:hover { transform: translateY(-4px); border-color: rgb(var(--brand-500) / 0.5); }
        .combo-mini.selected {
            border-color: rgb(var(--brand-500));
            box-shadow: 0 0 0 3px rgb(var(--brand-500) / 0.16), var(--shadow-card);
        }
        .combo-check {
            display: flex;
            align-items: center;
            justify-content: center;
            transform: scale(.2);
            opacity: 0;
            transition: transform .4s cubic-bezier(.34,1.56,.64,1), opacity .3s ease;
        }
        .combo-mini.selected .combo-check { transform: scale(1); opacity: 1; }
        .combo-pop { animation: comboPop .45s cubic-bezier(.34,1.56,.64,1); }
        @keyframes comboPop {
            0%   { transform: scale(1); }
            45%  { transform: scale(.93); }
            100% { transform: scale(1); }
        }
        .combo-row-in { animation: comboRowIn .45s cubic-bezier(.16,1,.3,1) both; }
        @keyframes comboRowIn {
            from { opacity: 0; transform: translateX(16px); }
            to   { opacity: 1; transform: none; }
        }
        .combo-progress-fill {
            background: linear-gradient(90deg, rgb(var(--brand-500)), rgb(var(--sky-600)), rgb(var(--brand-400)), rgb(var(--brand-500)));
            background-size: 200% 100%;
            animation: gradientFlow 3s linear infinite;
            transition: width .6s cubic-bezier(.16,1,.3,1);
        }
        .combo-progress-fill.done { background: linear-gradient(90deg, #10b981, #34d399, #10b981); }
        .combo-slot {
            transition: transform .35s cubic-bezier(.34,1.56,.64,1), background-color .3s ease,
                        border-color .3s ease, color .3s ease;
        }
        .combo-ready { animation: comboReadyPulse 1.8s ease-in-out infinite; }
        @keyframes comboReadyPulse {
            0%, 100% { box-shadow: 0 0 0 0 rgba(16, 185, 129, 0.45); }
            55%      { box-shadow: 0 0 0 12px rgba(16, 185, 129, 0); }
        }
        .total-pulse { animation: totalPulse .5s cubic-bezier(.34,1.56,.64,1); }
        @keyframes totalPulse {
            0%   { transform: scale(1); }
            40%  { transform: scale(1.12); }
            100% { transform: scale(1); }
        }

        /* ============================================================
           BUTTONS — sheen sweep on hover
           ============================================================ */
        .btn-glow { position: relative; overflow: hidden; isolation: isolate; }
        .btn-glow::before {
            content: "";
            position: absolute;
            top: 0; left: -80%;
            width: 55%; height: 100%;
            background: linear-gradient(100deg, transparent, rgba(255,255,255,.35), transparent);
            transform: skewX(-20deg);
            transition: left .65s ease;
            z-index: 1;
        }
        .btn-glow:hover::before { left: 135%; }

        /* ============================================================
           THEME TOGGLE — sun/moon morph
           ============================================================ */
        .theme-toggle { position: relative; overflow: hidden; }
        .theme-toggle i {
            position: absolute;
            inset: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: transform .55s cubic-bezier(.34,1.56,.64,1), opacity .35s ease;
        }
        html[data-theme='dark'] .icon-sun  { opacity: 0; transform: rotate(120deg) scale(.3); }
        html[data-theme='dark'] .icon-moon { opacity: 1; transform: rotate(0deg) scale(1); color: #a5f3fc; }
        html[data-theme='light'] .icon-sun  { opacity: 1; transform: rotate(0deg) scale(1); color: #f59e0b; }
        html[data-theme='light'] .icon-moon { opacity: 0; transform: rotate(-120deg) scale(.3); }
        html[data-theme='dark'] .theme-toggle:hover .icon-moon { transform: scale(1.15) rotate(-12deg); }
        html[data-theme='light'] .theme-toggle:hover .icon-sun { transform: scale(1.15) rotate(20deg); }

        /* ============================================================
           CATEGORY TABS
           ============================================================ */
        .category-tab { transition: background-color .3s ease, color .3s ease, transform .3s ease, box-shadow .3s ease; }
        .category-tab:active { transform: scale(.95); }
        .tab-active {
            background: linear-gradient(135deg, rgb(var(--brand-600)), rgb(var(--sky-600))) !important;
            color: #ffffff !important;
            box-shadow: 0 6px 18px -6px rgb(var(--brand-600) / 0.65) !important;
        }

        /* ============================================================
           FAQ — smooth accordion
           ============================================================ */
        .faq-item { transition: border-color .3s ease, box-shadow .3s ease; }
        .faq-item.open { border-color: rgb(var(--brand-500) / 0.45); box-shadow: 0 10px 30px -14px rgb(var(--brand-500) / 0.35); }
        .faq-answer {
            max-height: 0;
            overflow: hidden;
            transition: max-height .55s cubic-bezier(.16,1,.3,1);
        }
        /* Generous cap: long Bangla answers wrap to many lines on narrow phones. */
        .faq-item.open .faq-answer { max-height: 640px; }
        .faq-icon { transition: transform .45s cubic-bezier(.34,1.56,.64,1); }
        .faq-item.open .faq-icon { transform: rotate(180deg); }

        /* ============================================================
           MODALS & DRAWER
           ============================================================ */
        .modal-panel {
            opacity: 0;
            transform: translateY(22px) scale(.95);
            transition: opacity .35s ease, transform .45s cubic-bezier(.16,1,.3,1);
        }
        .modal-panel.show { opacity: 1; transform: none; }

        /* Cart badge pop when an item is added */
        .badge-pop { animation: badgePop .5s cubic-bezier(.34,1.56,.64,1); }
        @keyframes badgePop {
            0%   { transform: scale(1); }
            45%  { transform: scale(1.6); }
            100% { transform: scale(1); }
        }

        /* Payment method active ring */
        .payment-active {
            border-color: rgb(var(--brand-500)) !important;
            background: rgb(var(--brand-500) / 0.08) !important;
            box-shadow: 0 0 0 3px rgb(var(--brand-500) / 0.18);
        }

        /* Toast glass */
        .toast-glass {
            background: var(--glass-strong);
            backdrop-filter: blur(22px) saturate(180%);
            -webkit-backdrop-filter: blur(22px) saturate(180%);
            box-shadow: var(--shadow-pop), inset 0 1px 0 var(--glass-hi);
        }

        /* Footer */
        .site-footer { background: var(--footer-bg); color: var(--footer-ink); }

        /* Scroll-to-top floating button */
        #scroll-top {
            opacity: 0;
            pointer-events: none;
            transform: translateY(16px) scale(.85);
            transition: opacity .35s ease, transform .45s cubic-bezier(.34,1.56,.64,1);
        }
        #scroll-top.show { opacity: 1; pointer-events: auto; transform: none; }

        /* Toast slide animations */
        @keyframes slideIn { from { transform: translateY(110%); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
        @keyframes slideOut { from { transform: translateY(0); opacity: 1; } to { transform: translateY(110%); opacity: 0; } }
        .toast-enter { animation: slideIn .4s cubic-bezier(.16, 1, .3, 1) forwards; }
        .toast-exit { animation: slideOut .35s cubic-bezier(.16, 1, .3, 1) forwards; }

        /* Reduced motion — respect user preference */
        @media (prefers-reduced-motion: reduce) {
            *, *::before, *::after { animation-duration: .01ms !important; animation-iteration-count: 1 !important; transition-duration: .01ms !important; }
            .reveal { opacity: 1; transform: none; }
            .ticker { animation: none; }
        }
    </style>

    @if ($gaEnabled)
        <!-- Google Analytics (GA4) -->
        <script async src="https://www.googletagmanager.com/gtag/js?id={{ urlencode($gaMeasurementId) }}"></script>
        <script>
            window.dataLayer = window.dataLayer || [];
            function gtag(){dataLayer.push(arguments);}
            gtag('js', new Date());
            gtag('config', @json($gaMeasurementId));
        </script>
    @endif
</head>
