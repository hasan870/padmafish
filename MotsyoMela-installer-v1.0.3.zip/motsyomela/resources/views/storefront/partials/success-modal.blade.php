    <!-- ORDER SUCCESS CONFIRMATION MODAL (frosted glass) -->
    <div id="success-modal" class="fixed inset-0 bg-slate-950/70 backdrop-blur-md z-50 flex items-center justify-center p-4 opacity-0 pointer-events-none transition-opacity duration-300">
        <div id="success-panel" class="modal-panel glass-strong w-full max-w-md rounded-3xl p-6 sm:p-8 text-center relative overflow-y-auto overscroll-contain">
            <div class="mobile-sheet-grabber"></div>

            <div class="w-20 h-20 bg-emerald-500/15 text-emerald-500 rounded-full flex items-center justify-center text-4xl mx-auto mb-4 animate-bounce">
                <i class="fa-solid fa-circle-check"></i>
            </div>

            <h3 class="text-2xl font-black text-ink mb-1">{{ tr('অর্ডার সফলভাবে গৃহীত হয়েছে!', 'Order placed successfully!') }}</h3>
            <p class="text-xs text-ink3 mb-4">{{ tr('ধন্যবাদ! আপনার অর্ডারটি প্রক্রিয়াধীন রয়েছে।', 'Thank you! Your order is being processed.') }}</p>

            <div class="bg-card2/60 border border-line p-4 rounded-2xl text-left text-xs space-y-2 mb-6 backdrop-blur-sm">
                <div class="flex justify-between">
                    <span class="text-ink3">{{ tr('অর্ডার আইডি:', 'Order ID:') }}</span>
                    <span id="order-id-display" class="font-bold text-ink">#MM-84920</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-ink3">{{ tr('গ্রাহকের নাম:', 'Customer name:') }}</span>
                    <span id="order-cust-name" class="font-semibold text-ink">--</span>
                </div>
                <div class="flex justify-between">
                    <span class="text-ink3">{{ tr('ডেলিভারি সময়:', 'Delivery time:') }}</span>
                    <span id="order-time-display" class="font-semibold text-ink">--</span>
                </div>
                <div class="flex justify-between border-t border-line/70 pt-2 font-bold text-ink">
                    <span id="order-payment-label">{{ tr('মোট টাকা (COD):', 'Total (COD):') }}</span>
                    <span id="order-total-display" class="text-emerald-500 text-sm">৳০</span>
                </div>
            </div>

            <!-- Payment instructions (filled after order success) -->
            <div id="payment-info-box" class="hidden text-left bg-card2/60 border border-aqua-500/25 p-4 rounded-2xl text-xs space-y-2 mb-5 backdrop-blur-sm">
                <p class="font-bold text-ink flex items-center gap-2"><i class="fa-solid fa-wallet text-aqua-500"></i> <span id="payment-info-title">{{ tr('পেমেন্ট নির্দেশনা', 'Payment instructions') }}</span>
                    <img id="order-payment-icon" src="" alt="" class="hidden h-5 w-auto max-w-[4.5rem] object-contain bg-white rounded px-1 py-0.5 ml-auto">
                </p>
                <div id="order-payment-number-row" class="hidden items-center justify-between gap-2 rounded-lg bg-card border border-line px-3 py-2">
                    <span class="text-ink3">{{ tr('পেমেন্ট নম্বর:', 'Payment number:') }}</span>
                    <span id="order-payment-number" class="font-mono font-bold text-ink"></span>
                </div>
                <p id="order-payment-instructions" class="text-[11px] text-ink2 leading-relaxed"></p>
                <a id="order-payment-link" href="#" target="_blank" rel="noopener" class="hidden w-full justify-center items-center gap-2 bg-gradient-to-r from-aqua-600 to-sky-600 text-white font-bold py-2 rounded-lg text-[11px] transition-all active:scale-95">
                    <i class="fa-solid fa-arrow-up-right-from-square"></i> {{ tr('পেমেন্ট করুন', 'Pay now') }}
                </a>
                <a id="order-whatsapp-link" href="#" target="_blank" rel="noopener" class="flex w-full justify-center items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white font-bold py-2 rounded-lg text-[11px] transition-all active:scale-95">
                    <i class="fa-brands fa-whatsapp"></i> {{ tr('WhatsApp-এ পেমেন্ট কনফার্ম করুন', 'Confirm payment on WhatsApp') }}
                </a>
            </div>

            <a id="order-review-link" href="#" target="_blank" rel="noopener"
               class="hidden w-full justify-center items-center gap-2 bg-gradient-to-r from-gold-400 to-amber-500 text-slate-950 font-bold py-2.5 rounded-xl text-xs mb-4 transition-all active:scale-95">
                <i class="fa-solid fa-star"></i> {{ tr('আপনার মতামত দিন', 'Leave your review') }}
            </a>

            <p class="text-[11px] text-ink3 mb-2">
                {{ tr('প্রতিনিধি আপনার মোবাইল নম্বরে দ্রুত কল করে ডেলিভারি নিশ্চিত করবেন।', 'Our representative will call your mobile shortly to confirm delivery.') }}
            </p>
            <p id="order-email-note" class="hidden text-[10px] text-emerald-500 font-semibold mb-5">
                <i class="fa-solid fa-envelope-circle-check mr-1"></i>{{ tr('অর্ডার কনফার্মেশন আপনার ইমেইলে পাঠানো হয়েছে।', 'Order confirmation has been emailed to you.') }}
            </p>

            <button onclick="closeSuccessModal()" class="btn-glow w-full bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold py-3 rounded-xl text-xs transition-all active:scale-95 mt-2">
                {{ tr('পছন্দের কেনাকাটায় ফিরে যান', 'Back to shopping') }}
            </button>
        </div>
    </div>
