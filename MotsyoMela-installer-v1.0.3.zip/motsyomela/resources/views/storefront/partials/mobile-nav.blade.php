    <!-- APP-STYLE BOTTOM NAVIGATION (mobile only) -->
    <nav class="md:hidden fixed bottom-0 inset-x-0 z-40 glass-header border-t border-line/70" style="padding-bottom: env(safe-area-inset-bottom);" aria-label="মোবাইল নেভিগেশন">
        <div class="grid grid-cols-5 h-[4.35rem]">
            <a href="{{ url('/') }}" class="mobile-nav-item">
                <i class="fa-solid fa-house"></i>
                <span>{{ tr('হোম', 'Home') }}</span>
            </a>
            <a href="#product-section" class="mobile-nav-item">
                <i class="fa-solid fa-fish-fins"></i>
                <span>{{ tr('মাছ', 'Fish') }}</span>
            </a>
            @if ($combo['enabled'])
                <a href="#combo-section" class="mobile-nav-item !text-gold-500">
                    <span class="relative -mt-4 w-11 h-11 rounded-2xl bg-gradient-to-tr from-gold-400 to-amber-500 text-slate-950 flex items-center justify-center shadow-lg shadow-gold-500/30">
                        <i class="fa-solid fa-gift text-base"></i>
                    </span>
                    <span class="-mt-0.5">{{ tr('কম্বো', 'Combo') }}</span>
                </a>
            @else
                <button type="button" onclick="openCartDrawer()" class="mobile-nav-item">
                    <i class="fa-solid fa-tags"></i>
                    <span>{{ tr('অফার', 'Offers') }}</span>
                </button>
            @endif
            <button type="button" onclick="openCartDrawer()" class="mobile-nav-item relative">
                <span class="relative">
                    <i class="fa-solid fa-bag-shopping"></i>
                    <span id="mobile-cart-count" class="absolute -top-2 -right-2.5 bg-gold-500 text-slate-950 text-[9px] font-black min-w-[1rem] h-4 px-1 rounded-full flex items-center justify-center border-2 border-app">0</span>
                </span>
                <span>{{ tr('কার্ট', 'Cart') }}</span>
            </button>
            <button type="button" onclick="openMobileMenu()" class="mobile-nav-item">
                <i class="fa-solid fa-bars-staggered"></i>
                <span>{{ tr('মেনু', 'Menu') }}</span>
            </button>
        </div>
    </nav>
