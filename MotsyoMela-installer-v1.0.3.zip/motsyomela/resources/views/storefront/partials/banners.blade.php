    <!-- ADMIN PROMOTIONAL BANNER SLOTS (above the combo section) -->
    @php
        $bannerSlots = [];
        foreach ([1, 2] as $slot) {
            if (($settings['banner_slot_'.$slot.'_active'] ?? '0') !== '1') {
                continue;
            }

            $imagePath = (string) ($settings['banner_slot_'.$slot.'_image'] ?? '');
            $html = trim((string) ($settings['banner_slot_'.$slot.'_html'] ?? ''));

            if ($imagePath === '' && $html === '') {
                continue;
            }

            $bannerSlots[$slot] = [
                'image' => $imagePath !== '' ? \Illuminate\Support\Facades\Storage::url($imagePath) : null,
                'html' => $html,
                'link' => (string) ($settings['banner_slot_'.$slot.'_link'] ?? ''),
            ];
        }
    @endphp
    @if (! empty($bannerSlots))
        <style>
            .storefront-banner img { max-width: 100%; width: 100%; height: auto; display: block; margin-inline: auto; border-radius: 1rem; }
            .storefront-banner a { display: block; }
        </style>
        <div class="mt-16 space-y-4">
            @foreach ($bannerSlots as $slot => $banner)
                <div data-reveal class="storefront-banner glass rounded-3xl p-2 sm:p-3 overflow-hidden">
                    @if ($banner['image'])
                        @if ($banner['link'] !== '')
                            <a href="{{ $banner['link'] }}" target="_blank" rel="noopener sponsored">
                                <img src="{{ $banner['image'] }}" alt="ব্যানার {{ bn_num($slot) }}" loading="lazy">
                            </a>
                        @else
                            <img src="{{ $banner['image'] }}" alt="ব্যানার {{ bn_num($slot) }}" loading="lazy">
                        @endif
                    @else
                        {!! $banner['html'] !!}
                    @endif
                </div>
            @endforeach
        </div>
    @endif
