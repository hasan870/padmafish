        <!-- FAQ ACCORDION SECTION (smooth animated) -->
        <section id="faq-section" data-reveal class="mt-16 glass rounded-3xl p-6 sm:p-10">
            <div class="text-center max-w-xl mx-auto mb-8">
                <h2 class="text-2xl font-black text-ink">{{ tr('সাধারণ জিজ্ঞাসাবলী (FAQ)', 'Frequently asked questions (FAQ)') }}</h2>
                <p class="text-xs text-ink3 mt-1">{{ tr('মাছ কেনাকাটা সম্পর্কিত সচরাচর প্রশ্নের উত্তরসমূহ', 'Answers to the questions we hear most about buying fish') }}</p>
            </div>

            <div class="max-w-3xl mx-auto space-y-3" id="faq-accordion">

                @foreach ($faqs as $faq)
                <div class="faq-item glass-chip rounded-2xl overflow-hidden">
                    <button onclick="toggleFaq(this)" class="faq-q w-full text-left p-4 font-bold text-xs sm:text-sm text-ink flex justify-between items-center gap-3 hover:text-aqua-500 transition-colors">
                        <span>{{ $faq->question_bn }}</span>
                        <i class="faq-icon fa-solid fa-chevron-down text-ink3 shrink-0"></i>
                    </button>
                    <div class="faq-answer">
                        <div class="p-4 pt-0 text-xs text-ink2 leading-relaxed">
                            {{ $faq->answer_bn }}
                        </div>
                    </div>
                </div>
                @endforeach

            </div>
        </section>
