@extends('layouts.app')

@section('content')
    @php
        $pageTitle = localized($page->title_bn, $page->title_en);
        $pageHtml = app()->getLocale() === 'en' && trim((string) $page->content_en) !== ''
            ? $page->content_en
            : $page->content_bn;
    @endphp

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-1 w-full">
        <nav class="text-[11px] text-ink3 mb-4 flex items-center gap-2" aria-label="{{ tr('ব্রেডক্রাম্ব', 'Breadcrumb') }}">
            <a href="{{ url('/') }}" class="hover:text-aqua-500 transition-colors">{{ tr('হোম', 'Home') }}</a>
            <i class="fa-solid fa-chevron-right text-[8px]"></i>
            <span class="text-ink2 font-semibold">{{ $pageTitle }}</span>
        </nav>

        <article class="glass rounded-3xl p-6 sm:p-10">
            <h1 class="text-2xl sm:text-3xl font-black text-ink flex items-center gap-3">
                <span class="w-11 h-11 rounded-2xl bg-aqua-500/15 text-aqua-500 flex items-center justify-center text-lg shrink-0">
                    <i class="fa-solid fa-file-lines"></i>
                </span>
                {{ $pageTitle }}
            </h1>
            <div class="mt-5 border-t border-line/70 pt-5 page-content text-sm text-ink2 leading-relaxed">
                {!! $pageHtml ?: '<p>'.e(tr('এই পেজের কনটেন্ট এখনো যোগ করা হয়নি।', 'This page has no content yet.')).'</p>' !!}
            </div>
        </article>

        <div class="mt-6 flex flex-wrap items-center gap-2">
            <a href="{{ url('/') }}" class="glass-chip text-ink2 hover:text-ink font-bold px-4 py-2.5 rounded-xl text-xs transition-colors">
                <i class="fa-solid fa-arrow-left mr-1.5"></i> {{ tr('সব মাছে ফিরে যান', 'Back to the catalogue') }}
            </a>
            @if (! empty($settings['site_phone']))
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $settings['site_phone']) }}" class="glass-chip text-ink2 hover:text-ink font-bold px-4 py-2.5 rounded-xl text-xs transition-colors">
                    <i class="fa-solid fa-phone-volume text-aqua-500 mr-1.5"></i> {{ tr('হটলাইন', 'Hotline') }}: {{ bn_num($settings['site_phone']) }}
                </a>
            @endif
        </div>
    </main>

    <style>
        .page-content h1, .page-content h2, .page-content h3, .page-content h4 {
            color: rgb(var(--ink));
            font-weight: 800;
            line-height: 1.35;
            margin: 1.5rem 0 .6rem;
        }
        .page-content h1 { font-size: 1.35rem; }
        .page-content h2 { font-size: 1.15rem; }
        .page-content h3 { font-size: 1rem; }
        .page-content > :first-child { margin-top: 0; }
        .page-content p { margin: .7rem 0; }
        .page-content a { color: rgb(var(--brand-500)); text-decoration: underline; text-underline-offset: 2px; }
        .page-content ul, .page-content ol { margin: .8rem 0 .8rem 1.2rem; }
        .page-content ul { list-style: disc; }
        .page-content ol { list-style: decimal; }
        .page-content li { margin: .35rem 0; }
        .page-content strong { color: rgb(var(--ink)); font-weight: 700; }
        .page-content img { max-width: 100%; height: auto; border-radius: var(--radius-app); }
        .page-content table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: .8rem; }
        .page-content th, .page-content td { border: 1px solid rgb(var(--line)); padding: .55rem .7rem; text-align: left; }
        .page-content th { background: rgb(var(--card2)); color: rgb(var(--ink)); font-weight: 700; }
        .page-content blockquote {
            border-left: 3px solid rgb(var(--brand-500));
            padding: .4rem 0 .4rem .9rem;
            margin: .9rem 0;
            color: rgb(var(--ink2));
        }
        .page-content hr { border-color: rgb(var(--line)); margin: 1.4rem 0; }
    </style>
@endsection
