@include('storefront.partials.head')

@php
    $logoMode = $settings['theme_logo_mode'] ?? 'image';
    $showLogoMark = $logoMode !== 'text';
    $logoUrl = $showLogoMark && ! empty($settings['theme_logo']) ? \Illuminate\Support\Facades\Storage::url($settings['theme_logo']) : null;
    $reviewSiteName = $settings['site_name'] ?? 'মৎস্যমেলা';
    $reviewSiteTagline = $settings['site_tagline'] ?? '';
    $layoutBgStyle = $settings['theme_bg_style'] ?? 'aurora';
    if ($layoutBgStyle === 'image' && empty($settings['theme_bg_image'])) {
        $layoutBgStyle = 'aurora';
    }
    $status = session('review_status');
    $oldRating = (int) old('rating', 5);
@endphp
<body class="min-h-screen font-bangla bg-style-{{ $layoutBgStyle }} flex flex-col justify-center py-10 px-4">

    <div class="max-w-xl w-full mx-auto">

        <div class="flex items-center justify-center gap-3 mb-6">
            @if ($showLogoMark)
                <span class="w-11 h-11 rounded-2xl bg-gradient-to-tr from-aqua-600 via-sky-500 to-emerald-400 flex items-center justify-center text-white text-xl shadow-lg shadow-aqua-500/30 overflow-hidden">
                    @if ($logoUrl)
                        <img src="{{ $logoUrl }}" alt="{{ $reviewSiteName }}" class="w-full h-full object-contain p-1">
                    @else
                        <i class="fa-solid fa-fish-fins"></i>
                    @endif
                </span>
            @endif
            <div>
                <p class="font-black text-ink text-lg leading-tight">{{ $reviewSiteName }}</p>
                <p class="text-[11px] text-ink3">{{ $reviewSiteTagline }}</p>
            </div>
        </div>

        <div class="glass-strong rounded-3xl p-6 sm:p-8 shadow-2xl">
            <div class="text-center mb-6">
                <span class="inline-flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-widest text-gold-600 dark:text-gold-400 bg-gold-500/12 border border-gold-500/30 px-3 py-1 rounded-full">
                    <i class="fa-solid fa-star"></i> আপনার মতামত
                </span>
                <h1 class="text-2xl font-black text-ink mt-3">অর্ডারটি কেমন ছিল?</h1>
                <p class="text-xs text-ink2 mt-1.5">
                    অর্ডার <span class="font-bold text-ink">{{ $order->order_number }}</span>
                    · {{ bn_num($order->created_at->format('d/m/Y')) }}
                    · {{ bn_money($order->grand_total) }}
                </p>
            </div>

            @if ($status)
                <div class="rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-xs font-semibold text-emerald-600 dark:text-emerald-300 mb-5">
                    <i class="fa-solid fa-circle-check mr-1"></i> {{ $status }}
                </div>
            @endif

            @if ($submitted)
                <div class="text-center py-6">
                    <div class="w-16 h-16 mx-auto rounded-full bg-emerald-500/15 text-emerald-500 flex items-center justify-center text-3xl mb-4">
                        <i class="fa-solid fa-heart"></i>
                    </div>
                    <h2 class="text-lg font-bold text-ink">আপনার রিভিউ জমা হয়েছে</h2>
                    <p class="text-xs text-ink3 mt-2 leading-relaxed">
                        {{ $reviewSiteName }}-কে সময় দেওয়ার জন্য ধন্যবাদ। অনুমোদনের পর আপনার মতামত
                        আমাদের ওয়েবসাইটে দেখা যাবে।
                    </p>
                </div>
            @else
                <form method="POST" action="{{ $reviewUrl }}" class="space-y-4">
                    @csrf

                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-2">রেটিং <span class="text-rose-400">*</span></label>
                        <div class="flex items-center gap-1.5" id="rating-stars">
                            @for ($star = 1; $star <= 5; $star++)
                                <label class="cursor-pointer p-1.5 text-2xl leading-none transition-transform hover:scale-110">
                                    <input type="radio" name="rating" value="{{ $star }}" class="sr-only" @checked($oldRating === $star)>
                                    <i data-star="{{ $star }}" class="fa-solid fa-star {{ $star <= $oldRating ? 'text-gold-500' : 'text-ink3/40' }}"></i>
                                </label>
                            @endfor
                        </div>
                        @error('rating') <p class="text-[11px] text-rose-400 font-semibold mt-1">{{ $message }}</p> @enderror
                    </div>

                    <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                        <div>
                            <label class="block text-xs font-bold text-ink2 mb-1">আপনার নাম <span class="text-rose-400">*</span></label>
                            <input type="text" name="customer_name_bn" value="{{ old('customer_name_bn', $order->customer_name) }}" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2 text-sm text-ink focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25" maxlength="100" required>
                            @error('customer_name_bn') <p class="text-[11px] text-rose-400 font-semibold mt-1">{{ $message }}</p> @enderror
                        </div>
                        <div>
                            <label class="block text-xs font-bold text-ink2 mb-1">এলাকা (ঐচ্ছিক)</label>
                            <input type="text" name="location_bn" value="{{ old('location_bn', $order->zone?->name_bn) }}" class="w-full bg-card2/70 border border-line rounded-xl px-3.5 py-2 text-sm text-ink focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25" maxlength="100">
                            @error('location_bn') <p class="text-[11px] text-rose-400 font-semibold mt-1">{{ $message }}</p> @enderror
                        </div>
                    </div>

                    <div>
                        <label class="block text-xs font-bold text-ink2 mb-1">আপনার মতামত <span class="text-rose-400">*</span></label>
                        <textarea name="quote_bn" rows="4" maxlength="1000" required class="w-full bg-card2/70 border border-line rounded-xl p-3 text-sm text-ink focus:outline-none focus:border-aqua-500 focus:ring-2 focus:ring-aqua-500/25" placeholder="মাছের তাজাভাব, ডেলিভারি ও সার্ভিস নিয়ে আপনার অভিজ্ঞতা লিখুন...">{{ old('quote_bn') }}</textarea>
                        @error('quote_bn') <p class="text-[11px] text-rose-400 font-semibold mt-1">{{ $message }}</p> @enderror
                    </div>

                    <button type="submit" class="w-full bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold py-3 rounded-xl text-sm transition-all active:scale-95">
                        <i class="fa-solid fa-paper-plane mr-1"></i> রিভিউ জমা দিন
                    </button>
                    <p class="text-[10px] text-ink3 text-center">আপনার রিভিউ অ্যাডমিন অনুমোদনের পর স্টোরফ্রন্টে প্রকাশিত হবে।</p>
                </form>
            @endif
        </div>

        <p class="text-center text-[11px] text-ink3 mt-5">
            <a href="{{ url('/') }}" class="hover:text-aqua-500 font-semibold transition-colors">
                <i class="fa-solid fa-arrow-left mr-1"></i> {{ $reviewSiteName }}-এ ফিরে যান
            </a>
        </p>
    </div>

    <script>
        (function () {
            const stars = Array.from(document.querySelectorAll('#rating-stars i[data-star]'));
            const inputs = Array.from(document.querySelectorAll('input[name="rating"]'));

            function paint(value) {
                stars.forEach(function (star) {
                    star.classList.toggle('text-gold-500', Number(star.dataset.star) <= value);
                    star.classList.toggle('text-ink3/40', Number(star.dataset.star) > value);
                });
            }

            inputs.forEach(function (input) {
                input.addEventListener('change', function () { paint(Number(input.value)); });
            });

            stars.forEach(function (star) {
                star.addEventListener('mouseenter', function () { paint(Number(star.dataset.star)); });
            });

            document.getElementById('rating-stars').addEventListener('mouseleave', function () {
                const checked = inputs.find(function (input) { return input.checked; });
                paint(checked ? Number(checked.value) : 0);
            });
        })();
    </script>
</body>
</html>
