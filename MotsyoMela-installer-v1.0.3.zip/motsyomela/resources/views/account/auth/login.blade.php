@extends('layouts.account')

@section('content')
    <div class="max-w-md mx-auto">
        <div class="glass rounded-3xl p-6 sm:p-8">
            <div class="text-center mb-6">
                <span class="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-aqua-600 to-sky-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-aqua-600/30">
                    <i class="fa-regular fa-user"></i>
                </span>
                <h1 class="text-2xl font-black text-ink mt-3">{{ tr('লগইন করুন', 'Sign in') }}</h1>
                <p class="text-xs text-ink3 mt-1 leading-relaxed">{{ tr('অ্যাকাউন্ট থাকলে আপনার অর্ডার ও ডেলিভারি স্ট্যাটাস এক জায়গায় দেখতে পাবেন। মাছ অর্ডার করতে লগইন বাধ্যতামূলক নয়।', 'Sign in to see your orders and delivery status in one place. An account is not required to order fish.') }}</p>
            </div>

            @if ($errors->any())
                <div class="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-xs font-semibold text-rose-400">
                    <i class="fa-solid fa-triangle-exclamation mr-1"></i> {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('account.login.store') }}" class="space-y-4">
                @csrf

                <div>
                    <label class="form-label" for="email">{{ tr('ইমেইল ঠিকানা', 'Email address') }} <span class="text-rose-400">*</span></label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" class="form-input" placeholder="you@example.com" autocomplete="email" required>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="form-label" for="password">{{ tr('পাসওয়ার্ড', 'Password') }} <span class="text-rose-400">*</span></label>
                    <input id="password" type="password" name="password" class="form-input" placeholder="••••••••" autocomplete="current-password" required>
                    @error('password') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <label class="flex items-center gap-2 text-xs font-semibold text-ink2 cursor-pointer">
                    <input type="checkbox" name="remember" value="1" class="rounded border-line">
                    {{ tr('আমাকে মনে রাখুন', 'Remember me') }}
                </label>

                <button type="submit" class="w-full bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold py-3 rounded-xl text-sm shadow-lg shadow-aqua-600/25 transition-all active:scale-95">
                    <i class="fa-solid fa-right-to-bracket mr-1.5"></i> {{ tr('লগইন করুন', 'Sign in') }}
                </button>
            </form>

            <p class="text-xs text-center text-ink3 mt-5">
                {{ tr('অ্যাকাউন্ট নেই?', "Don't have an account?") }} <a href="{{ route('account.register') }}" class="font-bold text-aqua-500 hover:underline">{{ tr('নতুন অ্যাকাউন্ট খুলুন', 'Create an account') }}</a>
            </p>

            <div class="mt-5 pt-4 border-t border-line/70 text-center">
                <a href="{{ route('home') }}" class="text-[11px] font-semibold text-ink3 hover:text-ink transition-colors">
                    <i class="fa-solid fa-arrow-left mr-1"></i> {{ tr('লগইন ছাড়াই কেনাকাটা করুন', 'Shop without signing in') }}
                </a>
            </div>
        </div>
    </div>
@endsection
