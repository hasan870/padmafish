@extends('layouts.account')

@section('content')
    <div class="max-w-md mx-auto">
        <div class="glass rounded-3xl p-6 sm:p-8">
            <div class="text-center mb-6">
                <span class="w-14 h-14 mx-auto rounded-2xl bg-gradient-to-tr from-aqua-600 to-sky-600 text-white flex items-center justify-center text-2xl shadow-lg shadow-aqua-600/30">
                    <i class="fa-solid fa-user-plus"></i>
                </span>
                <h1 class="text-2xl font-black text-ink mt-3">{{ tr('নতুন অ্যাকাউন্ট', 'Create an account') }}</h1>
                <p class="text-xs text-ink3 mt-1 leading-relaxed">{{ tr('অ্যাকাউন্ট খুললে অর্ডার হিস্টোরি ও ডেলিভারি স্ট্যাটাস দেখতে পারবেন। অর্ডার করার জন্য অ্যাকাউন্ট বাধ্যতামূলক নয়।', 'Create an account to see your order history and delivery status. An account is not required to place an order.') }}</p>
            </div>

            @if ($errors->any())
                <div class="mb-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-xs font-semibold text-rose-400">
                    <i class="fa-solid fa-triangle-exclamation mr-1"></i> {{ $errors->first() }}
                </div>
            @endif

            <form method="POST" action="{{ route('account.register.store') }}" class="space-y-4">
                @csrf

                <div>
                    <label class="form-label" for="name">{{ tr('আপনার নাম', 'Your name') }} <span class="text-rose-400">*</span></label>
                    <input id="name" type="text" name="name" value="{{ old('name') }}" class="form-input" placeholder="{{ tr('যেমন: মো: আব্দুর রহিম', 'e.g. Md. Abdur Rahim') }}" autocomplete="name" required>
                    @error('name') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="form-label" for="email">{{ tr('ইমেইল ঠিকানা', 'Email address') }} <span class="text-rose-400">*</span></label>
                    <input id="email" type="email" name="email" value="{{ old('email') }}" class="form-input" placeholder="you@example.com" autocomplete="email" required>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="form-label" for="password">{{ tr('পাসওয়ার্ড', 'Password') }} <span class="text-rose-400">*</span></label>
                    <input id="password" type="password" name="password" class="form-input" placeholder="{{ tr('কমপক্ষে ৮ অক্ষর', 'At least 8 characters') }}" autocomplete="new-password" required>
                    @error('password') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="form-label" for="password_confirmation">{{ tr('পাসওয়ার্ড আবার লিখুন', 'Confirm password') }} <span class="text-rose-400">*</span></label>
                    <input id="password_confirmation" type="password" name="password_confirmation" class="form-input" placeholder="{{ tr('একই পাসওয়ার্ড', 'Repeat the same password') }}" autocomplete="new-password" required>
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold py-3 rounded-xl text-sm shadow-lg shadow-aqua-600/25 transition-all active:scale-95">
                    <i class="fa-solid fa-user-plus mr-1.5"></i> {{ tr('অ্যাকাউন্ট তৈরি করুন', 'Create account') }}
                </button>
            </form>

            <p class="text-xs text-center text-ink3 mt-5">
                {{ tr('আগে থেকেই অ্যাকাউন্ট আছে?', 'Already have an account?') }} <a href="{{ route('account.login') }}" class="font-bold text-aqua-500 hover:underline">{{ tr('লগইন করুন', 'Sign in') }}</a>
            </p>

            <div class="mt-5 pt-4 border-t border-line/70 text-center">
                <a href="{{ route('home') }}" class="text-[11px] font-semibold text-ink3 hover:text-ink transition-colors">
                    <i class="fa-solid fa-arrow-left mr-1"></i> {{ tr('লগইন ছাড়াই কেনাকাটা করুন', 'Shop without signing in') }}
                </a>
            </div>
        </div>
    </div>
@endsection
