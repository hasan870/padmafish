@extends('layouts.account')

@section('content')
    @php
        $timeline = [
            'pending' => ['label' => tr('অর্ডার গৃহীত', 'Order received'), 'icon' => 'fa-receipt'],
            'confirmed' => ['label' => tr('নিশ্চিত হয়েছে', 'Confirmed'), 'icon' => 'fa-circle-check'],
            'delivering' => ['label' => tr('ডেলিভারিতে', 'Out for delivery'), 'icon' => 'fa-truck-fast'],
            'delivered' => ['label' => tr('সম্পন্ন', 'Delivered'), 'icon' => 'fa-box-open'],
        ];
        $statusOrder = array_keys($timeline);
        $currentIndex = array_search($order->status, $statusOrder, true);
        $isCancelled = $order->status === 'cancelled';
    @endphp

    <a href="{{ route('account.index') }}" class="inline-flex items-center gap-1.5 text-xs font-semibold text-ink3 hover:text-ink transition-colors mb-3">
        <i class="fa-solid fa-arrow-left"></i> {{ tr('সব অর্ডারে ফিরে যান', 'Back to all orders') }}
    </a>

    <div class="glass rounded-3xl p-6 sm:p-8">
        <div class="flex flex-wrap items-start justify-between gap-3">
            <div>
                <p class="text-[11px] uppercase tracking-widest text-ink3 font-bold">{{ tr('অর্ডার ট্র্যাকিং', 'Order tracking') }}</p>
                <h1 class="text-xl sm:text-2xl font-black text-ink font-mono mt-1">{{ $order->order_number }}</h1>
                <p class="text-[11px] text-ink3 mt-1">{{ bn_num($order->created_at->format('d/m/Y, h:i A')) }}</p>
            </div>
            <span class="badge border px-3 py-1.5 text-xs font-bold {{ order_status_classes($order->status) }}">{{ $order->statusLabelBn() }}</span>
        </div>

        @if ($isCancelled)
            <div class="mt-5 rounded-2xl border border-rose-500/30 bg-rose-500/10 px-4 py-3 text-xs text-rose-400">
                <i class="fa-solid fa-circle-xmark mr-1"></i>
                {{ tr('এই অর্ডারটি বাতিল করা হয়েছে।', 'This order has been cancelled.') }}
                @if ($order->cancel_reason)
                    {{ tr('কারণ:', 'Reason:') }} {{ $order->cancel_reason }}
                @endif
            </div>
        @else
            <div class="mt-6 grid grid-cols-4 gap-1 sm:gap-2">
                @foreach ($timeline as $status => $step)
                    @php $isDone = $currentIndex !== false && $loop->index <= $currentIndex; @endphp
                    <div class="text-center">
                        <div class="relative flex items-center justify-center">
                            @if (! $loop->first)
                                <span class="absolute left-0 right-1/2 top-1/2 h-0.5 -translate-y-1/2 {{ $isDone ? 'bg-aqua-500' : 'bg-line' }}"></span>
                            @endif
                            @if (! $loop->last)
                                <span class="absolute left-1/2 right-0 top-1/2 h-0.5 -translate-y-1/2 {{ $currentIndex !== false && $loop->index < $currentIndex ? 'bg-aqua-500' : 'bg-line' }}"></span>
                            @endif
                            <span class="relative w-9 h-9 rounded-full border flex items-center justify-center text-xs {{ $isDone ? 'bg-aqua-600 border-aqua-600 text-white shadow-lg shadow-aqua-600/25' : 'bg-card2 border-line text-ink3' }}">
                                <i class="fa-solid {{ $step['icon'] }}"></i>
                            </span>
                        </div>
                        <p class="text-[10px] sm:text-[11px] font-bold mt-2 {{ $isDone ? 'text-ink' : 'text-ink3' }}">{{ $step['label'] }}</p>
                    </div>
                @endforeach
            </div>
        @endif
    </div>

    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mt-4">
        <div class="lg:col-span-2 glass rounded-3xl p-5 sm:p-6">
            <h2 class="text-sm font-extrabold text-ink mb-4 flex items-center gap-2"><i class="fa-solid fa-fish text-aqua-500"></i> {{ tr('অর্ডারকৃত পণ্য', 'Ordered items') }}</h2>

            <div class="space-y-3">
                @foreach ($order->items as $item)
                    <div class="rounded-2xl border border-line bg-card2/40 p-3.5">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <p class="font-bold text-ink text-sm">{{ $item->name_snapshot_bn }}</p>
                                <p class="text-[11px] text-ink3 mt-0.5">
                                    {{ $item->size_label_snapshot }} ·
                                    {{ $item->is_combo ? bn_num($item->weight_kg).' প্যাক' : bn_kg($item->weight_kg) }}
                                </p>
                            </div>
                            <p class="font-black text-ink text-sm whitespace-nowrap">{{ bn_money($item->line_total) }}</p>
                        </div>

                        @if ($item->is_combo && is_array($item->combo_meta))
                            @php $metaItems = $item->combo_meta['items'] ?? $item->combo_meta; @endphp
                            @if (! empty($metaItems))
                                <div class="mt-2 rounded-xl border border-gold-500/25 bg-gold-500/5 px-3 py-2 text-[11px] text-ink2 space-y-1">
                                    <p class="font-bold text-gold-500 text-[10px] uppercase tracking-wide">{{ tr('কম্বো প্যাকেজের মাছ', 'Fish in this combo') }}</p>
                                    @foreach ($metaItems as $meta)
                                        <p>{{ $meta['name_bn'] ?? '' }} ({{ $meta['size_label'] ?? '' }}) — {{ bn_kg($meta['weight_kg'] ?? 0) }}</p>
                                    @endforeach
                                </div>
                            @endif
                        @endif
                    </div>
                @endforeach
            </div>

            <div class="mt-5 pt-4 border-t border-line/70 space-y-1.5 text-xs">
                <div class="flex justify-between text-ink2"><span>{{ tr('সাবটোটাল', 'Subtotal') }}</span><span class="font-semibold text-ink">{{ bn_money($order->subtotal) }}</span></div>
                @if ((float) $order->discount_amount > 0)
                    <div class="flex justify-between text-ink2">
                        <span>{{ tr('কুপন ছাড়', 'Coupon discount') }}{{ $order->coupon_code ? ' ('.$order->coupon_code.')' : '' }}</span>
                        <span class="font-semibold text-emerald-500">− {{ bn_money($order->discount_amount) }}</span>
                    </div>
                @endif
                <div class="flex justify-between text-ink2"><span>{{ tr('ডেলিভারি চার্জ', 'Delivery charge') }}</span><span class="font-semibold text-ink">{{ bn_money($order->delivery_fee) }}</span></div>
                <div class="flex justify-between pt-2 mt-1 border-t border-line/70 text-sm font-black text-ink">
                    <span>{{ tr('সর্বমোট', 'Total') }}</span>
                    <span class="text-aqua-500">{{ bn_money($order->grand_total) }}</span>
                </div>
            </div>
        </div>

        <div class="space-y-4">
            <div class="glass rounded-3xl p-5">
                <h2 class="text-sm font-extrabold text-ink mb-3 flex items-center gap-2"><i class="fa-solid fa-truck-fast text-aqua-500"></i> {{ tr('ডেলিভারি তথ্য', 'Delivery details') }}</h2>
                <div class="text-xs text-ink2 space-y-2 leading-relaxed">
                    <p><span class="text-ink3">{{ tr('নাম:', 'Name:') }}</span> {{ $order->customer_name }}</p>
                    <p><span class="text-ink3">{{ tr('মোবাইল:', 'Mobile:') }}</span> {{ bn_num($order->customer_phone) }}</p>
                    <p><span class="text-ink3">{{ tr('ঠিকানা:', 'Address:') }}</span> {{ $order->customer_address }}</p>
                    <p><span class="text-ink3">{{ tr('এলাকা:', 'Area:') }}</span> {{ $order->zone?->name_bn ?? '—' }}</p>
                    <p><span class="text-ink3">{{ tr('সময়:', 'Time:') }}</span> {{ $order->time_slot_label }}</p>
                </div>
            </div>

            <div class="glass rounded-3xl p-5">
                <h2 class="text-sm font-extrabold text-ink mb-3 flex items-center gap-2"><i class="fa-solid fa-wallet text-aqua-500"></i> {{ tr('পেমেন্ট', 'Payment') }}</h2>
                <div class="text-xs text-ink2 space-y-2">
                    <p><span class="text-ink3">{{ tr('মাধ্যম:', 'Method:') }}</span> {{ $order->paymentLabelBn() }}</p>
                    <p><span class="text-ink3">{{ tr('স্ট্যাটাস:', 'Status:') }}</span> <span class="badge border px-2 py-0.5 text-[10px] font-bold {{ payment_status_classes($order->payment_status) }}">{{ $order->paymentStatusLabelBn() }}</span></p>
                    @if ($order->payment_reference)
                        <p><span class="text-ink3">{{ tr('রেফারেন্স:', 'Reference:') }}</span> {{ $order->payment_reference }}</p>
                    @endif
                </div>
            </div>

            <div class="glass rounded-3xl p-5 text-center">
                <p class="text-[11px] text-ink3">{{ tr('অর্ডার নিয়ে সাহায্য দরকার?', 'Need help with your order?') }}</p>
                <a href="tel:{{ preg_replace('/[^0-9+]/', '', $settings['site_phone'] ?? '') }}" class="mt-2 inline-flex items-center gap-1.5 text-xs font-bold text-aqua-500 hover:underline">
                    <i class="fa-solid fa-phone-volume"></i> {{ tr('হটলাইন:', 'Hotline:') }} {{ bn_num($settings['site_phone'] ?? '') }}
                </a>
            </div>
        </div>
    </div>
@endsection
