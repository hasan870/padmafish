@extends('layouts.account')

@section('content')
    <div class="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        <div class="lg:col-span-2 glass rounded-3xl p-6">
            <div class="flex items-start gap-4">
                <span class="w-14 h-14 rounded-2xl bg-gradient-to-br from-aqua-500 to-sky-600 text-white flex items-center justify-center font-black text-xl shrink-0">
                    {{ mb_substr($user->name, 0, 1) }}
                </span>
                <div class="min-w-0">
                    <h1 class="text-xl font-black text-ink truncate">{{ tr('স্বাগতম', 'Welcome') }}, {{ $user->name }}</h1>
                    <p class="text-xs text-ink3 truncate">{{ $user->email }}</p>
                    <p class="text-[11px] text-ink3 mt-1">
                        {{ tr('আপনার প্রোফাইল থেকে অর্ডারের সর্বশেষ অবস্থা দেখতে পারবেন। অর্ডার করতে অ্যাকাউন্ট থাকা বাধ্যতামূলক নয়।', 'Track your latest order status from your profile. An account is not required to place an order.') }}
                    </p>
                </div>
            </div>

            <form method="POST" action="{{ route('account.profile.update') }}" class="mt-5 pt-5 border-t border-line/70 grid grid-cols-1 sm:grid-cols-2 gap-4">
                @csrf
                @method('PUT')

                <div>
                    <label class="form-label" for="name">{{ tr('নাম', 'Name') }}</label>
                    <input id="name" type="text" name="name" value="{{ old('name', $user->name) }}" class="form-input" required>
                    @error('name') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div>
                    <label class="form-label" for="email">{{ tr('ইমেইল', 'Email') }}</label>
                    <input id="email" type="email" name="email" value="{{ old('email', $user->email) }}" class="form-input" required>
                    @error('email') <p class="form-error">{{ $message }}</p> @enderror
                </div>

                <div class="sm:col-span-2">
                    <button type="submit" class="btn-primary">
                        <i class="fa-solid fa-floppy-disk"></i> {{ tr('প্রোফাইল আপডেট করুন', 'Update profile') }}
                    </button>
                </div>
            </form>
        </div>

        <div class="glass rounded-3xl p-6 flex flex-col gap-4">
            <h2 class="text-sm font-extrabold text-ink flex items-center gap-2"><i class="fa-solid fa-chart-simple text-aqua-500"></i> {{ tr('সংক্ষিপ্ত হিসাব', 'Overview') }}</h2>
            <div class="rounded-2xl border border-line bg-card2/50 px-4 py-3">
                <p class="text-[11px] text-ink3">{{ tr('মোট অর্ডার', 'Total orders') }}</p>
                <p class="text-2xl font-black text-ink">{{ bn_num($totalOrders) }}</p>
            </div>
            <div class="rounded-2xl border border-line bg-card2/50 px-4 py-3">
                <p class="text-[11px] text-ink3">{{ tr('চলমান অর্ডার', 'Active orders') }}</p>
                <p class="text-2xl font-black text-aqua-500">{{ bn_num($activeOrders) }}</p>
            </div>
            <a href="{{ route('home') }}" class="mt-auto w-full justify-center bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white font-bold py-2.5 rounded-xl text-xs shadow-lg shadow-aqua-600/25 transition-all text-center">
                <i class="fa-solid fa-fish mr-1.5"></i> {{ tr('আবার কেনাকাটা করুন', 'Shop again') }}
            </a>
        </div>
    </div>

    <div class="glass rounded-3xl p-5 sm:p-6">
        <div class="flex items-center justify-between gap-3 mb-4">
            <h2 class="text-base font-extrabold text-ink flex items-center gap-2"><i class="fa-solid fa-bag-shopping text-aqua-500"></i> {{ tr('আমার অর্ডার', 'My orders') }}</h2>
            <span class="text-[11px] text-ink3">{{ tr('মোট', 'Total') }} {{ bn_num($orders->total()) }}{{ tr('টি', '') }}</span>
        </div>

        @if ($orders->isEmpty())
            <div class="rounded-2xl border border-dashed border-line bg-card2/40 px-6 py-10 text-center">
                <span class="w-14 h-14 mx-auto rounded-2xl bg-card2 border border-line text-ink3 flex items-center justify-center text-2xl mb-3">
                    <i class="fa-solid fa-receipt"></i>
                </span>
                <p class="text-sm font-bold text-ink">{{ tr('এখনো কোনো অর্ডার নেই', 'No orders yet') }}</p>
                <p class="text-xs text-ink3 mt-1">{{ tr('লগইন অবস্থায় করা অর্ডারগুলো এখানে জমা হবে। চাইলে লগইন ছাড়াও অর্ডার করতে পারেন।', 'Orders placed while signed in will appear here. You can also order without signing in.') }}</p>
                <a href="{{ route('home') }}" class="btn-primary mt-4"><i class="fa-solid fa-fish"></i> {{ tr('মাছ দেখুন', 'Browse fish') }}</a>
            </div>
        @else
            <div class="space-y-3">
                @foreach ($orders as $order)
                    <a href="{{ route('account.orders.show', $order) }}" class="block rounded-2xl border border-line bg-card2/40 hover:bg-card2/70 transition-colors p-4">
                        <div class="flex flex-wrap items-center gap-3">
                            <div class="flex-1 min-w-[10rem]">
                                <p class="font-mono font-black text-ink text-sm">{{ $order->order_number }}</p>
                                <p class="text-[11px] text-ink3 mt-0.5">
                                    {{ bn_num($order->created_at->format('d/m/Y, h:i A')) }} · {{ bn_num($order->items_count) }} {{ tr('টি আইটেম', 'items') }}
                                </p>
                            </div>
                            <div class="text-right">
                                <p class="text-sm font-black text-ink">{{ bn_money($order->grand_total) }}</p>
                                <p class="text-[10px] text-ink3">{{ $order->paymentLabelBn() }} · {{ $order->paymentStatusLabelBn() }}</p>
                            </div>
                            <span class="badge border px-2.5 py-1 text-[11px] font-bold {{ order_status_classes($order->status) }}">{{ $order->statusLabelBn() }}</span>
                            <i class="fa-solid fa-chevron-right text-ink3 text-xs"></i>
                        </div>
                    </a>
                @endforeach
            </div>

            @if ($orders->hasPages())
                <div class="mt-4">{{ $orders->links() }}</div>
            @endif
        @endif
    </div>
@endsection
