@include('storefront.partials.head')
@php
    $layoutBgStyle = $settings['theme_bg_style'] ?? 'aurora';
    if ($layoutBgStyle === 'image' && empty($settings['theme_bg_image'])) {
        $layoutBgStyle = 'aurora';
    }
    $accountLogoMode = $settings['theme_logo_mode'] ?? 'image';
    $accountLogo = $accountLogoMode !== 'text' && ! empty($settings['theme_logo'])
        ? \Illuminate\Support\Facades\Storage::url($settings['theme_logo'])
        : null;
    $accountSiteName = $settings['site_name'] ?? 'মৎস্যমেলা';
@endphp
<body class="flex flex-col min-h-screen relative antialiased selection:bg-aqua-500 selection:text-white font-bangla bg-style-{{ $layoutBgStyle }}">

    @include('storefront.partials.aurora')

    <header class="sticky top-0 z-40 glass-header text-ink shadow-lg">
        <div class="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-3">
            <a href="{{ route('home') }}" class="flex items-center gap-2.5 min-w-0">
                @if ($accountLogoMode !== 'text')
                    <span class="w-10 h-10 rounded-2xl bg-gradient-to-tr from-aqua-600 via-sky-500 to-emerald-400 flex items-center justify-center text-white text-lg shadow-lg shadow-aqua-500/30 overflow-hidden shrink-0">
                        @if ($accountLogo)
                            <img src="{{ $accountLogo }}" alt="{{ $accountSiteName }}" class="w-full h-full object-contain p-1">
                        @else
                            <i class="fa-solid fa-fish-fins"></i>
                        @endif
                    </span>
                @endif
                <span class="min-w-0">
                    <span class="block font-black text-ink text-base leading-tight truncate">{{ $accountSiteName }}</span>
                    <span class="block text-[10px] text-ink3 truncate">{{ tr('কাস্টমার অ্যাকাউন্ট', 'Customer account') }}</span>
                </span>
            </a>

            <nav class="flex items-center gap-2 shrink-0">
                <a href="{{ route('home') }}" class="glass-chip px-3 py-2 rounded-xl text-xs font-bold text-ink2 hover:text-ink transition-colors hidden sm:inline-flex items-center gap-1.5">
                    <i class="fa-solid fa-house"></i> {{ tr('হোম', 'Home') }}
                </a>
                @auth('web')
                    <a href="{{ route('account.index') }}" class="glass-chip px-3 py-2 rounded-xl text-xs font-bold text-ink2 hover:text-ink transition-colors inline-flex items-center gap-1.5">
                        <i class="fa-solid fa-bag-shopping"></i> {{ tr('আমার অর্ডার', 'My orders') }}
                    </a>
                    <form method="POST" action="{{ route('account.logout') }}">
                        @csrf
                        <button type="submit" class="glass-chip px-3 py-2 rounded-xl text-xs font-bold text-rose-500 hover:text-rose-400 transition-colors inline-flex items-center gap-1.5">
                            <i class="fa-solid fa-right-from-bracket"></i> {{ tr('লগআউট', 'Log out') }}
                        </button>
                    </form>
                @else
                    <a href="{{ route('account.login') }}" class="glass-chip px-3 py-2 rounded-xl text-xs font-bold text-ink2 hover:text-ink transition-colors">{{ tr('লগইন', 'Login') }}</a>
                    <a href="{{ route('account.register') }}" class="bg-gradient-to-r from-aqua-600 to-sky-600 hover:from-aqua-500 hover:to-sky-500 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-lg shadow-aqua-600/25 transition-all">
                        {{ tr('রেজিস্ট্রেশন', 'Register') }}
                    </a>
                @endauth
            </nav>
        </div>
    </header>

    <main class="flex-1 w-full max-w-5xl mx-auto px-4 sm:px-6 py-8">
        @if (session('status'))
            <div class="mb-4 rounded-2xl border border-emerald-500/30 bg-emerald-500/10 px-4 py-3 text-sm font-semibold text-emerald-500">
                <i class="fa-solid fa-circle-check mr-1"></i> {{ session('status') }}
            </div>
        @endif

        @yield('content')
    </main>

    @include('storefront.partials.footer')
    @include('storefront.partials.scroll-top')
    @include('storefront.partials.toasts')

</body>
</html>
