@extends('layouts.app')

@section('content')
    @include('storefront.partials.hero')

    <!-- MAIN PRODUCT CATALOG CONTENT AREA -->
    <main id="product-section" class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 flex-1 w-full">

        @include('storefront.partials.catalog')
        @include('storefront.partials.banners')

        @if ($combo['enabled'])
            @include('storefront.partials.combo')
        @endif

        @include('storefront.partials.trust')
        @include('storefront.partials.testimonials')
        @include('storefront.partials.faq')

    </main>

    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full">
        @include('storefront.partials.about')
    </div>
@endsection
